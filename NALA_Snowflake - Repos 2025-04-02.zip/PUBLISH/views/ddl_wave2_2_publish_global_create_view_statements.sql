----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_COST

--***** THIS IS A CUSTOMIZED VIEW NEEDED TO INCLUDE FK's FOR TABULAR PBI MODELS (junk dimensions) ******

create or replace view global.V_DIM_COST as
	select a.DIM_COST_KEY::number(19, 0) as DIM_COST_KEY
		, a.DIM_COST_SNKEY::number(19, 0) as DIM_COST_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.INVENTORY_DIMENSION_ID::varchar(250) as INVENTORY_DIMENSION_ID
		, a.ITEM_ID::varchar(250) as ITEM_ID
		, a.PRICE_TYPE::varchar(250) as PRICE_TYPE
		, a.ACTIVATION_DATE::date as ACTIVATION_DATE
		, a.CREATED_DATETIME::timestamp_tz as CREATED_DATETIME
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.DIM_INVENTORY_SNKEY::number(19, 0) as DIM_INVENTORY_SNKEY
		, a.DIM_ITEM_SNKEY::number(19, 0) as DIM_ITEM_SNKEY
		, a.DIM_LEGAL_ENTITY_SNKEY::number(19, 0) as DIM_LEGAL_ENTITY_SNKEY
		, hash(a.ITEM_STATUS)::number(19, 0) as DIM_ITEM_STATUS_KEY						-- junk dimension
		, hash(a.ITEM_STATUS)::number(19, 0) as DIM_ITEM_STATUS_SNKEY					-- junk dimension
		, a.COSTING_TYPE::varchar(250) as COSTING_TYPE
		, a.COST_VERSION::varchar(250) as COST_VERSION
		, a.PRICE::number(25, 16) as PRICE
		, a.PRICE_CHARGES::number(25, 16) as PRICE_CHARGES
		, a.PRICE_QUANTITY::number(25, 16) as PRICE_QUANTITY
		, a.PRICE_UNIT::number(25, 16) as PRICE_UNIT
		, a.STANDARD_COST::number(25, 16) as STANDARD_COST
		, a.UNIT_OF_MEASURE_CODE::varchar(250) as UNIT_OF_MEASURE_CODE
		, a.UNIT_OF_MEASURE::varchar(250) as UNIT_OF_MEASURE
		, a.ITEM_STATUS::varchar(250) as ITEM_STATUS
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_COST a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_CUSTOMER_GROUP

create or replace view global.V_DIM_CUSTOMER_GROUP as
	select a.DIM_CUSTOMER_GROUP_KEY::number(19, 0) as DIM_CUSTOMER_GROUP_KEY
		, a.DIM_CUSTOMER_GROUP_SNKEY::number(19, 0) as DIM_CUSTOMER_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.CUSTOMER_GROUP_ID::varchar(250) as CUSTOMER_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.CUSTOMER_GROUP::varchar(250) as CUSTOMER_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_CUSTOMER_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_CUSTOMER_MARKUP_GROUP

create or replace view global.V_DIM_CUSTOMER_MARKUP_GROUP as
	select a.DIM_CUSTOMER_MARKUP_GROUP_KEY::number(19, 0) as DIM_CUSTOMER_MARKUP_GROUP_KEY
		, a.DIM_CUSTOMER_MARKUP_GROUP_SNKEY::number(19, 0) as DIM_CUSTOMER_MARKUP_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.CUSTOMER_MARKUP_GROUP_ID::varchar(250) as CUSTOMER_MARKUP_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.CUSTOMER_MARKUP_GROUP::varchar(250) as CUSTOMER_MARKUP_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_CUSTOMER_MARKUP_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_GLOBAL_TRADE_ITEM_NUMBER

create or replace view global.V_DIM_GLOBAL_TRADE_ITEM_NUMBER as
	select a.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY::number(19, 0) as DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
		, a.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY::number(19, 0) as DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.CONFIGURATION_ID::varchar(250) as CONFIGURATION_ID
		, a.ITEM_ID::varchar(250) as ITEM_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.GLOBAL_TRADE_ITEM_NUMBER::varchar(250) as GLOBAL_TRADE_ITEM_NUMBER
		, a.GLOBAL_TRADE_ITEM_NUMBER_SETUP::varchar(250) as GLOBAL_TRADE_ITEM_NUMBER_SETUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_GLOBAL_TRADE_ITEM_NUMBER a
	where HK_SOFT_DELETE_FLAG = FALSE
;