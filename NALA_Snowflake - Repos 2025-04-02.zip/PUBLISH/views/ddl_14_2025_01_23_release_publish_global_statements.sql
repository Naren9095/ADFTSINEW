--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- RLS_SALES

create or replace view global.V_RLS_SALES as
	select a.RLS_SALES_KEY::number(19, 0) as RLS_SALES_KEY
		, a.RLS_SALES_SNKEY::number(19, 0) as RLS_SALES_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.AD_USER_ID::varchar(250) as AD_USER_ID
		, a.REPORT_PARENT_ID::varchar(250) as REPORT_PARENT_ID
		, a.SALES_REP_ID::varchar(250) as SALES_REP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.DIVISION_ID::varchar(250) as DIVISION_ID
		, a.REGION_ID::varchar(250) as REGION_ID
		, a.CUSTOMER_NAME::varchar(250) as CUSTOMER_NAME
		, a.EMAIL_ADDRESS::varchar(250) as EMAIL_ADDRESS
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.RLS_SALES a
	where HK_SOFT_DELETE_FLAG = FALSE
;