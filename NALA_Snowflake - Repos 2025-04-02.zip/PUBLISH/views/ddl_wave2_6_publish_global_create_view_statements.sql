----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_FACT_COST_OF_GOODS_SOLD

create or replace view global.V_FACT_COST_OF_GOODS_SOLD as
	select a.FACT_COST_OF_GOODS_SOLD_KEY::number(19, 0) as FACT_COST_OF_GOODS_SOLD_KEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.ITEM_ID::varchar(250) as ITEM_ID
		, a.CONFIGURATION_ID::varchar(250) as CONFIGURATION_ID
		, a.ORACLE_ITEM::varchar(250) as ORACLE_ITEM
		, a.EFFECTIVE_DATE::date as EFFECTIVE_DATE
		, a.DIM_SOURCE_SYSTEM_KEY::number(19, 0) as DIM_SOURCE_SYSTEM_KEY
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.EFFECTIVE_DATE_DIM_DATE_KEY::number(19, 0) as EFFECTIVE_DATE_DIM_DATE_KEY
		, a.EFFECTIVE_DATE_DIM_DATE_SNKEY::number(19, 0) as EFFECTIVE_DATE_DIM_DATE_SNKEY
		, a.DIM_ITEM_KEY::number(19, 0) as DIM_ITEM_KEY
		, a.DIM_ITEM_SNKEY::number(19, 0) as DIM_ITEM_SNKEY
		, a.DIM_LEGAL_ENTITY_KEY::number(19, 0) as DIM_LEGAL_ENTITY_KEY
		, a.DIM_LEGAL_ENTITY_SNKEY::number(19, 0) as DIM_LEGAL_ENTITY_SNKEY
		, a.FIXED_OVERHEAD::number(25, 16) as FIXED_OVERHEAD
		, a.LABOR::number(25, 16) as LABOR
		, a.MATERIAL::number(25, 16) as MATERIAL
		, a.STANDARD_COST::number(25, 16) as STANDARD_COST
		, a.VARIABLE_OVERHEAD::number(25, 16) as VARIABLE_OVERHEAD
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.FACT_COST_OF_GOODS_SOLD a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_FACT_INVENTORY_SUMMARY

--***** THIS IS A CUSTOMIZED VIEW NEEDED TO INCLUDE FK's FOR TABULAR PBI MODELS (junk dimensions) ******

create or replace view global.V_FACT_INVENTORY_SUMMARY as
	select a.FACT_INVENTORY_SUMMARY_KEY::number(19, 0) as FACT_INVENTORY_SUMMARY_KEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.INVENTORY_ID::varchar(250) as INVENTORY_ID
		, a.ITEM_ID::varchar(250) as ITEM_ID
		, a.DIM_SOURCE_SYSTEM_KEY::number(19, 0) as DIM_SOURCE_SYSTEM_KEY
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.DIM_INVENTORY_KEY::number(19, 0) as DIM_INVENTORY_KEY
		, a.DIM_INVENTORY_SNKEY::number(19, 0) as DIM_INVENTORY_SNKEY
		, a.DIM_ITEM_KEY::number(19, 0) as DIM_ITEM_KEY
		, a.DIM_ITEM_SNKEY::number(19, 0) as DIM_ITEM_SNKEY
		, a.DIM_LEGAL_ENTITY_KEY::number(19, 0) as DIM_LEGAL_ENTITY_KEY
		, a.DIM_LEGAL_ENTITY_SNKEY::number(19, 0) as DIM_LEGAL_ENTITY_SNKEY
		, hash(a.ITEM_STATUS)::number(19, 0) as DIM_ITEM_STATUS_KEY						-- junk dimension
		, hash(a.ITEM_STATUS)::number(19, 0) as DIM_ITEM_STATUS_SNKEY					-- junk dimension
		, a.IS_CLOSED::varchar(250) as IS_CLOSED
		, a.NO_OPEN_QUANTITIES::varchar(250) as NO_OPEN_QUANTITIES
		, a.ITEM_STATUS::varchar(250) as ITEM_STATUS
		, a.ARRIVED::number(28, 16) as ARRIVED
		, a.AVAILABLE_ORDERED::number(28, 16) as AVAILABLE_ORDERED
		, a.AVAILABLE_PHYSICAL::number(28, 16) as AVAILABLE_PHYSICAL
		, a.DEDUCTED::number(28, 16) as DEDUCTED
		, a.ON_ORDER::number(28, 16) as ON_ORDER
		, a.ORDERED::number(28, 16) as ORDERED
		, a.PICKED::number(28, 16) as PICKED
		, a.POSTED::number(28, 16) as POSTED
		, a.RECEIVED::number(28, 16) as RECEIVED
		, a.REGISTERED::number(28, 16) as REGISTERED
		, a.RESERVED_ORDERED::number(28, 16) as RESERVED_ORDERED
		, a.RESERVED_PHYSICAL::number(28, 16) as RESERVED_PHYSICAL
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.FACT_INVENTORY_SUMMARY a
	where HK_SOFT_DELETE_FLAG = FALSE
;