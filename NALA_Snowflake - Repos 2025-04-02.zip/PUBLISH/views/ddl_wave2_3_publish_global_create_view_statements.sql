----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_INTRA_STAT_TRANSACTION_CODE

create or replace view global.V_DIM_INTRA_STAT_TRANSACTION_CODE as
	select a.DIM_INTRA_STAT_TRANSACTION_CODE_KEY::number(19, 0) as DIM_INTRA_STAT_TRANSACTION_CODE_KEY
		, a.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY::number(19, 0) as DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.INTRA_STAT_TRANSACTION_CODE::varchar(250) as INTRA_STAT_TRANSACTION_CODE
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.INTRA_STAT_TRANSACTION_CODE_DESCRIPTION::varchar(250) as INTRA_STAT_TRANSACTION_CODE_DESCRIPTION
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_INTRA_STAT_TRANSACTION_CODE a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_MERCHANDISING_EVENT

create or replace view global.V_DIM_MERCHANDISING_EVENT as
	select a.DIM_MERCHANDISING_EVENT_KEY::number(19, 0) as DIM_MERCHANDISING_EVENT_KEY
		, a.DIM_MERCHANDISING_EVENT_SNKEY::number(19, 0) as DIM_MERCHANDISING_EVENT_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.MERCHANDISING_EVENT_ID::varchar(250) as MERCHANDISING_EVENT_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.MERCHANDISING_EVENT::varchar(250) as MERCHANDISING_EVENT
		, a.CLAIM_PAYMENT_TYPE::varchar(250) as CLAIM_PAYMENT_TYPE
		, a.MERCHANDISING_EVENT_TYPE::varchar(250) as MERCHANDISING_EVENT_TYPE
		, a.MERCHANDISING_EVENT_CATEGORY_NAME::varchar(250) as MERCHANDISING_EVENT_CATEGORY_NAME
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_MERCHANDISING_EVENT a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_PAYMENT_MODE

create or replace view global.V_DIM_PAYMENT_MODE as
	select a.DIM_PAYMENT_MODE_KEY::number(19, 0) as DIM_PAYMENT_MODE_KEY
		, a.DIM_PAYMENT_MODE_SNKEY::number(19, 0) as DIM_PAYMENT_MODE_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.PAYMENT_MODE_ID::varchar(250) as PAYMENT_MODE_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.PAYMENT_MODE::varchar(250) as PAYMENT_MODE
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_PAYMENT_MODE a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_PAYMENT_TERMS

create or replace view global.V_DIM_PAYMENT_TERMS as
	select a.DIM_PAYMENT_TERMS_KEY::number(19, 0) as DIM_PAYMENT_TERMS_KEY
		, a.DIM_PAYMENT_TERMS_SNKEY::number(19, 0) as DIM_PAYMENT_TERMS_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.PAYMENT_TERMS_ID::varchar(250) as PAYMENT_TERMS_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.PAYMENT_TERMS::varchar(250) as PAYMENT_TERMS
		, a.NUMBER_OF_DAYS::number(19, 0) as NUMBER_OF_DAYS
		, a.NUMBER_OF_MONTHS::number(19, 0) as NUMBER_OF_MONTHS
		, a.NUMBER_OF_PAYMENT_INSTALLMENTS::number(19, 0) as NUMBER_OF_PAYMENT_INSTALLMENTS
		, a.PAYMENT_METHOD::varchar(250) as PAYMENT_METHOD
		, a.PAYMENT_SCHEDULE_ID::varchar(250) as PAYMENT_SCHEDULE_ID
		, a.PAYMENT_SCHEDULE::varchar(250) as PAYMENT_SCHEDULE
		, a.IS_PREPAID::varchar(250) as IS_PREPAID
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_PAYMENT_TERMS a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_REBATE

create or replace view global.V_DIM_REBATE as
	select a.DIM_REBATE_KEY::number(19, 0) as DIM_REBATE_KEY
		, a.DIM_REBATE_SNKEY::number(19, 0) as DIM_REBATE_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.REBATE_TYPE_ID::varchar(250) as REBATE_TYPE_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.REBATE_TYPE::varchar(250) as REBATE_TYPE
		, a.REBATE_PROGRAM_TYPE::varchar(250) as REBATE_PROGRAM_TYPE
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_REBATE a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_RETURN_DISPOSITION

create or replace view global.V_DIM_RETURN_DISPOSITION as
	select a.DIM_RETURN_DISPOSITION_KEY::number(19, 0) as DIM_RETURN_DISPOSITION_KEY
		, a.DIM_RETURN_DISPOSITION_SNKEY::number(19, 0) as DIM_RETURN_DISPOSITION_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.RETURN_DISPOSITION_ID::varchar(250) as RETURN_DISPOSITION_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.RETURN_DISPOSITION::varchar(250) as RETURN_DISPOSITION
		, a.DISPOSITION_ACTION::varchar(250) as DISPOSITION_ACTION
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_RETURN_DISPOSITION a
	where HK_SOFT_DELETE_FLAG = FALSE
;