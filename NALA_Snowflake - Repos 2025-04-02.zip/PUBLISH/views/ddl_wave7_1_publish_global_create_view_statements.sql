----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DIM_BUDGET_MODEL

create or replace view global.V_DIM_BUDGET_MODEL as
	select a.DIM_BUDGET_MODEL_KEY::number(19, 0) as DIM_BUDGET_MODEL_KEY
		, a.DIM_BUDGET_MODEL_SNKEY::number(19, 0) as DIM_BUDGET_MODEL_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.BUDGET_MODEL_ID::varchar(250) as BUDGET_MODEL_ID
		, a.BUDGET_SUB_MODEL_ID::varchar(250) as BUDGET_SUB_MODEL_ID
		, a.BUDGET_MODEL_TYPE::varchar(250) as BUDGET_MODEL_TYPE
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.BUDGET_MODEL::varchar(250) as BUDGET_MODEL
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_BUDGET_MODEL a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DIM_TAX

create or replace view global.V_DIM_TAX as
	select a.DIM_TAX_KEY::number(19, 0) as DIM_TAX_KEY
		, a.DIM_TAX_SNKEY::number(19, 0) as DIM_TAX_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.TAX_ID::varchar(250) as TAX_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.TAX_NAME::varchar(250) as TAX_NAME
		, a.TAX_PERIOD::varchar(250) as TAX_PERIOD
		, a.TAX_ACCOUNT_GROUP::varchar(250) as TAX_ACCOUNT_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_TAX a
	where HK_SOFT_DELETE_FLAG = FALSE
;