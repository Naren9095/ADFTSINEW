----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_TAX_GROUP

create or replace view global.V_DIM_TAX_GROUP as
	select a.DIM_TAX_GROUP_KEY::number(19, 0) as DIM_TAX_GROUP_KEY
		, a.DIM_TAX_GROUP_SNKEY::number(19, 0) as DIM_TAX_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.TAX_GROUP_ID::varchar(250) as TAX_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.TAX_GROUP::varchar(250) as TAX_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_TAX_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_TAX_ITEM_GROUP

create or replace view global.V_DIM_TAX_ITEM_GROUP as
	select a.DIM_TAX_ITEM_GROUP_KEY::number(19, 0) as DIM_TAX_ITEM_GROUP_KEY
		, a.DIM_TAX_ITEM_GROUP_SNKEY::number(19, 0) as DIM_TAX_ITEM_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.TAX_ITEM_GROUP_ID::varchar(250) as TAX_ITEM_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.TAX_ITEM_GROUP::varchar(250) as TAX_ITEM_GROUP
		, a.EU_SALES_LIST_TYPE::varchar(250) as EU_SALES_LIST_TYPE
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_TAX_ITEM_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_TRADE_PROMOTION

create or replace view global.V_DIM_TRADE_PROMOTION as
	select a.DIM_TRADE_PROMOTION_KEY::number(19, 0) as DIM_TRADE_PROMOTION_KEY
		, a.DIM_TRADE_PROMOTION_SNKEY::number(19, 0) as DIM_TRADE_PROMOTION_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.TRADE_PROMOTION_ID::varchar(250) as TRADE_PROMOTION_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.TRADE_PROMOTION::varchar(250) as TRADE_PROMOTION
		, a.HAS_BEEN_APPROVED_FOR_ACTIVITY::varchar(250) as HAS_BEEN_APPROVED_FOR_ACTIVITY
		, a.CURRENCY_CODE::varchar(250) as CURRENCY_CODE
		, a.CURRENCY::varchar(250) as CURRENCY
		, a.PROMOTION_OWNER::varchar(250) as PROMOTION_OWNER
		, a.ORDERS_END_DATE::date as ORDERS_END_DATE
		, a.ORDERS_START_DATE::date as ORDERS_START_DATE
		, a.PROMOTION_STATUS_NAME::varchar(250) as PROMOTION_STATUS_NAME
		, a.PROMOTION_DISCOUNT_TYPE::varchar(250) as PROMOTION_DISCOUNT_TYPE
		, a.UNIT_OF_MEASURE_ID::varchar(250) as UNIT_OF_MEASURE_ID
		, a.UNIT_OF_MEASURE::varchar(250) as UNIT_OF_MEASURE
		, a.DEAL_ID::varchar(250) as DEAL_ID
		, a.DEAL_TYPE::number(19, 0) as DEAL_TYPE
		, a.DEAL_TYPE_NAME::varchar(250) as DEAL_TYPE_NAME
		, a.CATALOG_STATUS::varchar(250) as CATALOG_STATUS
		, a.DEAL_DESCRIPTION::varchar(250) as DEAL_DESCRIPTION
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_TRADE_PROMOTION a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_TRAILERS

create or replace view global.V_DIM_TRAILERS as
	select a.DIM_TRAILERS_KEY::number(19, 0) as DIM_TRAILERS_KEY
		, a.DIM_TRAILERS_SNKEY::number(19, 0) as DIM_TRAILERS_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.DATA_AREA_ID::varchar(250) as DATA_AREA_ID
		, a.TRAILER_NO::varchar(250) as TRAILER_NO
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.CARRIER_ID::varchar(250) as CARRIER_ID
		, a.CUBIC_VOLUME::varchar(250) as CUBIC_VOLUME
		, a.TRAILER_CUBIC_VOLUME::varchar(250) as TRAILER_CUBIC_VOLUME
		, a.TRAILER_LENGTH::number(19, 0) as TRAILER_LENGTH
		, a.CUBIC_VOLUME_INT::number(19, 0) as CUBIC_VOLUME_INT
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_TRAILERS a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_UNIT_OF_MEASURE

create or replace view global.V_DIM_UNIT_OF_MEASURE as
	select a.DIM_UNIT_OF_MEASURE_KEY::number(19, 0) as DIM_UNIT_OF_MEASURE_KEY
		, a.DIM_UNIT_OF_MEASURE_SNKEY::number(19, 0) as DIM_UNIT_OF_MEASURE_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.UNIT_OF_MEASURE_CODE::varchar(250) as UNIT_OF_MEASURE_CODE
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.UNIT_OF_MEASURE::varchar(250) as UNIT_OF_MEASURE
		, a.SYSTEM_OF_UNITS::varchar(250) as SYSTEM_OF_UNITS
		, a.UNIT_OF_MEASURE_CLASS::varchar(250) as UNIT_OF_MEASURE_CLASS
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_UNIT_OF_MEASURE a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_USER_INFO

create or replace view global.V_DIM_USER_INFO as
	select a.DIM_USER_INFO_KEY::number(19, 0) as DIM_USER_INFO_KEY
		, a.DIM_USER_INFO_SNKEY::number(19, 0) as DIM_USER_INFO_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.USER_ID::varchar(250) as USER_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.USER_NAME::varchar(250) as USER_NAME
		, a.USER_IS_ENABLED::varchar(250) as USER_IS_ENABLED
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_USER_INFO a
	where HK_SOFT_DELETE_FLAG = FALSE
;