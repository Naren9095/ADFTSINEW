----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SALES_GROUP

create or replace view global.V_DIM_SALES_GROUP as
	select a.DIM_SALES_GROUP_KEY::number(19, 0) as DIM_SALES_GROUP_KEY
		, a.DIM_SALES_GROUP_SNKEY::number(19, 0) as DIM_SALES_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.SALES_GROUP_ID::varchar(250) as SALES_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.SALES_GROUP::varchar(250) as SALES_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SALES_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SALES_LINE_DISCOUNT_GROUP

create or replace view global.V_DIM_SALES_LINE_DISCOUNT_GROUP as
	select a.DIM_SALES_LINE_DISCOUNT_GROUP_KEY::number(19, 0) as DIM_SALES_LINE_DISCOUNT_GROUP_KEY
		, a.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY::number(19, 0) as DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.SALES_LINE_DISCOUNT_GROUP_ID::varchar(250) as SALES_LINE_DISCOUNT_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.SALES_LINE_DISCOUNT_GROUP::varchar(250) as SALES_LINE_DISCOUNT_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SALES_LINE_DISCOUNT_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SALES_POOL

create or replace view global.V_DIM_SALES_POOL as
	select a.DIM_SALES_POOL_KEY::number(19, 0) as DIM_SALES_POOL_KEY
		, a.DIM_SALES_POOL_SNKEY::number(19, 0) as DIM_SALES_POOL_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.SALES_POOL_ID::varchar(250) as SALES_POOL_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.SALES_POOL::varchar(250) as SALES_POOL
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SALES_POOL a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SALES_PRICE_GROUP

create or replace view global.V_DIM_SALES_PRICE_GROUP as
	select a.DIM_SALES_PRICE_GROUP_KEY::number(19, 0) as DIM_SALES_PRICE_GROUP_KEY
		, a.DIM_SALES_PRICE_GROUP_SNKEY::number(19, 0) as DIM_SALES_PRICE_GROUP_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.SALES_PRICE_GROUP_ID::varchar(250) as SALES_PRICE_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.SALES_PRICE_GROUP::varchar(250) as SALES_PRICE_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SALES_PRICE_GROUP a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SALES_PROCUREMENT_CATEGORY

create or replace view global.V_DIM_SALES_PROCUREMENT_CATEGORY as
	select a.DIM_SALES_PROCUREMENT_CATEGORY_KEY::number(19, 0) as DIM_SALES_PROCUREMENT_CATEGORY_KEY
		, a.DIM_SALES_PROCUREMENT_CATEGORY_SNKEY::number(19, 0) as DIM_SALES_PROCUREMENT_CATEGORY_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.RECORD_ID::number(19, 0) as RECORD_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.PROCUREMENT_CATEGORY::varchar(250) as PROCUREMENT_CATEGORY
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SALES_PROCUREMENT_CATEGORY a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_SHIPPING_CARRIER

create or replace view global.V_DIM_SHIPPING_CARRIER as
	select a.DIM_SHIPPING_CARRIER_KEY::number(19, 0) as DIM_SHIPPING_CARRIER_KEY
		, a.DIM_SHIPPING_CARRIER_SNKEY::number(19, 0) as DIM_SHIPPING_CARRIER_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.SHIPPING_CARRIER_ID::varchar(250) as SHIPPING_CARRIER_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.SHIPPING_CARRIER_NAME::varchar(250) as SHIPPING_CARRIER_NAME
		, a.SHIPPING_CARRIER_DESCRIPTION::varchar(250) as SHIPPING_CARRIER_DESCRIPTION
		, a.SHIPPING_CARRIER_ACCOUNT_ID::varchar(250) as SHIPPING_CARRIER_ACCOUNT_ID
		, a.SHIPPING_CARRIER_ACCOUNT_NUMBER::varchar(250) as SHIPPING_CARRIER_ACCOUNT_NUMBER
		, a.SHIPPING_CARRIER_CURRENCY_CODE::varchar(250) as SHIPPING_CARRIER_CURRENCY_CODE
		, a.SHIPPING_CARRIER_CURRENCY_NAME::varchar(250) as SHIPPING_CARRIER_CURRENCY_NAME
		, a.ANCILLARY_CHARGE_ID::varchar(250) as ANCILLARY_CHARGE_ID
		, a.ANCILLARY_CHARGE::varchar(250) as ANCILLARY_CHARGE
		, a.CORE_CHARGE_ID::varchar(250) as CORE_CHARGE_ID
		, a.CORE_CHARGE::varchar(250) as CORE_CHARGE
		, a.FUEL_SURCHARGE_ID::varchar(250) as FUEL_SURCHARGE_ID
		, a.FUEL_SURCHARGE::varchar(250) as FUEL_SURCHARGE
		, a.HANDLING_SURCHARGE_ID::varchar(250) as HANDLING_SURCHARGE_ID
		, a.HANDLING_SURCHARGE::varchar(250) as HANDLING_SURCHARGE
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_SHIPPING_CARRIER a
	where HK_SOFT_DELETE_FLAG = FALSE
;