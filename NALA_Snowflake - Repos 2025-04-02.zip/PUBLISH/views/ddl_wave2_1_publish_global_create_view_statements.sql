----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_ARKIEVA_CUSTOMER

create or replace view global.V_DIM_ARKIEVA_CUSTOMER as
	select a.DIM_ARKIEVA_CUSTOMER_KEY::number(19, 0) as DIM_ARKIEVA_CUSTOMER_KEY
		, a.DIM_ARKIEVA_CUSTOMER_SNKEY::number(19, 0) as DIM_ARKIEVA_CUSTOMER_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.ARKIEVA_CUSTOMER_ID::varchar(250) as ARKIEVA_CUSTOMER_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.ARKIEVA_CUSTOMER_NAME::varchar(250) as ARKIEVA_CUSTOMER_NAME
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_EFFECTIVE_START_TIMESTAMP::timestamp_tz as HK_EFFECTIVE_START_TIMESTAMP
		, a.HK_EFFECTIVE_END_TIMESTAMP::timestamp_tz as HK_EFFECTIVE_END_TIMESTAMP
		, a.HK_CURRENT_FLAG::boolean as HK_CURRENT_FLAG
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_ARKIEVA_CUSTOMER a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_ARKIEVA_SUB_CHANNEL

create or replace view global.V_DIM_ARKIEVA_SUB_CHANNEL as
	select a.DIM_ARKIEVA_SUB_CHANNEL_KEY::number(19, 0) as DIM_ARKIEVA_SUB_CHANNEL_KEY
		, a.DIM_ARKIEVA_SUB_CHANNEL_SNKEY::number(19, 0) as DIM_ARKIEVA_SUB_CHANNEL_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.ARKIEVA_SUB_CHANNEL_ID::varchar(250) as ARKIEVA_SUB_CHANNEL_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.ARKIEVA_SUB_CHANNEL::varchar(250) as ARKIEVA_SUB_CHANNEL
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_EFFECTIVE_START_TIMESTAMP::timestamp_tz as HK_EFFECTIVE_START_TIMESTAMP
		, a.HK_EFFECTIVE_END_TIMESTAMP::timestamp_tz as HK_EFFECTIVE_END_TIMESTAMP
		, a.HK_CURRENT_FLAG::boolean as HK_CURRENT_FLAG
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_ARKIEVA_SUB_CHANNEL a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_CAMPAIGN

-- **** modified the CAMPAIGN_DESCRIPTION due to the length of data in that column

create or replace view global.V_DIM_CAMPAIGN as
	select a.DIM_CAMPAIGN_KEY::number(19, 0) as DIM_CAMPAIGN_KEY
		, a.DIM_CAMPAIGN_SNKEY::number(19, 0) as DIM_CAMPAIGN_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.CAMPAIGN_ID::varchar(250) as CAMPAIGN_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.START_DATE::date as START_DATE
		, a.END_DATE::date as END_DATE
		, a.FOLLOW_UP_DATE::date as FOLLOW_UP_DATE
		, a.CAMPAIGN_NAME::varchar(250) as CAMPAIGN_NAME
		, a.CAMPAIGN_OWNER::varchar(250) as CAMPAIGN_OWNER
		, a.CAMPAIGN_DESCRIPTION::varchar(1500) as CAMPAIGN_DESCRIPTION		-- modified
		, a.CAMPAIGN_STATUS::varchar(250) as CAMPAIGN_STATUS
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_CAMPAIGN a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_CORPORATE_ALLOCATION_MAPPING

create or replace view global.V_DIM_CORPORATE_ALLOCATION_MAPPING as
	select a.DIM_CORPORATE_ALLOCATION_MAPPING_KEY::number(19, 0) as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
		, a.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY::number(19, 0) as DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.MAIN_ACCOUNT::varchar(250) as MAIN_ACCOUNT
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.IBR_LINE::varchar(250) as IBR_LINE
		, a.TAM_CODE::varchar(250) as TAM_CODE
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_CORPORATE_ALLOCATION_MAPPING a
	where HK_SOFT_DELETE_FLAG = FALSE
;