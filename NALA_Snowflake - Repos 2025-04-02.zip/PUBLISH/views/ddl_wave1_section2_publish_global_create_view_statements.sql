----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_LINE_RETURN_REASON

create or replace view global.V_DIM_LINE_RETURN_REASON as
	select a.DIM_LINE_RETURN_REASON_KEY::number(19, 0) as DIM_LINE_RETURN_REASON_KEY
		, a.DIM_LINE_RETURN_REASON_SNKEY::number(19, 0) as DIM_LINE_RETURN_REASON_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.LINE_RETURN_REASON_ID::varchar(250) as LINE_RETURN_REASON_ID
		, a.LINE_RETURN_REASON_GROUP_ID::varchar(250) as LINE_RETURN_REASON_GROUP_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.LINE_RETURN_REASON::varchar(250) as LINE_RETURN_REASON
		, a.LINE_RETURN_REASON_GROUP::varchar(250) as LINE_RETURN_REASON_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_LINE_RETURN_REASON a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_LOCATION

create or replace view global.V_DIM_LOCATION as
	select a.DIM_LOCATION_KEY::number(19, 0) as DIM_LOCATION_KEY
		, a.DIM_LOCATION_SNKEY::number(19, 0) as DIM_LOCATION_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.RECORD_ID::number(19, 0) as RECORD_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.CITY::varchar(250) as CITY
		, a.COUNTY::varchar(250) as COUNTY
		, a.COUNTRY::varchar(250) as COUNTRY
		, a.LATITUDE::number(25, 16) as LATITUDE
		, a.LOCATION_ID::varchar(250) as LOCATION_ID
		, a.LOCATION_NAME::varchar(250) as LOCATION_NAME
		, a.LONGITUDE::number(25, 16) as LONGITUDE
		, a.POSTAL_CODE::varchar(250) as POSTAL_CODE
		, a.STATE::varchar(250) as STATE
		, a.STREET::varchar(250) as STREET
		, a.TIME_ZONE::varchar(250) as TIME_ZONE
		, a.ADDRESS_IS_PRIVATE::varchar(250) as ADDRESS_IS_PRIVATE
		, a.FIPS_CODE::varchar(250) as FIPS_CODE
		, a.GEO_DIVISION_CODE::number(19, 0) as GEO_DIVISION_CODE
		, a.GEO_DIVISION::varchar(250) as GEO_DIVISION
		, a.GEO_REGION_CODE::number(19, 0) as GEO_REGION_CODE
		, a.GEO_REGION::varchar(250) as GEO_REGION
		, a.STRATEGIC_MARKETING_AREA_CODE::number(19, 0) as STRATEGIC_MARKETING_AREA_CODE
		, a.STRATEGIC_MARKETING_AREA::varchar(250) as STRATEGIC_MARKETING_AREA
		, a.BUSINESS_TRADE_AREA_CODE::number(19, 0) as BUSINESS_TRADE_AREA_CODE
		, a.BUSINESS_TRADE_AREA::varchar(250) as BUSINESS_TRADE_AREA
		, a.GEO_COUNTY::varchar(250) as GEO_COUNTY
		, a.ISPA_REGION_ID::number(19, 0) as ISPA_REGION_ID
		, a.ISPA_REGION::varchar(250) as ISPA_REGION
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_LOCATION a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_MAIN_ACCOUNT

create or replace view global.V_DIM_MAIN_ACCOUNT as
	select a.DIM_MAIN_ACCOUNT_KEY::number(19, 0) as DIM_MAIN_ACCOUNT_KEY
		, a.DIM_MAIN_ACCOUNT_SNKEY::number(19, 0) as DIM_MAIN_ACCOUNT_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.RECORD_ID::number(19, 0) as RECORD_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.MAIN_ACCOUNT_ID::varchar(250) as MAIN_ACCOUNT_ID
		, a.MAIN_ACCOUNT::varchar(250) as MAIN_ACCOUNT
		, a.ACCOUNT_CATEGORY_ID::varchar(250) as ACCOUNT_CATEGORY_ID
		, a.ACCOUNT_CATEGORY::varchar(250) as ACCOUNT_CATEGORY
		, a.LEDGER_CHART_OF_ACCOUNTS_ID::varchar(250) as LEDGER_CHART_OF_ACCOUNTS_ID
		, a.LEDGER_CHART_OF_ACCOUNTS::varchar(250) as LEDGER_CHART_OF_ACCOUNTS
		, a.ACCOUNT_TYPE::varchar(250) as ACCOUNT_TYPE
		, a.POSTING_TYPE::varchar(250) as POSTING_TYPE
		, a.IS_MONETARY_ACCOUNT::varchar(250) as IS_MONETARY_ACCOUNT
		, a.LEVEL_1::varchar(250) as LEVEL_1
		, a.LEVEL_2::varchar(250) as LEVEL_2
		, a.LEVEL_3::varchar(250) as LEVEL_3
		, a.LEVEL_4::varchar(250) as LEVEL_4
		, a.LEVEL_5::varchar(250) as LEVEL_5
		, a.LEVEL_6::varchar(250) as LEVEL_6
		, a.HFM_ACCOUNT_ID::varchar(250) as HFM_ACCOUNT_ID
		, a.HFM_ACCOUNT::varchar(250) as HFM_ACCOUNT
		, a.REPORTING_CATEGORY::varchar(250) as REPORTING_CATEGORY
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_MAIN_ACCOUNT a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- V_DIM_RETURN_REASON

create or replace view global.V_DIM_RETURN_REASON as
	select a.DIM_RETURN_REASON_KEY::number(19, 0) as DIM_RETURN_REASON_KEY
		, a.DIM_RETURN_REASON_SNKEY::number(19, 0) as DIM_RETURN_REASON_SNKEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.RETURN_REASON_ID::varchar(250) as RETURN_REASON_ID
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.RETURN_REASON::varchar(250) as RETURN_REASON
		, a.RETURN_REASON_GROUP_ID::varchar(250) as RETURN_REASON_GROUP_ID
		, a.RETURN_REASON_GROUP::varchar(250) as RETURN_REASON_GROUP
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.DIM_RETURN_REASON a
	where HK_SOFT_DELETE_FLAG = FALSE
;