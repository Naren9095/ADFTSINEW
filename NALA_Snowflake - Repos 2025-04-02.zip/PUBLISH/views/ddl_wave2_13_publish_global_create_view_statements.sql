----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- BRIDGE_INVOICE_REBATE

create or replace view global.V_BRIDGE_INVOICE_REBATE as
	select a.INVOICE_KEY::number(19, 0) as INVOICE_KEY
		, a.DIM_MERCHANDISING_EVENT_KEY::number(19, 0) as DIM_MERCHANDISING_EVENT_KEY
		, a.DIM_MERCHANDISING_EVENT_SNKEY::number(19, 0) as DIM_MERCHANDISING_EVENT_SNKEY
		, a.DIM_TRADE_PROMOTION_KEY::number(19, 0) as DIM_TRADE_PROMOTION_KEY
		, a.DIM_TRADE_PROMOTION_SNKEY::number(19, 0) as DIM_TRADE_PROMOTION_SNKEY
		, a.DIM_REBATE_KEY::number(19, 0) as DIM_REBATE_KEY
		, a.DIM_REBATE_SNKEY::number(19, 0) as DIM_REBATE_SNKEY
	from $ENV$_CURATE.GLOBAL.FACT_REBATE_TRANSACTIONS a
	full outer join (select INVOICE_KEY::number(19, 0) as INVOICE_KEY
						, -2::number(19, 0) as DIM_MERCHANDISING_EVENT_KEY
						, -2::number(19, 0) as DIM_MERCHANDISING_EVENT_SNKEY
						, -2::number(19, 0) as DIM_TRADE_PROMOTION_KEY
						, -2::number(19, 0) as DIM_TRADE_PROMOTION_SNKEY
						, -2::number(19, 0) as DIM_REBATE_KEY
						, -2::number(19, 0) as DIM_REBATE_SNKEY
					from $ENV$_CURATE.GLOBAL.FACT_SALES_INVOICES
					where HK_SOFT_DELETE_FLAG = FALSE) b on
		a.INVOICE_KEY = b.INVOICE_KEY
	where a.HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- GENERAL_LEDGER_NON_INVOICE

create or replace view global.V_GENERAL_LEDGER_NON_INVOICE as
	select unionquery.dim_corporate_allocation_mapping_key
		, unionquery.dim_customer_key
		, unionquery.accounting_date
		, unionquery.dim_legal_entity_key
		, unionquery.accounting_currency_amount
		, unionquery.source_name
	from (
		--740 history from bo
		select f1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.amount_debit - f1.amount_credit) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_LEDGER_JOURNAL_TRANSACTIONS f1
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.dim_customer_key = dc1.dim_customer_key
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			dd1.year_number > '2015' and
			f1.transaction_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '740'
		and f1.posted = 1
		and f1.journal_name = 'ORACLE'
		and f1.dim_corporate_allocation_mapping_key not in (-1, -2)
		group by 1, 2, 3, 4, 5, 6
	
		/****************************************************** FACT_GENERAL_LEDGER not available until wave 7 **********************************************
		union
	
		--740 ax data
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, f1.accounting_date as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.accounting_currency_amount) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71', '70') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			dd1.year_number > '2015' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '740'
		and f1.accounting_date >= '2021-01-01'
		group by 1, 2, 3, 4, 5, 6
		*/
		
	
		---- need 415 components 
		/* 415 stuff to do */
	
		-- original manbase  
	
		union all
	
		select hash('AXNALA'::varchar, '~', f1.LEGALENTITY, '~', f1.MAINACCOUNT) as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, nvl(dc1.DIM_CUSTOMER_KEY, -1) as DIM_CUSTOMER_KEY
			, f1.HISTDATE as ACCOUNTING_DATE
			, hash('AXNALA'::varchar, '~', f1.LEGALENTITY) as DIM_LEGAL_ENTITY_KEY
			, f1.DATASOURCE as SOURCE_NAME
			, f1.LEGALENTITY as LEGAL_ENTITY
			, f1.AMOUNT as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_RAW.global.HISTORICNONINVOICE f1
		left join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.HK_CURRENT_FLAG = TRUE and
			hash('AXNALA'::varchar, '~', f1.LEGALENTITY, '~', f1.CUSTOMERACCOUNT) = dc1.DIM_CUSTOMER_SNKEY

	
		/****************************************************** FACT_GENERAL_LEDGER not available until wave 7 **********************************************
		union all
	
		-- load 415 ax non-in data from gl, except manual entries
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(case when dcam1.ibr_line = 'Floor Sample Discount' and left(f1.voucher, 1) in ('I', 'C') then 0.00
					else f1.accounting_currency_amount
				end) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			'FY' || right(dd1.smmc_year, 2) >= 'FY16' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '415'
		and f1.voucher not like 'ManAcc%'
		and f1.voucher not like 'InvAcc%'
		and f1.voucher not like 'ChainAcc%'
		and f1.voucher not like 'RebGLpay%'
		and (f1.journal_name not like 'MB%' or f1.journal_name = '')
		group by 1, 2, 3, 4, 5, 6
		*/
	
		/****************************************************** FACT_GENERAL_LEDGER not available until wave 7 **********************************************
		union all
	
		-- load ax manual accurals that are entered in ax and have a description entered
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.accounting_currency_amount) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			'FY' || right(dd1.smmc_year, 2) >= 'FY16' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '415'
		and f1.voucher like 'ManAcc%'
		and f1.journal_text = 'yes'
		group by 1, 2, 3, 4, 5, 6
		*/
		) unionquery
;
