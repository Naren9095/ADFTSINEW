create or replace view GLOBAL.V_RETURN_DETAILS ("FiscalQuarter"
,"FiscalYear"
,"FiscalMonth"
,"ErrorFlagDesc"
,"Sales Type"
,"ReturnReasonCode"
,"ReturnReason"
,"ReturnReasonGroupCode"
,"ReturnReasonGroup"
,"RANumber"
,"RALine"
,"ShipTo"
,"CustomerSegment"
,"CustomerSubSegment"
,"ShipToName"
,"Channel"
,"ChannelDesc"
,"Family"
,"FamilyDesc"
,"ProductGroup"
,"ProductGroupDesc"
,"ProductGroup1st2"
,"SalesQty"
,"ReturnAmt"
,"ReturnDate"
,"CreditDate"
,"ProductionDate"
,"DaysOutstandingCnt"
,"Legal Entity"
,"Cost"
,"Classification"
,"ItemID"
,"InvoiceID"
)
AS
WITH CTE_RAW AS
(Select 
DimCustomer.Customer_Account 
     , DimCustomer.Segment_ID 
     , DimCustomer.Sub_segment_ID
     , DimCustomer.Customer_Name 
     , DimDefaultDimension.Sales_Channel_ID
     , ifnull((select max(dd1.SALES_CHANNEL) from DEV_CURATE.GLOBAL.DIM_DEFAULT_DIMENSION dd1 where DimDefaultDimension.SALES_CHANNEL_ID = dd1.SALES_CHANNEL_ID and dd1.SOURCE_NAME = 'D365' and dd1.HK_SOFT_DELETE_FLAG = FALSE), DimDefaultDimension.SALES_CHANNEL) as SALES_CHANNEL
     , DimDefaultDimension.FAMILY_ID                  AS FAMILY
     , ifnull((select max(dd1.FAMILY) from DEV_CURATE.GLOBAL.DIM_DEFAULT_DIMENSION dd1 where DimDefaultDimension.FAMILY_ID = dd1.FAMILY_ID and dd1.SOURCE_NAME = 'D365' and     dd1.HK_SOFT_DELETE_FLAG = FALSE), DimDefaultDimension.FAMILY)                 AS FAMILY_DESC
     , DimItem.PRODUCT_GROUP_CODE_ID                   AS PRODUCT_GROUP
     , DimItem.PRODUCT_GROUP_CODE                      AS PRODUCT_GROUP_DESC
     , LEFT(DimItem.PRODUCT_GROUP_CODE_ID, 2)          AS PRODUCT_GROUP_2
     , DimItem.ITEM_ID 
     , DimLineReturnReason.Line_Return_Reason_ID 
     , DimLineReturnReason.Line_Return_Reason 
     , DimLineReturnReason.LINE_RETURN_REASON_GROUP_ID As RETURN_REASON_GROUP_CODE
     , DimLineReturnReason.LINE_RETURN_REASON_GROUP    As LINE_RETURN_REASON_GROUP
     , DimSalesOrder.RMA_Number 
	 -- , coalesce(FactSalesDeliveries.SALES_TYPE, FactSalesInvoices.SALES_TYPE, FactSalesOrders.SALES_TYPE) As "SALESTYPE"
     , coalesce(FactSalesInvoices.SALES_TYPE, FactSalesOrders.SALES_TYPE) As SALES_TYPE
     , FactSalesInvoices.INVOICE_DATE                  As CREDIT_DATE
     , FactSalesInvoices.INVOICE_ID 
     , FactSalesOrders.Line_Number                     AS RA_LINE
     , FactSalesOrders.SALES_QUANTITY 
     , FactSalesOrders.SALES_AMOUNT                    AS RETURN_AMOUNT
     , FactSalesOrders.SALES_LINE_CREATED_DATE         AS RETURN_DATE
     , CASE
           WHEN FactSalesOrders.SALES_LINE_CREATED_DATE < FactSalesOrders.PRODUCED_DATE
               THEN 'Creation Date Older Than Production'
           WHEN FactSalesOrders.PRODUCED_DATE = '1950-01-01'
               THEN 'No Production Date'
           WHEN YEAR(FactSalesOrders.PRODUCED_DATE) < '2000'
               THEN 'Production Date in 20th Centrury'
           ELSE 'No Error'
       END                                             AS ERROR_FLAG_DESC
     , Case
           When FactSalesOrders.Produced_Date = '1950-01-01'
                And DimLineReturnReason.LINE_RETURN_REASON = 'Service Level Returns - Return to Stock'
               Then DateAdd(   dd
                             , -90
                             , FactSalesOrders.SALES_LINE_CREATED_DATE
                           )
           When FactSalesOrders.Produced_Date = '1950-01-01'
                And DimLineReturnReason.LINE_RETURN_REASON_GROUP In
              (
                  'Comfort Returns'
                , 'Comfort Exchanges'
                , 'Accommodation/Courtesy Returns'
              )
               --DimLineReturnReason.LineReturnReasonGroup In ('Comfort Returns','Comfort Exchanges','Accommodation/Courtesy Returns')
               Then DateAdd(   dd
                             , -365
                             , FactSalesOrders.SALES_LINE_CREATED_DATE
                           )
           When FactSalesOrders.Produced_Date = '1950-01-01'
                And DimLineReturnReason.LINE_RETURN_REASON_GROUP In
              (
                  'Warranty Returns'
                , 'Warranty Exchanges'
              )
               --DimLineReturnReason.LineReturnReasonGroup In ('Warranty Returns','Warranty Exchanges')
               Then DateAdd(   dd
                             , -630
                             , FactSalesOrders.SALES_LINE_CREATED_DATE
                           )
           Else FactSalesOrders.Produced_Date
       End                                             As "PRODUCED_DATE"
     , FactSalesOrders.LEGAL_ENTITY
     , FactSalesOrders.COST_PRICE
     , Case
           When DimLineReturnReason.LINE_RETURN_REASON_GROUP In
               (
                  'Comfort Returns'
                , 'Comfort Exchanges'
                , 'Accommodation/Courtesy Returns'
              )

                --DimLineReturnReason.LineReturnReasonGroup In ('Comfort Returns','Comfort Exchanges','Accommodation/Courtesy Returns')
                And DimCustomer.SUB_SEGMENT_ID Not In
              (
                  'MFI'
                , 'MF Franchisees'
                , 'Sears(Sears-Outlet-K'
                , 'Kmart(Sears-Outlet-K'
                , 'Big Lots'
                , 'Sears Outlet(Sears-O'
              )
               --And Family Not In ('54', 'QB', 'QC')
               Then 'Accommodation'
           When DimLineReturnReason.LINE_RETURN_REASON_GROUP In
                (
                  'Warranty Returns'
                , 'Warranty Exchanges'
              )

                --DimLineReturnReason.LineReturnReasonGroup In ('Warranty Returns','Warranty Exchanges')
                And DimCustomer.SUB_SEGMENT_ID Not In
              (
                  'MF Franchisees'
                , 'Sears(Sears-Outlet-K'
                , 'Big Lots'
              )
               Then 'WarrantyNoAllowance'
           When DimLineReturnReason.LINE_RETURN_REASON_GROUP In
               (
                  'Warranty Returns'
                , 'Warranty Exchanges'
              )

                --DimLineReturnReason.LineReturnReasonGroup In ('Warranty Returns','Warranty Exchanges')
                And DimCustomer.SUB_SEGMENT_ID IN
              (
                  'MF Franchisees'
                , 'Sears(Sears-Outlet-K'
                , 'Big Lots'
              )
               Then 'WarrantyWithAllowance'
           Else 'Not Classified'
       End   AS CLASSIFICATION

                                          
 FROM
    DEV_CURATE.global.Fact_Sales_Orders           as FactSalesOrders
     LEFT OUTER JOIN
         DEV_CURATE.global.DIM_CUSTOMER           as DimCustomer
     ON
         FactSalesOrders.DIM_CUSTOMER_ORDER_KEY = DimCustomer.DIM_CUSTOMER_KEY
     LEFT OUTER JOIN
         DEV_CURATE.global.DIM_Legal_Entity       as DimLegalEntity
     On
         FactSalesOrders.DIM_LEGAL_ENTITY_KEY = DimLegalEntity.DIM_LEGAL_ENTITY_KEY

         LEFT OUTER JOIN
         DEV_CURATE.global.DIM_DEFAULT_DIMENSION  as DimDefaultDimension
     ON
         FactSalesOrders.DIM_DEFAULT_DIMENSION_KEY = DimDefaultDimension.DIM_DEFAULT_DIMENSION_KEY
    LEFT OUTER JOIN
         DEV_CURATE.global.DIM_ITEM               as DimItem
     ON
         FactSalesOrders.DIM_ITEM_KEY = DimItem.DIM_ITEM_KEY
     LEFT OUTER JOIN
         DEV_CURATE.global.DIM_LINE_RETURN_REASON as DimLineReturnReason
     ON
         FactSalesOrders.DIM_LINE_RETURN_REASON_KEY = DimLineReturnReason.DIM_LINE_RETURN_REASON_KEY
         
      LEFT OUTER JOIN
         DEV_CURATE.global.DIM_SALES_ORDER        as DimSalesOrder
     ON
          FactSalesOrders.DIM_SALES_ORDER_KEY = DimSalesOrder.DIM_SALES_ORDER_KEY
      LEFT OUTER JOIN
         DEV_CURATE.global.FACT_SALES_INVOICES    as FactSalesInvoices
     ON
         FactSalesOrders.DIM_SALES_ORDER_KEY = FactSalesInvoices.DIM_SALES_ORDER_KEY
          AND FactSalesOrders.INVENTORY_TRANSACTION_ID = FactSalesInvoices.INVENTORY_TRANSACTION_ID
          AND year(FactSalesInvoices.INVOICE_DATE) >= year(dateadd(year, -5, current_date))
     --     --LEFT OUTER JOIN
 --     --     DEV_CURATE.Global.FACT_SALES_DELIVERIES      as FactSalesDeliveries
 --     -- ON
 --     --     FactSalesOrders.DIM_SALES_ORDER_KEY = FactSalesDeliveries.DIM_SALES_ORDER_KEY

	LEFT JOIN DEV_CURATE.GLOBAL.DIM_DEFAULT_DIMENSION AS dd1
		ON         dd1.DIM_DEFAULT_DIMENSION_KEY = DimDefaultDimension.DIM_DEFAULT_DIMENSION_KEY
            AND dd1.SALES_CHANNEL_ID = DimDefaultDimension.SALES_CHANNEL_ID 
			AND dd1.SOURCE_NAME = 'D365' 
            AND dd1.HK_SOFT_DELETE_FLAG = FALSE
    LEFT JOIN DEV_CURATE.GLOBAL.DIM_DEFAULT_DIMENSION AS dd2 
		ON        dd2.DIM_DEFAULT_DIMENSION_KEY = DimDefaultDimension.DIM_DEFAULT_DIMENSION_KEY
            AND dd2.FAMILY_ID = DimDefaultDimension.FAMILY_ID 
			AND dd2.SOURCE_NAME = 'D365' 
			AND dd2.HK_SOFT_DELETE_FLAG = FALSE

WHERE FactSalesOrders.LEGAL_ENTITY = '415'
       AND FactSalesOrders.HK_SOURCE_NAME ='AXNALA'
    AND  FactSalesOrders.LEGAL_ENTITY NOT in ('760', '761')
    AND FactSalesOrders.HK_SOFT_DELETE_FLAG = FALSE
   AND DimCustomer.HK_SOFT_DELETE_FLAG = FALSE
   and not upper(DimCustomer.LEGAL_ENTITY) like any ('USA')
    	and year(FactSalesOrders.SALES_LINE_CREATED_DATE) >= year(dateadd(year, -5, current_date))
    AND DimDefaultDimension.HK_SOFT_DELETE_FLAG = FALSE
    AND DimDefaultDimension.SALES_CHANNEL_ID <> '900'
    AND DimItem.HK_SOFT_DELETE_FLAG = FALSE
    AND DimLegalEntity.HK_SOFT_DELETE_FLAG = FALSE
    AND (DimLineReturnReason.HK_SOFT_DELETE_FLAG = FALSE OR DimLineReturnReason.HK_SOFT_DELETE_FLAG IS NULL)
    AND (DimSalesOrder.HK_SOFT_DELETE_FLAG = FALSE OR DimSalesOrder.HK_SOFT_DELETE_FLAG IS NULL)
    AND (FactSalesInvoices.HK_SOFT_DELETE_FLAG = FALSE OR FactSalesInvoices.HK_SOFT_DELETE_FLAG IS NULL)
    AND IFNULL(FactSalesInvoices.Sales_Type, FactSalesOrders.Sales_Type) = 'Returned order'

),
CTE_SUM AS
(
SELECT Customer_Account 
     , Segment_ID 
     , Sub_segment_ID
     , Customer_Name 
     , Sales_Channel_ID
     , Sales_Channel
     , FAMILY
     , FAMILY_DESC
     , PRODUCT_GROUP
     , PRODUCT_GROUP_DESC
     , PRODUCT_GROUP_2
     , ITEM_ID 
     , LINE_RETURN_REASON_ID 
     , LINE_RETURN_REASON
     , RETURN_REASON_GROUP_CODE
     , LINE_RETURN_REASON_GROUP
     , RMA_Number 
     , SALES_TYPE
     , CREDIT_DATE
     , INVOICE_ID 
     , RA_LINE
     , SUM(SALES_QUANTITY) as SALES_QUANTITY
     , SUM(RETURN_AMOUNT) * -1 as RETURN_AMOUNT
     , RETURN_DATE
     , ERROR_FLAG_DESC
     , PRODUCED_DATE
     , LEGAL_ENTITY
     , COST_PRICE
     , CLASSIFICATION
     , Sum(COST_PRICE)  as COST               

FROM CTE_RAW
GROUP BY
Customer_Account 
     , Segment_ID 
     , Sub_segment_ID
     , Customer_Name 
     , Sales_Channel_ID
     , Sales_Channel
     , FAMILY
     , FAMILY_DESC
     , PRODUCT_GROUP
     , PRODUCT_GROUP_DESC
     , PRODUCT_GROUP_2
     , ITEM_ID 
     , LINE_RETURN_REASON_ID 
     , LINE_RETURN_REASON
     , RETURN_REASON_GROUP_CODE
     , LINE_RETURN_REASON_GROUP
     , RMA_Number 
     , SALES_TYPE
     , CREDIT_DATE
     , INVOICE_ID 
     , RA_LINE
     , RETURN_DATE
     , ERROR_FLAG_DESC
     , PRODUCED_DATE
     , LEGAL_ENTITY
     , COST_PRICE
     , CLASSIFICATION
)
Select
Case 
 When DimDate.SMMC_QUARTER_NAME = 'UNRELATED' Then
                   Case When PRODUCED_DATE IS Not NULL 
                   Then 'Q' || TO_CHAR(DATE_PART('QUARTER', PRODUCED_DATE))
                                  Else NULL
                   End
   Else DimDate.SMMC_QUARTER_NAME
End AS "FiscalQuarter"
--,DimDate.SMMC_YEAR_NAME AS "FiscalYear"
,Case 
 When DimDate.SMMC_YEAR_NAME = 'UNRELATED' Then
                   Case When PRODUCED_DATE  IS Not NULL Then 'FY ' || TO_CHAR(YEAR(PRODUCED_DATE))
                                  Else NULL
                   End
   Else DimDate.SMMC_YEAR_NAME
End AS "FiscalYear"
--,DimDate.SMMC_MONTH_NAME AS "FiscalMonth"
,Case 
 When DimDate.SMMC_MONTH_NAME = 'UNRELATED' Then
                   Case When PRODUCED_DATE IS Not NULL Then TO_CHAR(PRODUCED_DATE, 'Month')
                                  Else NULL
                   End
                   Else DimDate.SMMC_MONTH_NAME
End AS "FiscalMonth"
, ERROR_FLAG_DESC AS"ErrorFlagDesc"
, Sales_Type AS "Sales Type"
, Line_Return_Reason_ID AS "ReturnReasonCode"
, Line_Return_Reason AS "ReturnReason"
, RETURN_REASON_GROUP_CODE AS "ReturnReasonGroupCode"
, LINE_RETURN_REASON_GROUP AS "ReturnReasonGroup"
, RMA_Number  AS "RANumber"
, RA_LINE AS "RALine"
, Customer_Account "ShipTo"
, Segment_ID  AS "CustomerSegment"
, Sub_segment_ID AS "CustomerSubSegment"
, Customer_Name AS "ShipToName"
, Sales_Channel_ID AS "Channel"
, SALES_CHANNEL AS "ChannelDesc"
, FAMILY AS "Family"
, FAMILY_DESC AS "FamilyDesc"
, PRODUCT_GROUP AS "ProductGroup"
, PRODUCT_GROUP_DESC "ProductGroupDesc"
, PRODUCT_GROUP_2 "ProductGroup1st2"
, SALES_QUANTITY AS "SalesQty"
, RETURN_AMOUNT AS "ReturnAmt"
, RETURN_DATE AS "ReturnDate"
, CREDIT_DATE AS "CreditDate"
, PRODUCED_DATE AS "ProductionDate"
, DATEDIFF(DAY, "ProductionDate", "ReturnDate") AS "DaysOutstandingCnt"
, LEGAL_ENTITY AS "Legal Entity"
, COST AS "Cost"
, CLASSIFICATION as "Classification"
, ITEM_ID AS "ItemID"
, INVOICE_ID AS "InvoiceID"
From CTE_SUM 
LEFT OUTER JOIN DEV_PUBLISH.global.V_DIM_DATE as DimDate 
ON CTE_SUM.PRODUCED_DATE = DimDate.DATE_VALUE
--Where ErrorFlagDesc <> 'No Production Date'
where DimDate.source_name != 'UNKNOWN'
Order by 
2,1,3
,Customer_Account 
,LEGAL_ENTITY
, RMA_Number
, RA_LINE
, INVOICE_ID
, ITEM_ID 
,Credit_Date

;
    