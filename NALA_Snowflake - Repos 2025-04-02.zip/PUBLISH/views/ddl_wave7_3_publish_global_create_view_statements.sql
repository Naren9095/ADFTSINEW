----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FACT_GENERAL_LEDGER

create or replace view global.V_FACT_GENERAL_LEDGER as
	select a.FACT_GENERAL_LEDGER_KEY::number(19, 0) as FACT_GENERAL_LEDGER_KEY
		, a.SOURCE_NAME::varchar(250) as SOURCE_NAME
		, a.RECORD_ID::number(19, 0) as RECORD_ID
		, a.DIM_SOURCE_SYSTEM_KEY::number(19, 0) as DIM_SOURCE_SYSTEM_KEY
		, a.DIM_SOURCE_SYSTEM_SNKEY::number(19, 0) as DIM_SOURCE_SYSTEM_SNKEY
		, a.ACCOUNTING_DATE_DIM_DATE_KEY::number(19, 0) as ACCOUNTING_DATE_DIM_DATE_KEY
		, a.ACCOUNTING_DATE_DIM_DATE_SNKEY::number(19, 0) as ACCOUNTING_DATE_DIM_DATE_SNKEY
		, a.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY::number(19, 0) as ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
		, a.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY::number(19, 0) as ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
		, a.CREATED_DATE_DIM_DATE_KEY::number(19, 0) as CREATED_DATE_DIM_DATE_KEY
		, a.CREATED_DATE_DIM_DATE_SNKEY::number(19, 0) as CREATED_DATE_DIM_DATE_SNKEY
		, a.DOCUMENT_DATE_DIM_DATE_KEY::number(19, 0) as DOCUMENT_DATE_DIM_DATE_KEY
		, a.DOCUMENT_DATE_DIM_DATE_SNKEY::number(19, 0) as DOCUMENT_DATE_DIM_DATE_SNKEY
		, a.DIM_CURRENCY_KEY::number(19, 0) as DIM_CURRENCY_KEY
		, a.DIM_CURRENCY_SNKEY::number(19, 0) as DIM_CURRENCY_SNKEY
		, a.DIM_FINANCIAL_CALENDAR_PERIOD_KEY::number(19, 0) as DIM_FINANCIAL_CALENDAR_PERIOD_KEY
		, a.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY::number(19, 0) as DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
		, a.DIM_LEDGER_KEY::number(19, 0) as DIM_LEDGER_KEY
		, a.DIM_LEDGER_SNKEY::number(19, 0) as DIM_LEDGER_SNKEY
		, a.DIM_LEDGER_DIMENSION_KEY::number(19, 0) as DIM_LEDGER_DIMENSION_KEY
		, a.DIM_LEDGER_DIMENSION_SNKEY::number(19, 0) as DIM_LEDGER_DIMENSION_SNKEY
		, a.DIM_LEGAL_ENTITY_KEY::number(19, 0) as DIM_LEGAL_ENTITY_KEY
		, a.DIM_LEGAL_ENTITY_SNKEY::number(19, 0) as DIM_LEGAL_ENTITY_SNKEY
		, a.DIM_MAIN_ACCOUNT_KEY::number(19, 0) as DIM_MAIN_ACCOUNT_KEY
		, a.DIM_MAIN_ACCOUNT_SNKEY::number(19, 0) as DIM_MAIN_ACCOUNT_SNKEY
		, a.DIM_REASON_KEY::number(19, 0) as DIM_REASON_KEY
		, a.DIM_REASON_SNKEY::number(19, 0) as DIM_REASON_SNKEY
		, hash(a.JOURNAL_CATEGORY, '~', a.POSTING_TYPE, '~', a.IS_CORRECTION, '~', a.IS_CREDIT)::number(19, 0) as DIM_GENERAL_LEDGER_DETAILS_KEY					-- junk dimension
		, DIM_GENERAL_LEDGER_DETAILS_KEY::number(19, 0) as DIM_GENERAL_LEDGER_DETAILS_SNKEY																			-- junk dimension
		, a.CURRENCY_CODE::varchar(250) as CURRENCY_CODE
		, a.RECORD_ID_FINANCIAL_CALENDAR_PERIOD::number(19, 0) as RECORD_ID_FINANCIAL_CALENDAR_PERIOD
		, a.RECORD_ID_LEDGER::number(19, 0) as RECORD_ID_LEDGER
		, a.LEDGER_DIMENSION::varchar(250) as LEDGER_DIMENSION
		, a.RECORD_ID_MAIN_ACCOUNT::number(19, 0) as RECORD_ID_MAIN_ACCOUNT
		, a.RECORD_ID_REASON::number(19, 0) as RECORD_ID_REASON
		, a.JOURNAL_CATEGORY::varchar(250) as JOURNAL_CATEGORY
		, a.POSTING_TYPE::varchar(250) as POSTING_TYPE
		, a.IS_CORRECTION::varchar(250) as IS_CORRECTION
		, a.IS_CREDIT::varchar(250) as IS_CREDIT
		, a.ACCOUNTING_DATE::date as ACCOUNTING_DATE
		, a.ACKNOWLEDGEMENT_DATE::date as ACKNOWLEDGEMENT_DATE
		, a.CREATED_DATE::date as CREATED_DATE
		, a.DOCUMENT_DATE::date as DOCUMENT_DATE
		, a.DOCUMENT_NUMBER::varchar(250) as DOCUMENT_NUMBER
		, a.LEDGER_ACCOUNT::varchar(250) as LEDGER_ACCOUNT
		, a.LEGAL_ENTITY::varchar(250) as LEGAL_ENTITY
		, a.JOURNAL_NUMBER::varchar(250) as JOURNAL_NUMBER
		, a.VOUCHER::varchar(250) as VOUCHER
		, a.QUANTITY::number(28, 16) as QUANTITY
		, a.ACCOUNTING_CURRENCY_AMOUNT::number(28, 16) as ACCOUNTING_CURRENCY_AMOUNT
		, a.REPORTING_CURRENCY_AMOUNT::number(28, 16) as REPORTING_CURRENCY_AMOUNT
		, a.TRANSACTION_CURRENCY_AMOUNT::number(28, 16) as TRANSACTION_CURRENCY_AMOUNT
		, a.JOURNAL_NAME::varchar(250) as JOURNAL_NAME
		, a.JOURNAL_TEXT::varchar(250) as JOURNAL_TEXT
		, a.HK_HASH_KEY::number(19, 0) as HK_HASH_KEY
		, a.HK_SOURCE_NAME::varchar(250) as HK_SOURCE_NAME
		, a.HK_SOFT_DELETE_FLAG::boolean as HK_SOFT_DELETE_FLAG
		, a.HK_SOURCE_CREATED_TIMESTAMP::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, a.HK_SOURCE_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, a.HK_CREATED_JOB_RUN_ID::varchar(250) as HK_CREATED_JOB_RUN_ID
		, a.HK_LAST_UPDATED_JOB_RUN_ID::varchar(250) as HK_LAST_UPDATED_JOB_RUN_ID
		, a.HK_CREATED_TIMESTAMP::timestamp_tz as HK_CREATED_TIMESTAMP
		, a.HK_LAST_UPDATED_TIMESTAMP::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, a.HK_WAREHOUSE_ID::varchar(250) as HK_WAREHOUSE_ID
	from $ENV$_CURATE.GLOBAL.FACT_GENERAL_LEDGER a
	where HK_SOFT_DELETE_FLAG = FALSE
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DIM_GENERAL_LEDGER_DETAILS

create or replace view global.V_DIM_GENERAL_LEDGER_DETAILS as
	select distinct a.DIM_GENERAL_LEDGER_DETAILS_KEY::number(19, 0) as DIM_GENERAL_LEDGER_DETAILS_KEY
		, a.DIM_GENERAL_LEDGER_DETAILS_KEY::number(19, 0) as DIM_GENERAL_LEDGER_DETAILS_SNKEY
		, a.JOURNAL_CATEGORY::varchar(250) as JOURNAL_CATEGORY
		, a.POSTING_TYPE::varchar(250) as POSTING_TYPE
		, a.IS_CORRECTION::varchar(250) as IS_CORRECTION
		, a.IS_CREDIT::varchar(250) as IS_CREDIT
		, max(a.HK_LAST_UPDATED_TIMESTAMP) over (partition by a.DIM_GENERAL_LEDGER_DETAILS_KEY)::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
	from (select distinct fgl1.JOURNAL_CATEGORY::varchar as JOURNAL_CATEGORY
			, fgl1.POSTING_TYPE::varchar as POSTING_TYPE
			, fgl1.IS_CORRECTION::varchar as IS_CORRECTION
			, fgl1.IS_CREDIT::varchar as IS_CREDIT
			, hash(fgl1.JOURNAL_CATEGORY, '~', fgl1.POSTING_TYPE, '~', fgl1.IS_CORRECTION, '~', fgl1.IS_CREDIT) as DIM_GENERAL_LEDGER_DETAILS_KEY
			, max(fgl1.HK_LAST_UPDATED_TIMESTAMP) over (partition by DIM_GENERAL_LEDGER_DETAILS_KEY) as HK_LAST_UPDATED_TIMESTAMP
		from $ENV$_CURATE.GLOBAL.FACT_GENERAL_LEDGER fgl1
	) a
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS

create or replace view global.V_DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS as
	select distinct a.DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY::number(19, 0) as DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY
		, a.DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY::number(19, 0) as DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_SNKEY
		, a.ACCOUNT_TYPE::varchar(250) as ACCOUNT_TYPE
		, a.MANBASE_TRANSACTION_TYPE::varchar(250) as MANBASE_TRANSACTION_TYPE
		, a.OFFSET_ACCOUNT_TYPE::varchar(250) as OFFSET_ACCOUNT_TYPE
		, a.TRANSACTION_TYPE::varchar(250) as TRANSACTION_TYPE
		, a.IS_APPROVED::varchar(250) as IS_APPROVED
		, a.IS_POSTED::varchar(250) as IS_POSTED
		, a.IS_REVERSAL::varchar(250) as IS_REVERSAL
		, max(a.HK_LAST_UPDATED_TIMESTAMP) over (partition by a.DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY)::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
	from (select distinct fljt1.ACCOUNT_TYPE::varchar as ACCOUNT_TYPE
			, fljt1.MANBASE_TRANSACTION_TYPE::varchar as MANBASE_TRANSACTION_TYPE
			, fljt1.OFFSET_ACCOUNT_TYPE::varchar as OFFSET_ACCOUNT_TYPE
			, fljt1.TRANSACTION_TYPE::varchar as TRANSACTION_TYPE
			, fljt1.IS_APPROVED::varchar as IS_APPROVED
			, fljt1.IS_POSTED::varchar as IS_POSTED
			, fljt1.IS_REVERSAL::varchar as IS_REVERSAL
			, hash(fljt1.ACCOUNT_TYPE, '~', fljt1.MANBASE_TRANSACTION_TYPE, '~', fljt1.OFFSET_ACCOUNT_TYPE, '~', fljt1.TRANSACTION_TYPE, '~', fljt1.IS_APPROVED, '~', fljt1.IS_POSTED, '~', fljt1.IS_REVERSAL) as DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY
			, max(fljt1.HK_LAST_UPDATED_TIMESTAMP) over (partition by DIM_LEDGER_JOURNAL_TRANSACTION_DETAILS_KEY) as HK_LAST_UPDATED_TIMESTAMP
		from $ENV$_CURATE.GLOBAL.FACT_LEDGER_JOURNAL_TRANSACTIONS fljt1
	) a
;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- GENERAL_LEDGER_NON_INVOICE (pulled from wave 2)

create or replace view global.V_GENERAL_LEDGER_NON_INVOICE as
	select unionquery.dim_corporate_allocation_mapping_key
		, unionquery.dim_customer_key
		, unionquery.accounting_date
		, unionquery.dim_legal_entity_key
		, unionquery.accounting_currency_amount
		, unionquery.source_name
	from (
		--740 history from bo
		select f1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.amount_debit - f1.amount_credit) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_LEDGER_JOURNAL_TRANSACTIONS f1
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.dim_customer_key = dc1.dim_customer_key
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			dd1.year_number > '2015' and
			f1.transaction_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '740'
		and f1.posted = 1
		and f1.journal_name = 'ORACLE'
		and f1.dim_corporate_allocation_mapping_key not in (-1, -2)
		group by 1, 2, 3, 4, 5, 6
	
		union
	
		--740 ax data
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, f1.accounting_date as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.accounting_currency_amount) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71', '70') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			dd1.year_number > '2015' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '740'
		and f1.accounting_date >= '2021-01-01'
		group by 1, 2, 3, 4, 5, 6
		
	
		---- need 415 components 
		/* 415 stuff to do */
	
		-- original manbase  
	
		union all
	
		select hash('AXNALA'::varchar, '~', f1.LEGALENTITY, '~', f1.MAINACCOUNT) as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, nvl(dc1.DIM_CUSTOMER_KEY, -1) as DIM_CUSTOMER_KEY
			, f1.HISTDATE as ACCOUNTING_DATE
			, hash('AXNALA'::varchar, '~', f1.LEGALENTITY) as DIM_LEGAL_ENTITY_KEY
			, f1.DATASOURCE as SOURCE_NAME
			, f1.LEGALENTITY as LEGAL_ENTITY
			, f1.AMOUNT as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_RAW.global.HISTORICNONINVOICE f1
		left join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.HK_CURRENT_FLAG = TRUE and
			hash('AXNALA'::varchar, '~', f1.LEGALENTITY, '~', f1.CUSTOMERACCOUNT) = dc1.DIM_CUSTOMER_SNKEY

	
		union all
	
		-- load 415 ax non-in data from gl, except manual entries
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(case when dcam1.ibr_line = 'Floor Sample Discount' and left(f1.voucher, 1) in ('I', 'C') then 0.00
					else f1.accounting_currency_amount
				end) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			'FY' || right(dd1.smmc_year, 2) >= 'FY16' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '415'
		and f1.voucher not like 'ManAcc%'
		and f1.voucher not like 'InvAcc%'
		and f1.voucher not like 'ChainAcc%'
		and f1.voucher not like 'RebGLpay%'
		and (f1.journal_name not like 'MB%' or f1.journal_name = '')
		group by 1, 2, 3, 4, 5, 6
		
		union all
	
		-- load ax manual accurals that are entered in ax and have a description entered
		select dcam1.dim_corporate_allocation_mapping_key as DIM_CORPORATE_ALLOCATION_MAPPING_KEY
			, dc1.dim_customer_key as DIM_CUSTOMER_KEY
			, dd1.date_value as ACCOUNTING_DATE
			, f1.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY
			, f1.source_name as SOURCE_NAME
			, f1.legal_entity as LEGAL_ENTITY
			, sum(f1.accounting_currency_amount) as ACCOUNTING_CURRENCY_AMOUNT
		from $ENV$_CURATE.global.FACT_GENERAL_LEDGER f1
		inner join $ENV$_CURATE.global.DIM_LEDGER_DIMENSION dld1 on
			dld1.hk_soft_delete_flag = false and
			f1.dim_ledger_dimension_key = dld1.dim_ledger_dimension_key
		inner join $ENV$_CURATE.global.DIM_CUSTOMER dc1 on
			dc1.hk_soft_delete_flag = false and
			dc1.hk_current_flag = true and
			dc1.dim_customer_key not in (-1, -2) and
			dc1.sales_district_id not in ('94', '44', '20', '99', '87', '90', '93', '25', '71') and
			f1.legal_entity = dc1.legal_entity and
			dld1.customer = dc1.customer_account
		inner join $ENV$_CURATE.global.DIM_MAIN_ACCOUNT dma1 on
			dma1.hk_soft_delete_flag = false and
			f1.dim_main_account_key = dma1.dim_main_account_key
		inner join $ENV$_CURATE.global.DIM_CORPORATE_ALLOCATION_MAPPING dcam1 on
			dcam1.hk_soft_delete_flag = false and
			dcam1.dim_corporate_allocation_mapping_key not in (-1, -2) and
			f1.legal_entity = dcam1.legal_entity and
			dma1.main_account_id = dcam1.main_account
		inner join $ENV$_CURATE.global.DIM_DATE dd1 on
			dd1.hk_soft_delete_flag = false and
			'FY' || right(dd1.smmc_year, 2) >= 'FY16' and
			f1.accounting_date_dim_date_key = dd1.dim_date_key
		where f1.hk_soft_delete_flag = false
		and f1.legal_entity = '415'
		and f1.voucher like 'ManAcc%'
		and f1.journal_text = 'yes'
		group by 1, 2, 3, 4, 5, 6
		) unionquery
;