Alter table ax_nala.custledger rename to ax_nala.zzz_custledger;
undrop table ax_nala.custledger;
drop table ax_nala.zzz_custledger;


Alter table edw_dwh.dimcustomerpostingprofile rename to edw_dwh.zzz_dimcustomerpostingprofile;
undrop table edw_dwh.dimcustomerpostingprofile;
drop table edw_dwh.zzz_dimcustomerpostingprofile;