----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactCostOfGoodsSold

create or replace table edw_dwh.FactCostOfGoodsSold (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	DATASOURCEKEY						NUMBER,
	ITEMKEY								NUMBER,
	LEGALENTITYKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	ITEMID								VARCHAR,
	CONFIGURATIONID						VARCHAR,
	EFFECTIVEDATE						TIMESTAMP_TZ,
	ORACLEITEM							VARCHAR,
	FIXEDOVERHEAD						NUMBER(25, 16),
	LABOR								NUMBER(25, 16),
	MATERIAL							NUMBER(25, 16),
	STANDARDCOST						NUMBER(25, 16),
	VARIABLEOVERHEAD					NUMBER(25, 16),
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactInventorySummary

create or replace table edw_dwh.FactInventorySummary (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	LEGALENTITYKEY						NUMBER,
	INVENTORYKEY						NUMBER,
	INVENTORYSUMMARYDETAILSKEY			NUMBER,
	ITEMKEY								NUMBER,
	ITEMSTATUSKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	INVENTORYID							VARCHAR,
	ITEMID								VARCHAR,
	ARRIVED								NUMBER(38, 16),
	AVAILABLEORDERED					NUMBER(38, 16),
	AVAILABLEPHYSICAL					NUMBER(38, 16),
	DEDUCTED							NUMBER(38, 16),
	ONORDER								NUMBER(38, 16),
	ORDERED								NUMBER(38, 16),
	PICKED								NUMBER(38, 16),
	POSTED								NUMBER(38, 16),
	RECEIVED							NUMBER(38, 16),
	REGISTERED							NUMBER(38, 16),
	RESERVEDORDERED						NUMBER(38, 16),
	RESERVEDPHYSICAL					NUMBER(38, 16),
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	
	ISCLOSED							VARCHAR,
	NOOPENQUANTITIES					VARCHAR,
	ITEMSTATUS							VARCHAR,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);