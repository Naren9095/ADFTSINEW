----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- COGS (FactCostOfGoodsSold)

create or replace table ax_nala.COGS (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	ITEMNUMBER											VARCHAR NOT NULL,				-- PK1.2 from source table
	CONFIGURATION										VARCHAR NOT NULL,				-- PK1.3 from source table
	ORACLEITEM											VARCHAR NOT NULL,				-- PK1.4 from source table
	EFFECTIVEDATE										DATE NOT NULL,					-- PK1.5 from source table
	FIXEDOVERHEAD										NUMBER(25,16),
	LABOR												NUMBER(25,16),
	MATERIAL											NUMBER(25,16),
	STANDARDCOST										NUMBER(25,16),
	VARIABLEOVERHEAD									NUMBER(25,16),
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTSUM (FactInventorySummary)

create or replace table ax_nala.INVENTSUM (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	INVENTDIMID											VARCHAR NOT NULL,				-- PK1.2 from source table
	ITEMID												VARCHAR NOT NULL,				-- PK1.3 from source table
	CLOSED												NUMBER,
	CLOSEDQTY											NUMBER,
	ARRIVED												NUMBER(38,16),
	AVAILORDERED										NUMBER(38,16),
	AVAILPHYSICAL										NUMBER(38,16),
	DEDUCTED											NUMBER(38,16),
	ONORDER												NUMBER(38,16),
	ORDERED												NUMBER(38,16),
	PICKED												NUMBER(38,16),
	POSTEDQTY											NUMBER(38,16),
	RECEIVED											NUMBER(38,16),
	REGISTERED											NUMBER(38,16),
	RESERVORDERED										NUMBER(38,16),
	RESERVPHYSICAL										NUMBER(38,16),
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	INVENTDIM_CONFIGID									VARCHAR,
	INVENTDIM_MODIFIEDDATETIME							TIMESTAMP_TZ,
	INVENTDIMCOMBINATION_PDMSTATUS						VARCHAR,
	INVENTDIMCOMBINATION_MODIFIEDDATETIME				TIMESTAMP_TZ,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);