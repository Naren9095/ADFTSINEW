----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAXGROUPHEADING (DimTaxGroup)

create or replace table ax_nala.TAXGROUPHEADING (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	TAXGROUP											VARCHAR NOT NULL,				-- PK1.2 from source table
	TAXGROUPNAME										VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAXITEMGROUPHEADING (DimTaxItemGroup)

create or replace table ax_nala.TAXITEMGROUPHEADING (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	TAXITEMGROUP										VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	EUSALESLISTTYPE										NUMBER,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_EUSALESLISTTYPE	VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAMTRADEPROMOTION (DimTradePromotion)

create or replace table ax_nala.TAMTRADEPROMOTION (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	PROMOTIONID											VARCHAR NOT NULL,				-- PK1.2 from source table
	PROMOTIONDESCRIPTION								VARCHAR,
	ACTIVITY											NUMBER,
	CURRENCY											VARCHAR,
	HCMWORKERID											NUMBER,
	ORDERSENDDATE										DATE,
	ORDERSSTARTDATE										DATE,
	PROMOTIONSTATUS										NUMBER,
	TPXDEALTYPE											NUMBER,
	UNITID												VARCHAR,
	TPXDEALID											NUMBER,
	MCSTAMDEALSTATUS									VARCHAR,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	CURRENCY_TXT										VARCHAR,
	CURRENCY_MODIFIEDDATETIME							TIMESTAMP_TZ,
	HCMWORKER_PERSON									NUMBER,
	HCMWORKER_MODIFIEDDATETIME							TIMESTAMP_TZ,
	DIRPARTYTABLE_NAME									VARCHAR,
	DIRPARTYTABLE_MODIFIEDDATETIME						TIMESTAMP_TZ,
	UNITOFMEASURE_SYMBOL								VARCHAR,
	UNITOFMEASURE_MODIFIEDDATETIME						TIMESTAMP_TZ,
	UNITOFMEASURETRANSLATION_DESCRIPTION				VARCHAR,
	UNITOFMEASURETRANSLATION_MODIFIEDDATETIME			TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_PROMOTIONSTATUS	VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_TPXDEALTYPE	VARCHAR,
	TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_TPXDEALTYPE	VARCHAR,
	DEAL_DEAL_DESCRIPTION								VARCHAR,
	DEAL_LASTEDITDATE									TIMESTAMP_TZ,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- MCSTRAILERS (DimTrailers)

create or replace table ax_nala.MCSTRAILERS (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	TRAILERNO											VARCHAR NOT NULL,				-- PK1.2 from source table
	CARRIERID											VARCHAR,
	CUBICVOLUME											VARCHAR,
	TRAILERCUBICVOLUME									VARCHAR,
	TRAILERLENGTH										NUMBER,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- UNITOFMEASURE (DimUnitOfMeasure)

create or replace table ax_nala.UNITOFMEASURE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	SYMBOL												VARCHAR NOT NULL,				-- PK1.1 from source table
	RECID												NUMBER,
	SYSTEMOFUNITS										NUMBER,
	UNITOFMEASURECLASS									NUMBER,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	UNITOFMEASURETRANSLATION_DESCRIPTION				VARCHAR,
	UNITOFMEASURETRANSLATION_MODIFIEDDATETIME			TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_SYSTEMOFUNITS	VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_UNITOFMEASURECLASS		VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- USERINFO (DimUserInfo)

create or replace table ax_nala.USERINFO (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	ID													VARCHAR NOT NULL,				-- PK1.1 from source table
	NAME												VARCHAR,
	ENABLE												NUMBER,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ARKIEVA_INVENTORY (DimInventory - Arkieva)

create or replace table ax_nala.ARKIEVA_INVENTORY (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	LOCATION											VARCHAR NOT NULL,				-- PK1.2 from source table
	ITEM_CONFIG											VARCHAR NOT NULL,				-- PK1.2 from source table
	LOCATION_DESCRIPTION								VARCHAR,

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);