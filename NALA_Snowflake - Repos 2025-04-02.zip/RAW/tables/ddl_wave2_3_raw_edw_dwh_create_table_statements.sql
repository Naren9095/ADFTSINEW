----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimIntrastatTransactionCode

create or replace table edw_dwh.DimIntrastatTransactionCode (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	INTRASTATTRANSACTIONCODEKEY			NUMBER,
	LEGALENTITY							VARCHAR,
	INTRASTATTRANSACTIONCODE			VARCHAR,
	INTRASTATTRANSACTIONCODEDESCRIPTION	VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimMerchandisingEvent

create or replace table edw_dwh.DimMerchandisingEvent (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								BIGINT,
	MERCHANDISINGEVENTKEY				BIGINT,
	LEGALENTITY							VARCHAR,
	MERCHANDISINGEVENTID				VARCHAR,
	MERCHANDISINGEVENT					VARCHAR,
	CLAIMPAYMENTTYPE					VARCHAR,
	MERCHANDISINGEVENTTYPE				VARCHAR,
	MERCHANDSINGEVENTCATEGORYNAME		VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimPaymentMode

create or replace table edw_dwh.DimPaymentMode (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	PAYMENTMODEKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	PAYMENTMODEID						VARCHAR,
	PAYMENTMODE							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimPaymentTerms

create or replace table edw_dwh.DimPaymentTerms (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	PAYMENTTERMSKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	PAYMENTTERMSID						VARCHAR,
	PAYMENTTERMS						VARCHAR,
	NUMBEROFDAYS						NUMBER,
	NUMBEROFMONTHS						NUMBER,
	NUMBEROFPAYMENTINSTALLMENTS			NUMBER,
	PAYMENTMETHOD						VARCHAR,
	PAYMENTSCHEDULEID					VARCHAR,
	PAYMENTSCHEDULE						VARCHAR,
	ISPREPAID							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimRebate

create or replace table edw_dwh.DimRebate (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	REBATEKEY							NUMBER,
	LEGALENTITY							VARCHAR,
	REBATETYPEID						VARCHAR,
	REBATETYPE							VARCHAR,
	REBATEPROGRAMTYPE					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimReturnDisposition

create or replace table edw_dwh.DimReturnDisposition (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	RETURNDISPOSITIONKEY				NUMBER,
	LEGALENTITY							VARCHAR,
	RETURNDISPOSITIONID					VARCHAR,
	RETURNDISPOSITION					VARCHAR,
	DISPOSITIONACTION					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);