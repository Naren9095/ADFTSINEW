----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- LEDGERJOURNALTRANS (FactLedgerJournalTransactions)

create or replace table ax_nala.LEDGERJOURNALTRANS (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID																NUMBER NOT NULL,				-- PK1.1 from source table
	CURRENCYCODE														VARCHAR,
	DEFAULTDIMENSION													NUMBER,
	OFFSETDEFAULTDIMENSION												NUMBER,
	LEDGERDIMENSION														NUMBER,
	OFFSETLEDGERDIMENSION												NUMBER,
	TAXCODE																VARCHAR,
	TAXGROUP															VARCHAR,
	APPROVER															NUMBER,
	ACCOUNTTYPE															NUMBER,
	DXCMBINTEGRATIONTRANSTYPE											NUMBER,
	OFFSETACCOUNTTYPE													NUMBER,
	TRANSACTIONTYPE														NUMBER,
	APPROVED															NUMBER,
	REVERSEENTRY														NUMBER,
	DOCUMENTDATE														DATE,
	TRANSDATE															DATE,
	DOCUMENTNUM															VARCHAR,
	INVOICE																VARCHAR,
	JOURNALNUM															VARCHAR,
	TXT																	VARCHAR,
	VOUCHER																VARCHAR,
	DATAAREAID															VARCHAR,
	LINENUM																NUMBER(25,16),
	QTY																	NUMBER(25,16),
	AMOUNTCURCREDIT														NUMBER(38,16),
	AMOUNTCURDEBIT														NUMBER(38,16),
	MODIFIEDDATETIME													TIMESTAMP_TZ,
	DIMENSIONATTRIBUTEVALUECOMBINATION_MAINACCOUNT						NUMBER,
	DIMENSIONATTRIBUTEVALUECOMBINATION_MODIFIEDDATETIME					TIMESTAMP_TZ,
	DEFAULTDIMENSION_MAIN_ACCOUNT										VARCHAR,
	DEFAULTDIMENSION_I_CUSTOMER											VARCHAR,
	DEFAULTDIMENSION_MODIFIEDDATETIME									TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_ACCOUNTTYPE					VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_DXCMBINTEGRATIONTRANSTYPE		VARCHAR,
	TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_OFFSETACCOUNTTYPE				VARCHAR,
	TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_TRANSACTIONTYPE				VARCHAR,
	LEDGERJOURNALTABLE_CREATEDDATETIME									DATE,
	LEDGERJOURNALTABLE_REVERSEDATE										DATE,
	LEDGERJOURNALTABLE_CREATEDBY										VARCHAR,
	LEDGERJOURNALTABLE_NAME												VARCHAR,
	LEDGERJOURNALTABLE_JOURNALNAME										VARCHAR,
	LEDGERJOURNALTABLE_POSTED											NUMBER,
	LEDGERJOURNALTABLE_MODIFIEDDATETIME									TIMESTAMP_TZ,
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTCONSENSUSFORECASTMONTHLY (FactMonthlyForecast)

create or replace table ax_nala.EXPORTCONSENSUSFORECASTMONTHLY (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID															VARCHAR,						-- PK1.1 from source table
	CUSTOMER_NUMBER														VARCHAR,						-- PK1.2 from source table
	LOCATION															VARCHAR,						-- PK1.3a from source table
	ITEM_CONFIG															VARCHAR,						-- PK1.3b from source table
	SUB_CHANNEL_NUMBER													VARCHAR,						-- PK1.4 from source table
	ITEM_NUMBER															VARCHAR,						-- PK1.5 from source table
	CONFORECAST_MONTH													DATE,							-- PK1.6 from source table
	LOADDATE															DATE,							-- PK1.7 from source table
	CONSENSUS_FORECAST													NUMBER(25,2),
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);