----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimTaxGroup

create or replace table edw_dwh.DimTaxGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	TAXGROUPKEY							NUMBER,
	LEGALENTITY							VARCHAR,
	TAXGROUPID							VARCHAR,
	TAXGROUP							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimTaxItemGroup

create or replace table edw_dwh.DimTaxItemGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	TAXITEMGROUPKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	TAXITEMGROUPID						VARCHAR,
	TAXITEMGROUP						VARCHAR,
	EUSALESLISTTYPE						VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimTradePromotion

create or replace table edw_dwh.DimTradePromotion (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	TRADEPROMOTIONKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	TRADEPROMOTIONID					VARCHAR,
	TRADEPROMOTION						VARCHAR,
	HASBEENAPPROVEDFORACTIVITY			VARCHAR,
	CURRENCYCODE						VARCHAR,
	CURRENCY							VARCHAR,
	PROMOTIONOWNER						VARCHAR,
	ORDERSENDDATE						DATE,
	ORDERSSTARTDATE						DATE,
	PROMOTIONSTATUSNAME					VARCHAR,
	PROMOTIONDISCOUNTTYPE				VARCHAR,
	UNITOFMEASUREID						VARCHAR,
	UNITOFMEASURE						VARCHAR,
	DEALID								VARCHAR,
	DEALTYPE							NUMBER,
	DEALTYPENAME						VARCHAR,
	CATALOGSTATUS						VARCHAR,
	DEAL_DESCRIPTION					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimTrailers

create or replace table edw_dwh.DimTrailers (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	DATAAREAID							VARCHAR,
	TRAILERNO							VARCHAR,
	CARRIERID							VARCHAR,
	CUBICVOLUME							VARCHAR,
	TRAILERCUBICVOLUME					VARCHAR,
	TRAILERLENGTH						NUMBER,
	TRAILERKEY							NUMBER,
	CUBICVOLUMEINT						NUMBER,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimUnitOfMeasure

create or replace table edw_dwh.DimUnitOfMeasure (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	UNITOFMEASUREKEY					NUMBER,
	RECORDID							NUMBER,
	UNITOFMEASURECODE					VARCHAR,
	UNITOFMEASURE						VARCHAR,
	SYSTEMOFUNITS						VARCHAR,
	UNITOFMEASURECLASS					VARCHAR,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimUserInfo

create or replace table edw_dwh.DimUserInfo (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	USERINFOKEY							NUMBER,
	USERID								VARCHAR,
	DATASOURCE							VARCHAR,
	USERNAME							VARCHAR,
	USERISENABLED						VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);