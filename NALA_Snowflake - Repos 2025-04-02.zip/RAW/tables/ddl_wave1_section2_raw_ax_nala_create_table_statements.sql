----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTTABLE (DimItem)

truncate table ax_nala.INVENTTABLE;
truncate table ax_nala.INVENTTABLE_ITEM_HIERARCHY;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TPX_LINERETURNREASONCODE (DimLineReturnReason)

create or replace table ax_nala.TPX_LINERETURNREASONCODE (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID							VARCHAR	NOT NULL,				-- PK1.1 from source table
	REASONCODEID						VARCHAR	NOT NULL,				-- PK1.2 from source table
	RETURNREASONCODEGROUPID				VARCHAR NOT NULL,				-- PK1.3 from source table
	DESCRIPTION							VARCHAR,
	DESCRIPTION_CODEGROUP				VARCHAR,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- LOGISTICSPOSTALADDRESS (DimLocation)

create or replace table ax_nala.LOGISTICSPOSTALADDRESS (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID								NUMBER NOT NULL,				-- PK1.1 from source table
	CITY								VARCHAR,
	COUNTY								VARCHAR,
	COUNTRYREGIONID						VARCHAR,
	LATITUDE							NUMBER(25,16),
	LONGITUDE							NUMBER(25,16),
	ZIPCODE								VARCHAR,
	STATE								VARCHAR,
	STREET								VARCHAR,
	ISPRIVATE							NUMBER,
	MODIFIEDDATETIME					TIMESTAMP_TZ,
	LOCATIONID							VARCHAR,
	DESCRIPTION							VARCHAR,
	LOGISTICSLOCATION_MODIFIEDDATETIME	TIMESTAMP_TZ,
	TIMEZONEKEYNAME						VARCHAR,
	FIPSCODE							VARCHAR,
	FIPSZIPS_MODIFIEDDATETIME			TIMESTAMP_TZ,
	REGIONCODE							NUMBER,
	REGIONLONGNAME						VARCHAR,
	DISTRICTCODE						NUMBER,
	DISTRICTLONGNAME					VARCHAR,
	SMACODE								NUMBER,
	SMALONGNAME							VARCHAR,
	BTACODE								NUMBER,
	BTALONGNAME							VARCHAR,
	MSCNTYLONGNAME						VARCHAR,
	GEO_MODIFIEDDATETIME				TIMESTAMP_TZ,
	ISPAREGIONID						NUMBER,
	ISPAREGIONDESCRIPTION				VARCHAR,
	ISPA_REGION_MODIFIEDDATETIME		TIMESTAMP_TZ,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- MAINACCOUNT (DimMainAccount)

create or replace table ax_nala.MAINACCOUNT (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID																NUMBER	NOT NULL,				-- PK1.1 from source table
	MAINACCOUNTID														VARCHAR,
	NAME																VARCHAR,
	ACCOUNTCATEGORYREF													NUMBER,
	LEDGERCHARTOFACCOUNTS												NUMBER,
	TYPE																NUMBER,
	POSTINGTYPE															NUMBER,
	MONETARY															NUMBER,
	MODIFIEDDATETIME													TIMESTAMP_TZ,
	MAINACCOUNTCATEGORY_ACCOUNTCATEGORY									VARCHAR,
	MAINACCOUNTCATEGORY_DESCRIPTION										VARCHAR,
	LEDGERCHARTOFACCOUNTS_NAME											VARCHAR,
	LEDGERCHARTOFACCOUNTS_DESCRIPTION									VARCHAR,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_DIMENSIONLEDGERACCOUNTTYPE		VARCHAR,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_LEDGERPOSTINGTYPE				VARCHAR,
	MAINACCOUNT2_LEVEL1													VARCHAR,
	MAINACCOUNT2_LEVEL2													VARCHAR,
	MAINACCOUNT2_LEVEL3													VARCHAR,
	MAINACCOUNT2_LEVEL4													VARCHAR,
	MAINACCOUNT2_LEVEL5													VARCHAR,
	MAINACCOUNT2_LEVEL6													VARCHAR,
	MAINACCOUNT_MAPPING_HFMACCOUNT										VARCHAR,
	MAINACCOUNT_MAPPING_HFMDESCRIPTION									VARCHAR,
	MAINACCOUNT_MAPPING_REPORTINGCATEGORY								VARCHAR,
	MAINACCOUNT_MAPPING_MODIFIEDDATETIME								TIMESTAMP_TZ,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- RETURNREASONCODE (DimReturnReason)

create or replace table ax_nala.RETURNREASONCODE (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID							VARCHAR	NOT NULL,				-- PK1.1 from source table
	REASONCODEID						VARCHAR	NOT NULL,				-- PK1.2 from source table
	DESCRIPTION							VARCHAR,
	REASONCODEGROUPID					VARCHAR,
	DESCRIPTION_CODEGROUP				VARCHAR,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);