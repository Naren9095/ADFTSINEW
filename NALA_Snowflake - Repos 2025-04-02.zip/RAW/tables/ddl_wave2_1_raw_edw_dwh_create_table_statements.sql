----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimArkievaCustomer

create or replace table edw_dwh.DimArkievaCustomer (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	ARKIEVACUSTOMERKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	ARKIEVACUSTOMERID					VARCHAR,
	ARKIEVACUSTOMERNAME					VARCHAR,
	VALIDFROM							TIMESTAMP_TZ,
	VALIDTO								TIMESTAMP_TZ,
	ISCURRENT							NUMBER,
	ISDELETED							NUMBER,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimArkievaSubchannel

create or replace table edw_dwh.DimArkievaSubchannel (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	ARKIEVASUBCHANNELKEY				NUMBER,
	LEGALENTITY							VARCHAR,
	ARKIEVASUBCHANNELID					VARCHAR,
	ARKIEVASUBCHANNEL					VARCHAR,
	VALIDFROM							TIMESTAMP_TZ,
	VALIDTO								TIMESTAMP_TZ,
	ISCURRENT							NUMBER,
	ISDELETED							NUMBER,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCampaign

create or replace table edw_dwh.DimCampaign (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	CAMPAIGNKEY							NUMBER,
	LEGALENTITY							VARCHAR,
	CAMPAIGNID							VARCHAR,
	DATASOURCE							VARCHAR,
	STARTDATE							DATE,
	ENDDATE								DATE,
	FOLLOWUPDATE						DATE,
	CAMPAIGNNAME						VARCHAR,
	CAMPAIGNOWNER						VARCHAR,
	CAMPAIGNDESCRIPTION					VARCHAR,
	CAMPAIGNSTATUS						VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCorporateAllocationMapping

create or replace table edw_dwh.DimCorporateAllocationMapping (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	CORPALLOCATIONKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	MAINACCOUNT							VARCHAR,
	IBRLINE								VARCHAR,
	TAMCODE								VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);