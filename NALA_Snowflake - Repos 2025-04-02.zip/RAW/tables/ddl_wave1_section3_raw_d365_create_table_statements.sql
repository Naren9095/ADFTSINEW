----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SALESTABLE (DimSalesOrder)

create or replace table d365.SALESTABLE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR	NOT NULL,				-- PK1.1 from source table
	SALESID												VARCHAR	NOT NULL,				-- PK1.2 from source table
	CUSTOMERREF											VARCHAR,
	PURCHORDERFORMNUM									VARCHAR,
	SALESTYPE											NUMBER,
	RETURNITEMNUM										VARCHAR,
	RETURNREPLACEMENTCREATED							NUMBER,
	SALESPOOLID											VARCHAR,
	PLANNUMBER											VARCHAR,
	RETURNREPLACEMENTID									VARCHAR,
	MODIFIEDDATETIME									VARCHAR,
	MCRHOLDCODE											VARCHAR,
	SALESLINE_LARGEITEMORDEREDQTY						NUMBER(25,16),
	SALESLINE_TOTALLARGEITEMVOLUME						NUMBER(25,16),
	SALESLINE_MODIFIEDDATETIME							VARCHAR,
	CUSTPACKINGSLIPTRANS_FIRSTLARGEITEMSHIPPEDQTY		NUMBER(25,16),
	CUSTPACKINGSLIPTRANS_MODIFIEDDATETIME				VARCHAR,
	LKP_TRUCK_VOLUME_LEGAL_ENTITY_ID					VARCHAR,
	LKP_TRUCK_VOLUME_TRUCK_TOTAL_CUBIC_FEET				NUMBER(25,16),

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SALESORIGIN (DimSalesOrigin)

create or replace table d365.SALESORIGIN (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID							VARCHAR	NOT NULL,				-- PK1.1 from source table
	ORIGINID							VARCHAR	NOT NULL,				-- PK1.2 from source table
	DESCRIPTION							VARCHAR,
	EBCMARKUPALLOWED					NUMBER,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTSITE (DimSite)

create or replace table d365.INVENTSITE (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID							VARCHAR	NOT NULL,				-- PK1.1 from source table
	SITEID								VARCHAR	NOT NULL,				-- PK1.2 from source table
	NAME								VARCHAR,
	DEFAULTDIMENSION					NUMBER,
	TIMEZONE							NUMBER,
	MODIFIEDDATETIME					TIMESTAMP_TZ,
	DISPLAYVALUE_BUSINESS_UNIT			VARCHAR,
	DEFAULTDIMENSION_MODIFIEDDATETIME	TIMESTAMP_TZ,
	DIRPARTYTABLE_NAME_BUSINESS_UNIT	VARCHAR,
	TIMEZONELIST_TIMEZONEKEYNAME		VARCHAR,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTLOCATION (DimWarehouse)

create or replace table d365.INVENTLOCATION (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID							VARCHAR	NOT NULL,				-- PK1.1 from source table
	INVENTLOCATIONID					VARCHAR	NOT NULL,				-- PK1.2 from source table
	NAME								VARCHAR,
	INVENTLOCATIONIDQUARANTINE			VARCHAR,
	NAME_QUARANTINE						VARCHAR,
	INVENTLOCATIONIDTRANSIT				VARCHAR,
	NAME_TRANSIT						VARCHAR,
	INVENTSITEID						VARCHAR,
	INVENTLOCATIONTYPE					NUMBER,
	MANUAL								NUMBER,
	NAME_SITE							VARCHAR,
	
	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- HCMWORKER (DimWorker)

create or replace table d365.HCMWORKER (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID								NUMBER	NOT NULL,				-- PK1.1 from source table
	PERSONNELNUMBER						VARCHAR,
	PERSON								NUMBER,
	MODIFIEDDATETIME					TIMESTAMP_TZ,
	DIRPARTYTABLE_NAME					VARCHAR,
	DIRPARTYTABLE_MODIFIEDDATETIME		TIMESTAMP_TZ,

	LATEST_MODIFIEDDATETIME				TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CUSTTRANS (FactCustomerTransactions)

create or replace table d365.CUSTTRANS (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID																NUMBER NOT NULL,				-- PK1.1 from source table
	
	CASHDISCCODE														VARCHAR,
	CURRENCYCODE														VARCHAR,
	ACCOUNTNUM															VARCHAR,
	ORDERACCOUNT														VARCHAR,
	POSTINGPROFILE														VARCHAR,
	DEFAULTDIMENSION													NUMBER,
	DELIVERYMODE														VARCHAR,
	DATAAREAID															VARCHAR,
	PAYMMODE															VARCHAR,
	REASONREFRECID														NUMBER,
	APPROVER															NUMBER,
	PAYMMETHOD															NUMBER,
	DXCMBINTEGRATIONTRANSTYPE											NUMBER,
	TRANSTYPE															NUMBER,
	APPROVED															NUMBER,
	CANCELLEDPAYMENT													NUMBER,
	PREPAYMENT															NUMBER,
	CORRECT																NUMBER,
	INVOICE																VARCHAR,
	CLOSED																DATE,
	DOCUMENTDATE														DATE,
	DUEDATE																DATE,
	LASTSETTLEDATE														DATE,
	TRANSDATE															DATE,
	DOCUMENTNUM															VARCHAR,
	LASTSETTLEVOUCHER													VARCHAR,
	PAYMREFERENCE														VARCHAR,
	EBCPURCHORDERFORMNUM												VARCHAR,
	TXT																	VARCHAR,
	VOUCHER																VARCHAR,
	AMOUNTCUR															NUMBER(38,16),
	AMOUNTMST															NUMBER(38,16),
	SETTLEAMOUNTCUR														NUMBER(38,16),
	SETTLEAMOUNTMST														NUMBER(38,16),
	MODIFIEDDATETIME													TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_NETCURRENT						VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_DXCMBINTEGRATIONTRANSTYPE		VARCHAR,
	TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_LEDGERTRANSTYPE				VARCHAR,
	CUSTINVOICEJOUR_SALESID												VARCHAR,
	CUSTINVOICEJOUR_MODIFIEDDATETIME									TIMESTAMP_TZ,
	LEDGERJOURNALTRANS_JOURNALNUM										VARCHAR,
	LEDGERJOURNALTRANS_MODIFIEDDATETIME									TIMESTAMP_TZ,
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);