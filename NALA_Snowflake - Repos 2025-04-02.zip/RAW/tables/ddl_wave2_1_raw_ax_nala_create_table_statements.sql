----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ARKIEVA_CUSTOMER (DimArkievaCustomer)

create or replace table ax_nala.ARKIEVA_CUSTOMER (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR	NOT NULL,				-- PK1.1 from source table
	CUSTOMER_NUMBER										VARCHAR	NOT NULL,				-- PK1.2 from source table
	CUSTOMER											VARCHAR,

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ARKIEVA_INVENTORY (DimInventory)

create or replace table ax_nala.ARKIEVA_INVENTORY (
	HK_SOURCE_NAME VARCHAR(16777216) NOT NULL,
	HK_JOB_RUN_ID VARCHAR(16777216) NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID VARCHAR(16777216) NOT NULL,
	LOCATION VARCHAR(16777216) NOT NULL,
	ITEM_CONFIG VARCHAR(16777216) NOT NULL,
	LOCATION_DESCRIPTION VARCHAR(16777216),
	LATEST_MODIFIEDDATETIME TIMESTAMP_TZ(9) NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ARKIEVA_SUB_CHANNEL (DimArkievaSubchannel)

create or replace table ax_nala.ARKIEVA_SUB_CHANNEL (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR	NOT NULL,				-- PK1.1 from source table
	SUB_CHANNEL_NUMBER									VARCHAR	NOT NULL,				-- PK1.2 from source table
	SUB_CHANNEL_DESCRIPTION								VARCHAR,

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SMMCAMPAIGNTABLE (DimCampaign)

create or replace table ax_nala.SMMCAMPAIGNTABLE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR	NOT NULL,				-- PK1.1 from source table
	CAMPAIGNID											VARCHAR	NOT NULL,				-- PK1.2 from source table
	CAMPAIGNDATE										DATE,
	CAMPAIGNENDDATE										DATE,
	CAMPAIGNFOLLOWUPDATE								DATE,
	CAMPAIGNNAME										VARCHAR,
	CAMPAIGNRESPWORKER									NUMBER,
	DESCRIPTION											VARCHAR,
	CAMPAIGNSTATUS										NUMBER,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	HCMWORKER_PERSON									NUMBER,
	HCMWORKER_MODIFIEDDATETIME							TIMESTAMP_TZ,
	DIRPARTYTABLE_NAME									VARCHAR,
	DIRPARTYTABLE_MODIFIEDDATETIME						TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_CAMPAIGNSTATUS	VARCHAR,

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CORPALLOCATIONMAPPING (DimCorporateAllocationMapping)

create or replace table ax_nala.CORPALLOCATIONMAPPING (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	AX_COMPANY											VARCHAR	NOT NULL,				-- PK1.1 from source table
	AX_MAIN_ACCOUNT										VARCHAR	NOT NULL,				-- PK1.2 from source table
	IBR_LINE											VARCHAR,
	TAM_CODE											VARCHAR,
	MODIFIEDDATETIME									TIMESTAMP_TZ,

	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);