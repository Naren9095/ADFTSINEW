----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- BUDGETMODEL (DimBudgetModel)

create or replace table ax_nala.BUDGETMODEL (
	HK_SOURCE_NAME												VARCHAR NOT NULL,
	HK_JOB_RUN_ID												VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP										TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID												VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID													VARCHAR NOT NULL,				-- PK1.1 from source table
	MODELID														VARCHAR NOT NULL,				-- PK1.2 from source table
	SUBMODELID													VARCHAR NOT NULL,				-- PK1.3 from source table
	TYPE														NUMBER NOT NULL,				-- PK1.4 from source table
	TXT															VARCHAR,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_BUDGETMODELTYPE		VARCHAR,

	LATEST_MODIFIEDDATETIME									TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAXTABLE (DimTax)

create or replace table ax_nala.TAXTABLE (
	HK_SOURCE_NAME												VARCHAR NOT NULL,
	HK_JOB_RUN_ID												VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP										TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID												VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID													VARCHAR NOT NULL,				-- PK1.1 from source table
	TAXCODE														VARCHAR NOT NULL,				-- PK1.2 from source table
	TAXNAME														VARCHAR NOT NULL,
	TAXPERIOD													VARCHAR NOT NULL,
	TAXACCOUNTGROUP												VARCHAR,

	LATEST_MODIFIEDDATETIME										TIMESTAMP_TZ NOT NULL
);