----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactTransportationLoad

create or replace table edw_dwh.FactTransportationLoad (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	DATAAREAID							VARCHAR,
	LEGALENTITYKEY						NUMBER,
	LOADID								VARCHAR,
	INVENTSITEID						VARCHAR,
	SITEKEY								NUMBER,
	EBCCARRIERID						VARCHAR,
	SHIPPINGCARRIERKEY					NUMBER,
	EBCTRAILERID						VARCHAR,
	TRAILERKEY							NUMBER,
	PLANNEDSTOPCOUNT					NUMBER,
	SCHEDULEDPIECES						NUMBER(25, 16),
	SCHEDULEDMILEAGE					NUMBER(25, 16),
	ACTUALMILES							NUMBER(25, 16),
	ACTUALSTOPCOUNT						NUMBER,
	ACTUALPIECES						NUMBER(25, 16),
	SALESORDERKEY						NUMBER,
	ITEMKEY								NUMBER,
	LOCATIONKEY							NUMBER,
	CUSTOMERKEY							NUMBER,
	TRANSACTIONTYPE						VARCHAR,
	TRAILERCUBICVOLUMECAPACITY			NUMBER,
	ACTUALCUBES							NUMBER(25, 6),
	PLANNEDCUBES						NUMBER(25, 6),
	PLANNEDSHIPDATE						DATE,
	ACTUALSHIPDATE						DATE,
	LOADSTATUSDESCRIPTION				VARCHAR,
	
	SALESORDERID						VARCHAR,
	ITEMID								VARCHAR,
	CUSTOMERACCOUNT						VARCHAR,
	RECORDIDLOCATION					NUMBER,
		
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactWeeklyForecast

create or replace table edw_dwh.FactWeeklyForecast (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	ARKIEVACUSTOMERKEY					NUMBER,
	ARKIEVASUBCHANNELKEY				NUMBER,
	INVENTORYKEY						NUMBER,
	ITEMKEY								NUMBER,
	LEGALENTITYKEY						NUMBER,
	WEEKLYFORECASTDATE					DATE,
	WEEKLYFORECASTLOADDATE				DATE,
	LEGALENTITY							VARCHAR,
	FORECASTQUANTITY					NUMBER(25, 2),
	
	CUSTOMER_NUMBER						VARCHAR,
	SUB_CHANNEL_NUMBER					VARCHAR,
	ARKIEVAINVENTORYID					VARCHAR,
	ITEM_NUMBER							VARCHAR,
	CONFORECAST_WEEK					TIMESTAMP_TZ,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactWeeklyWMAPE

create or replace table edw_dwh.FactWeeklyWMAPE (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	INVENTORYKEY						NUMBER,
	ITEMKEY								NUMBER,
	LEGALENTITYKEY						NUMBER,
	WEEKLYWMAPEDATE						DATE,
	WEEKLYWMAPELOADDATE					DATE,
	ARKIEVAINVENTORYID					VARCHAR,
	LEGALENTITY							VARCHAR,
	ITEMID								VARCHAR,
	WMAPE								NUMBER(25, 2),
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);