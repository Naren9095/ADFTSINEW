----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTITEMPRICE (DimCost)

create or replace table ax_nala.INVENTITEMPRICE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	INVENTDIMID											VARCHAR NOT NULL,				-- PK1.2 from source table
	ITEMID												VARCHAR NOT NULL,				-- PK1.3 from source table
	PRICETYPE											NUMBER NOT NULL,				-- PK1.4 from source table
	ACTIVATIONDATE										DATE NOT NULL,					-- PK1.5 from source table
	CREATEDDATETIME										TIMESTAMP_TZ NOT NULL,			-- PK1.6 from source table
	COSTINGTYPE											NUMBER,
	VERSIONID											VARCHAR,
	PRICE												NUMBER(25,16),
	MARKUP												NUMBER(25,16),
	PRICEQTY											NUMBER(25,16),
	PRICEUNIT											NUMBER(25,16),
	UNITID												VARCHAR,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	UNITOFMEASURE_SYMBOL								VARCHAR,
	UNITOFMEASURE_MODIFIEDDATETIME						TIMESTAMP_TZ,
	UNITOFMEASURETRANSLATION_DESCRIPTION				VARCHAR,
	UNITOFMEASURETRANSLATION_MODIFIEDDATETIME			TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_PRICETYPE		VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_COSTINGTYPE	VARCHAR,
	INVENTDIM_CONFIGID									VARCHAR,
	INVENTDIM_MODIFIEDDATETIME							TIMESTAMP_TZ,
	INVENTDIMCOMBINATION_PDMSTATUS						VARCHAR,
	INVENTDIMCOMBINATION_MODIFIEDDATETIME				TIMESTAMP_TZ,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CUSTGROUP (DimCustomerGroup)

create or replace table ax_nala.CUSTGROUP (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	CUSTGROUP											VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- MARKUPGROUP (DimCustomerMarkupGroup)

create or replace table ax_nala.MARKUPGROUP (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	GROUPID												VARCHAR NOT NULL,				-- PK1.2 from source table
	TXT													VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INVENTITEMGTIN (DimGlobalTradeItemNumber)

create or replace table ax_nala.INVENTITEMGTIN (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	INVENTDIMID											VARCHAR NOT NULL,				-- PK1.2 from source table
	ITEMID												VARCHAR NOT NULL,				-- PK1.3 from source table
	GLOBALTRADEITEMNUMBER								VARCHAR,
	GTINSETUP											VARCHAR,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	INVENTDIM_CONFIGID									VARCHAR,
	INVENTDIM_MODIFIEDDATETIME							TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_GTINSETUP		VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);