----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- INTRASTATTRANSACTIONCODE (DimIntraStatTransactionCode)

create or replace table ax_nala.INTRASTATTRANSACTIONCODE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	TRANSACTIONCODE										VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAMMERCHANDISINGEVENT (DimMerchandisingEvent)

create or replace table ax_nala.TAMMERCHANDISINGEVENT (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	MERCHANDISINGEVENTID								VARCHAR NOT NULL,				-- PK1.2 from source table
	DESCRIPTION											VARCHAR,
	CLAIMPAYTYPE										NUMBER,
	MERCHEVENTTYPE										VARCHAR,
	MERCHANDISINGEVENTCATEGORY							VARCHAR,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	TAMMERCHANDISINGEVENTTYPE_DESCRIPTION				VARCHAR,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_CLAIMPAYTYPE	VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_MERCHANDISINGEVENTCATEGORY		VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CUSTPAYMMODETABLE (DimPaymentMode)

create or replace table ax_nala.CUSTPAYMMODETABLE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	PAYMMODE											VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PAYMTERM (DimPaymentTerms)

create or replace table ax_nala.PAYMTERM (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	PAYMTERMID											VARCHAR NOT NULL,				-- PK1.2 from source table
	DESCRIPTION											VARCHAR,
	NUMOFDAYS											NUMBER,
	NUMOFMONTHS											NUMBER,
	PAYMSCHED											VARCHAR,
	PAYMMETHOD											NUMBER,
	PREPAID												NUMBER,
	PAYMSCHED_NUMOFPAYMENT								NUMBER,
	PAYMSCHED_DESCRIPTION								VARCHAR,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_PAYMMETHOD		VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PDSREBATE (DimRebate)

create or replace table ax_nala.PDSREBATE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	PDSREBATETYPE										VARCHAR NOT NULL,				-- PK1.2 from source table
	DESCRIPTION											VARCHAR,
	PDSREBATEPROGRAMTYPE								NUMBER,
	MODIFIEDDATETIME									TIMESTAMP_TZ,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_PDSREBATEPROGRAMTYPE	VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- RETURNDISPOSITIONCODE (DimReturnDisposition)

create or replace table ax_nala.RETURNDISPOSITIONCODE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	DISPOSITIONCODEID									VARCHAR NOT NULL,				-- PK1.2 from source table
	DESCRIPTION											VARCHAR,
	DISPOSITIONACTION									NUMBER,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_DISPOSITIONACTION	VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);