--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SalesRowLevelSecurity (RLS_SALES):

create or replace table edw_dwh.SalesRowLevelSecurity(
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER NOT NULL,
	REPORTPARENTID						VARCHAR,
	DIVISIONID							VARCHAR,
	REGIONID							VARCHAR,
	CUSTOMERNAME						VARCHAR,
	SALESREPID							VARCHAR,
	ADUSERID							VARCHAR,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);