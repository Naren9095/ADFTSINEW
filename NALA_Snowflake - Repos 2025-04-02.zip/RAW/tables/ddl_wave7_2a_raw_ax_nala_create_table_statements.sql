----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TAXTRANS (FactTaxTransactions)

create or replace table ax_nala.TAXTRANS (
	HK_SOURCE_NAME												VARCHAR NOT NULL,
	HK_JOB_RUN_ID												VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP										TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID												VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID														NUMBER NOT NULL,				-- PK1.1 from source table
	CURRENCYCODE												VARCHAR,
	TAXCODE														VARCHAR,
	TAXGROUP													VARCHAR,
	TRANSDATE													DATE,
	INVENTTRANSID												VARCHAR,
	INVOICEID													VARCHAR,
	JOURNALNUM													VARCHAR,
	DATAAREAID													VARCHAR,
	VOUCHER														VARCHAR,
	TAXAMOUNT													NUMBER(38,16),
	TAXAMOUNTCUR												NUMBER(38,16),
	TAXBASEAMOUNT												NUMBER(38,16),
	TAXBASEAMOUNTCUR											NUMBER(38,16),

	LATEST_MODIFIEDDATETIME										TIMESTAMP_TZ NOT NULL
);