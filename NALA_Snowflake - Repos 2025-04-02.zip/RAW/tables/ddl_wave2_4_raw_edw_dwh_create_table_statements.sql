----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimSalesGroup

create or replace table edw_dwh.DimSalesGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	SALESGROUPKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	SALESGROUPID						VARCHAR,
	SALESGROUP							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimSalesLineDiscountGroup

create or replace table edw_dwh.DimSalesLineDiscountGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	SALESLINEDISCOUNTGROUPKEY			NUMBER,
	LEGALENTITY							VARCHAR,
	SALESLINEDISCOUNTGROUPID			VARCHAR,
	SALESLINEDISCOUNTGROUP				VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimSalesPool

create or replace table edw_dwh.DimSalesPool (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	SALESPOOLKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	SALESPOOLID							VARCHAR,
	SALESPOOL							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimSalesPriceGroup

create or replace table edw_dwh.DimSalesPriceGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	SALESPRICEGROUPKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	SALESPRICEGROUPID					VARCHAR,
	SALESPRICEGROUP						VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimSalesProcurementCategory

create or replace table edw_dwh.DimSalesProcurementCategory (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	PROCUREMENTCATEGORYKEY				NUMBER,
	RECORDID							NUMBER,
	PROCUREMENTCATEGORY					VARCHAR,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimShippingCarrier

create or replace table edw_dwh.DimShippingCarrier (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	SHIPPINGCARRIERKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	SHIPPINGCARRIERID					VARCHAR,
	SHIPPINGCARRIERNAME					VARCHAR,
	SHIPPINGCARRIERDESCRIPTION			VARCHAR,
	SHIPPINGCARRIERACCOUNTID			VARCHAR,
	SHIPPINGCARRIERACCOUNTNUMBER		VARCHAR,
	SHIPPINGCARRIERCURRENCYCODE			VARCHAR,
	SHIPPINGCARRIERCURRENCYNAME			VARCHAR,
	ANCILLARYCHARGEID					VARCHAR,
	ANCILLARYCHARGE						VARCHAR,
	CORECHARGEID						VARCHAR,
	CORECHARGE							VARCHAR,
	FUELSURCHARGEID						VARCHAR,
	FUELSURCHARGE						VARCHAR,
	HANDLINGSURCHARGEID					VARCHAR,
	HANDLINGSURCHARGE					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);