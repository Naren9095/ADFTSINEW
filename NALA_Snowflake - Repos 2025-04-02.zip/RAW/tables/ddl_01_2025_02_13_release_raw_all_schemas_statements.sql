--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36483:

truncate table ax_nala.CUSTTABLE;
truncate table ax_nala.CUSTTABLE_EXT;

truncate table ax_retail.CUSTTABLE;
truncate table ax_retail.CUSTTABLE_EXT;

truncate table d365.CUSTTABLE;
truncate table d365.CUSTTABLE_EXT;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DIMCUSTOMER_DEFAULTDELIVERYTERMS_FIX

create or replace table edw_dwh.DIMCUSTOMER_DEFAULTDELIVERYTERMS_FIX (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DATAAREAID							VARCHAR,
	CUSTOMERACCOUNT						VARCHAR,
	DEFAULTDELIVERYTERMS				VARCHAR
);


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

truncate table ax_nala.DEFAULTDIMENSION;
truncate table ax_retail.DEFAULTDIMENSION;
truncate table d365.DEFAULTDIMENSION;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ORACLESALESCHANNEL_DEFAULTDIMENSION_FIX

create or replace table edw_dwh.ORACLESALESCHANNEL_DEFAULTDIMENSION_FIX (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	AXSALESCHANNEL						VARCHAR,
	AXSALESCHANNELKEY					NUMBER,
	DEFAULTDIMENSIONKEY					NUMBER,
	DESCRIPTION							VARCHAR,
	DATASOURCE							VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

truncate table ax_nala.CUSTINVOICETRANS;
truncate table ax_nala.CUSTINVOICETRANS_STANDARDCOST;

truncate table ax_retail.CUSTINVOICETRANS;
truncate table ax_retail.CUSTINVOICETRANS_STANDARDCOST;

truncate table d365.CUSTINVOICETRANS;
truncate table d365.CUSTINVOICETRANS_STANDARDCOST;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FACTSALESINVOICES_DEFAULTDIMENSION_FIX

create or replace table edw_dwh.FACTSALESINVOICES_DEFAULTDIMENSION_FIX (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	RECID								NUMBER,
	DATAAREAID							VARCHAR,
	ITEMID								VARCHAR,
	DEFAULTDIMENSION					VARCHAR
);


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36273:

truncate table ax_nala.CUSTINVOICETRANS;
truncate table ax_nala.CUSTINVOICETRANS_STANDARDCOST;

truncate table ax_retail.CUSTINVOICETRANS;
truncate table ax_retail.CUSTINVOICETRANS_STANDARDCOST;

truncate table d365.CUSTINVOICETRANS;
truncate table d365.CUSTINVOICETRANS_STANDARDCOST;



--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36332:

truncate table ax_nala.SALESLINE;
truncate table ax_retail.SALESLINE;
truncate table d365.SALESLINE;