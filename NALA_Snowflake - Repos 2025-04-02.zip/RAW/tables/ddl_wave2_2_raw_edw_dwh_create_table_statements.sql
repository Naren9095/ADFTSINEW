----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCost

create or replace table edw_dwh.DimCost (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	INVENTORYKEY						NUMBER,
	ITEMKEY								NUMBER,
	ITEMSTATUSKEY						NUMBER,
	LEGALENTITYKEY						NUMBER,
	COSTKEY								NUMBER,
	ACTIVATIONDATE						DATE,
	CREATEDDATETIME						TIMESTAMP_TZ,
	INVENTORYDIMENSIONID				VARCHAR,
	ITEMID								VARCHAR,
	LEGALENTITY							VARCHAR,
	COSTINGTYPE							VARCHAR,
	COSTVERSION							VARCHAR,
	MODIFIEDDATETIME					TIMESTAMP_TZ,
	PRICE								NUMBER(25, 16),
	PRICECHARGES						NUMBER(25, 16),
	PRICEQUANTITY						NUMBER(25, 16),
	PRICETYPE							VARCHAR,
	PRICEUNIT							NUMBER(25, 16),
	STANDARDCOST						NUMBER(25, 16),
	UNITOFMEASURECODE					VARCHAR,
	UNITOFMEASURE						VARCHAR,
	ISDELETED							NUMBER,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	
	ITEMSTATUS							VARCHAR,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCustomerGroup

create or replace table edw_dwh.DimCustomerGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	CUSTOMERGROUPKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	CUSTOMERGROUPID						VARCHAR,
	CUSTOMERGROUP						VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCustomerMarkupGroup

create or replace table edw_dwh.DimCustomerMarkupGroup (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	CUSTOMERMARKUPGROUPKEY				NUMBER,
	LEGALENTITY							VARCHAR,
	CUSTOMERMARKUPGROUPID				VARCHAR,
	CUSTOMERMARKUPGROUP					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimGlobalTradeItemNumber

create or replace table edw_dwh.DimGlobalTradeItemNumber (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	GLOBALTRADEITEMNUMBERKEY			NUMBER,
	LEGALENTITY							VARCHAR,
	CONFIGURATIONID						VARCHAR,
	ITEMID								VARCHAR,
	GLOBALTRADEITEMNUMBER				VARCHAR,
	GLOBALTRADEITEMNUMBERSETUP			VARCHAR,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);