----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimBudgetModel:

create or replace table edw_dwh.DimBudgetModel(
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	
	DW_ID								NUMBER NOT NULL,
	BUDGETMODELKEY						NUMBER,
	BUDGETMODELID						VARCHAR,
	BUDGETSUBMODELID					VARCHAR,
	BUDGETMODEL							VARCHAR,
	BUDGETMODELTYPE						VARCHAR,
	LEGALENTITY							VARCHAR,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimTax:

create or replace table edw_dwh.DimTax(
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	
	DW_ID								NUMBER NOT NULL,
	TAXKEY								NUMBER,
	LEGALENTITY							VARCHAR,
	TAXID								VARCHAR,
	TAXNAME								VARCHAR,
	TAXPERIOD							VARCHAR,
	TAXACCOUNTGROUP						VARCHAR,
	
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);