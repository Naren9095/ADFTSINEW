----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- WHSLOADLINE (FactTransportationLoad)

create or replace table ax_nala.WHSLOADLINE (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID															VARCHAR NOT NULL,						-- PK1.1 from source table
	LOADID																VARCHAR NOT NULL,						-- PK1.2 from source table
	ORDERNUM															VARCHAR NOT NULL,						-- PK1.3 from source table
	ITEMID																VARCHAR NOT NULL,						-- PK1.4 from source table
	QTY																	NUMBER(25,16),
	MODIFIEDDATETIME													TIMESTAMP_TZ,
	MCSRNAEVENTLINE_ACTUALPIECES										NUMBER(25,16),
	MCSRNAEVENTLINE_UNITVOLUME											NUMBER(25,16),
	MCSRNAEVENTLINE_INVENTTABLE_MODIFIEDDATETIME						TIMESTAMP_TZ,
	MCSRNAEVENTLINE_SALESLINE_MODIFIEDDATETIME							TIMESTAMP_TZ,
	INVENTTABLE_UNITVOLUME												NUMBER(25,16),
	INVENTTABLE_MODIFIEDDATETIME										TIMESTAMP_TZ,
	SALESTABLE_SALESID													VARCHAR,
	SALESTABLE_CUSTACCOUNT												VARCHAR,
	SALESTABLE_DELIVERYPOSTALADDRESS									NUMBER,
	SALESTABLE_SHIPPINGDATECONFIRMED									DATE,
	SALESTABLE_MODIFIEDDATETIME											TIMESTAMP_TZ,
	WHSLOADTABLE_EBCCARRIERID											VARCHAR,
	WHSLOADTABLE_INVENTSITEID											VARCHAR,
	WHSLOADTABLE_EBCTRAILERID											VARCHAR,
	WHSLOADTABLE_LOADSCHEDSHIPUTCDATETIME								DATE,
	WHSLOADTABLE_LOADSTATUS												NUMBER,
	WHSLOADTABLE_MODIFIEDDATETIME										TIMESTAMP_TZ,
	WHSLOADTABLE_ENTITYKEY												NUMBER,
	MCSROADNETSTAGINGTABLE_MODIFIEDDATETIME								TIMESTAMP_TZ,
	MCSRNAROUTESTOP_STOPCOUNT											NUMBER,
	MCSRNAROUTESTOP_MILEAGE												NUMBER(25,16),
	MCSRNAEVENTHEADER_ACTUALMILES										NUMBER(25,16),
	MCSRNAEVENTHEADER_ACTUALSTOPCOUNT									NUMBER,
	MCSTRAILERS_CUBICVOLUME												NUMBER,
	TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_SALESTYPE						VARCHAR,
	TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_LOADSTATUS						VARCHAR,
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);

create or replace table ax_nala.WHSLOADLINE_EXT (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	HK_WHSLOADLINE_EXT_HASH_KEY											VARCHAR NOT NULL,
	DATAAREAID															VARCHAR NOT NULL,						-- PK1.1 from source table
	LOADID																VARCHAR NOT NULL,						-- PK1.2 from source table
	ORDERNUM															VARCHAR NOT NULL,						-- PK1.3 from source table
	ITEMID																VARCHAR NOT NULL,						-- PK1.4 from source table
	MCSRNAEVENTLINE_ACTUALPIECES										NUMBER(25,16),
	MCSRNAEVENTLINE_UNITVOLUME											NUMBER(25,16),
	MCSRNAROUTESTOP_STOPCOUNT											NUMBER,
	MCSRNAROUTESTOP_MILEAGE												NUMBER(25,16),
	MCSRNAEVENTHEADER_ACTUALMILES										NUMBER(25,16),
	MCSRNAEVENTHEADER_ACTUALSTOPCOUNT									NUMBER,
	MCSTRAILERS_CUBICVOLUME												NUMBER
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTCONSENSUSFORECASTWEEKLY (FactWeeklyForecast)

create or replace table ax_nala.EXPORTCONSENSUSFORECASTWEEKLY (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID															VARCHAR,						-- PK1.1 from source table
	CUSTOMER_NUMBER														VARCHAR,						-- PK1.2 from source table
	LOCATION															VARCHAR,						-- PK1.3a from source table
	ITEM_CONFIG															VARCHAR,						-- PK1.3b from source table
	SUB_CHANNEL_NUMBER													VARCHAR,						-- PK1.4 from source table
	ITEM_NUMBER															VARCHAR,						-- PK1.5 from source table
	CONFORECAST_WEEK													DATE,							-- PK1.6 from source table
	LOADDATE															DATE,
	CONSENSUS_FORECAST													NUMBER(25,2),
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTCONSENSUSFORECASTWEEKLYWMAPE (FactWeeklyWMAPE)

create or replace table ax_nala.EXPORTCONSENSUSFORECASTWEEKLYWMAPE (
	HK_SOURCE_NAME														VARCHAR NOT NULL,
	HK_JOB_RUN_ID														VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP												TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID														VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID															VARCHAR,						-- PK1.1 from source table
	LOCATION															VARCHAR,						-- PK1.2a from source table
	ITEM_CONFIG															VARCHAR,						-- PK1.2b from source table
	ITEM_NUMBER															VARCHAR,						-- PK1.3 from source table
	CONSENSUS_FORECAST													DATE,							-- PK1.4 from source table
	LOADDATE															DATE,
	WMAPE																NUMBER(25,2),
	
	LATEST_MODIFIEDDATETIME												TIMESTAMP_TZ NOT NULL
);