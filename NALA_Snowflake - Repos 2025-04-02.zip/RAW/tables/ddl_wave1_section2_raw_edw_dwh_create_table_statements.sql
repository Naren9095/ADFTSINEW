----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimLineReturnReason

create or replace table edw_dwh.DimLineReturnReason (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	LINERETURNREASONKEY					NUMBER,
	LEGALENTITY							VARCHAR,
	LINERETURNREASONID					VARCHAR,
	LINERETURNREASON					VARCHAR,
	LINERETURNREASONGROUPID				VARCHAR,
	LINERETURNREASONGROUP				VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimLocation

create or replace table edw_dwh.DimLocation (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	LOCATIONKEY							NUMBER,
	DATASOURCE							VARCHAR,
	RECORDID							NUMBER,
	CITY								VARCHAR,
	COUNTY								VARCHAR,
	COUNTRY								VARCHAR,
	LATITUDE							NUMBER(25, 16),
	LOCATIONID							VARCHAR,
	LOCATIONNAME						VARCHAR,
	LONGITUDE							NUMBER(25, 16),
	POSTALCODE							VARCHAR,
	STATE								VARCHAR,
	STREET								VARCHAR,
	TIMEZONE							VARCHAR,
	ADDRESSISPRIVATE					VARCHAR,
	FIPSCODE							VARCHAR,
	GEODIVISIONCODE						NUMBER,
	GEODIVISION							VARCHAR,
	GEOREGIONCODE						NUMBER,
	GEOREGION							VARCHAR,
	STRATEGICMARKETINGAREACODE			NUMBER,
	STRATEGICMARKETINGAREA				VARCHAR,
	BUSINESSTRADEAREACODE				NUMBER,
	BUSINESSTRADEAREA					VARCHAR,
	GEOCOUNTY							VARCHAR,
	ISPAREGIONID						NUMBER,
	ISPAREGION							VARCHAR,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimMainAccount

create or replace table edw_dwh.DimMainAccount (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	MAINACCOUNTKEY						NUMBER,
	RECORDID							NUMBER,
	MAINACCOUNTID						VARCHAR,
	MAINACCOUNT							VARCHAR,
	ACCOUNTCATEGORYID					VARCHAR,
	ACCOUNTCATEGORY						VARCHAR,
	LEDGERCHARTOFACCOUNTSID				VARCHAR,
	LEDGERCHARTOFACCOUNTS				VARCHAR,
	ACCOUNTTYPE							VARCHAR,
	POSTINGTYPE							VARCHAR,
	ISMONETARYACCOUNT					VARCHAR,
	LEVEL1								VARCHAR,
	LEVEL2								VARCHAR,
	LEVEL3								VARCHAR,
	LEVEL4								VARCHAR,
	LEVEL5								VARCHAR,
	LEVEL6								VARCHAR,
	INCREMENTALTIMESTAMP				TIMESTAMP_TZ,
	DW_ID_RAW							NUMBER,
	
	HFMACCOUNTID						VARCHAR,
	HFMACCOUNT							VARCHAR,
	REPORTINGCATEGORY					VARCHAR,

	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimReturnReason

create or replace table edw_dwh.DimReturnReason (
	HK_SOURCE_NAME						VARCHAR NOT NULL,
	HK_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL,
	DW_ID								NUMBER,
	RETURNREASONKEY						NUMBER,
	LEGALENTITY							VARCHAR,
	RETURNREASONID						VARCHAR,
	RETURNREASON						VARCHAR,
	RETURNREASONGROUPID					VARCHAR,
	RETURNREASONGROUP					VARCHAR,
	DW_BATCH							NUMBER,
	DW_SOURCECODE						VARCHAR,
	DW_TIMESTAMP						TIMESTAMP_TZ
);