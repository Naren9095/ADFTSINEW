----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- COMMISSIONSALESGROUP (DimSalesGroup)

create or replace table ax_nala.COMMISSIONSALESGROUP (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	GROUPID												VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PRICEDISCGROUP_SLDG (DimSalesLineDiscountGroup)

create or replace table ax_nala.PRICEDISCGROUP_SLDG (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	GROUPID												VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SALESPOOL (DimSalesPool)

create or replace table ax_nala.SALESPOOL (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	SALESPOOLID											VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PRICEDISCGROUP_SPG (DimSalesLineDiscountGroup)

create or replace table ax_nala.PRICEDISCGROUP_SPG (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	GROUPID												VARCHAR NOT NULL,				-- PK1.2 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ECORESCATEGORY (DimSalesProcurementCategory)

create or replace table ax_nala.ECORESCATEGORY (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	RECID												NUMBER NOT NULL,				-- PK1.1 from source table
	NAME												VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SHIPCARRIERTABLE (DimShippingCarrier)

create or replace table ax_nala.SHIPCARRIERTABLE (
	HK_SOURCE_NAME										VARCHAR NOT NULL,
	HK_JOB_RUN_ID										VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP								TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	HK_WAREHOUSE_ID										VARCHAR NOT NULL DEFAULT UUID_STRING(),
	DATAAREAID											VARCHAR NOT NULL,				-- PK1.1 from source table
	CARRIERID											VARCHAR NOT NULL,				-- PK1.2 from source table
	CARRIERNAME											VARCHAR,
	CARRIERSERVICEDESCRIPTION							VARCHAR,
	SHIPCARRIERCOMPANY_CARRIERNAME						VARCHAR,
	SHIPCARRIERCOMPANY_ANCILLARYCHARGE					VARCHAR,
	SHIPCARRIERCOMPANY_CORECHARGE						VARCHAR,
	SHIPCARRIERCOMPANY_FUELSURCHAGE						VARCHAR,
	SHIPCARRIERCOMPANY_HANDLINGCHARGE					VARCHAR,
	SHIPCARRIERCOMPANYACCOUNTS_CARRIERNAME				VARCHAR,
	SHIPCARRIERCOMPANYACCOUNTS_ACCOUNTNUMBER			VARCHAR,
	SHIPCARRIERCOMPANYACCOUNTS_CURRENCYCODE				VARCHAR,
	CURRENCY_TXT										VARCHAR,
	MARKUPTABLE1_TXT									VARCHAR,
	MARKUPTABLE2_TXT									VARCHAR,
	MARKUPTABLE3_TXT									VARCHAR,
	MARKUPTABLE4_TXT									VARCHAR,
	
	LATEST_MODIFIEDDATETIME								TIMESTAMP_TZ NOT NULL
);