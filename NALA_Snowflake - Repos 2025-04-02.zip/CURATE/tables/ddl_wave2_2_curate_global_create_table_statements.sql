----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_COST
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_COST (
	DIM_COST_KEY									NUMBER NOT NULL,					-- Primary Key
	DIM_COST_SNKEY									NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	INVENTORY_DIMENSION_ID							VARCHAR NOT NULL,					-- AK1.3
	ITEM_ID											VARCHAR NOT NULL,					-- AK1.4
	PRICE_TYPE										VARCHAR NOT NULL,					-- AK1.5
	ACTIVATION_DATE									DATE NOT NULL,						-- AK1.6
	CREATED_DATETIME								TIMESTAMP_TZ NOT NULL,				-- AK1.7
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	DIM_INVENTORY_SNKEY								NUMBER NOT NULL,					-- FK to DIM_INVENTORY table
	DIM_ITEM_SNKEY									NUMBER NOT NULL,					-- FK to DIM_ITEM table
	DIM_LEGAL_ENTITY_SNKEY							NUMBER NOT NULL,					-- FK to DIM_LEGAL_ENTITY table
	
	--INVENTORYKEY									NUMBER NOT NULL,
	--ITEMKEY										NUMBER NOT NULL,
	--ITEMSTATUSKEY									NUMBER NOT NULL,
	--LEGALENTITYKEY								NUMBER NOT NULL,
	--COSTKEY										NUMBER NOT NULL,
	
	COSTING_TYPE									VARCHAR NOT NULL,
	COST_VERSION									VARCHAR NOT NULL,
	--MODIFIED_DATETIME								TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_SOURCE_LAST_UPDATED_TIMESTAMP
	PRICE											NUMBER(25, 16) NOT NULL,
	PRICE_CHARGES									NUMBER(25, 16) NOT NULL,
	PRICE_QUANTITY									NUMBER(25, 16) NOT NULL,
	PRICE_UNIT										NUMBER(25, 16) NOT NULL,
	STANDARD_COST									NUMBER(25, 16) NOT NULL,
	UNIT_OF_MEASURE_CODE							VARCHAR NOT NULL,
	UNIT_OF_MEASURE									VARCHAR NOT NULL,
	--IS_DELETED									NUMBER NOT NULL,					---------------------------- replaced by HK_SOFT_DELETE_FLAG
	
	-- flattened from the DIM_ITEM_STATUS table
	ITEM_STATUS										VARCHAR NOT NULL,
	
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CUSTOMER_GROUP
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CUSTOMER_GROUP (
	DIM_CUSTOMER_GROUP_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_CUSTOMER_GROUP_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	CUSTOMER_GROUP_ID 								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	CUSTOMER_GROUP									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CUSTOMER_MARKUP_GROUP
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CUSTOMER_MARKUP_GROUP (
	DIM_CUSTOMER_MARKUP_GROUP_KEY					NUMBER NOT NULL,					-- Primary Key
	DIM_CUSTOMER_MARKUP_GROUP_SNKEY					NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	CUSTOMER_MARKUP_GROUP_ID 						VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	CUSTOMER_MARKUP_GROUP							VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_GLOBAL_TRADE_ITEM_NUMBER
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_GLOBAL_TRADE_ITEM_NUMBER (
	DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY				NUMBER NOT NULL,					-- Primary Key
	DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY				NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	CONFIGURATION_ID								VARCHAR NOT NULL,					-- AK1.3
	ITEM_ID											VARCHAR NOT NULL,					-- AK1.4
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	GLOBAL_TRADE_ITEM_NUMBER						VARCHAR NOT NULL,
	GLOBAL_TRADE_ITEM_NUMBER_SETUP					VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);