-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_BUSINESS_UNIT
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_BUSINESS_UNIT (
	DIM_BUSINESS_UNIT_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_BUSINESS_UNIT_SNKEY							NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	BUSINESS_UNIT_ID								VARCHAR NOT NULL,					-- AK1.2
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--RECORD_ID										NUMBER NOT NULL,
	BUSINESS_UNIT_NAME								VARCHAR NOT NULL,
	BUSINESS_UNIT_ALIAS								VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_COMMISSION_GROUP
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_COMMISSION_GROUP (
	DIM_COMMISSION_GROUP_KEY						NUMBER NOT NULL,					-- Primary Key
	DIM_COMMISSION_GROUP_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	COMMISSION_GROUP_ID 							VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	COMMISSION_GROUP								VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CURRENCY
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CURRENCY (
	DIM_CURRENCY_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_CURRENCY_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	CURRENCY_CODE									VARCHAR NOT NULL,					-- AK1.2
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	CURRENCY_NAME									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CUSTOMER (SCD type-2)
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CUSTOMER (
	DIM_CUSTOMER_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_CUSTOMER_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	CUSTOMER_ACCOUNT 								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--CUSTOMER_HISTORY_KEY							NUMBER NOT NULL,					-- this is used for SCD type-2; not required in new design
	CUSTOMER_NAME									VARCHAR NOT NULL,
	RECORD_TYPE										VARCHAR NOT NULL,
	CUSTOMER_COMPANY_TYPE							VARCHAR NOT NULL,
	LEGACY_CUSTOMER									VARCHAR NOT NULL,
	LEGACY_CONSUMER_NUMBER							VARCHAR NOT NULL,
	ORGANIZATION_NUMBER								VARCHAR NOT NULL,
	INVOICE_ACCOUNT									VARCHAR NOT NULL,
	CUSTOMER_CURRENCY_CODE							VARCHAR NOT NULL,
	CUSTOMER_CURRENCY_NAME							VARCHAR NOT NULL,
	USE_CASH_DISCOUNT								VARCHAR NOT NULL,
	SALES_REPRESENTATIVE_ID							VARCHAR NOT NULL,
	SALES_REPRESENTATIVE							VARCHAR NOT NULL,
	CUSTOMER_IS_BLOCKED								VARCHAR NOT NULL,
	IS_PAST_DUE_CHECK								VARCHAR NOT NULL,
	CREDIT_LIMIT									NUMBER(25, 16) NOT NULL,
	IS_MANDATORY_CREDIT_LIMIT						VARCHAR NOT NULL,
	IS_CREDIT_LIMIT_BLOCKING_EXCLUDED				VARCHAR NOT NULL,
	GRACE_DAYS										NUMBER(25, 16) NOT NULL,
	CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY				NUMBER NOT NULL,
	YEARLY_AVERAGE_DAYS_TO_PAY						NUMBER NOT NULL,
	BUYING_GROUP_EXEMPT								VARCHAR NOT NULL,
	BUYING_GROUP_KICKER								VARCHAR NOT NULL,
	DEFAULT_CASH_DISCOUNT_ID						VARCHAR NOT NULL,
	DEFAULT_CASH_DISCOUNT							VARCHAR NOT NULL,
	DEFAULT_CASH_DISCOUNT_PERCENT					NUMBER(25, 16) NOT NULL,
	DEFAULT_DELIVERY_MODE_ID						VARCHAR NOT NULL,
	DEFAULT_DELIVERY_MODE							VARCHAR NOT NULL,
	DEFAULT_DELIVERY_TERMS_ID						VARCHAR NOT NULL,
	DEFAULT_DELIVERY_TERMS							VARCHAR NOT NULL,
	DEFAULT_PAYMENT_MODE_ID							VARCHAR NOT NULL,
	DEFAULT_PAYMENT_MODE							VARCHAR NOT NULL,
	DEFAULT_PAYMENT_TERMS_ID						VARCHAR NOT NULL,
	DEFAULT_PAYMENT_TERMS							VARCHAR NOT NULL,
	PAYMENT_TERMS_NUMBER_OF_DAYS					NUMBER NOT NULL,
	PAYMENT_TERMS_NUMBER_OF_MONTHS					NUMBER NOT NULL,
	CLASSIFICATION_GROUP_ID							VARCHAR NOT NULL,
	CLASSIFICATION_GROUP							VARCHAR NOT NULL,
	COMPANY_CHAIN_ID								VARCHAR NOT NULL,
	COMPANY_CHAIN									VARCHAR NOT NULL,
	CUSTOMER_GROUP_ID								VARCHAR NOT NULL,
	CUSTOMER_GROUP									VARCHAR NOT NULL,
	DIVISION_ID										VARCHAR NOT NULL,
	DIVISION										VARCHAR NOT NULL,
	LINE_OF_BUSINESS_ID								VARCHAR NOT NULL,
	LINE_OF_BUSINESS								VARCHAR NOT NULL,
	MARKUP_GROUP_ID									VARCHAR NOT NULL,
	MARKUP_GROUP									VARCHAR NOT NULL,
	PRICE_GROUP_ID									VARCHAR NOT NULL,
	PRICE_GROUP										VARCHAR NOT NULL,
	SALES_CHANNEL_ID								VARCHAR NOT NULL,
	SALES_CHANNEL									VARCHAR NOT NULL,
	SALES_DISTRICT_ID								VARCHAR NOT NULL,
	SALES_DISTRICT									VARCHAR NOT NULL,
	SALES_GROUP_ID									VARCHAR NOT NULL,
	SALES_GROUP										VARCHAR NOT NULL,
	SALES_POOL_ID									VARCHAR NOT NULL,
	SALES_POOL										VARCHAR NOT NULL,
	SEGMENT_ID										VARCHAR NOT NULL,
	SEGMENT											VARCHAR NOT NULL,
	SUB_SEGMENT_ID									VARCHAR NOT NULL,
	SUB_SEGMENT										VARCHAR NOT NULL,
	TAX_GROUP_ID									VARCHAR NOT NULL,
	TAX_GROUP										VARCHAR NOT NULL,
	PRIMARY_STREET									VARCHAR NOT NULL,
	PRIMARY_CITY									VARCHAR NOT NULL,
	PRIMARY_STATE									VARCHAR NOT NULL,
	PRIMARY_ZIP_CODE								VARCHAR NOT NULL,
	PRIMARY_COUNTRY									VARCHAR NOT NULL,
	PRIMARY_TIME_ZONE								VARCHAR NOT NULL,
	PRIMARY_ADDRESS_NAME							VARCHAR NOT NULL,
	PRIMARY_EMAIL_ADDRESS							VARCHAR NOT NULL,
	PRIMARY_FAX_NUMBER								VARCHAR NOT NULL,
	PRIMARY_PHONE_NUMBER							VARCHAR NOT NULL,
	INVOICE_STREET									VARCHAR NOT NULL,
	INVOICE_CITY									VARCHAR NOT NULL,
	INVOICE_STATE									VARCHAR NOT NULL,
	INVOICE_ZIP_CODE								VARCHAR NOT NULL,
	INVOICE_COUNTRY									VARCHAR NOT NULL,
	INVOICE_ADDRESS_NAME							VARCHAR NOT NULL,
	INVOICE_ADDRESS_LOCATION_ID						VARCHAR NOT NULL,
	REPORT_PARENT									VARCHAR NOT NULL,
	REPORT_PARENT_DIVISION_ID						VARCHAR NOT NULL,
	REPORT_PARENT_DIVISION							VARCHAR NOT NULL,
	REPORT_PARENT_SALES_DISTRICT_ID					VARCHAR NOT NULL,
	REPORT_PARENT_SALES_DISTRICT					VARCHAR NOT NULL,
	REPORT_PARENT_SALES_REPRESENTATIVE_ID			VARCHAR NOT NULL,
	REPORT_PARENT_SALES_REPRESENTATIVE				VARCHAR NOT NULL,
	ALTERNATIVE_ROLLUP_1							VARCHAR NOT NULL,
	ALTERNATIVE_ROLLUP_2							VARCHAR NOT NULL,
	ALTERNATIVE_ROLLUP_3							VARCHAR NOT NULL,
	--VALID_FROM									TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_START_TIMESTAMP
	--VALID_TO										TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_END_TIMESTAMP
	--IS_CURRENT									NUMBER NOT NULL,					---------------------------- replaced by HK_CURRENT_FLAG
	--IS_DELETED									NUMBER NOT NULL,					---------------------------- replaced by HK_SOFT_DELETE_FLAG
	--INCREMENTALTIMESTAMP							TIMESTAMP_TZ NOT NULL,
	EXTERNAL_PRICING								VARCHAR NOT NULL,
	REPORTING_DEALER_ID								VARCHAR NOT NULL,
	REPORTING_DEALER								VARCHAR NOT NULL,
	MCS_NETWORK_ID									VARCHAR NOT NULL,
	REPORTING_DEALER_NAME_ID						VARCHAR NOT NULL,
	--DW_ID_RAW										NUMBER NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_EFFECTIVE_START_TIMESTAMP					TIMESTAMP_TZ NOT NULL,				-- AK1.4
	HK_EFFECTIVE_END_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_CURRENT_FLAG									BOOLEAN NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	LKP_TRUCK_VOLUME (needed for populating DIM_CUSTOMER value, MCS_NETWORK_ID, and for DIM_SALES_ORDER calculations)
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.LKP_TRUCK_VOLUME (
	LEGAL_ENTITY_ID                   				VARCHAR NOT NULL,
	NETWORK_ID                        				VARCHAR NOT NULL,
	NETWORK_NAME                      				VARCHAR NOT NULL,
	TRUCK_TOTAL_CUBIC_FEET            				NUMBER(25, 16) NOT NULL,
	IS_TEMPURPEDIC									BOOLEAN NOT NULL,
	START_TIMESTAMP                   				TIMESTAMP_TZ NOT NULL,
	END_TIMESTAMP                     				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_TIMESTAMP              				TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP          				TIMESTAMP_TZ NOT NULL
);

insert into global.LKP_TRUCK_VOLUME (legal_entity_id, network_id, network_name, truck_total_cubic_feet, is_tempurpedic, start_timestamp, end_timestamp, hk_created_timestamp, HK_LAST_UPDATED_TIMESTAMP)
select '401' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '402' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '405' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '415' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '415' as LEGAL_ENTITY_ID, 'FragilePak'::varchar as NETWORK_ID, 'FragilePak'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '415' as LEGAL_ENTITY_ID, 'STI'::varchar as NETWORK_ID, 'STI'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '425' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '429' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '434' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '456' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '457' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '458' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '469' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '470' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '471' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '482' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '503' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '605' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '610' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '620' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '640' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '700' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '710' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '715' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '730' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '740' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '745' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '750' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '751' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '760' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 2550::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select '761' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 2550::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'MDM' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'mstr' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'TSII' as LEGAL_ENTITY_ID, 'DHL'::varchar as NETWORK_ID, 'DHL'::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, true::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U455' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U458' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U469' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U470' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U471' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'U750' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'USA' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP union all
select 'DAT' as LEGAL_ENTITY_ID, ''::varchar as NETWORK_ID, ''::varchar as NETWORK_NAME, 0::number(25,16) as TRUCK_TOTAL_CUBIC_FEET, false::boolean as IS_TEMPURPEDIC, '1950-01-01'::timestamp_tz as START_TIMESTAMP, '9000-01-01'::timestamp_tz as END_TIMESTAMP, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
;


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_DEFAULT_DIMENSION
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_DEFAULT_DIMENSION (
	DIM_DEFAULT_DIMENSION_KEY						NUMBER NOT NULL,					-- Primary Key
	DIM_DEFAULT_DIMENSION_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	DEFAULT_DIMENSION								VARCHAR NOT NULL,					-- AK1.2
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	DEPARTMENT_ID									VARCHAR NOT NULL,
	DEPARTMENT										VARCHAR NOT NULL,
	INTER_COMPANY_ID								VARCHAR NOT NULL,
	INTER_COMPANY									VARCHAR NOT NULL,
	SALES_CHANNEL_ID								VARCHAR NOT NULL,
	SALES_CHANNEL									VARCHAR NOT NULL,
	TYPE_ID											VARCHAR NOT NULL,
	TYPE											VARCHAR NOT NULL,
	CATEGORY_ID										VARCHAR NOT NULL,
	CATEGORY										VARCHAR NOT NULL,
	FAMILY_ID										VARCHAR NOT NULL,
	FAMILY											VARCHAR NOT NULL,
	SIZE_ID											VARCHAR NOT NULL,
	SIZE											VARCHAR NOT NULL,
	VERSION_ID										VARCHAR NOT NULL,
	VERSION											VARCHAR NOT NULL,
	FOAM_SOURCED_ID									VARCHAR NOT NULL,
	FOAM_SOURCED									VARCHAR NOT NULL,
	STORE_ID										VARCHAR NOT NULL,
	STORE											VARCHAR NOT NULL,
	BUSINESS_UNIT_ID								VARCHAR NOT NULL,
	BUSINESS_UNIT									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_DELIVERY_MODE
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_DELIVERY_MODE (
	DIM_DELIVERY_MODE_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_DELIVERY_MODE_SNKEY							NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	DELIVERY_MODE_ID								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	DELIVERY_MODE									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_DELIVERY_TERM
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_DELIVERY_TERM (
	DIM_DELIVERY_TERM_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_DELIVERY_TERM_SNKEY							NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	DELIVERY_TERM_ID								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	DELIVERY_TERM									VARCHAR NOT NULL,
	TAX_LOCATION_ROLE_TYPE							VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);