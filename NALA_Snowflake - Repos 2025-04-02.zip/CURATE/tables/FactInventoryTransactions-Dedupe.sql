delete from global.FACT_INVENTORY_TRANSACTIONS z
where exists (
    select b.fact_inventory_transactions_key, b.hk_warehouse_id
    from global.FACT_INVENTORY_TRANSACTIONS a
    inner join (select fact_inventory_transactions_key, hk_warehouse_id
                from global.FACT_INVENTORY_TRANSACTIONS
                qualify row_number() over (partition by fact_inventory_transactions_key order by hk_last_updated_timestamp desc) > 1) b on
        a.fact_inventory_transactions_key = b.fact_inventory_transactions_key and
        a.hk_warehouse_id = b.hk_warehouse_id
    where a.fact_inventory_transactions_key = z.fact_inventory_transactions_key
    and a.hk_warehouse_id = z.hk_warehouse_id
    )
;