--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33729:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_COST
    -- new:				n/a
    -- updated:			ITEM_STATUS, HK_HASH_KEY
    -- removed:			n/a

update global.DIM_COST a
set a.item_status = b.item_status_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.dim_cost_key
		, ''::varchar as ITEM_STATUS_NEW
		
		, hash(f1.source_name, '~', f1.legal_entity, '~', f1.inventory_dimension_id, '~', f1.item_id, '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.costing_type, '~', f1.cost_version, '~', to_char(f1.price), '~', to_char(f1.price_charges), '~', to_char(f1.price_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.standard_cost), '~', f1.unit_of_measure_code, '~', f1.unit_of_measure, '~', ITEM_STATUS_NEW, '~', f1.configuration_id, '~', f1.inventory_site_id, '~', to_char(f1.price_type_id))::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.DIM_COST f1
	where f1.item_status in ('0', '5637144578', '5637144579', '5637145328', '5637146826', '5637147578', '5637148327', '5637149076')
	and (f1.item_status != ITEM_STATUS_NEW
		)
	) b
where a.dim_cost_key = b.dim_cost_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				INVENTORY_SITE_ID
    -- updated:			n/a
    -- removed:			n/a

create or replace TABLE global.FACT_SALES_INVOICES_UPDATES (
	FACT_SALES_INVOICES_KEY NUMBER(38,0) NOT NULL,
	SOURCE_NAME VARCHAR(16777216) NOT NULL,
	RECORD_ID NUMBER(38,0) NOT NULL,
	LEGAL_ENTITY VARCHAR(16777216) NOT NULL,
	ITEM_ID VARCHAR(16777216) NOT NULL,
	DIM_SOURCE_SYSTEM_KEY NUMBER(38,0) NOT NULL,
	DIM_SOURCE_SYSTEM_SNKEY NUMBER(38,0) NOT NULL,
	DELIVERY_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	DELIVERY_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	DOCUMENT_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	DOCUMENT_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	DUE_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	DUE_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	INVOICE_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	INVOICE_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	MANUFACTURED_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	MANUFACTURED_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	RELATED_ORDER_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	RELATED_ORDER_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	RETURN_ARRIVAL_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	RETURN_CLOSED_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	RETURN_CLOSED_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	SALES_LINE_CREATED_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_BUSINESS_UNIT_KEY NUMBER(38,0) NOT NULL,
	DIM_BUSINESS_UNIT_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CAMPAIGN_KEY NUMBER(38,0) NOT NULL,
	DIM_CAMPAIGN_SNKEY NUMBER(38,0) NOT NULL,
	DIM_COMMISSION_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_COMMISSION_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_COST_KEY NUMBER(38,0) NOT NULL,
	DIM_COST_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CURRENCY_KEY NUMBER(38,0) NOT NULL,
	DIM_CURRENCY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_INVOICE_KEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_INVOICE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_ORDER_KEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_ORDER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_MARKUP_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_CUSTOMER_MARKUP_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_DEFAULT_DIMENSION_KEY NUMBER(38,0) NOT NULL,
	DIM_DEFAULT_DIMENSION_SNKEY NUMBER(38,0) NOT NULL,
	DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY NUMBER(38,0) NOT NULL,
	DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_INTRA_STAT_TRANSACTION_CODE_KEY NUMBER(38,0) NOT NULL,
	DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_INVENTORY_KEY NUMBER(38,0) NOT NULL,
	DIM_INVENTORY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_KEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_SNKEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_STATUS_KEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_STATUS_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LEGAL_ENTITY_KEY NUMBER(38,0) NOT NULL,
	DIM_LEGAL_ENTITY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LINE_RETURN_REASON_KEY NUMBER(38,0) NOT NULL,
	DIM_LINE_RETURN_REASON_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_DELIVERY_ADDRESS_KEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_DELIVERY_ADDRESS_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_INVOICE_ADDRESS_KEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_INVOICE_ADDRESS_SNKEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_MODE_KEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_MODE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_TERM_KEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_TERM_SNKEY NUMBER(38,0) NOT NULL,
	DIM_PAYMENT_TERMS_KEY NUMBER(38,0) NOT NULL,
	DIM_PAYMENT_TERMS_SNKEY NUMBER(38,0) NOT NULL,
	DIM_PROCUREMENT_CATEGORY_KEY NUMBER(38,0) NOT NULL,
	DIM_PROCUREMENT_CATEGORY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_DISPOSITION_KEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_DISPOSITION_SNKEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_REASON_KEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_REASON_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_LINE_DISCOUNT_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_ORDER_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_ORDER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_ORIGIN_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_ORIGIN_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_POOL_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_POOL_SNKEY NUMBER(38,0) NOT NULL,
	DIM_SALES_PRICE_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_SALES_PRICE_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_TAX_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_TAX_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_TAX_ITEM_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_TAX_ITEM_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_SALES_KEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_SALES_SNKEY NUMBER(38,0) NOT NULL,
	DIM_WAREHOUSE_KEY NUMBER(38,0) NOT NULL,
	DIM_WAREHOUSE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_SALES_RESPONSIBLE_KEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_SALES_RESPONSIBLE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_SALES_TAKER_KEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_SALES_TAKER_SNKEY NUMBER(38,0) NOT NULL,
	INVOICE_KEY NUMBER(38,0) NOT NULL,
	BUSINESS_UNIT_ID VARCHAR(16777216) NOT NULL,
	CAMPAIGN_ID VARCHAR(16777216) NOT NULL,
	COMMISSION_GROUP_ID VARCHAR(16777216) NOT NULL,
	CURRENCY_CODE VARCHAR(16777216) NOT NULL,
	CUSTOMER_ACCOUNT_INVOICE VARCHAR(16777216) NOT NULL,
	CUSTOMER_ACCOUNT_ORDER VARCHAR(16777216) NOT NULL,
	CUSTOMER_GROUP_ID VARCHAR(16777216) NOT NULL,
	CUSTOMER_MARKUP_GROUP_ID VARCHAR(16777216) NOT NULL,
	DEFAULT_DIMENSION VARCHAR(16777216) NOT NULL,
	CONFIGURATION_ID VARCHAR(16777216) NOT NULL,
	INTRA_STAT_TRANSACTION_CODE VARCHAR(16777216) NOT NULL,
	INVENTORY_DIMENSION_ID VARCHAR(16777216) NOT NULL,
	ITEM_STATUS VARCHAR(16777216) NOT NULL,
	LINE_RETURN_REASON_ID VARCHAR(16777216) NOT NULL,
	LINE_RETURN_REASON_GROUP_ID VARCHAR(16777216) NOT NULL,
	RECORD_ID_LOCATION_DELIVERY_ADDRESS NUMBER(38,0) NOT NULL,
	RECORD_ID_LOCATION_INVOICE_ADDRESS NUMBER(38,0) NOT NULL,
	DELIVERY_MODE_ID VARCHAR(16777216) NOT NULL,
	DELIVERY_TERM_ID VARCHAR(16777216) NOT NULL,
	PAYMENT_TERMS_ID VARCHAR(16777216) NOT NULL,
	PROCUREMENT_CATEGORY NUMBER(38,0) NOT NULL,
	RETURN_DISPOSITION_ID VARCHAR(16777216) NOT NULL,
	RETURN_REASON_ID VARCHAR(16777216) NOT NULL,
	SALES_GROUP_ID VARCHAR(16777216) NOT NULL,
	SALES_LINE_DISCOUNT_GROUP_ID VARCHAR(16777216) NOT NULL,
	SALES_ORDER_ID VARCHAR(16777216) NOT NULL,
	SALES_ORIGIN_ID VARCHAR(16777216) NOT NULL,
	SALES_POOL_ID VARCHAR(16777216) NOT NULL,
	SALES_PRICE_GROUP_ID VARCHAR(16777216) NOT NULL,
	TAX_GROUP_ID VARCHAR(16777216) NOT NULL,
	TAX_ITEM_GROUP_ID VARCHAR(16777216) NOT NULL,
	UNIT_OF_MEASURE_CODE_SALES VARCHAR(16777216) NOT NULL,
	WAREHOUSE_ID VARCHAR(16777216) NOT NULL,
	RECORD_ID_SALES_RESPONSIBLE NUMBER(38,0) NOT NULL,
	RECORD_ID_SALES_TAKER NUMBER(38,0) NOT NULL,
	DOCUMENT_STATUS VARCHAR(16777216) NOT NULL,
	FLOOR_SAMPLE_TYPE VARCHAR(16777216) NOT NULL,
	HEADER_RETURN_STATUS VARCHAR(16777216) NOT NULL,
	HEADER_SALES_STATUS VARCHAR(16777216) NOT NULL,
	RETURN_STATUS VARCHAR(16777216) NOT NULL,
	SALES_STATUS VARCHAR(16777216) NOT NULL,
	SALES_TYPE VARCHAR(16777216) NOT NULL,
	SHIP_CARRIER_DELIVERY_TYPE VARCHAR(16777216) NOT NULL,
	TRADE_LINE_DELIVERY_TYPE VARCHAR(16777216) NOT NULL,
	IS_AT_AGENT_TRANSACTION VARCHAR(16777216) NOT NULL,
	IS_BLIND_SHIPMENT VARCHAR(16777216) NOT NULL,
	IS_EXPEDITED_SHIPMENT VARCHAR(16777216) NOT NULL,
	IS_FLOOR_SAMPLE_DISCOUNT VARCHAR(16777216) NOT NULL,
	IS_ITEM_TRANSACTION VARCHAR(16777216) NOT NULL,
	IS_LINE_DELIVERY_COMPLETE VARCHAR(16777216) NOT NULL,
	IS_ORDER_BLOCKED VARCHAR(16777216) NOT NULL,
	IS_ORDER_LINE_BLOCKED VARCHAR(16777216) NOT NULL,
	IS_ORDER_LOCKED VARCHAR(16777216) NOT NULL,
	IS_RETURNED_ITEM_SCRAP VARCHAR(16777216) NOT NULL,
	IS_SHIP_CARRIER_USING_FUEL_SURCHARGE VARCHAR(16777216) NOT NULL,
	IS_STOCKED_PRODUCT VARCHAR(16777216) NOT NULL,
	DROP_SHIPMENT VARCHAR(16777216) NOT NULL,
	DELIVERY_DATE DATE NOT NULL,
	DOCUMENT_DATE DATE NOT NULL,
	DUE_DATE DATE NOT NULL,
	INVOICE_DATE DATE NOT NULL,
	MANUFACTURED_DATE DATE NOT NULL,
	ORIGINATING_ORDER_CREATED_DATE DATE NOT NULL,
	RELATED_ORDER_DATE DATE NOT NULL,
	RETURN_ARRIVAL_DATE DATE NOT NULL,
	RETURN_CLOSED_DATE DATE NOT NULL,
	SALES_LINE_CREATED_DATE DATE NOT NULL,
	INVENTORY_TRANSACTION_ID VARCHAR(16777216) NOT NULL,
	INVOICE_ID VARCHAR(16777216) NOT NULL,
	LEDGER_VOUCHER VARCHAR(16777216) NOT NULL,
	LINE_NUMBER NUMBER(25,16) NOT NULL,
	ORIGINAL_SALES_ORDER_ID VARCHAR(16777216) NOT NULL,
	PRODUCTION_TIME TIMESTAMP_TZ(9) NOT NULL,
	PURCHASE_ORDER_ID VARCHAR(16777216) NOT NULL,
	ORIGINATING_ORDER_SALES_ID VARCHAR(16777216) NOT NULL,
	REGISTRY_NUMBER VARCHAR(16777216) NOT NULL,
	INVENTORY_QUANTITY NUMBER(25,16) NOT NULL,
	INVOICE_QUANTITY NUMBER(25,16) NOT NULL,
	PHYSICAL_QUANTITY NUMBER(25,16) NOT NULL,
	PRICE_UNIT NUMBER(25,16) NOT NULL,
	SALES_PRICE NUMBER(25,16) NOT NULL,
	COMMISSION_AMOUNT_TRANSACTION_CURRENCY NUMBER(25,16) NOT NULL,
	COMMISSION_AMOUNT_COMPANY_CURRENCY NUMBER(25,16) NOT NULL,
	LINE_AMOUNT_TRANSACTION_CURRENCY NUMBER(25,16) NOT NULL,
	LINE_AMOUNT_COMPANY_CURRENCY NUMBER(25,16) NOT NULL,
	TAX_AMOUNT_TRANSACTION_CURRENCY NUMBER(38,16) NOT NULL,
	TAX_AMOUNT_COMPANY_CURRENCY NUMBER(38,16) NOT NULL,
	DISCOUNT_PERCENT NUMBER(25,16) NOT NULL,
	DISCOUNT_AMOUNT NUMBER(25,16) NOT NULL,
	LINE_DISCOUNT NUMBER(25,16) NOT NULL,
	LINE_DISCOUNT_PERCENT NUMBER(25,16) NOT NULL,
	FLOOR_LINE_DISCOUNT NUMBER(25,16) NOT NULL,
	LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY NUMBER(25,16) NOT NULL,
	LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY NUMBER(25,16) NOT NULL,
	COST_OF_GOODS_SOLD NUMBER(25,16) NOT NULL,
	FIXED_OVERHEAD NUMBER(25,16) NOT NULL,
	LABOR NUMBER(25,16) NOT NULL,
	MATERIAL NUMBER(25,16) NOT NULL,
	VARIABLE_OVERHEAD NUMBER(25,16) NOT NULL,
	FROZEN_COST_OF_GOODS_SOLD NUMBER(25,16) NOT NULL,
	FROZEN_FIXED_OVERHEAD NUMBER(25,16) NOT NULL,
	FROZEN_LABOR NUMBER(25,16) NOT NULL,
	FROZEN_MATERIAL NUMBER(25,16) NOT NULL,
	FROZEN_VARIABLE_OVERHEAD NUMBER(25,16) NOT NULL,
	STANDARD_COST NUMBER(25,16) NOT NULL,
	FROZEN_STANDARD_COST NUMBER(25,16) NOT NULL,
	PRICE_OVERRIDE_REASON_CODE VARCHAR(16777216) NOT NULL,
	PRICE_OVERRIDE_REASON_CODE_DESCRIPTION VARCHAR(16777216) NOT NULL,
	ISLR NUMBER(25,16) NOT NULL,
	RECORD_ID_POS NUMBER(38,0) NOT NULL,
	PRICE_TYPE VARCHAR(16777216) NOT NULL,
	ACTIVATION_DATE DATE NOT NULL,
	CREATED_DATETIME TIMESTAMP_TZ(9) NOT NULL,
	JOURNAL_NUMBER varchar not null,
	JOURNAL_NAME varchar not null,
	INVENTORY_SITE_ID varchar not null,											-- new column
	HK_HASH_KEY NUMBER(38,0) NOT NULL,
	HK_SOURCE_NAME VARCHAR(16777216) NOT NULL,
	HK_SOFT_DELETE_FLAG BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_CREATED_JOB_RUN_ID VARCHAR(16777216) NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID VARCHAR(16777216) NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL
);


-- insert historical data into table:
truncate table global.FACT_SALES_INVOICES_UPDATES;
insert into global.FACT_SALES_INVOICES_UPDATES (fact_sales_invoices_key, source_name, record_id, legal_entity, item_id, dim_source_system_key, dim_source_system_snkey, delivery_date_dim_date_key, delivery_date_dim_date_snkey, document_date_dim_date_key, document_date_dim_date_snkey, due_date_dim_date_key, due_date_dim_date_snkey, invoice_date_dim_date_key, invoice_date_dim_date_snkey, manufactured_date_dim_date_key, manufactured_date_dim_date_snkey, originating_order_created_date_dim_date_key, originating_order_created_date_dim_date_snkey, related_order_date_dim_date_key, related_order_date_dim_date_snkey, return_arrival_date_dim_date_key, return_arrival_date_dim_date_snkey, return_closed_date_dim_date_key, return_closed_date_dim_date_snkey, sales_line_created_date_dim_date_key, sales_line_created_date_dim_date_snkey, dim_business_unit_key, dim_business_unit_snkey, dim_campaign_key, dim_campaign_snkey, dim_commission_group_key, dim_commission_group_snkey, dim_cost_key, dim_cost_snkey, dim_currency_key, dim_currency_snkey, dim_customer_invoice_key, dim_customer_invoice_snkey, dim_customer_order_key, dim_customer_order_snkey, dim_customer_group_key, dim_customer_group_snkey, dim_customer_markup_group_key, dim_customer_markup_group_snkey, dim_default_dimension_key, dim_default_dimension_snkey, dim_global_trade_item_number_key, dim_global_trade_item_number_snkey, dim_intra_stat_transaction_code_key, dim_intra_stat_transaction_code_snkey, dim_inventory_key, dim_inventory_snkey, dim_item_key, dim_item_snkey, dim_item_status_key, dim_item_status_snkey, dim_legal_entity_key, dim_legal_entity_snkey, dim_line_return_reason_key, dim_line_return_reason_snkey, dim_location_delivery_address_key, dim_location_delivery_address_snkey, dim_location_invoice_address_key, dim_location_invoice_address_snkey, dim_delivery_mode_key, dim_delivery_mode_snkey, dim_delivery_term_key, dim_delivery_term_snkey, dim_payment_terms_key, dim_payment_terms_snkey, dim_procurement_category_key, dim_procurement_category_snkey, dim_return_disposition_key, dim_return_disposition_snkey, dim_return_reason_key, dim_return_reason_snkey, dim_sales_group_key, dim_sales_group_snkey, dim_sales_line_discount_group_key, dim_sales_line_discount_group_snkey, dim_sales_order_key, dim_sales_order_snkey, dim_sales_origin_key, dim_sales_origin_snkey, dim_sales_pool_key, dim_sales_pool_snkey, dim_sales_price_group_key, dim_sales_price_group_snkey, dim_tax_group_key, dim_tax_group_snkey, dim_tax_item_group_key, dim_tax_item_group_snkey, dim_unit_of_measure_sales_key, dim_unit_of_measure_sales_snkey, dim_warehouse_key, dim_warehouse_snkey, dim_worker_sales_responsible_key, dim_worker_sales_responsible_snkey, dim_worker_sales_taker_key, dim_worker_sales_taker_snkey, invoice_key, business_unit_id, campaign_id, commission_group_id, currency_code, customer_account_invoice, customer_account_order, customer_group_id, customer_markup_group_id, default_dimension, configuration_id, intra_stat_transaction_code, inventory_dimension_id, item_status, line_return_reason_id, line_return_reason_group_id, record_id_location_delivery_address, record_id_location_invoice_address, delivery_mode_id, delivery_term_id, payment_terms_id, procurement_category, return_disposition_id, return_reason_id, sales_group_id, sales_line_discount_group_id, sales_order_id, sales_origin_id, sales_pool_id, sales_price_group_id, tax_group_id, tax_item_group_id, unit_of_measure_code_sales, warehouse_id, record_id_sales_responsible, record_id_sales_taker, document_status, floor_sample_type, header_return_status, header_sales_status, return_status, sales_status, sales_type, ship_carrier_delivery_type, trade_line_delivery_type, is_at_agent_transaction, is_blind_shipment, is_expedited_shipment, is_floor_sample_discount, is_item_transaction, is_line_delivery_complete, is_order_blocked, is_order_line_blocked, is_order_locked, is_returned_item_scrap, is_ship_carrier_using_fuel_surcharge, is_stocked_product, drop_shipment, delivery_date, document_date, due_date, invoice_date, manufactured_date, originating_order_created_date, related_order_date, return_arrival_date, return_closed_date, sales_line_created_date, inventory_transaction_id, invoice_id, ledger_voucher, line_number, original_sales_order_id, production_time, purchase_order_id, originating_order_sales_id, registry_number, inventory_quantity, invoice_quantity, physical_quantity, price_unit, sales_price, commission_amount_transaction_currency, commission_amount_company_currency, line_amount_transaction_currency, line_amount_company_currency, tax_amount_transaction_currency, tax_amount_company_currency, discount_percent, discount_amount, line_discount, line_discount_percent, floor_line_discount, line_discount_total_transaction_currency, line_discount_total_company_currency, cost_of_goods_sold, fixed_overhead, labor, material, variable_overhead, frozen_cost_of_goods_sold, frozen_fixed_overhead, frozen_labor, frozen_material, frozen_variable_overhead, standard_cost, frozen_standard_cost, price_override_reason_code, price_override_reason_code_description, islr, record_id_pos, price_type, activation_date, created_datetime, journal_number, journal_name, inventory_site_id, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select a.fact_sales_invoices_key as FACT_SALES_INVOICES_KEY, a.source_name as SOURCE_NAME, a.record_id as RECORD_ID, a.legal_entity as LEGAL_ENTITY, a.item_id as ITEM_ID, a.dim_source_system_key as DIM_SOURCE_SYSTEM_KEY, a.dim_source_system_snkey as DIM_SOURCE_SYSTEM_SNKEY, a.delivery_date_dim_date_key as DELIVERY_DATE_DIM_DATE_KEY, a.delivery_date_dim_date_snkey as DELIVERY_DATE_DIM_DATE_SNKEY, a.document_date_dim_date_key as DOCUMENT_DATE_DIM_DATE_KEY, a.document_date_dim_date_snkey as DOCUMENT_DATE_DIM_DATE_SNKEY, a.due_date_dim_date_key as DUE_DATE_DIM_DATE_KEY, a.due_date_dim_date_snkey as DUE_DATE_DIM_DATE_SNKEY, a.invoice_date_dim_date_key as INVOICE_DATE_DIM_DATE_KEY, a.invoice_date_dim_date_snkey as INVOICE_DATE_DIM_DATE_SNKEY, a.manufactured_date_dim_date_key as MANUFACTURED_DATE_DIM_DATE_KEY, a.manufactured_date_dim_date_snkey as MANUFACTURED_DATE_DIM_DATE_SNKEY, a.originating_order_created_date_dim_date_key as ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY, a.originating_order_created_date_dim_date_snkey as ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY, a.related_order_date_dim_date_key as RELATED_ORDER_DATE_DIM_DATE_KEY, a.related_order_date_dim_date_snkey as RELATED_ORDER_DATE_DIM_DATE_SNKEY, a.return_arrival_date_dim_date_key as RETURN_ARRIVAL_DATE_DIM_DATE_KEY, a.return_arrival_date_dim_date_snkey as RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY, a.return_closed_date_dim_date_key as RETURN_CLOSED_DATE_DIM_DATE_KEY, a.return_closed_date_dim_date_snkey as RETURN_CLOSED_DATE_DIM_DATE_SNKEY, a.sales_line_created_date_dim_date_key as SALES_LINE_CREATED_DATE_DIM_DATE_KEY, a.sales_line_created_date_dim_date_snkey as SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY, a.dim_business_unit_key as DIM_BUSINESS_UNIT_KEY, a.dim_business_unit_snkey as DIM_BUSINESS_UNIT_SNKEY, a.dim_campaign_key as DIM_CAMPAIGN_KEY, a.dim_campaign_snkey as DIM_CAMPAIGN_SNKEY, a.dim_commission_group_key as DIM_COMMISSION_GROUP_KEY, a.dim_commission_group_snkey as DIM_COMMISSION_GROUP_SNKEY, a.dim_cost_key as DIM_COST_KEY, a.dim_cost_snkey as DIM_COST_SNKEY, a.dim_currency_key as DIM_CURRENCY_KEY, a.dim_currency_snkey as DIM_CURRENCY_SNKEY, a.dim_customer_invoice_key as DIM_CUSTOMER_INVOICE_KEY, a.dim_customer_invoice_snkey as DIM_CUSTOMER_INVOICE_SNKEY, a.dim_customer_order_key as DIM_CUSTOMER_ORDER_KEY, a.dim_customer_order_snkey as DIM_CUSTOMER_ORDER_SNKEY, a.dim_customer_group_key as DIM_CUSTOMER_GROUP_KEY, a.dim_customer_group_snkey as DIM_CUSTOMER_GROUP_SNKEY, a.dim_customer_markup_group_key as DIM_CUSTOMER_MARKUP_GROUP_KEY, a.dim_customer_markup_group_snkey as DIM_CUSTOMER_MARKUP_GROUP_SNKEY, a.dim_default_dimension_key as DIM_DEFAULT_DIMENSION_KEY, a.dim_default_dimension_snkey as DIM_DEFAULT_DIMENSION_SNKEY, a.dim_global_trade_item_number_key as DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY, a.dim_global_trade_item_number_snkey as DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY, a.dim_intra_stat_transaction_code_key as DIM_INTRA_STAT_TRANSACTION_CODE_KEY, a.dim_intra_stat_transaction_code_snkey as DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY, a.dim_inventory_key as DIM_INVENTORY_KEY, a.dim_inventory_snkey as DIM_INVENTORY_SNKEY, a.dim_item_key as DIM_ITEM_KEY, a.dim_item_snkey as DIM_ITEM_SNKEY, a.dim_item_status_key as DIM_ITEM_STATUS_KEY, a.dim_item_status_snkey as DIM_ITEM_STATUS_SNKEY, a.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY, a.dim_legal_entity_snkey as DIM_LEGAL_ENTITY_SNKEY, a.dim_line_return_reason_key as DIM_LINE_RETURN_REASON_KEY, a.dim_line_return_reason_snkey as DIM_LINE_RETURN_REASON_SNKEY, a.dim_location_delivery_address_key as DIM_LOCATION_DELIVERY_ADDRESS_KEY, a.dim_location_delivery_address_snkey as DIM_LOCATION_DELIVERY_ADDRESS_SNKEY, a.dim_location_invoice_address_key as DIM_LOCATION_INVOICE_ADDRESS_KEY, a.dim_location_invoice_address_snkey as DIM_LOCATION_INVOICE_ADDRESS_SNKEY, a.dim_delivery_mode_key as DIM_DELIVERY_MODE_KEY, a.dim_delivery_mode_snkey as DIM_DELIVERY_MODE_SNKEY, a.dim_delivery_term_key as DIM_DELIVERY_TERM_KEY, a.dim_delivery_term_snkey as DIM_DELIVERY_TERM_SNKEY, a.dim_payment_terms_key as DIM_PAYMENT_TERMS_KEY, a.dim_payment_terms_snkey as DIM_PAYMENT_TERMS_SNKEY, a.dim_procurement_category_key as DIM_PROCUREMENT_CATEGORY_KEY, a.dim_procurement_category_snkey as DIM_PROCUREMENT_CATEGORY_SNKEY, a.dim_return_disposition_key as DIM_RETURN_DISPOSITION_KEY, a.dim_return_disposition_snkey as DIM_RETURN_DISPOSITION_SNKEY, a.dim_return_reason_key as DIM_RETURN_REASON_KEY, a.dim_return_reason_snkey as DIM_RETURN_REASON_SNKEY, a.dim_sales_group_key as DIM_SALES_GROUP_KEY, a.dim_sales_group_snkey as DIM_SALES_GROUP_SNKEY, a.dim_sales_line_discount_group_key as DIM_SALES_LINE_DISCOUNT_GROUP_KEY, a.dim_sales_line_discount_group_snkey as DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY, a.dim_sales_order_key as DIM_SALES_ORDER_KEY, a.dim_sales_order_snkey as DIM_SALES_ORDER_SNKEY, a.dim_sales_origin_key as DIM_SALES_ORIGIN_KEY, a.dim_sales_origin_snkey as DIM_SALES_ORIGIN_SNKEY, a.dim_sales_pool_key as DIM_SALES_POOL_KEY, a.dim_sales_pool_snkey as DIM_SALES_POOL_SNKEY, a.dim_sales_price_group_key as DIM_SALES_PRICE_GROUP_KEY, a.dim_sales_price_group_snkey as DIM_SALES_PRICE_GROUP_SNKEY, a.dim_tax_group_key as DIM_TAX_GROUP_KEY, a.dim_tax_group_snkey as DIM_TAX_GROUP_SNKEY, a.dim_tax_item_group_key as DIM_TAX_ITEM_GROUP_KEY, a.dim_tax_item_group_snkey as DIM_TAX_ITEM_GROUP_SNKEY, a.dim_unit_of_measure_sales_key as DIM_UNIT_OF_MEASURE_SALES_KEY, a.dim_unit_of_measure_sales_snkey as DIM_UNIT_OF_MEASURE_SALES_SNKEY, a.dim_warehouse_key as DIM_WAREHOUSE_KEY, a.dim_warehouse_snkey as DIM_WAREHOUSE_SNKEY, a.dim_worker_sales_responsible_key as DIM_WORKER_SALES_RESPONSIBLE_KEY, a.dim_worker_sales_responsible_snkey as DIM_WORKER_SALES_RESPONSIBLE_SNKEY, a.dim_worker_sales_taker_key as DIM_WORKER_SALES_TAKER_KEY, a.dim_worker_sales_taker_snkey as DIM_WORKER_SALES_TAKER_SNKEY, a.invoice_key as INVOICE_KEY, a.business_unit_id as BUSINESS_UNIT_ID, a.campaign_id as CAMPAIGN_ID, a.commission_group_id as COMMISSION_GROUP_ID, a.currency_code as CURRENCY_CODE, a.customer_account_invoice as CUSTOMER_ACCOUNT_INVOICE, a.customer_account_order as CUSTOMER_ACCOUNT_ORDER, a.customer_group_id as CUSTOMER_GROUP_ID, a.customer_markup_group_id as CUSTOMER_MARKUP_GROUP_ID, a.default_dimension as DEFAULT_DIMENSION, a.configuration_id as CONFIGURATION_ID, a.intra_stat_transaction_code as INTRA_STAT_TRANSACTION_CODE, a.inventory_dimension_id as INVENTORY_DIMENSION_ID, a.item_status as ITEM_STATUS, a.line_return_reason_id as LINE_RETURN_REASON_ID, a.line_return_reason_group_id as LINE_RETURN_REASON_GROUP_ID, a.record_id_location_delivery_address as RECORD_ID_LOCATION_DELIVERY_ADDRESS, a.record_id_location_invoice_address as RECORD_ID_LOCATION_INVOICE_ADDRESS, a.delivery_mode_id as DELIVERY_MODE_ID, a.delivery_term_id as DELIVERY_TERM_ID, a.payment_terms_id as PAYMENT_TERMS_ID, a.procurement_category as PROCUREMENT_CATEGORY, a.return_disposition_id as RETURN_DISPOSITION_ID, a.return_reason_id as RETURN_REASON_ID, a.sales_group_id as SALES_GROUP_ID, a.sales_line_discount_group_id as SALES_LINE_DISCOUNT_GROUP_ID, a.sales_order_id as SALES_ORDER_ID, a.sales_origin_id as SALES_ORIGIN_ID, a.sales_pool_id as SALES_POOL_ID, a.sales_price_group_id as SALES_PRICE_GROUP_ID, a.tax_group_id as TAX_GROUP_ID, a.tax_item_group_id as TAX_ITEM_GROUP_ID, a.unit_of_measure_code_sales as UNIT_OF_MEASURE_CODE_SALES, a.warehouse_id as WAREHOUSE_ID, a.record_id_sales_responsible as RECORD_ID_SALES_RESPONSIBLE, a.record_id_sales_taker as RECORD_ID_SALES_TAKER, a.document_status as DOCUMENT_STATUS, a.floor_sample_type as FLOOR_SAMPLE_TYPE, a.header_return_status as HEADER_RETURN_STATUS, a.header_sales_status as HEADER_SALES_STATUS, a.return_status as RETURN_STATUS, a.sales_status as SALES_STATUS, a.sales_type as SALES_TYPE, a.ship_carrier_delivery_type as SHIP_CARRIER_DELIVERY_TYPE, a.trade_line_delivery_type as TRADE_LINE_DELIVERY_TYPE, a.is_at_agent_transaction as IS_AT_AGENT_TRANSACTION, a.is_blind_shipment as IS_BLIND_SHIPMENT, a.is_expedited_shipment as IS_EXPEDITED_SHIPMENT, a.is_floor_sample_discount as IS_FLOOR_SAMPLE_DISCOUNT, a.is_item_transaction as IS_ITEM_TRANSACTION, a.is_line_delivery_complete as IS_LINE_DELIVERY_COMPLETE, a.is_order_blocked as IS_ORDER_BLOCKED, a.is_order_line_blocked as IS_ORDER_LINE_BLOCKED, a.is_order_locked as IS_ORDER_LOCKED, a.is_returned_item_scrap as IS_RETURNED_ITEM_SCRAP, a.is_ship_carrier_using_fuel_surcharge as IS_SHIP_CARRIER_USING_FUEL_SURCHARGE, a.is_stocked_product as IS_STOCKED_PRODUCT, a.drop_shipment as DROP_SHIPMENT, a.delivery_date as DELIVERY_DATE, a.document_date as DOCUMENT_DATE, a.due_date as DUE_DATE, a.invoice_date as INVOICE_DATE, a.manufactured_date as MANUFACTURED_DATE, a.originating_order_created_date as ORIGINATING_ORDER_CREATED_DATE, a.related_order_date as RELATED_ORDER_DATE, a.return_arrival_date as RETURN_ARRIVAL_DATE, a.return_closed_date as RETURN_CLOSED_DATE, a.sales_line_created_date as SALES_LINE_CREATED_DATE, a.inventory_transaction_id as INVENTORY_TRANSACTION_ID, a.invoice_id as INVOICE_ID, a.ledger_voucher as LEDGER_VOUCHER, a.line_number as LINE_NUMBER, a.original_sales_order_id as ORIGINAL_SALES_ORDER_ID, a.production_time as PRODUCTION_TIME, a.purchase_order_id as PURCHASE_ORDER_ID, a.originating_order_sales_id as ORIGINATING_ORDER_SALES_ID, a.registry_number as REGISTRY_NUMBER, a.inventory_quantity as INVENTORY_QUANTITY, a.invoice_quantity as INVOICE_QUANTITY, a.physical_quantity as PHYSICAL_QUANTITY, a.price_unit as PRICE_UNIT, a.sales_price as SALES_PRICE, a.commission_amount_transaction_currency as COMMISSION_AMOUNT_TRANSACTION_CURRENCY, a.commission_amount_company_currency as COMMISSION_AMOUNT_COMPANY_CURRENCY, a.line_amount_transaction_currency as LINE_AMOUNT_TRANSACTION_CURRENCY, a.line_amount_company_currency as LINE_AMOUNT_COMPANY_CURRENCY, a.tax_amount_transaction_currency as TAX_AMOUNT_TRANSACTION_CURRENCY, a.tax_amount_company_currency as TAX_AMOUNT_COMPANY_CURRENCY, a.discount_percent as DISCOUNT_PERCENT, a.discount_amount as DISCOUNT_AMOUNT, a.line_discount as LINE_DISCOUNT, a.line_discount_percent as LINE_DISCOUNT_PERCENT, a.floor_line_discount as FLOOR_LINE_DISCOUNT, a.line_discount_total_transaction_currency as LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY, a.line_discount_total_company_currency as LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY, a.cost_of_goods_sold as COST_OF_GOODS_SOLD, a.fixed_overhead as FIXED_OVERHEAD, a.labor as LABOR, a.material as MATERIAL, a.variable_overhead as VARIABLE_OVERHEAD, a.frozen_cost_of_goods_sold as FROZEN_COST_OF_GOODS_SOLD, a.frozen_fixed_overhead as FROZEN_FIXED_OVERHEAD, a.frozen_labor as FROZEN_LABOR, a.frozen_material as FROZEN_MATERIAL, a.frozen_variable_overhead as FROZEN_VARIABLE_OVERHEAD, a.standard_cost as STANDARD_COST, a.frozen_standard_cost as FROZEN_STANDARD_COST, a.price_override_reason_code as PRICE_OVERRIDE_REASON_CODE, a.price_override_reason_code_description as PRICE_OVERRIDE_REASON_CODE_DESCRIPTION, a.islr as ISLR, a.record_id_pos as RECORD_ID_POS, a.price_type as PRICE_TYPE, a.activation_date as ACTIVATION_DATE, a.created_datetime as CREATED_DATETIME, a.journal_number as JOURNAL_NUMBER, a.journal_name as JOURNAL_NAME
		
		, a.inventory_site_id_new as INVENTORY_SITE_ID
		
		, a.hk_hash_key_new as HK_HASH_KEY
		
		, a.hk_source_name as HK_SOURCE_NAME, a.hk_soft_delete_flag as HK_SOFT_DELETE_FLAG, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP
	
		, a.hk_last_updated_timestamp_new as HK_LAST_UPDATED_TIMESTAMP
		
		, a.hk_warehouse_id as HK_WAREHOUSE_ID
	
	from (select f1.*
			, ''::varchar as INVENTORY_SITE_ID_NEW
			, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.legal_entity, '~', f1.item_id, '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.commission_group_id, '~', f1.currency_code, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_group_id, '~', f1.customer_markup_group_id, '~', f1.default_dimension, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_status, '~', f1.line_return_reason_id, '~', f1.line_return_reason_group_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.payment_terms_id, '~', to_char(f1.procurement_category), '~', f1.return_disposition_id, '~', f1.return_reason_id, '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_order_id, '~', f1.sales_origin_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.tax_group_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', f1.sales_status, '~', f1.sales_type, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.due_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', to_char(f1.manufactured_date, 'yyyymmdd'), '~', to_char(f1.originating_order_created_date, 'yyyymmdd'), '~', to_char(f1.related_order_date, 'yyyymmdd'), '~', to_char(f1.return_arrival_date, 'yyyymmdd'), '~', to_char(f1.return_closed_date, 'yyyymmdd'), '~', to_char(f1.sales_line_created_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.invoice_id, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', to_char(f1.production_time, 'yyyymmddhh24missff3'), '~', f1.purchase_order_id, '~', f1.originating_order_sales_id, '~', f1.registry_number, '~', to_char(f1.inventory_quantity), '~', to_char(f1.invoice_quantity), '~', to_char(f1.physical_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.sales_price), '~', to_char(f1.commission_amount_transaction_currency), '~', to_char(f1.commission_amount_company_currency), '~', to_char(f1.line_amount_transaction_currency), '~', to_char(f1.line_amount_company_currency), '~', to_char(f1.tax_amount_transaction_currency), '~', to_char(f1.tax_amount_company_currency), '~', to_char(f1.discount_percent), '~', to_char(f1.discount_amount), '~', to_char(f1.line_discount), '~', to_char(f1.line_discount_percent), '~', to_char(f1.floor_line_discount), '~', to_char(f1.line_discount_total_transaction_currency), '~', to_char(f1.line_discount_total_company_currency), '~', to_char(f1.cost_of_goods_sold), '~', to_char(f1.fixed_overhead), '~', to_char(f1.labor), '~', to_char(f1.material), '~', to_char(f1.variable_overhead), '~', to_char(f1.frozen_cost_of_goods_sold), '~', to_char(f1.frozen_fixed_overhead), '~', to_char(f1.frozen_labor), '~', to_char(f1.frozen_material), '~', to_char(f1.frozen_variable_overhead), '~', to_char(f1.standard_cost), '~', to_char(f1.frozen_standard_cost), '~', f1.price_override_reason_code, '~', f1.price_override_reason_code_description, '~', to_char(f1.islr), '~', to_char(f1.record_id_pos), '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.journal_number, '~', f1.journal_name, '~', INVENTORY_SITE_ID_NEW)::number as HK_HASH_KEY_NEW
			, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
		from global.FACT_SALES_INVOICES f1
		) a
;


create or replace table global.zzz_FACT_SALES_INVOICES clone global.FACT_SALES_INVOICES;
drop table if exists global.FACT_SALES_INVOICES;
alter table global.FACT_SALES_INVOICES_UPDATES rename to global.FACT_SALES_INVOICES;


drop table if exists global.zzz_FACT_SALES_INVOICES;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33729:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_INVENTORY_SUMMARY
    -- new:				n/a
    -- updated:			ITEM_STATUS, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_INVENTORY_SUMMARY a
set a.item_status = b.item_status_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_inventory_summary_key
		, ''::varchar as ITEM_STATUS_NEW
		
		, hash(f1.source_name, '~', f1.legal_entity, '~', f1.inventory_id, '~', f1.item_id, '~', f1.is_closed, '~', f1.no_open_quantities, '~', ITEM_STATUS_NEW, '~', to_char(f1.arrived), '~', to_char(f1.available_ordered), '~', to_char(f1.available_physical), '~', to_char(f1.deducted), '~', to_char(f1.on_order), '~', to_char(f1.ordered), '~', to_char(f1.picked), '~', to_char(f1.posted), '~', to_char(f1.received), '~', to_char(f1.registered), '~', to_char(f1.reserved_ordered), '~', to_char(f1.reserved_physical))::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_INVENTORY_SUMMARY f1
	where f1.item_status in ('0', '5637144578', '5637144579', '5637145328', '5637146826', '5637147578', '5637148327', '5637149076')
	and (f1.item_status != ITEM_STATUS_NEW
		)
	) b
where a.fact_inventory_summary_key = b.fact_inventory_summary_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_PURCHASE_INVOICES
    -- new:				INVENTORY_SITE_ID, CONFIGURATION_ID
    -- updated:			n/a
    -- removed:			n/a

create or replace TABLE global.FACT_PURCHASE_INVOICES_UPDATES (
	FACT_PURCHASE_INVOICES_KEY NUMBER(38,0) NOT NULL,
	SOURCE_NAME VARCHAR(16777216) NOT NULL,
	RECORD_ID NUMBER(38,0) NOT NULL,
	DIM_SOURCE_SYSTEM_KEY NUMBER(38,0) NOT NULL,
	DIM_SOURCE_SYSTEM_SNKEY NUMBER(38,0) NOT NULL,
	INVENTORY_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	INVENTORY_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	INVOICE_DATE_DIM_DATE_KEY NUMBER(38,0) NOT NULL,
	INVOICE_DATE_DIM_DATE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_COST_KEY NUMBER(38,0) NOT NULL,
	DIM_COST_SNKEY NUMBER(38,0) NOT NULL,
	DIM_CURRENCY_KEY NUMBER(38,0) NOT NULL,
	DIM_CURRENCY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_DEFAULT_DIMENSION_KEY NUMBER(38,0) NOT NULL,
	DIM_DEFAULT_DIMENSION_SNKEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_MODE_KEY NUMBER(38,0) NOT NULL,
	DIM_DELIVERY_MODE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_INTRA_STAT_TRANSACTION_CODE_KEY NUMBER(38,0) NOT NULL,
	DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_INVENTORY_KEY NUMBER(38,0) NOT NULL,
	DIM_INVENTORY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_KEY NUMBER(38,0) NOT NULL,
	DIM_ITEM_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LEGAL_ENTITY_KEY NUMBER(38,0) NOT NULL,
	DIM_LEGAL_ENTITY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_KEY NUMBER(38,0) NOT NULL,
	DIM_LOCATION_SNKEY NUMBER(38,0) NOT NULL,
	DIM_PROCUREMENT_CATEGORY_KEY NUMBER(38,0) NOT NULL,
	DIM_PROCUREMENT_CATEGORY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_PURCHASE_ORDER_KEY NUMBER(38,0) NOT NULL,
	DIM_PURCHASE_ORDER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_REASON_KEY NUMBER(38,0) NOT NULL,
	DIM_RETURN_REASON_SNKEY NUMBER(38,0) NOT NULL,
	DIM_TAX_ITEM_GROUP_KEY NUMBER(38,0) NOT NULL,
	DIM_TAX_ITEM_GROUP_SNKEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_INVENTORY_KEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_INVENTORY_SNKEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_PURCHASE_KEY NUMBER(38,0) NOT NULL,
	DIM_UNIT_OF_MEASURE_PURCHASE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_VENDOR_INVOICE_KEY NUMBER(38,0) NOT NULL,
	DIM_VENDOR_INVOICE_SNKEY NUMBER(38,0) NOT NULL,
	DIM_VENDOR_ORDER_KEY NUMBER(38,0) NOT NULL,
	DIM_VENDOR_ORDER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_ORDERER_KEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_ORDERER_SNKEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_REQUESTER_KEY NUMBER(38,0) NOT NULL,
	DIM_WORKER_REQUESTER_SNKEY NUMBER(38,0) NOT NULL,
	INVENTORY_DIMENSION_ID VARCHAR(16777216) NOT NULL,
	ITEM_ID VARCHAR(16777216) NOT NULL,
	PRICE_TYPE VARCHAR(16777216) NOT NULL,
	ACTIVATION_DATE DATE NOT NULL,
	CREATED_DATETIME TIMESTAMP_TZ(9) NOT NULL,
	CURRENCY_CODE VARCHAR(16777216) NOT NULL,
	DEFAULT_DIMENSION VARCHAR(16777216) NOT NULL,
	DELIVERY_MODE_ID VARCHAR(16777216) NOT NULL,
	INTRA_STAT_TRANSACTION_CODE VARCHAR(16777216) NOT NULL,
	RECORD_ID_LOCATION NUMBER(38,0) NOT NULL,
	PROCUREMENT_CATEGORY NUMBER(38,0) NOT NULL,
	RETURN_REASON_ID VARCHAR(16777216) NOT NULL,
	TAX_ITEM_GROUP_ID VARCHAR(16777216) NOT NULL,
	UNIT_OF_MEASURE_CODE_INVENTORY VARCHAR(16777216) NOT NULL,
	UNIT_OF_MEASURE_CODE_PURCHASE VARCHAR(16777216) NOT NULL,
	VENDOR_ACCOUNT_ID_INVOICE VARCHAR(16777216) NOT NULL,
	VENDOR_ACCOUNT_ID_ORDER VARCHAR(16777216) NOT NULL,
	RECORD_ID_ORDERER NUMBER(38,0) NOT NULL,
	RECORD_ID_REQUESTER NUMBER(38,0) NOT NULL,
	ASSET_TRANSACTION_TYPE VARCHAR(16777216) NOT NULL,
	DELIVERY_TYPE VARCHAR(16777216) NOT NULL,
	DOCUMENT_STATUS VARCHAR(16777216) NOT NULL,
	IS_STOCKED_PRODUCT VARCHAR(16777216) NOT NULL,
	PURCHASE_LINE_STATUS VARCHAR(16777216) NOT NULL,
	PURCHASE_HEADER_STATUS VARCHAR(16777216) NOT NULL,
	PURCHASE_TYPE VARCHAR(16777216) NOT NULL,
	INVENTORY_DATE DATE NOT NULL,
	INVOICE_DATE DATE NOT NULL,
	INVENTORY_TRANSACTION_ID VARCHAR(16777216) NOT NULL,
	LEGAL_ENTITY VARCHAR(16777216) NOT NULL,
	PURCHASE_ORDER_ID VARCHAR(16777216) NOT NULL,
	PURCHASE_INVOICE_ID VARCHAR(16777216) NOT NULL,
	LINE_NUMBER NUMBER(25,16) NOT NULL,
	PURCHASE_LINE_NUMBER NUMBER(38,0) NOT NULL,
	QTY_PURCHASE_UNIT NUMBER(25,16) NOT NULL,
	PURCHASE_UNIT VARCHAR(16777216) NOT NULL,
	QTY_INVENTORY_UNIT NUMBER(25,16) NOT NULL,
	INVENTORY_UNIT VARCHAR(16777216) NOT NULL,
	PRICE_UNIT NUMBER(25,16) NOT NULL,
	PURCHASE_PRICE NUMBER(25,16) NOT NULL,
	NET_AMOUNT_COMPANY_CURRENCY NUMBER(25,16) NOT NULL,
	NET_AMOUNT_TRANSACTION_CURRENCY NUMBER(25,16) NOT NULL,
	TAX_AMOUNT_SETTLEMENT_CURRENCY NUMBER(25,16) NOT NULL,
	STANDARD_COST NUMBER(25,16) NOT NULL,
	INVENTORY_SITE_ID varchar not null,											-- new column
	CONFIGURATION_ID varchar not null,											-- new column
	HK_HASH_KEY NUMBER(38,0) NOT NULL,
	HK_SOURCE_NAME VARCHAR(16777216) NOT NULL,
	HK_SOFT_DELETE_FLAG BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_CREATED_JOB_RUN_ID VARCHAR(16777216) NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID VARCHAR(16777216) NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL
);


-- insert historical data into table:
truncate table global.FACT_PURCHASE_INVOICES_UPDATES;
insert into global.FACT_PURCHASE_INVOICES_UPDATES (fact_purchase_invoices_key, source_name, record_id, dim_source_system_key, dim_source_system_snkey, inventory_date_dim_date_key, inventory_date_dim_date_snkey, invoice_date_dim_date_key, invoice_date_dim_date_snkey, dim_cost_key, dim_cost_snkey, dim_currency_key, dim_currency_snkey, dim_default_dimension_key, dim_default_dimension_snkey, dim_delivery_mode_key, dim_delivery_mode_snkey, dim_intra_stat_transaction_code_key, dim_intra_stat_transaction_code_snkey, dim_inventory_key, dim_inventory_snkey, dim_item_key, dim_item_snkey, dim_legal_entity_key, dim_legal_entity_snkey, dim_location_key, dim_location_snkey, dim_procurement_category_key, dim_procurement_category_snkey, dim_purchase_order_key, dim_purchase_order_snkey, dim_return_reason_key, dim_return_reason_snkey, dim_tax_item_group_key, dim_tax_item_group_snkey, dim_unit_of_measure_inventory_key, dim_unit_of_measure_inventory_snkey, dim_unit_of_measure_purchase_key, dim_unit_of_measure_purchase_snkey, dim_vendor_invoice_key, dim_vendor_invoice_snkey, dim_vendor_order_key, dim_vendor_order_snkey, dim_worker_orderer_key, dim_worker_orderer_snkey, dim_worker_requester_key, dim_worker_requester_snkey, inventory_dimension_id, item_id, price_type, activation_date, created_datetime, currency_code, default_dimension, delivery_mode_id, intra_stat_transaction_code, record_id_location, procurement_category, return_reason_id, tax_item_group_id, unit_of_measure_code_inventory, unit_of_measure_code_purchase, vendor_account_id_invoice, vendor_account_id_order, record_id_orderer, record_id_requester, asset_transaction_type, delivery_type, document_status, is_stocked_product, purchase_line_status, purchase_header_status, purchase_type, inventory_date, invoice_date, inventory_transaction_id, legal_entity, purchase_order_id, purchase_invoice_id, line_number, purchase_line_number, qty_purchase_unit, purchase_unit, qty_inventory_unit, inventory_unit, price_unit, purchase_price, net_amount_company_currency, net_amount_transaction_currency, tax_amount_settlement_currency, standard_cost, inventory_site_id, configuration_id, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select a.fact_purchase_invoices_key as FACT_PURCHASE_INVOICES_KEY, a.source_name as SOURCE_NAME, a.record_id as RECORD_ID, a.dim_source_system_key as DIM_SOURCE_SYSTEM_KEY, a.dim_source_system_snkey as DIM_SOURCE_SYSTEM_SNKEY, a.inventory_date_dim_date_key as INVENTORY_DATE_DIM_DATE_KEY, a.inventory_date_dim_date_snkey as INVENTORY_DATE_DIM_DATE_SNKEY, a.invoice_date_dim_date_key as INVOICE_DATE_DIM_DATE_KEY, a.invoice_date_dim_date_snkey as INVOICE_DATE_DIM_DATE_SNKEY, a.dim_cost_key as DIM_COST_KEY, a.dim_cost_snkey as DIM_COST_SNKEY, a.dim_currency_key as DIM_CURRENCY_KEY, a.dim_currency_snkey as DIM_CURRENCY_SNKEY, a.dim_default_dimension_key as DIM_DEFAULT_DIMENSION_KEY, a.dim_default_dimension_snkey as DIM_DEFAULT_DIMENSION_SNKEY, a.dim_delivery_mode_key as DIM_DELIVERY_MODE_KEY, a.dim_delivery_mode_snkey as DIM_DELIVERY_MODE_SNKEY, a.dim_intra_stat_transaction_code_key as DIM_INTRA_STAT_TRANSACTION_CODE_KEY, a.dim_intra_stat_transaction_code_snkey as DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY, a.dim_inventory_key as DIM_INVENTORY_KEY, a.dim_inventory_snkey as DIM_INVENTORY_SNKEY, a.dim_item_key as DIM_ITEM_KEY, a.dim_item_snkey as DIM_ITEM_SNKEY, a.dim_legal_entity_key as DIM_LEGAL_ENTITY_KEY, a.dim_legal_entity_snkey as DIM_LEGAL_ENTITY_SNKEY, a.dim_location_key as DIM_LOCATION_KEY, a.dim_location_snkey as DIM_LOCATION_SNKEY, a.dim_procurement_category_key as DIM_PROCUREMENT_CATEGORY_KEY, a.dim_procurement_category_snkey as DIM_PROCUREMENT_CATEGORY_SNKEY, a.dim_purchase_order_key as DIM_PURCHASE_ORDER_KEY, a.dim_purchase_order_snkey as DIM_PURCHASE_ORDER_SNKEY, a.dim_return_reason_key as DIM_RETURN_REASON_KEY, a.dim_return_reason_snkey as DIM_RETURN_REASON_SNKEY, a.dim_tax_item_group_key as DIM_TAX_ITEM_GROUP_KEY, a.dim_tax_item_group_snkey as DIM_TAX_ITEM_GROUP_SNKEY, a.dim_unit_of_measure_inventory_key as DIM_UNIT_OF_MEASURE_INVENTORY_KEY, a.dim_unit_of_measure_inventory_snkey as DIM_UNIT_OF_MEASURE_INVENTORY_SNKEY, a.dim_unit_of_measure_purchase_key as DIM_UNIT_OF_MEASURE_PURCHASE_KEY, a.dim_unit_of_measure_purchase_snkey as DIM_UNIT_OF_MEASURE_PURCHASE_SNKEY, a.dim_vendor_invoice_key as DIM_VENDOR_INVOICE_KEY, a.dim_vendor_invoice_snkey as DIM_VENDOR_INVOICE_SNKEY, a.dim_vendor_order_key as DIM_VENDOR_ORDER_KEY, a.dim_vendor_order_snkey as DIM_VENDOR_ORDER_SNKEY, a.dim_worker_orderer_key as DIM_WORKER_ORDERER_KEY, a.dim_worker_orderer_snkey as DIM_WORKER_ORDERER_SNKEY, a.dim_worker_requester_key as DIM_WORKER_REQUESTER_KEY, a.dim_worker_requester_snkey as DIM_WORKER_REQUESTER_SNKEY, a.inventory_dimension_id as INVENTORY_DIMENSION_ID, a.item_id as ITEM_ID, a.price_type as PRICE_TYPE, a.activation_date as ACTIVATION_DATE, a.created_datetime as CREATED_DATETIME, a.currency_code as CURRENCY_CODE, a.default_dimension as DEFAULT_DIMENSION, a.delivery_mode_id as DELIVERY_MODE_ID, a.intra_stat_transaction_code as INTRA_STAT_TRANSACTION_CODE, a.record_id_location as RECORD_ID_LOCATION, a.procurement_category as PROCUREMENT_CATEGORY, a.return_reason_id as RETURN_REASON_ID, a.tax_item_group_id as TAX_ITEM_GROUP_ID, a.unit_of_measure_code_inventory as UNIT_OF_MEASURE_CODE_INVENTORY, a.unit_of_measure_code_purchase as UNIT_OF_MEASURE_CODE_PURCHASE, a.vendor_account_id_invoice as VENDOR_ACCOUNT_ID_INVOICE, a.vendor_account_id_order as VENDOR_ACCOUNT_ID_ORDER, a.record_id_orderer as RECORD_ID_ORDERER, a.record_id_requester as RECORD_ID_REQUESTER, a.asset_transaction_type as ASSET_TRANSACTION_TYPE, a.delivery_type as DELIVERY_TYPE, a.document_status as DOCUMENT_STATUS, a.is_stocked_product as IS_STOCKED_PRODUCT, a.purchase_line_status as PURCHASE_LINE_STATUS, a.purchase_header_status as PURCHASE_HEADER_STATUS, a.purchase_type as PURCHASE_TYPE, a.inventory_date as INVENTORY_DATE, a.invoice_date as INVOICE_DATE, a.inventory_transaction_id as INVENTORY_TRANSACTION_ID, a.legal_entity as LEGAL_ENTITY, a.purchase_order_id as PURCHASE_ORDER_ID, a.purchase_invoice_id as PURCHASE_INVOICE_ID, a.line_number as LINE_NUMBER, a.purchase_line_number as PURCHASE_LINE_NUMBER, a.qty_purchase_unit as QTY_PURCHASE_UNIT, a.purchase_unit as PURCHASE_UNIT, a.qty_inventory_unit as QTY_INVENTORY_UNIT, a.inventory_unit as INVENTORY_UNIT, a.price_unit as PRICE_UNIT, a.purchase_price as PURCHASE_PRICE, a.net_amount_company_currency as NET_AMOUNT_COMPANY_CURRENCY, a.net_amount_transaction_currency as NET_AMOUNT_TRANSACTION_CURRENCY, a.tax_amount_settlement_currency as TAX_AMOUNT_SETTLEMENT_CURRENCY, a.standard_cost as STANDARD_COST
		
		, a.inventory_site_id_new as INVENTORY_SITE_ID
		, a.configration_id_new as CONFIGURATION_ID
		
		, a.hk_hash_key_new as HK_HASH_KEY
		
		, a.hk_source_name as HK_SOURCE_NAME, a.hk_soft_delete_flag as HK_SOFT_DELETE_FLAG, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP
	
		, a.hk_last_updated_timestamp_new as HK_LAST_UPDATED_TIMESTAMP
		
		, a.hk_warehouse_id as HK_WAREHOUSE_ID
	
	from (select f1.*
			, ''::varchar as INVENTORY_SITE_ID_NEW
			, ''::varchar as CONFIGRATION_ID_NEW
			
			, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.inventory_dimension_id, '~', f1.item_id, '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.currency_code, '~', f1.default_dimension, '~', f1.delivery_mode_id, '~', f1.intra_stat_transaction_code, '~', to_char(f1.record_id_location), '~', to_char(f1.procurement_category), '~', f1.return_reason_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_inventory, '~', f1.unit_of_measure_code_purchase, '~', f1.vendor_account_id_invoice, '~', f1.vendor_account_id_order, '~', to_char(f1.record_id_orderer), '~', to_char(f1.record_id_requester), '~', f1.asset_transaction_type, '~', f1.delivery_type, '~', f1.document_status, '~', f1.is_stocked_product, '~', f1.purchase_line_status, '~', f1.purchase_header_status, '~', f1.purchase_type, '~', to_char(f1.inventory_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.legal_entity, '~', f1.purchase_order_id, '~', f1.purchase_invoice_id, '~', to_char(f1.line_number), '~', to_char(f1.purchase_line_number), '~', to_char(f1.qty_purchase_unit), '~', f1.purchase_unit, '~', to_char(f1.qty_inventory_unit), '~', f1.inventory_unit, '~', to_char(f1.price_unit), '~', to_char(f1.purchase_price), '~', to_char(f1.net_amount_company_currency), '~', to_char(f1.net_amount_transaction_currency), '~', to_char(f1.tax_amount_settlement_currency), '~', to_char(f1.standard_cost), '~', INVENTORY_SITE_ID_NEW, '~', CONFIGRATION_ID_NEW)::number as HK_HASH_KEY_NEW
			, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
		from global.FACT_PURCHASE_INVOICES f1
		) a
;


create or replace table global.zzz_FACT_PURCHASE_INVOICES clone global.FACT_PURCHASE_INVOICES;
drop table if exists global.FACT_PURCHASE_INVOICES;
alter table global.FACT_PURCHASE_INVOICES_UPDATES rename to global.FACT_PURCHASE_INVOICES;


drop table if exists global.zzz_FACT_PURCHASE_INVOICES;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_PURCHASE_INVOICES
    -- new:				n/a
    -- updated:			DIM_COST_KEY, DIM_COST_SNKEY
    -- removed:			n/a

update global.FACT_PURCHASE_INVOICES a
set a.dim_cost_key = b.dim_cost_key_new
	, a.dim_cost_snkey = b.dim_cost_snkey_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_purchase_invoices_key
		, case when f1.item_id = '' then -2
			else coalesce(dc1.dim_cost_key, dc2.dim_cost_key, dc3.dim_cost_key, dc4.dim_cost_key, -1)
			end::number as DIM_COST_KEY_NEW
		, case when f1.item_id = '' then -2
			else coalesce(dc1.dim_cost_snkey, dc2.dim_cost_snkey, dc3.dim_cost_snkey, dc4.dim_cost_snkey, -1)
			end::number as DIM_COST_SNKEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_PURCHASE_INVOICES f1
	left join (select f10.fact_purchase_invoices_key, dc10.dim_cost_key, dc10.dim_cost_snkey
			from global.DIM_COST dc10
			inner join global.FACT_PURCHASE_INVOICES f10 on
				f10.legal_entity = dc10.legal_entity and
				f10.item_id = dc10.item_id and
				f10.configuration_id = dc10.configuration_id and
				f10.inventory_site_id = dc10.inventory_site_id
			where dc10.price_type_id = 0
			qualify row_number() over (partition by f10.fact_purchase_invoices_key order by dc10.activation_date desc, dc10.hk_last_updated_timestamp desc) = 1) dc1 on
		f1.fact_purchase_invoices_key = dc1.fact_purchase_invoices_key
	left join (select f20.fact_purchase_invoices_key, dc20.dim_cost_key, dc20.dim_cost_snkey
			from global.DIM_COST dc20
			inner join global.FACT_PURCHASE_INVOICES f20 on
				f20.legal_entity = dc20.legal_entity and
				f20.item_id = dc20.item_id and
				f20.inventory_site_id = dc20.inventory_site_id and
				f20.invoice_date >= dc20.activation_date
			where dc20.price_type_id = 0
			qualify row_number() over (partition by f20.fact_purchase_invoices_key order by dc20.activation_date desc, dc20.hk_last_updated_timestamp desc) = 1) dc2 on
		f1.fact_purchase_invoices_key = dc2.fact_purchase_invoices_key
	left join (select f30.fact_purchase_invoices_key, dc30.dim_cost_key, dc30.dim_cost_snkey
			from global.DIM_COST dc30
			inner join global.FACT_PURCHASE_INVOICES f30 on
				f30.legal_entity = dc30.legal_entity and
				f30.item_id = dc30.item_id and
				f30.configuration_id = dc30.configuration_id and
				f30.invoice_date >= dc30.activation_date
			where dc30.price_type_id = 0
			qualify row_number() over (partition by f30.fact_purchase_invoices_key order by dc30.activation_date desc, dc30.hk_last_updated_timestamp desc) = 1) dc3 on
		f1.fact_purchase_invoices_key = dc3.fact_purchase_invoices_key
	left join (select f40.fact_purchase_invoices_key, dc40.dim_cost_key, dc40.dim_cost_snkey
			from global.DIM_COST dc40
			inner join global.FACT_PURCHASE_INVOICES f40 on
				f40.legal_entity = dc40.legal_entity and
				f40.item_id = dc40.item_id and
				f40.invoice_date >= dc40.activation_date
			where dc40.price_type_id = 0
			qualify row_number() over (partition by f40.fact_purchase_invoices_key order by dc40.activation_date desc, dc40.hk_last_updated_timestamp desc) = 1) dc4 on
		f1.fact_purchase_invoices_key = dc4.fact_purchase_invoices_key
	where (f1.dim_cost_key != DIM_COST_KEY_NEW
		or f1.dim_cost_snkey != DIM_COST_SNKEY_NEW
		)
	) b
where a.fact_purchase_invoices_key = b.fact_purchase_invoices_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33864:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_DELIVERIES
    -- new:				n/a
    -- updated:			DIM_SALES_ORDER_KEY, DIM_SALES_ORDER_SNKEY
    -- removed:			n/a

update global.FACT_SALES_DELIVERIES a
set a.dim_sales_order_key = b.dim_sales_order_key_new
	, a.dim_sales_order_snkey = b.dim_sales_order_snkey_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_deliveries_key
		, case when nvl(f1.legal_entity, '') = '' or nvl(f1.original_sales_order_id, '') = '' then -2
			else hash(f1.source_name, '~', f1.legal_entity, '~', f1.original_sales_order_id)
			end::number as DIM_SALES_ORDER_SNKEY_NEW
		, nvl(dso1.dim_sales_order_key, -1)::number as DIM_SALES_ORDER_KEY_NEW
		
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_DELIVERIES f1
	left join global.DIM_SALES_ORDER dso1 on
		DIM_SALES_ORDER_SNKEY_NEW = dso1.dim_sales_order_snkey
	where (f1.dim_sales_order_key != DIM_SALES_ORDER_KEY_NEW
		or f1.dim_sales_order_snkey != DIM_SALES_ORDER_SNKEY_NEW
		)
	) b
where a.fact_sales_deliveries_key = b.fact_sales_deliveries_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35198:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_DELIVERIES
    -- new:				n/a
    -- updated:			SALES_STATUS, SALES_TYPE, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_DELIVERIES a
set a.sales_status = b.sales_status_new
	, a.sales_type = b.sales_type_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_deliveries_key
		, ''::varchar as SALES_STATUS_NEW
		, ''::varchar as SALES_TYPE_NEW
		
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_markup_group_id, '~', f1.default_dimension, '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.shipping_carrier_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', SALES_STATUS_NEW, '~', SALES_TYPE_NEW, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', f1.item_status, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.dhl_delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.sales_line_confirmed_shipping_date, 'yyyymmdd'), '~', to_char(f1.sales_line_requested_shipping_date, 'yyyymmdd'), '~', to_char(f1.ship_date, 'yyyymmdd'), '~', f1.bill_of_lading_id, '~', f1.carrier_id, '~', f1.carrier_name, '~', f1.internal_packing_slip_id, '~', f1.inventory_transaction_id, '~', f1.legal_entity, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', f1.packing_slip_id, '~', f1.purchase_order_id, '~', f1.sales_order_id, '~', to_char(f1.inventory_quantity), '~', to_char(f1.receipt_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.amount_company_currency), '~', f1.tracking_number, '~', f1.delivery_status, '~', f1.ebc_override_status)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_DELIVERIES f1
	where f1.source_name = 'AXNALA'
	and f1.sales_status != 'Delivered'
	and (f1.sales_status != SALES_STATUS_NEW
		or f1.sales_type != SALES_TYPE_NEW
		)
	) b
where a.fact_sales_deliveries_key = b.fact_sales_deliveries_key
;