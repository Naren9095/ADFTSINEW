--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_SOURCE_SYSTEM
    -- new:				<new record>
    -- updated:			n/a
    -- removed:			n/a

delete from global.DIM_SOURCE_SYSTEM where source_name = 'ATHENA';
insert into global.DIM_SOURCE_SYSTEM (dim_source_system_key, dim_source_system_snkey, source_name, source_description, active_flag, active_start_timestamp, active_end_timestamp, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select hash(a.source_name)::number as DIM_SOURCE_SYSTEM_KEY
		, hash(a.source_name)::number as DIM_SOURCE_SYSTEM_SNKEY
		, a.source_name as SOURCE_NAME
		, a.source_description as SOURCE_DESCRIPTION
		, a.active_flag as ACTIVE_FLAG
		, a.active_start_timestamp as ACTIVE_START_TIMESTAMP
		, a.active_end_timestamp as ACTIVE_END_TIMESTAMP
		, hash(a.source_name, '~', a.source_description, '~', to_char(a.active_flag), '~', to_char(a.active_start_timestamp, 'yyyymmddhh24missff3'), '~', to_char(a.active_end_timestamp, 'yyyymmddhh24missff3'))::number as HK_HASH_KEY
		, 'MANUAL'::varchar as HK_SOURCE_NAME
		, false::boolean as HK_SOFT_DELETE_FLAG
		, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
		, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
		, '-1'::varchar as HK_CREATED_JOB_RUN_ID
		, '-1'::varchar as HK_LAST_UPDATED_JOB_RUN_ID
		, '1950-01-01 00:00:00'::timestamp_tz as HK_CREATED_TIMESTAMP
		, '1950-01-01 00:00:00'::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string()::varchar as HK_WAREHOUSE_ID
	from (select 'ATHENA'::varchar as SOURCE_NAME
			, 'Athena'::varchar as SOURCE_DESCRIPTION
			, true::boolean as ACTIVE_FLAG
			, '1950-01-01 00:00:00'::timestamp_tz as ACTIVE_START_TIMESTAMP
			, '9000-01-01 00:00:00'::timestamp_tz as ACTIVE_END_TIMESTAMP
		) a
	left join global.DIM_SOURCE_SYSTEM dss1 on
		a.source_name = dss1.source_name
	where dss1.source_name is null
;


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	RLS_SALES
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.RLS_SALES (
	RLS_SALES_KEY									NUMBER NOT NULL,					-- Primary Key
	RLS_SALES_SNKEY									NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	AD_USER_ID										VARCHAR NOT NULL,					-- AK1.2
	REPORT_PARENT_ID								VARCHAR NOT NULL,					-- AK1.3
	SALES_REP_ID									VARCHAR NOT NULL,					-- AK1.4
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table

	DIVISION_ID										VARCHAR NOT NULL,
	REGION_ID										VARCHAR NOT NULL,
	CUSTOMER_NAME									VARCHAR NOT NULL,
	EMAIL_ADDRESS									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);