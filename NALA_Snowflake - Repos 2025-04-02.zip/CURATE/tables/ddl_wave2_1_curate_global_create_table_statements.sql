----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_ARKIEVA_CUSTOMER (SCD type-2)
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_ARKIEVA_CUSTOMER (
	DIM_ARKIEVA_CUSTOMER_KEY						NUMBER NOT NULL,					-- Primary Key
	DIM_ARKIEVA_CUSTOMER_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	ARKIEVA_CUSTOMER_ID 							VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	ARKIEVA_CUSTOMER_NAME							VARCHAR NOT NULL,
	--VALID_FROM									TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_START_TIMESTAMP
	--VALID_TO										TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_END_TIMESTAMP
	--IS_CURRENT									NUMBER NOT NULL,					---------------------------- replaced by HK_CURRENT_FLAG
	--IS_DELETED									NUMBER NOT NULL,					---------------------------- replaced by HK_SOFT_DELETE_FLAG
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_EFFECTIVE_START_TIMESTAMP					TIMESTAMP_TZ NOT NULL,				-- AK1.4
	HK_EFFECTIVE_END_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_CURRENT_FLAG									BOOLEAN NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_ARKIEVA_SUB_CHANNEL (SCD type-2)
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_ARKIEVA_SUB_CHANNEL (
	DIM_ARKIEVA_SUB_CHANNEL_KEY						NUMBER NOT NULL,					-- Primary Key
	DIM_ARKIEVA_SUB_CHANNEL_SNKEY					NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	ARKIEVA_SUB_CHANNEL_ID 							VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	ARKIEVA_SUB_CHANNEL								VARCHAR NOT NULL,
	--VALID_FROM									TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_START_TIMESTAMP
	--VALID_TO										TIMESTAMP_TZ NOT NULL,				---------------------------- replaced by HK_EFFECTIVE_END_TIMESTAMP
	--IS_CURRENT									NUMBER NOT NULL,					---------------------------- replaced by HK_CURRENT_FLAG
	--IS_DELETED									NUMBER NOT NULL,					---------------------------- replaced by HK_SOFT_DELETE_FLAG
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_EFFECTIVE_START_TIMESTAMP					TIMESTAMP_TZ NOT NULL,				-- AK1.4
	HK_EFFECTIVE_END_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_CURRENT_FLAG									BOOLEAN NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CAMPAIGN
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CAMPAIGN (
	DIM_CAMPAIGN_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_CAMPAIGN_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	CAMPAIGN_ID 									VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--DATA_SOURCE									VARCHAR NOT NULL,
	START_DATE										DATE NOT NULL,
	END_DATE										DATE NOT NULL,
	FOLLOW_UP_DATE									DATE NOT NULL,
	CAMPAIGN_NAME									VARCHAR NOT NULL,
	CAMPAIGN_OWNER									VARCHAR NOT NULL,
	CAMPAIGN_DESCRIPTION							VARCHAR NOT NULL,
	CAMPAIGN_STATUS									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CORPORATE_ALLOCATION_MAPPING
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_CORPORATE_ALLOCATION_MAPPING (
	DIM_CORPORATE_ALLOCATION_MAPPING_KEY			NUMBER NOT NULL,					-- Primary Key
	DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY			NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	MAIN_ACCOUNT 									VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	IBR_LINE										VARCHAR NOT NULL,
	TAM_CODE										VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);