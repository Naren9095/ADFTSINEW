-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_BUDGET_MODEL
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_BUDGET_MODEL (
	DIM_BUDGET_MODEL_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_BUDGET_MODEL_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME											VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY										VARCHAR NOT NULL,					-- AK1.2
	BUDGET_MODEL_ID 									VARCHAR NOT NULL,					-- AK1.3
	BUDGET_SUB_MODEL_ID									VARCHAR NOT NULL,					-- AK1.4
	BUDGET_MODEL_TYPE									VARCHAR NOT NULL,					-- AK1.5
	DIM_SOURCE_SYSTEM_SNKEY								NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--DW_ID												NUMBER NOT NULL,
	--BUDGETMODELKEY										NUMBER,
	BUDGET_MODEL										VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_TAX
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_TAX (
	DIM_TAX_KEY										NUMBER NOT NULL,					-- Primary Key
	DIM_TAX_SNKEY									NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	TAX_ID		 									VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--DW_ID											NUMBER NOT NULL,
	--TAXKEY											NUMBER,
	TAX_NAME										VARCHAR NOT NULL,
	TAX_PERIOD										VARCHAR NOT NULL,
	TAX_ACCOUNT_GROUP								VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);