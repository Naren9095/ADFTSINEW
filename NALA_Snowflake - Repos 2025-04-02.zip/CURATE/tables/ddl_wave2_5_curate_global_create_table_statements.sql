----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_TAX_GROUP
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_TAX_GROUP (
	DIM_TAX_GROUP_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_TAX_GROUP_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	TAX_GROUP_ID									VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	TAX_GROUP										VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_TAX_ITEM_GROUP
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_TAX_ITEM_GROUP (
	DIM_TAX_ITEM_GROUP_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_TAX_ITEM_GROUP_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	TAX_ITEM_GROUP_ID								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	TAX_ITEM_GROUP									VARCHAR NOT NULL,
	EU_SALES_LIST_TYPE								VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_TRADE_PROMOTION
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_TRADE_PROMOTION (
	DIM_TRADE_PROMOTION_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_TRADE_PROMOTION_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	LEGAL_ENTITY									VARCHAR NOT NULL,					-- AK1.2
	TRADE_PROMOTION_ID								VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	TRADE_PROMOTION									VARCHAR NOT NULL,
	HAS_BEEN_APPROVED_FOR_ACTIVITY					VARCHAR NOT NULL,
	CURRENCY_CODE									VARCHAR NOT NULL,
	CURRENCY										VARCHAR NOT NULL,
	PROMOTION_OWNER									VARCHAR NOT NULL,
	ORDERS_END_DATE									DATE NOT NULL,
	ORDERS_START_DATE								DATE NOT NULL,
	PROMOTION_STATUS_NAME							VARCHAR NOT NULL,
	PROMOTION_DISCOUNT_TYPE							VARCHAR NOT NULL,
	UNIT_OF_MEASURE_ID								VARCHAR NOT NULL,
	UNIT_OF_MEASURE									VARCHAR NOT NULL,
	DEAL_ID											VARCHAR NOT NULL,
	DEAL_TYPE										NUMBER NOT NULL,
	DEAL_TYPE_NAME									VARCHAR NOT NULL,
	CATALOG_STATUS									VARCHAR NOT NULL,
	DEAL_DESCRIPTION								VARCHAR NOT NULL,				------------- this had a space between the 2 words in SQL Server
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_TRAILERS
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_TRAILERS (
	DIM_TRAILERS_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_TRAILERS_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	DATA_AREA_ID									VARCHAR NOT NULL,					-- AK1.2
	TRAILER_NO										VARCHAR NOT NULL,					-- AK1.3
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	CARRIER_ID										VARCHAR NOT NULL,
	CUBIC_VOLUME									VARCHAR NOT NULL,
	TRAILER_CUBIC_VOLUME							VARCHAR NOT NULL,
	TRAILER_LENGTH									NUMBER NOT NULL,
	--TRAILER_KEY									NUMBER NOT NULL,
	CUBIC_VOLUME_INT								NUMBER NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_UNIT_OF_MEASURE
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

create or replace table global.DIM_UNIT_OF_MEASURE (
	DIM_UNIT_OF_MEASURE_KEY							NUMBER NOT NULL,					-- Primary Key
	DIM_UNIT_OF_MEASURE_SNKEY						NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	--RECORD_ID										NUMBER NOT NULL,					-- AK1.2
	UNIT_OF_MEASURE_CODE							VARCHAR NOT NULL,					-- AK1.2
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	UNIT_OF_MEASURE									VARCHAR NOT NULL,
	SYSTEM_OF_UNITS									VARCHAR NOT NULL,
	UNIT_OF_MEASURE_CLASS							VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_USER_INFO
    -- new:				<new table>
    -- updated:			n/a
    -- removed:			n/a

-- ************************************************************* duplicates in the table....take the AXNALA record over the Oracle one

create or replace table global.DIM_USER_INFO (
	DIM_USER_INFO_KEY								NUMBER NOT NULL,					-- Primary Key
	DIM_USER_INFO_SNKEY								NUMBER NOT NULL,					-- Surrogate Natural Key
	SOURCE_NAME										VARCHAR NOT NULL,					-- AK1.1
	USER_ID											VARCHAR NOT NULL,					-- AK1.2
	DIM_SOURCE_SYSTEM_SNKEY							NUMBER NOT NULL,					-- FK to DIM_SOURCE_SYSTEM table
	
	--DATASOURCE									VARCHAR NOT NULL,
	USER_NAME										VARCHAR NOT NULL,
	USER_IS_ENABLED									VARCHAR NOT NULL,
	
	HK_HASH_KEY										NUMBER NOT NULL,
	HK_SOURCE_NAME									VARCHAR NOT NULL,
	HK_SOFT_DELETE_FLAG								BOOLEAN NOT NULL,
	HK_SOURCE_CREATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_SOURCE_LAST_UPDATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL,
	HK_CREATED_JOB_RUN_ID							VARCHAR NOT NULL,
	HK_LAST_UPDATED_JOB_RUN_ID						VARCHAR NOT NULL,
	HK_CREATED_TIMESTAMP							TIMESTAMP_TZ NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP						TIMESTAMP_TZ NOT NULL,
	HK_WAREHOUSE_ID									VARCHAR NOT NULL
);