
/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_DIM_DATE
    CREATED BY     : Joshua Mills
    CREATED ON     : 01/26/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_DIM_DATE(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_DIM_DATE
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_DIM_DATE';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'GLOBAL';
    LET src_tbl STRING := 'DATE_CALENDAR';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'DIM_DATE';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_DATE_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.             a PK_ROW_NUMBER column should be included that is partitioned by the AK of the table ordered by a timestamp descending (latest AK record would have the highest PK_ROW_NUMBER value)
        g.              Working Columns: TGT_HK_HASH_KEY, PK_ROW_NUMBER

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                            0 AS DIM_DATE_KEY
                            , 0 AS DIM_DATE_SNKEY
                            , '''' AS SOURCE_NAME
                            , src.DATEVALUE AS DATE_VALUE
                            , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                            , to_char(src.DATEVALUE, ''YYYY-MM-DD'') AS DISPLAY_DATE
                            , to_number(to_char(src.DATEVALUE, ''DD'')) AS DAY_OF_MONTH
                            , decode(dayname(src.DATEVALUE), ''Mon'', ''Monday'', ''Tue'', ''Tuesday'', ''Wed'', ''Wednesday'', ''Thu'', ''Thursday'', ''Fri'', ''Friday'', ''Sat'', ''Saturday'', ''Sunday'') AS DAY_NAME
                            , decode(dayname(src.DATEVALUE), ''Mon'', 1, ''Tue'', 2, ''Wed'', 3, ''Thu'', 4, ''Fri'', 5, ''Sat'', 6, 7) AS DAY_OF_WEEK
                            , decode(dayname(src.DATEVALUE), ''Sat'', 0, ''Sun'', 0, 1) AS IS_WEEKDAY
                            , datediff(''day'',date_trunc(''QUARTER'', src.DATEVALUE), src.DATEVALUE) + 1 AS DAY_OF_QUARTER
                            , dayofyear(src.DATEVALUE) AS DAY_OF_YEAR
                            , to_number(   case when week(src.DATEVALUE) = 1 and month(src.DATEVALUE) = 12 then year(src.DATEVALUE) + 1       when week(src.DATEVALUE) >= 52 and month(src.DATEVALUE) = 1 then year(src.DATEVALUE) - 1     else year(src.DATEVALUE)   end || lpad(week(src.DATEVALUE), 2, ''0'') ) AS WEEK_KEY
                            , week(src.DATEVALUE) AS WEEK_NUMBER
                            , (''Week '' || week(src.DATEVALUE)) AS WEEK_NAME
                            , (''Week '' || week(src.DATEVALUE) || '' - '' ||   case when week(src.DATEVALUE) = 1 and month(src.DATEVALUE) = 12 then year(src.DATEVALUE) + 1       when week(src.DATEVALUE) >= 52 and month(src.DATEVALUE) = 1 then year(src.DATEVALUE) - 1   else year(src.DATEVALUE)   end) AS YEAR_WEEK_NAME
                            , floor(((date_part(day, src.DATEVALUE) - 1) / 7) + 1) AS WEEK_OF_MONTH
                            , ceil((datediff(day,   case when quarter(src.DATEVALUE) = 1 then datefromparts(year(src.DATEVALUE), 1, 1)     when quarter(src.DATEVALUE) = 2 then datefromparts(year(src.DATEVALUE), 4, 1)     when quarter(src.DATEVALUE) = 3 then datefromparts(year(src.DATEVALUE), 7, 1)   else datefromparts(year(src.DATEVALUE), 10, 1)   end , src.DATEVALUE) + 1) / 7) AS WEEK_OF_QUARTER
                            , week(src.DATEVALUE) AS WEEK_OF_YEAR
                            , month(src.DATEVALUE) AS MONTH_NUMBER
                            , to_char(src.DATEVALUE, ''MMMM'') AS MONTH_NAME
                            , to_char(src.DATEVALUE, ''MMMM'') || '' '' || year(src.DATEVALUE) AS YEAR_MONTH_NAME
                            , quarter(src.DATEVALUE) AS QUARTER_NUMBER
                            , (''Q'' || quarter(src.DATEVALUE)) AS SRC_QUARTER_NAME
                            , case when month(src.DATEVALUE) < 7 then 1 else 2 END AS HALF_YEAR
                            , case when month(src.DATEVALUE) < 7 then ''1st Half Year'' else ''2nd Half Year'' END AS SRC_HALF_YEAR_NAME
                            , (SRC_HALF_YEAR_NAME || '' '' || year(src.DATEVALUE)) AS YEAR_HALF_YEAR_NAME
                            , (SRC_QUARTER_NAME || '' '' || year(src.DATEVALUE)) AS YEAR_QUARTER_NAME
                            , year(src.DATEVALUE) AS YEAR_NUMBER
                            , (''CY'' || '' '' || year(src.DATEVALUE)) AS YEAR_NAME
                            , date_trunc(''month'', src.DATEVALUE) AS FIRST_DAY_OF_MONTH
                            , last_day(src.DATEVALUE) AS LAST_DAY_OF_MONTH
                            , date_trunc(''quarter'', src.DATEVALUE) AS FIRST_DAY_OF_QUARTER
                            , last_day(src.DATEVALUE, ''quarter'') AS LAST_DAY_OF_QUARTER
                            , date_trunc(''year'', src.DATEVALUE) AS FIRST_DAY_OF_YEAR
                            , last_day(src.DATEVALUE, ''year'') AS LAST_DAY_OF_YEAR
                            , to_char(src.DATEVALUE, ''yyyy'') || to_char(src.DATEVALUE, ''mm'') AS MONTH_KEY
                            , to_char(src.DATEVALUE, ''yyyy'') || lpad(quarter(src.DATEVALUE), 2, ''0'') AS QUARTER_KEY
                            , nvl(src.SMMCPERIOD, -1) AS SMMC_PERIOD
                            , nvl(src.SMMCPERIODDESCRIPTION, '''') AS SMMC_PERIOD_DESCRIPTION
                            , nvl(src.SMMCMONTHNAME, '''') AS SMMC_MONTH_NAME
                            , nvl(src.SMMCQUARTERNAME, '''') AS SMMC_QUARTER_NAME
                            , nvl(src.SMMCQUARTER, -1) AS SMMC_QUARTER
                            , nvl(src.SMMCYEARNAME, '''') AS SMMC_YEAR_NAME
                            , nvl(src.SMMCYEAR, '''') AS SMMC_YEAR
                            , nvl(src.SMMCISOPENINGPERIOD, -1) AS SMMC_IS_OPENING_PERIOD
                            , nvl(src.SMMCISCLOSINGPERIOD, -1) AS SMMC_IS_CLOSING_PERIOD
                            , dayname(src.DATEVALUE) AS SHORT_DAY_NAME
                            , (''W'' || week(src.DATEVALUE)) AS SHORT_WEEK_NAME
                            , monthname(src.DATEVALUE) AS SHORT_MONTH_NAME
                            , to_char(src.DATEVALUE, ''yy'') AS SHORT_YEAR
                            , monthname(src.DATEVALUE) || '' '' || to_char(src.DATEVALUE, ''yy'') AS SHORT_MONTH_YEAR
                            , (''Q'' || quarter(src.DATEVALUE) || '' '' || to_char(src.DATEVALUE, ''yy'')) AS SHORT_QUARTER_YEAR
                            , nvl(src.ALTFISCALYEAR,'''') AS ALT_FISCAL_YEAR
                            , nvl(src.ALTWEEKOFFISCALYEAR, '''') AS ALT_WEEK_OF_FISCAL_YEAR
                            , nvl(src.ALTBILLINGDAY, 0) AS ALT_BILLING_DAY
                            , nvl(src.FORECASTMONTHYEAR, '''') AS FORECAST_MONTH_YEAR
                            , nvl(src.FORECASTMONTH, '''') AS FORECAST_MONTH
                            , nvl(src.FORECASTWEEKYEAR, '''') AS FORECAST_WEEK_YEAR
                            , nvl(src.FORECASTWEEK, '''') AS FORECAST_WEEK
                            , nvl(src.CUMULATIVEDAYS, 0) AS CUMULATIVE_DAYS
                            , nvl(src.DAYOFFISCALMONTH, 0) AS DAY_OF_FISCAL_MONTH
                            , nvl(src.DAYOFFISCALYEAR, 0) AS DAY_OF_FISCAL_YEAR
                            , nvl(src.PERIODOFFISCALYEAR, 0) AS PERIOD_OF_FISCAL_YEAR
                            , nvl(src.WEEKOFFISCALMONTH, 0) AS WEEK_OF_FISCAL_MONTH
                            , 0 AS HK_HASH_KEY
                            , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                            , FALSE AS HK_SOFT_DELETE_FLAG
                            , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                            , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                            , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                            , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                            , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                            , uuid_string() AS HK_WAREHOUSE_ID
                            , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                ON src.DATEVALUE = tgt.DATE_VALUE
                            where
                                src.LATEST_MODIFIEDDATETIME > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_DATE_PREP_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_DATE_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1 
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash('''', ''~'', to_char(DATE_VALUE, ''yyyymmdd'')) AS DIM_DATE_KEY
                            , hash('''', ''~'', to_char(DATE_VALUE, ''yyyymmdd'')) AS DIM_DATE_SNKEY
                            , SOURCE_NAME
                            , DATE_VALUE
                            , case when SOURCE_NAME = '''' then -2 else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , DISPLAY_DATE
                            , DAY_OF_MONTH
                            , DAY_NAME
                            , DAY_OF_WEEK
                            , IS_WEEKDAY
                            , DAY_OF_QUARTER
                            , DAY_OF_YEAR
                            , WEEK_KEY
                            , WEEK_NUMBER
                            , WEEK_NAME
                            , YEAR_WEEK_NAME
                            , WEEK_OF_MONTH
                            , WEEK_OF_QUARTER
                            , WEEK_OF_YEAR
                            , MONTH_NUMBER
                            , MONTH_NAME
                            , YEAR_MONTH_NAME
                            , QUARTER_NUMBER
                            , SRC_QUARTER_NAME AS QUARTER_NAME
                            , HALF_YEAR
                            , SRC_HALF_YEAR_NAME AS HALF_YEAR_NAME
                            , YEAR_HALF_YEAR_NAME
                            , YEAR_QUARTER_NAME
                            , YEAR_NUMBER
                            , YEAR_NAME
                            , FIRST_DAY_OF_MONTH
                            , LAST_DAY_OF_MONTH
                            , FIRST_DAY_OF_QUARTER
                            , LAST_DAY_OF_QUARTER
                            , FIRST_DAY_OF_YEAR
                            , LAST_DAY_OF_YEAR
                            , MONTH_KEY
                            , QUARTER_KEY
                            , SMMC_PERIOD
                            , SMMC_PERIOD_DESCRIPTION
                            , SMMC_MONTH_NAME
                            , SMMC_QUARTER_NAME
                            , SMMC_QUARTER
                            , SMMC_YEAR_NAME
                            , SMMC_YEAR
                            , SMMC_IS_OPENING_PERIOD
                            , SMMC_IS_CLOSING_PERIOD
                            , SHORT_DAY_NAME
                            , SHORT_WEEK_NAME
                            , SHORT_MONTH_NAME
                            , SHORT_YEAR
                            , SHORT_MONTH_YEAR
                            , SHORT_QUARTER_YEAR
                            , ALT_FISCAL_YEAR
                            , ALT_WEEK_OF_FISCAL_YEAR
                            , ALT_BILLING_DAY
                            , FORECAST_MONTH_YEAR
                            , FORECAST_MONTH
                            , FORECAST_WEEK_YEAR
                            , FORECAST_WEEK
                            , CUMULATIVE_DAYS
                            , DAY_OF_FISCAL_MONTH
                            , DAY_OF_FISCAL_YEAR
                            , PERIOD_OF_FISCAL_YEAR
                            , WEEK_OF_FISCAL_MONTH
                            , hash(SOURCE_NAME, ''~'', to_char(DATE_VALUE, ''yyyymmdd''), ''~'', DISPLAY_DATE, ''~'', to_char(DAY_OF_MONTH), ''~'', DAY_NAME, ''~'', to_char(DAY_OF_WEEK), ''~'', to_char(IS_WEEKDAY), ''~'', to_char(DAY_OF_QUARTER), ''~'', to_char(DAY_OF_YEAR), ''~'', to_char(WEEK_KEY), ''~'', to_char(WEEK_NUMBER), ''~'', WEEK_NAME, ''~'', YEAR_WEEK_NAME, ''~'', to_char(WEEK_OF_MONTH), ''~'', to_char(WEEK_OF_QUARTER), ''~'', to_char(WEEK_OF_YEAR), ''~'', to_char(MONTH_NUMBER), ''~'', MONTH_NAME, ''~'', YEAR_MONTH_NAME, ''~'', to_char(QUARTER_NUMBER), ''~'', SRC_QUARTER_NAME, ''~'', to_char(HALF_YEAR), ''~'', SRC_HALF_YEAR_NAME, ''~'', YEAR_HALF_YEAR_NAME, ''~'', YEAR_QUARTER_NAME, ''~'', to_char(YEAR_NUMBER), ''~'', YEAR_NAME, ''~'', to_char(FIRST_DAY_OF_MONTH, ''yyyymmdd''), ''~'', to_char(LAST_DAY_OF_MONTH, ''yyyymmdd''), ''~'', to_char(FIRST_DAY_OF_QUARTER, ''yyyymmdd''), ''~'', to_char(LAST_DAY_OF_QUARTER, ''yyyymmdd''), ''~'', to_char(FIRST_DAY_OF_YEAR, ''yyyymmdd''), ''~'', to_char(LAST_DAY_OF_YEAR, ''yyyymmdd''), ''~'', to_char(MONTH_KEY), ''~'', to_char(QUARTER_KEY), ''~'', to_char(SMMC_PERIOD), ''~'', SMMC_PERIOD_DESCRIPTION, ''~'', SMMC_MONTH_NAME, ''~'', SMMC_QUARTER_NAME, ''~'', to_char(SMMC_QUARTER), ''~'', SMMC_YEAR_NAME, ''~'', SMMC_YEAR, ''~'', to_char(SMMC_IS_OPENING_PERIOD), ''~'', to_char(SMMC_IS_CLOSING_PERIOD), ''~'', SHORT_DAY_NAME, ''~'', SHORT_WEEK_NAME, ''~'', SHORT_MONTH_NAME, ''~'', SHORT_YEAR, ''~'', SHORT_MONTH_YEAR, ''~'', SHORT_QUARTER_YEAR, ''~'', ALT_FISCAL_YEAR, ''~'', ALT_WEEK_OF_FISCAL_YEAR, ''~'', to_char(ALT_BILLING_DAY), ''~'', FORECAST_MONTH_YEAR, ''~'', FORECAST_MONTH, ''~'', FORECAST_WEEK_YEAR, ''~'', FORECAST_WEEK, ''~'', to_char(CUMULATIVE_DAYS), ''~'', to_char(DAY_OF_FISCAL_MONTH), ''~'', to_char(DAY_OF_FISCAL_YEAR), ''~'', to_char(PERIOD_OF_FISCAL_YEAR), ''~'', to_char(WEEK_OF_FISCAL_MONTH)) AS SRC_HK_HASH_KEY
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
, row_number() over (partition by SOURCE_NAME, DATE_VALUE order by HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER                   
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' src 
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_LEGAL_ENTITY_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.DIM_LEGAL_ENTITY

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.DIM_DATE_KEY = tgt.DIM_DATE_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.DIM_DATE_KEY = tgt.DIM_DATE_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set                               
                                    tgt.DISPLAY_DATE = src.DISPLAY_DATE
                                    , tgt.DAY_OF_MONTH = src.DAY_OF_MONTH
                                    , tgt.DAY_NAME = src.DAY_NAME
                                    , tgt.DAY_OF_WEEK = src.DAY_OF_WEEK
                                    , tgt.IS_WEEKDAY = src.IS_WEEKDAY
                                    , tgt.DAY_OF_QUARTER = src.DAY_OF_QUARTER
                                    , tgt.DAY_OF_YEAR = src.DAY_OF_YEAR
                                    , tgt.WEEK_KEY = src.WEEK_KEY
                                    , tgt.WEEK_NUMBER = src.WEEK_NUMBER
                                    , tgt.WEEK_NAME = src.WEEK_NAME
                                    , tgt.YEAR_WEEK_NAME = src.YEAR_WEEK_NAME
                                    , tgt.WEEK_OF_MONTH = src.WEEK_OF_MONTH
                                    , tgt.WEEK_OF_QUARTER = src.WEEK_OF_QUARTER
                                    , tgt.WEEK_OF_YEAR = src.WEEK_OF_YEAR
                                    , tgt.MONTH_NUMBER = src.MONTH_NUMBER
                                    , tgt.MONTH_NAME = src.MONTH_NAME
                                    , tgt.YEAR_MONTH_NAME = src.YEAR_MONTH_NAME
                                    , tgt.QUARTER_NUMBER = src.QUARTER_NUMBER
                                    , tgt.QUARTER_NAME = src.QUARTER_NAME
                                    , tgt.HALF_YEAR = src.HALF_YEAR
                                    , tgt.HALF_YEAR_NAME = src.HALF_YEAR_NAME
                                    , tgt.YEAR_HALF_YEAR_NAME = src.YEAR_HALF_YEAR_NAME
                                    , tgt.YEAR_QUARTER_NAME = src.YEAR_QUARTER_NAME
                                    , tgt.YEAR_NUMBER = src.YEAR_NUMBER
                                    , tgt.YEAR_NAME = src.YEAR_NAME
                                    , tgt.FIRST_DAY_OF_MONTH = src.FIRST_DAY_OF_MONTH
                                    , tgt.LAST_DAY_OF_MONTH = src.LAST_DAY_OF_MONTH
                                    , tgt.FIRST_DAY_OF_QUARTER = src.FIRST_DAY_OF_QUARTER
                                    , tgt.LAST_DAY_OF_QUARTER = src.LAST_DAY_OF_QUARTER
                                    , tgt.FIRST_DAY_OF_YEAR = src.FIRST_DAY_OF_YEAR
                                    , tgt.LAST_DAY_OF_YEAR = src.LAST_DAY_OF_YEAR
                                    , tgt.MONTH_KEY = src.MONTH_KEY
                                    , tgt.QUARTER_KEY = src.QUARTER_KEY
                                    , tgt.SMMC_PERIOD = src.SMMC_PERIOD
                                    , tgt.SMMC_PERIOD_DESCRIPTION = src.SMMC_PERIOD_DESCRIPTION
                                    , tgt.SMMC_MONTH_NAME = src.SMMC_MONTH_NAME
                                    , tgt.SMMC_QUARTER_NAME = src.SMMC_QUARTER_NAME
                                    , tgt.SMMC_QUARTER = src.SMMC_QUARTER
                                    , tgt.SMMC_YEAR_NAME = src.SMMC_YEAR_NAME
                                    , tgt.SMMC_YEAR = src.SMMC_YEAR
                                    , tgt.SMMC_IS_OPENING_PERIOD = src.SMMC_IS_OPENING_PERIOD
                                    , tgt.SMMC_IS_CLOSING_PERIOD = src.SMMC_IS_CLOSING_PERIOD
                                    , tgt.SHORT_DAY_NAME = src.SHORT_DAY_NAME
                                    , tgt.SHORT_WEEK_NAME = src.SHORT_WEEK_NAME
                                    , tgt.SHORT_MONTH_NAME = src.SHORT_MONTH_NAME
                                    , tgt.SHORT_YEAR = src.SHORT_YEAR
                                    , tgt.SHORT_MONTH_YEAR = src.SHORT_MONTH_YEAR
                                    , tgt.SHORT_QUARTER_YEAR = src.SHORT_QUARTER_YEAR
                                    , tgt.ALT_FISCAL_YEAR = src.ALT_FISCAL_YEAR
                                    , tgt.ALT_WEEK_OF_FISCAL_YEAR = src.ALT_WEEK_OF_FISCAL_YEAR
                                    , tgt.ALT_BILLING_DAY = src.ALT_BILLING_DAY
                                    , tgt.FORECAST_MONTH_YEAR = src.FORECAST_MONTH_YEAR
                                    , tgt.FORECAST_MONTH = src.FORECAST_MONTH
                                    , tgt.FORECAST_WEEK_YEAR = src.FORECAST_WEEK_YEAR
                                    , tgt.FORECAST_WEEK = src.FORECAST_WEEK
                                    , tgt.CUMULATIVE_DAYS = src.CUMULATIVE_DAYS
                                    , tgt.DAY_OF_FISCAL_MONTH = src.DAY_OF_FISCAL_MONTH
                                    , tgt.DAY_OF_FISCAL_YEAR = src.DAY_OF_FISCAL_YEAR
                                    , tgt.PERIOD_OF_FISCAL_YEAR = src.PERIOD_OF_FISCAL_YEAR
                                    , tgt.WEEK_OF_FISCAL_MONTH = src.WEEK_OF_FISCAL_MONTH
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                           INSERT
                            (
                             DIM_DATE_KEY
                            ,DIM_DATE_SNKEY
                            ,SOURCE_NAME
                            ,DATE_VALUE
                            ,DIM_SOURCE_SYSTEM_SNKEY
                            ,DISPLAY_DATE
                            ,DAY_OF_MONTH
                            ,DAY_NAME
                            ,DAY_OF_WEEK
                            ,IS_WEEKDAY
                            ,DAY_OF_QUARTER
                            ,DAY_OF_YEAR
                            ,WEEK_KEY
                            ,WEEK_NUMBER
                            ,WEEK_NAME
                            ,YEAR_WEEK_NAME
                            ,WEEK_OF_MONTH
                            ,WEEK_OF_QUARTER
                            ,WEEK_OF_YEAR
                            ,MONTH_NUMBER
                            ,MONTH_NAME
                            ,YEAR_MONTH_NAME
                            ,QUARTER_NUMBER
                            ,QUARTER_NAME
                            ,HALF_YEAR
                            ,HALF_YEAR_NAME
                            ,YEAR_HALF_YEAR_NAME
                            ,YEAR_QUARTER_NAME
                            ,YEAR_NUMBER
                            ,YEAR_NAME
                            ,FIRST_DAY_OF_MONTH
                            ,LAST_DAY_OF_MONTH
                            ,FIRST_DAY_OF_QUARTER
                            ,LAST_DAY_OF_QUARTER
                            ,FIRST_DAY_OF_YEAR
                            ,LAST_DAY_OF_YEAR
                            ,MONTH_KEY
                            ,QUARTER_KEY
                            ,SMMC_PERIOD
                            ,SMMC_PERIOD_DESCRIPTION
                            ,SMMC_MONTH_NAME
                            ,SMMC_QUARTER_NAME
                            ,SMMC_QUARTER
                            ,SMMC_YEAR_NAME
                            ,SMMC_YEAR
                            ,SMMC_IS_OPENING_PERIOD
                            ,SMMC_IS_CLOSING_PERIOD
                            ,SHORT_DAY_NAME
                            ,SHORT_WEEK_NAME
                            ,SHORT_MONTH_NAME
                            ,SHORT_YEAR
                            ,SHORT_MONTH_YEAR
                            ,SHORT_QUARTER_YEAR
                            ,ALT_FISCAL_YEAR
                            ,ALT_WEEK_OF_FISCAL_YEAR
                            ,ALT_BILLING_DAY
                            ,FORECAST_MONTH_YEAR
                            ,FORECAST_MONTH
                            ,FORECAST_WEEK_YEAR
                            ,FORECAST_WEEK
                            ,CUMULATIVE_DAYS
                            ,DAY_OF_FISCAL_MONTH
                            ,DAY_OF_FISCAL_YEAR
                            ,PERIOD_OF_FISCAL_YEAR
                            ,WEEK_OF_FISCAL_MONTH
                            ,HK_HASH_KEY
                            ,HK_SOURCE_NAME
                            ,HK_SOFT_DELETE_FLAG
                            ,HK_SOURCE_CREATED_TIMESTAMP
                            ,HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            ,HK_CREATED_JOB_RUN_ID
                            ,HK_LAST_UPDATED_JOB_RUN_ID
                            ,HK_CREATED_TIMESTAMP
                            ,HK_LAST_UPDATED_TIMESTAMP
                            ,HK_WAREHOUSE_ID
                            )
                             VALUES
                            (
                             src.DIM_DATE_KEY
                            ,src.DIM_DATE_SNKEY
                            ,src.SOURCE_NAME
                            ,src.DATE_VALUE
                            ,src.DIM_SOURCE_SYSTEM_SNKEY
                            ,src.DISPLAY_DATE
                            ,src.DAY_OF_MONTH
                            ,src.DAY_NAME
                            ,src.DAY_OF_WEEK
                            ,src.IS_WEEKDAY
                            ,src.DAY_OF_QUARTER
                            ,src.DAY_OF_YEAR
                            ,src.WEEK_KEY
                            ,src.WEEK_NUMBER
                            ,src.WEEK_NAME
                            ,src.YEAR_WEEK_NAME
                            ,src.WEEK_OF_MONTH
                            ,src.WEEK_OF_QUARTER
                            ,src.WEEK_OF_YEAR
                            ,src.MONTH_NUMBER
                            ,src.MONTH_NAME
                            ,src.YEAR_MONTH_NAME
                            ,src.QUARTER_NUMBER
                            ,src.QUARTER_NAME
                            ,src.HALF_YEAR
                            ,src.HALF_YEAR_NAME
                            ,src.YEAR_HALF_YEAR_NAME
                            ,src.YEAR_QUARTER_NAME
                            ,src.YEAR_NUMBER
                            ,src.YEAR_NAME
                            ,src.FIRST_DAY_OF_MONTH
                            ,src.LAST_DAY_OF_MONTH
                            ,src.FIRST_DAY_OF_QUARTER
                            ,src.LAST_DAY_OF_QUARTER
                            ,src.FIRST_DAY_OF_YEAR
                            ,src.LAST_DAY_OF_YEAR
                            ,src.MONTH_KEY
                            ,src.QUARTER_KEY
                            ,src.SMMC_PERIOD
                            ,src.SMMC_PERIOD_DESCRIPTION
                            ,src.SMMC_MONTH_NAME
                            ,src.SMMC_QUARTER_NAME
                            ,src.SMMC_QUARTER
                            ,src.SMMC_YEAR_NAME
                            ,src.SMMC_YEAR
                            ,src.SMMC_IS_OPENING_PERIOD
                            ,src.SMMC_IS_CLOSING_PERIOD
                            ,src.SHORT_DAY_NAME
                            ,src.SHORT_WEEK_NAME
                            ,src.SHORT_MONTH_NAME
                            ,src.SHORT_YEAR
                            ,src.SHORT_MONTH_YEAR
                            ,src.SHORT_QUARTER_YEAR
                            ,src.ALT_FISCAL_YEAR
                            ,src.ALT_WEEK_OF_FISCAL_YEAR
                            ,src.ALT_BILLING_DAY
                            ,src.FORECAST_MONTH_YEAR
                            ,src.FORECAST_MONTH
                            ,src.FORECAST_WEEK_YEAR
                            ,src.FORECAST_WEEK
                            ,src.CUMULATIVE_DAYS
                            ,src.DAY_OF_FISCAL_MONTH
                            ,src.DAY_OF_FISCAL_YEAR
                            ,src.PERIOD_OF_FISCAL_YEAR
                            ,src.WEEK_OF_FISCAL_MONTH
                            ,src.SRC_HK_HASH_KEY
                            ,src.HK_SOURCE_NAME
                            ,src.HK_SOFT_DELETE_FLAG
                            ,src.HK_SOURCE_CREATED_TIMESTAMP
                            ,src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            ,src.HK_CREATED_JOB_RUN_ID
                            ,src.HK_LAST_UPDATED_JOB_RUN_ID
                            ,src.HK_CREATED_TIMESTAMP
                            ,src.HK_LAST_UPDATED_TIMESTAMP
                            ,src.HK_WAREHOUSE_ID
                            );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '6';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '7';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging stored procedure completed
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '9';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;
