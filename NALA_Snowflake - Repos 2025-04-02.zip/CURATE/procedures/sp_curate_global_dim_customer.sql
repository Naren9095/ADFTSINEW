
/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_DIM_CUSTOMER
    CREATED BY     : Joshua Mills
    CREATED ON     : 03/25/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_DIM_RETURN_REASON(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_DIM_CUSTOMER
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_DIM_CUSTOMER';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'CUSTTABLE';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'DIM_CUSTOMER';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest record for each SNKEY since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY, SRC_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS DIM_CUSTOMER_KEY
                                , 0 AS DIM_CUSTOMER_SNKEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.DATAAREAID AS LEGAL_ENTITY
                                , src.ACCOUNTNUM AS CUSTOMER_ACCOUNT
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , nvl(src.DIRPARTYTABLE1_NAME, '''') AS CUSTOMER_NAME
                                , case when src.DIRPARTYTABLE1_INSTANCERELATIONTYPE = 2975 then ''Person'' else ''Organization'' END AS RECORD_TYPE
                                , nvl(src.EBCCOMPANYID, '''') AS CUSTOMER_COMPANY_TYPE
                                , nvl(src.DIRPARTYTABLE1_EBCLEGACY, '''') AS LEGACY_CUSTOMER
                                , nvl(src.OURACCOUNTNUM, '''') AS LEGACY_CONSUMER_NUMBER
                                , nvl(src.DIRPARTYTABLE1_ORGNUMBER, '''') AS ORGANIZATION_NUMBER
                                , nvl(src.INVOICEACCOUNT, '''') AS INVOICE_ACCOUNT
                                , nvl(src.CURRENCY, '''') AS CUSTOMER_CURRENCY_CODE
                                , nvl(src.CURRENCY_TXT, '''') AS CUSTOMER_CURRENCY_NAME
                                , case when src.USECASHDISC = 1 then ''Yes'' else ''No'' END AS USE_CASH_DISCOUNT
                                , nvl(src.HCMWORKER1_PERSONNELNUMBER, '''') AS SALES_REPRESENTATIVE_ID
                                , nvl(src.DIRPARTYTABLE2_NAME, '''') AS SALES_REPRESENTATIVE
                                , case when src.BLOCKED = 1 then ''Yes'' else ''No'' END AS CUSTOMER_IS_BLOCKED
                                , case when src.PASTDUECHECK = 1 then ''Yes'' else ''No'' END AS IS_PAST_DUE_CHECK
                                , nvl(src.CREDITMAX, 0) AS CREDIT_LIMIT
                                , case when src.MANDATORYCREDITLIMIT = 1 then ''Yes'' else ''No'' END AS IS_MANDATORY_CREDIT_LIMIT
                                , case when src.EXCLUDECREDITLIMITBLOCKING = 1 then ''Yes'' else ''No'' END AS IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                                , nvl(src.GRACEDAYS, 0) AS GRACE_DAYS
                                , nvl(src.TSIAVGDAYS_CPAVGDAY, 0) AS CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                                , nvl(src.TSIAVGDAYS_YRAVGDAY, 0) AS YEARLY_AVERAGE_DAYS_TO_PAY
                                , case when src.EBCBUYGRPEXEMPTION = 1 then ''Yes'' else ''No'' END AS BUYING_GROUP_EXEMPT
                                , case when src.EBCBUYGRPKICKER = 1 then ''Yes'' else ''No'' END AS BUYING_GROUP_KICKER
                                , nvl(src.CASHDISC, '''') AS DEFAULT_CASH_DISCOUNT_ID
                                , nvl(src.CASHDISC_DESCRIPTION, '''') AS DEFAULT_CASH_DISCOUNT
                                , nvl(src.CASHDISC_PERCENT, 0) AS DEFAULT_CASH_DISCOUNT_PERCENT
                                , nvl(src.DLVMODE, '''') AS DEFAULT_DELIVERY_MODE_ID
                                , nvl(src.DLVMODE_TXT, '''') AS DEFAULT_DELIVERY_MODE
                                , nvl(src.DLVTERM, '''') AS DEFAULT_DELIVERY_TERMS_ID
                                , nvl(src.DLVTERM_TXT, '''') AS DEFAULT_DELIVERY_TERMS
                                , nvl(src.PAYMMODE, '''') AS DEFAULT_PAYMENT_MODE_ID
                                , nvl(src.CUSTPAYMMODETABLE_NAME, '''') AS DEFAULT_PAYMENT_MODE
                                , nvl(src.PAYMTERMID, '''') AS DEFAULT_PAYMENT_TERMS_ID
                                , nvl(src.PAYMTERM_DESCRIPTION, '''') AS DEFAULT_PAYMENT_TERMS
                                , nvl(src.PAYMTERM_NUMOFDAYS, 0) AS PAYMENT_TERMS_NUMBER_OF_DAYS
                                , nvl(src.PAYMTERM_NUMOFMONTHS, 0) AS PAYMENT_TERMS_NUMBER_OF_MONTHS
                                , nvl(src.CUSTCLASSIFICATIONID, '''') AS CLASSIFICATION_GROUP_ID
                                , nvl(src.CUSTCLASSIFICATIONGROUP_TXT, '''') AS CLASSIFICATION_GROUP
                                , nvl(src.COMPANYCHAINID, '''') AS COMPANY_CHAIN_ID
                                , nvl(src.SMMBUSRELCHAINGROUP_DESCRIPTION, '''') AS COMPANY_CHAIN
                                , nvl(src.CUSTGROUP, '''') AS CUSTOMER_GROUP_ID
                                , nvl(src.CUSTGROUP_NAME, '''') AS CUSTOMER_GROUP
                                , nvl(src.EBCDIVISIONID, '''') AS DIVISION_ID
                                , nvl(src.EBCSALESMKTDIVISION1_EBCDIVISIONDESC, '''') AS DIVISION
                                , nvl(src.LINEOFBUSINESSID, '''') AS LINE_OF_BUSINESS_ID
                                , nvl(src.LINEOFBUSINESS_DESCRIPTION, '''') AS LINE_OF_BUSINESS
                                , nvl(src.MARKUPGROUP, '''') AS MARKUP_GROUP_ID
                                , nvl(src.MARKUPGROUP_TXT, '''') AS MARKUP_GROUP
                                , nvl(src.PRICEGROUP, '''') AS PRICE_GROUP_ID
                                , nvl(src.PRICEDISCGROUP_NAME, '''') AS PRICE_GROUP
                                , nvl(src.DEFAULTDIMENSION_C_SALES_CHANNEL, '''') AS SALES_CHANNEL_ID
                                , nvl(src.DEFAULTDIMENSION_C_SALES_CHANNEL_DESCRIPTION, '''') AS SALES_CHANNEL
                                , nvl(src.SALESDISTRICTID, '''') AS SALES_DISTRICT_ID
                                , nvl(src.SMMBUSRELSALESDISTRICTGROUP1_DESCRIPTION, '''') AS SALES_DISTRICT
                                , nvl(src.SALESGROUP, '''') AS SALES_GROUP_ID
                                , nvl(src.COMMISSIONSALESGROUP_NAME, '''') AS SALES_GROUP
                                , nvl(src.SALESPOOLID, '''') AS SALES_POOL_ID
                                , nvl(src.SALESPOOL_NAME, '''') AS SALES_POOL
                                , nvl(src.SEGMENTID, '''') AS SEGMENT_ID
                                , nvl(src.SMMBUSRELSEGMENTGROUP_DESCRIPTION, '''') AS SEGMENT
                                , nvl(src.SUBSEGMENTID, '''') AS SUB_SEGMENT_ID
                                , nvl(src.SMMBUSRELSUBSEGMENTGROUP_DESCRIPTION, '''') AS SUB_SEGMENT
                                , nvl(src.TAXGROUP, '''') AS TAX_GROUP_ID
                                , nvl(src.TAXGROUPHEADING_TAXGROUPNAME, '''') AS TAX_GROUP
                                , nvl(src.LOGISTICSPOSTALADDRESS1_STREET, '''') AS PRIMARY_STREET
                                , nvl(src.LOGISTICSPOSTALADDRESS1_CITY, '''') AS PRIMARY_CITY
                                , nvl(src.LOGISTICSPOSTALADDRESS1_STATE, '''') AS PRIMARY_STATE
                                , nvl(src.LOGISTICSPOSTALADDRESS1_ZIPCODE, '''') AS PRIMARY_ZIP_CODE
                                , nvl(src.LOGISTICSPOSTALADDRESS1_COUNTRYREGIONID, '''') AS PRIMARY_COUNTRY
                                , nvl(src.TIMEZONESLIST_TIMEZONEKEYNAME, '''') AS PRIMARY_TIME_ZONE
                                , nvl(src.LOGISTICSLOCATION1_DESCRIPTION, '''') AS PRIMARY_ADDRESS_NAME
                                , nvl(src.LOGISTICSELECTRONICADDRESS1_LOCATOR, '''') AS PRIMARY_EMAIL_ADDRESS
                                , nvl(src.LOGISTICSELECTRONICADDRESS2_LOCATOR, '''') AS PRIMARY_FAX_NUMBER
                                , nvl(src.LOGISTICSELECTRONICADDRESS3_LOCATOR, '''') AS PRIMARY_PHONE_NUMBER
                                , nvl(src.LOGISTICSPOSTALADDRESS2_STREET, '''') AS INVOICE_STREET
                                , nvl(src.LOGISTICSPOSTALADDRESS2_CITY, '''') AS INVOICE_CITY
                                , nvl(src.LOGISTICSPOSTALADDRESS2_STATE, '''') AS INVOICE_STATE
                                , nvl(src.LOGISTICSPOSTALADDRESS2_ZIPCODE, '''') AS INVOICE_ZIP_CODE
                                , nvl(src.LOGISTICSPOSTALADDRESS2_COUNTRYREGIONID, '''') AS INVOICE_COUNTRY
                                , nvl(src.LOGISTICSLOCATION2_DESCRIPTION, '''') AS INVOICE_ADDRESS_NAME
                                , nvl(src.LOGISTICSLOCATION2_LOCATIONID, '''') AS INVOICE_ADDRESS_LOCATION_ID
                                , nvl(src.EBCREPORTPARENT, '''') AS REPORT_PARENT
                                , nvl(src.CUSTTABLE2_EBCDIVISIONID, '''') AS REPORT_PARENT_DIVISION_ID
                                , nvl(src.EBCSALESMKTDIVISION2_EBCDIVISIONDESC, '''') AS REPORT_PARENT_DIVISION
                                , nvl(src.CUSTTABLE2_SALESDISTRICTID, '''') AS REPORT_PARENT_SALES_DISTRICT_ID
                                , nvl(src.SMMBUSRELSALESDISTRICTGROUP2_DESCRIPTION, '''') AS REPORT_PARENT_SALES_DISTRICT
                                , nvl(src.HCMWORKER2_PERSONNELNUMBER, '''') AS REPORT_PARENT_SALES_REPRESENTATIVE_ID
                                , nvl(src.DIRPARTYTABLE3_NAME, '''') AS REPORT_PARENT_SALES_REPRESENTATIVE
                                , nvl(src.SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP1, '''') AS ALTERNATIVE_ROLLUP_1
                                , nvl(src.SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP2, '''') AS ALTERNATIVE_ROLLUP_2
                                , nvl(src.SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP3, '''') AS ALTERNATIVE_ROLLUP_3
                                , case when src.MCSEXTERNALPRICING = 1 then ''Yes'' else ''No'' END AS EXTERNAL_PRICING
                                , case 
                                    when nvl(nullif(rtrim(src.SEGMENTID), ''''), ''blank'') != nvl(src.REPORTDEALEREXCSEGMENT_SEGMENTID, ''nomatch'') then coalesce(nullif(rtrim(src.SEGMENTID), ''''), src.ACCOUNTNUM, '''')
                                    when nvl(nullif(rtrim(src.SUBSEGMENTID), ''''), ''blank'') != nvl(src.REPORTDEALEREXCSUBSEGMENT_SUBSEGMENTID, ''nomatch'') then coalesce(nullif(rtrim(src.SUBSEGMENTID), ''''), src.ACCOUNTNUM, '''')
                                    else nvl(src.ACCOUNTNUM, '''')
                                END AS SRC_REPORTING_DEALER_ID
                                , case
                                    when nvl(nullif(rtrim(src.SEGMENTID), ''''), ''blank'') != nvl(src.REPORTDEALEREXCSEGMENT_SEGMENTID, ''nomatch'') then coalesce(nullif(rtrim(src.SMMBUSRELSEGMENTGROUP_DESCRIPTION), ''''), src.DIRPARTYTABLE1_NAME, '''')   
                                    when nvl(nullif(rtrim(src.SUBSEGMENTID), ''''), ''blank'') != nvl(src.REPORTDEALEREXCSUBSEGMENT_SUBSEGMENTID, ''nomatch'') then coalesce(nullif(rtrim(src.SMMBUSRELSUBSEGMENTGROUP_DESCRIPTION), ''''), src.DIRPARTYTABLE1_NAME, '''')   
                                    else nvl(src.DIRPARTYTABLE1_NAME, '''') 
                                END AS SRC_REPORTING_DEALER
                                , case when nvl(src.MCSNETWORKID, '''') = '''' and src.LKP_TRUCK_VOLUME_LEGAL_ENTITY_ID is not null then ''DHL'' else nvl(src.MCSNETWORKID, '''') END AS MCS_NETWORK_ID
                                , case when src.ACCOUNTNUM = SRC_REPORTING_DEALER_ID then rtrim(SRC_REPORTING_DEALER) || '' ('' || rtrim(SRC_REPORTING_DEALER_ID) || '')'' else rtrim(SRC_REPORTING_DEALER) END AS REPORTING_DEALER_NAME_ID
                                , 0 AS HK_HASH_KEY
                                , CASE WHEN tgt.HK_HASH_KEY IS NULL THEN ''' || :MIN_DATE || ''' ELSE src.LATEST_MODIFIEDDATETIME END AS HK_EFFECTIVE_START_TIMESTAMP
                                , ''' || :MAX_DATE || ''' AS HK_EFFECTIVE_END_TIMESTAMP
                                , tgt.HK_CURRENT_FLAG
                                , TRUE AS SRC_HK_CURRENT_FLAG
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                (SELECT
                                    HK_SOURCE_NAME
                                    , HK_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                    , DATAAREAID
                                    , ACCOUNTNUM
                                    , PARTY
                                    , EBCCOMPANYID
                                    , OURACCOUNTNUM
                                    , INVOICEACCOUNT
                                    , CURRENCY
                                    , USECASHDISC
                                    , MAINCONTACTWORKER
                                    , BLOCKED
                                    , PASTDUECHECK
                                    , CREDITMAX
                                    , MANDATORYCREDITLIMIT
                                    , EXCLUDECREDITLIMITBLOCKING
                                    , GRACEDAYS
                                    , EBCBUYGRPEXEMPTION
                                    , EBCBUYGRPKICKER
                                    , CASHDISC
                                    , DLVMODE
                                    , DLVTERM
                                    , PAYMMODE
                                    , PAYMTERMID
                                    , CUSTCLASSIFICATIONID
                                    , COMPANYCHAINID
                                    , CUSTGROUP
                                    , EBCDIVISIONID
                                    , LINEOFBUSINESSID
                                    , MARKUPGROUP
                                    , PRICEGROUP
                                    , DEFAULTDIMENSION
                                    , SALESDISTRICTID
                                    , SALESGROUP
                                    , SALESPOOLID
                                    , SEGMENTID
                                    , SUBSEGMENTID
                                    , TAXGROUP
                                    , EBCREPORTPARENT
                                    , MCSEXTERNALPRICING
                                    , MCSNETWORKID
                                    , MODIFIEDDATETIME
                                    , DIRPARTYTABLE1_NAME
                                    , DIRPARTYTABLE1_INSTANCERELATIONTYPE
                                    , DIRPARTYTABLE1_EBCLEGACY
                                    , DIRPARTYTABLE1_ORGNUMBER
                                    , DIRPARTYTABLE1_PRIMARYADDRESSLOCATION
                                    , DIRPARTYTABLE1_MODIFIEDDATETIME
                                    , CURRENCY_TXT
                                    , CURRENCY_MODIFIEDDATETIME
                                    , HCMWORKER1_PERSONNELNUMBER
                                    , HCMWORKER1_PERSON
                                    , HCMWORKER1_MODIFIEDDATETIME
                                    , DIRPARTYTABLE2_NAME
                                    , DIRPARTYTABLE2_MODIFIEDDATETIME
                                    , TSIAVGDAYS_CPAVGDAY
                                    , TSIAVGDAYS_YRAVGDAY
                                    , CASHDISC_DESCRIPTION
                                    , CASHDISC_PERCENT
                                    , DLVMODE_TXT
                                    , DLVTERM_TXT
                                    , CUSTPAYMMODETABLE_NAME
                                    , PAYMTERM_DESCRIPTION
                                    , PAYMTERM_NUMOFDAYS
                                    , PAYMTERM_NUMOFMONTHS
                                    , CUSTCLASSIFICATIONGROUP_TXT
                                    , SMMBUSRELCHAINGROUP_DESCRIPTION
                                    , CUSTGROUP_NAME
                                    , SMMBUSRELSALESDISTRICTGROUP1_EBCDIVISIONID
                                    , SMMBUSRELSALESDISTRICTGROUP1_DESCRIPTION
                                    , SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP1
                                    , SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP2
                                    , SMMBUSRELSALESDISTRICTGROUP1_ALTROLLUP3
                                    , EBCSALESMKTDIVISION1_EBCDIVISIONDESC
                                    , LINEOFBUSINESS_DESCRIPTION
                                    , MARKUPGROUP_TXT
                                    , PRICEDISCGROUP_NAME
                                    , DEFAULTDIMENSION_C_SALES_CHANNEL
                                    , DEFAULTDIMENSION_C_SALES_CHANNEL_DESCRIPTION
                                    , DEFAULTDIMENSION_MODIFIEDDATETIME
                                    , COMMISSIONSALESGROUP_NAME
                                    , SALESPOOL_NAME
                                    , SMMBUSRELSEGMENTGROUP_DESCRIPTION
                                    , SMMBUSRELSUBSEGMENTGROUP_DESCRIPTION
                                    , TAXGROUPHEADING_TAXGROUPNAME
                                    , LOGISTICSPOSTALADDRESS1_STREET
                                    , LOGISTICSPOSTALADDRESS1_CITY
                                    , LOGISTICSPOSTALADDRESS1_STATE
                                    , LOGISTICSPOSTALADDRESS1_ZIPCODE
                                    , LOGISTICSPOSTALADDRESS1_COUNTRYREGIONID
                                    , LOGISTICSPOSTALADDRESS1_TIMEZONE
                                    , TIMEZONESLIST_TIMEZONEKEYNAME
                                    , LOGISTICSLOCATION1_DESCRIPTION
                                    , LOGISTICSELECTRONICADDRESS1_LOCATOR
                                    , LOGISTICSELECTRONICADDRESS2_LOCATOR
                                    , LOGISTICSELECTRONICADDRESS3_LOCATOR
                                    , LOGISTICSPOSTALADDRESS2_STREET
                                    , LOGISTICSPOSTALADDRESS2_CITY
                                    , LOGISTICSPOSTALADDRESS2_STATE
                                    , LOGISTICSPOSTALADDRESS2_ZIPCODE
                                    , LOGISTICSPOSTALADDRESS2_COUNTRYREGIONID
                                    , LOGISTICSLOCATION2_DESCRIPTION
                                    , LOGISTICSLOCATION2_LOCATIONID
                                    , CUSTTABLE2_EBCDIVISIONID
                                    , CUSTTABLE2_SALESDISTRICTID
                                    , CUSTTABLE2_MAINCONTACTWORKER
                                    , CUSTTABLE2_MODIFIEDDATETIME
                                    , SMMBUSRELSALESDISTRICTGROUP2_DESCRIPTION
                                    , EBCSALESMKTDIVISION2_EBCDIVISIONDESC
                                    , HCMWORKER2_PERSONNELNUMBER
                                    , HCMWORKER2_PERSON
                                    , HCMWORKER2_MODIFIEDDATETIME
                                    , DIRPARTYTABLE3_NAME
                                    , DIRPARTYTABLE3_MODIFIEDDATETIME
                                    , REPORTDEALEREXCSEGMENT_SEGMENTID
                                    , REPORTDEALEREXCSUBSEGMENT_SUBSEGMENTID
                                    , LKP_TRUCK_VOLUME_LEGAL_ENTITY_ID
                                    , LATEST_MODIFIEDDATETIME
                                    , row_number() over (partition by HK_SOURCE_NAME, DATAAREAID, ACCOUNTNUM order by LATEST_MODIFIEDDATETIME DESC) as PK_ROW_NUMBER
                                FROM ' || :src_db || '.' || :src_schema || '.' || :src_tbl || '
                                QUALIFY PK_ROW_NUMBER = 1) src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                ON src.HK_SOURCE_NAME = tgt.SOURCE_NAME AND src.DATAAREAID = tgt.LEGAL_ENTITY AND src.ACCOUNTNUM = tgt.CUSTOMER_ACCOUNT AND tgt.HK_CURRENT_FLAG = TRUE
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )
                                     
                                AND src.LATEST_MODIFIEDDATETIME > nvl(tgt.HK_EFFECTIVE_START_TIMESTAMP, ''' || :MIN_DATE || ''');';

        EXECUTE IMMEDIATE :create_wrk_tbl1;

        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY (aliased as SRC_HK_HASH_KEY); to be used later for determining insert/updates/no changes
        b. Set KEY/SNKEY values
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', CUSTOMER_ACCOUNT, ''~'', to_char(HK_EFFECTIVE_START_TIMESTAMP, ''yyyymmddhh24missff3'')) AS DIM_CUSTOMER_KEY
                            , hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', CUSTOMER_ACCOUNT) AS DIM_CUSTOMER_SNKEY
                            , SOURCE_NAME
                            , LEGAL_ENTITY
                            , CUSTOMER_ACCOUNT
                            , case when SOURCE_NAME = '''' then -2 else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , CUSTOMER_NAME
                            , RECORD_TYPE
                            , CUSTOMER_COMPANY_TYPE
                            , LEGACY_CUSTOMER
                            , LEGACY_CONSUMER_NUMBER
                            , ORGANIZATION_NUMBER
                            , INVOICE_ACCOUNT
                            , CUSTOMER_CURRENCY_CODE
                            , CUSTOMER_CURRENCY_NAME
                            , USE_CASH_DISCOUNT
                            , SALES_REPRESENTATIVE_ID
                            , SALES_REPRESENTATIVE
                            , CUSTOMER_IS_BLOCKED
                            , IS_PAST_DUE_CHECK
                            , CREDIT_LIMIT
                            , IS_MANDATORY_CREDIT_LIMIT
                            , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                            , GRACE_DAYS
                            , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                            , YEARLY_AVERAGE_DAYS_TO_PAY
                            , BUYING_GROUP_EXEMPT
                            , BUYING_GROUP_KICKER
                            , DEFAULT_CASH_DISCOUNT_ID
                            , DEFAULT_CASH_DISCOUNT
                            , DEFAULT_CASH_DISCOUNT_PERCENT
                            , DEFAULT_DELIVERY_MODE_ID
                            , DEFAULT_DELIVERY_MODE
                            , DEFAULT_DELIVERY_TERMS_ID
                            , DEFAULT_DELIVERY_TERMS
                            , DEFAULT_PAYMENT_MODE_ID
                            , DEFAULT_PAYMENT_MODE
                            , DEFAULT_PAYMENT_TERMS_ID
                            , DEFAULT_PAYMENT_TERMS
                            , PAYMENT_TERMS_NUMBER_OF_DAYS
                            , PAYMENT_TERMS_NUMBER_OF_MONTHS
                            , CLASSIFICATION_GROUP_ID
                            , CLASSIFICATION_GROUP
                            , COMPANY_CHAIN_ID
                            , COMPANY_CHAIN
                            , CUSTOMER_GROUP_ID
                            , CUSTOMER_GROUP
                            , DIVISION_ID
                            , DIVISION
                            , LINE_OF_BUSINESS_ID
                            , LINE_OF_BUSINESS
                            , MARKUP_GROUP_ID
                            , MARKUP_GROUP
                            , PRICE_GROUP_ID
                            , PRICE_GROUP
                            , SALES_CHANNEL_ID
                            , SALES_CHANNEL
                            , SALES_DISTRICT_ID
                            , SALES_DISTRICT
                            , SALES_GROUP_ID
                            , SALES_GROUP
                            , SALES_POOL_ID
                            , SALES_POOL
                            , SEGMENT_ID
                            , SEGMENT
                            , SUB_SEGMENT_ID
                            , SUB_SEGMENT
                            , TAX_GROUP_ID
                            , TAX_GROUP
                            , PRIMARY_STREET
                            , PRIMARY_CITY
                            , PRIMARY_STATE
                            , PRIMARY_ZIP_CODE
                            , PRIMARY_COUNTRY
                            , PRIMARY_TIME_ZONE
                            , PRIMARY_ADDRESS_NAME
                            , PRIMARY_EMAIL_ADDRESS
                            , PRIMARY_FAX_NUMBER
                            , PRIMARY_PHONE_NUMBER
                            , INVOICE_STREET
                            , INVOICE_CITY
                            , INVOICE_STATE
                            , INVOICE_ZIP_CODE
                            , INVOICE_COUNTRY
                            , INVOICE_ADDRESS_NAME
                            , INVOICE_ADDRESS_LOCATION_ID
                            , REPORT_PARENT
                            , REPORT_PARENT_DIVISION_ID
                            , REPORT_PARENT_DIVISION
                            , REPORT_PARENT_SALES_DISTRICT_ID
                            , REPORT_PARENT_SALES_DISTRICT
                            , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                            , REPORT_PARENT_SALES_REPRESENTATIVE
                            , ALTERNATIVE_ROLLUP_1
                            , ALTERNATIVE_ROLLUP_2
                            , ALTERNATIVE_ROLLUP_3
                            , EXTERNAL_PRICING
                            , SRC_REPORTING_DEALER_ID AS REPORTING_DEALER_ID
                            , SRC_REPORTING_DEALER AS REPORTING_DEALER
                            , MCS_NETWORK_ID
                            , REPORTING_DEALER_NAME_ID
                            , hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', CUSTOMER_ACCOUNT, ''~'', CUSTOMER_NAME, ''~'', RECORD_TYPE, ''~'', CUSTOMER_COMPANY_TYPE, ''~'', LEGACY_CUSTOMER, ''~'', LEGACY_CONSUMER_NUMBER, ''~'', ORGANIZATION_NUMBER, ''~'', INVOICE_ACCOUNT, ''~'', CUSTOMER_CURRENCY_CODE, ''~'', CUSTOMER_CURRENCY_NAME, ''~'', USE_CASH_DISCOUNT, ''~'', SALES_REPRESENTATIVE_ID, ''~'', SALES_REPRESENTATIVE, ''~'', CUSTOMER_IS_BLOCKED, ''~'', IS_PAST_DUE_CHECK, ''~'', to_char(CREDIT_LIMIT), ''~'', IS_MANDATORY_CREDIT_LIMIT, ''~'', IS_CREDIT_LIMIT_BLOCKING_EXCLUDED, ''~'', to_char(GRACE_DAYS), ''~'', to_char(CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY), ''~'', to_char(YEARLY_AVERAGE_DAYS_TO_PAY), ''~'', BUYING_GROUP_EXEMPT, ''~'', BUYING_GROUP_KICKER, ''~'', DEFAULT_CASH_DISCOUNT_ID, ''~'', DEFAULT_CASH_DISCOUNT, ''~'', to_char(DEFAULT_CASH_DISCOUNT_PERCENT), ''~'', DEFAULT_DELIVERY_MODE_ID, ''~'', DEFAULT_DELIVERY_MODE, ''~'', DEFAULT_DELIVERY_TERMS_ID, ''~'', DEFAULT_DELIVERY_TERMS, ''~'', DEFAULT_PAYMENT_MODE_ID, ''~'', DEFAULT_PAYMENT_MODE, ''~'', DEFAULT_PAYMENT_TERMS_ID, ''~'', DEFAULT_PAYMENT_TERMS, ''~'', to_char(PAYMENT_TERMS_NUMBER_OF_DAYS), ''~'', to_char(PAYMENT_TERMS_NUMBER_OF_MONTHS), ''~'', CLASSIFICATION_GROUP_ID, ''~'', CLASSIFICATION_GROUP, ''~'', COMPANY_CHAIN_ID, ''~'', COMPANY_CHAIN, ''~'', CUSTOMER_GROUP_ID, ''~'', CUSTOMER_GROUP, ''~'', DIVISION_ID, ''~'', DIVISION, ''~'', LINE_OF_BUSINESS_ID, ''~'', LINE_OF_BUSINESS, ''~'', MARKUP_GROUP_ID, ''~'', MARKUP_GROUP, ''~'', PRICE_GROUP_ID, ''~'', PRICE_GROUP, ''~'', SALES_CHANNEL_ID, ''~'', SALES_CHANNEL, ''~'', SALES_DISTRICT_ID, ''~'', SALES_DISTRICT, ''~'', SALES_GROUP_ID, ''~'', SALES_GROUP, ''~'', SALES_POOL_ID, ''~'', SALES_POOL, ''~'', SEGMENT_ID, ''~'', SEGMENT, ''~'', SUB_SEGMENT_ID, ''~'', SUB_SEGMENT, ''~'', TAX_GROUP_ID, ''~'', TAX_GROUP, ''~'', PRIMARY_STREET, ''~'', PRIMARY_CITY, ''~'', PRIMARY_STATE, ''~'', PRIMARY_ZIP_CODE, ''~'', PRIMARY_COUNTRY, ''~'', PRIMARY_TIME_ZONE, ''~'', PRIMARY_ADDRESS_NAME, ''~'', PRIMARY_EMAIL_ADDRESS, ''~'', PRIMARY_FAX_NUMBER, ''~'', PRIMARY_PHONE_NUMBER, ''~'', INVOICE_STREET, ''~'', INVOICE_CITY, ''~'', INVOICE_STATE, ''~'', INVOICE_ZIP_CODE, ''~'', INVOICE_COUNTRY, ''~'', INVOICE_ADDRESS_NAME, ''~'', INVOICE_ADDRESS_LOCATION_ID, ''~'', REPORT_PARENT, ''~'', REPORT_PARENT_DIVISION_ID, ''~'', REPORT_PARENT_DIVISION, ''~'', REPORT_PARENT_SALES_DISTRICT_ID, ''~'', REPORT_PARENT_SALES_DISTRICT, ''~'', REPORT_PARENT_SALES_REPRESENTATIVE_ID, ''~'', REPORT_PARENT_SALES_REPRESENTATIVE, ''~'', ALTERNATIVE_ROLLUP_1, ''~'', ALTERNATIVE_ROLLUP_2, ''~'', ALTERNATIVE_ROLLUP_3, ''~'', EXTERNAL_PRICING, ''~'', REPORTING_DEALER_ID, ''~'', REPORTING_DEALER, ''~'', MCS_NETWORK_ID, ''~'', REPORTING_DEALER_NAME_ID) AS SRC_HK_HASH_KEY
                            , HK_EFFECTIVE_START_TIMESTAMP
                            , HK_EFFECTIVE_END_TIMESTAMP
                            , SRC_HK_CURRENT_FLAG
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' src;';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;

    /*
        3.	Read data from second working table and write to third working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_02_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_03_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_03_<YYYYMMDDHH24MISSFF3>

        a. Create CTE for the union of second prep table and most recent active records from target table
        b. Target table records should meet the following requirements:
            i. HK_CURRENT_FLAG = TRUE
            ii. Target SNKEY is in the table of source records (to keep from bringing in unnecessary target values)
            iii. Target HK_HASH_KEY must not be present in table of source records (to keep from triggering updates on unchanged data)
    */
    v_proc_step := '4.3';
        LET create_wrk_tbl3 STRING DEFAULT '';                   
        create_wrk_tbl3 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                        WITH union_cte AS (
                            SELECT
                            DIM_CUSTOMER_KEY
                            , DIM_CUSTOMER_SNKEY
                            , SOURCE_NAME
                            , LEGAL_ENTITY
                            , CUSTOMER_ACCOUNT
                            , DIM_SOURCE_SYSTEM_SNKEY
                            , CUSTOMER_NAME
                            , RECORD_TYPE
                            , CUSTOMER_COMPANY_TYPE
                            , LEGACY_CUSTOMER
                            , LEGACY_CONSUMER_NUMBER
                            , ORGANIZATION_NUMBER
                            , INVOICE_ACCOUNT
                            , CUSTOMER_CURRENCY_CODE
                            , CUSTOMER_CURRENCY_NAME
                            , USE_CASH_DISCOUNT
                            , SALES_REPRESENTATIVE_ID
                            , SALES_REPRESENTATIVE
                            , CUSTOMER_IS_BLOCKED
                            , IS_PAST_DUE_CHECK
                            , CREDIT_LIMIT
                            , IS_MANDATORY_CREDIT_LIMIT
                            , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                            , GRACE_DAYS
                            , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                            , YEARLY_AVERAGE_DAYS_TO_PAY
                            , BUYING_GROUP_EXEMPT
                            , BUYING_GROUP_KICKER
                            , DEFAULT_CASH_DISCOUNT_ID
                            , DEFAULT_CASH_DISCOUNT
                            , DEFAULT_CASH_DISCOUNT_PERCENT
                            , DEFAULT_DELIVERY_MODE_ID
                            , DEFAULT_DELIVERY_MODE
                            , DEFAULT_DELIVERY_TERMS_ID
                            , DEFAULT_DELIVERY_TERMS
                            , DEFAULT_PAYMENT_MODE_ID
                            , DEFAULT_PAYMENT_MODE
                            , DEFAULT_PAYMENT_TERMS_ID
                            , DEFAULT_PAYMENT_TERMS
                            , PAYMENT_TERMS_NUMBER_OF_DAYS
                            , PAYMENT_TERMS_NUMBER_OF_MONTHS
                            , CLASSIFICATION_GROUP_ID
                            , CLASSIFICATION_GROUP
                            , COMPANY_CHAIN_ID
                            , COMPANY_CHAIN
                            , CUSTOMER_GROUP_ID
                            , CUSTOMER_GROUP
                            , DIVISION_ID
                            , DIVISION
                            , LINE_OF_BUSINESS_ID
                            , LINE_OF_BUSINESS
                            , MARKUP_GROUP_ID
                            , MARKUP_GROUP
                            , PRICE_GROUP_ID
                            , PRICE_GROUP
                            , SALES_CHANNEL_ID
                            , SALES_CHANNEL
                            , SALES_DISTRICT_ID
                            , SALES_DISTRICT
                            , SALES_GROUP_ID
                            , SALES_GROUP
                            , SALES_POOL_ID
                            , SALES_POOL
                            , SEGMENT_ID
                            , SEGMENT
                            , SUB_SEGMENT_ID
                            , SUB_SEGMENT
                            , TAX_GROUP_ID
                            , TAX_GROUP
                            , PRIMARY_STREET
                            , PRIMARY_CITY
                            , PRIMARY_STATE
                            , PRIMARY_ZIP_CODE
                            , PRIMARY_COUNTRY
                            , PRIMARY_TIME_ZONE
                            , PRIMARY_ADDRESS_NAME
                            , PRIMARY_EMAIL_ADDRESS
                            , PRIMARY_FAX_NUMBER
                            , PRIMARY_PHONE_NUMBER
                            , INVOICE_STREET
                            , INVOICE_CITY
                            , INVOICE_STATE
                            , INVOICE_ZIP_CODE
                            , INVOICE_COUNTRY
                            , INVOICE_ADDRESS_NAME
                            , INVOICE_ADDRESS_LOCATION_ID
                            , REPORT_PARENT
                            , REPORT_PARENT_DIVISION_ID
                            , REPORT_PARENT_DIVISION
                            , REPORT_PARENT_SALES_DISTRICT_ID
                            , REPORT_PARENT_SALES_DISTRICT
                            , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                            , REPORT_PARENT_SALES_REPRESENTATIVE
                            , ALTERNATIVE_ROLLUP_1
                            , ALTERNATIVE_ROLLUP_2
                            , ALTERNATIVE_ROLLUP_3
                            , EXTERNAL_PRICING
                            , REPORTING_DEALER_ID
                            , REPORTING_DEALER
                            , MCS_NETWORK_ID
                            , REPORTING_DEALER_NAME_ID
                            , SRC_HK_HASH_KEY
                            , HK_EFFECTIVE_START_TIMESTAMP
                            , HK_EFFECTIVE_END_TIMESTAMP
                            , SRC_HK_CURRENT_FLAG
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , TGT_HK_HASH_KEY
                            , 1 AS TIEBREAKER_COLUMN
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
                            || '
                            UNION ALL
                            SELECT
                                DIM_CUSTOMER_KEY
                            , DIM_CUSTOMER_SNKEY
                            , SOURCE_NAME
                            , LEGAL_ENTITY
                            , CUSTOMER_ACCOUNT
                            , DIM_SOURCE_SYSTEM_SNKEY
                            , CUSTOMER_NAME
                            , RECORD_TYPE
                            , CUSTOMER_COMPANY_TYPE
                            , LEGACY_CUSTOMER
                            , LEGACY_CONSUMER_NUMBER
                            , ORGANIZATION_NUMBER
                            , INVOICE_ACCOUNT
                            , CUSTOMER_CURRENCY_CODE
                            , CUSTOMER_CURRENCY_NAME
                            , USE_CASH_DISCOUNT
                            , SALES_REPRESENTATIVE_ID
                            , SALES_REPRESENTATIVE
                            , CUSTOMER_IS_BLOCKED
                            , IS_PAST_DUE_CHECK
                            , CREDIT_LIMIT
                            , IS_MANDATORY_CREDIT_LIMIT
                            , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                            , GRACE_DAYS
                            , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                            , YEARLY_AVERAGE_DAYS_TO_PAY
                            , BUYING_GROUP_EXEMPT
                            , BUYING_GROUP_KICKER
                            , DEFAULT_CASH_DISCOUNT_ID
                            , DEFAULT_CASH_DISCOUNT
                            , DEFAULT_CASH_DISCOUNT_PERCENT
                            , DEFAULT_DELIVERY_MODE_ID
                            , DEFAULT_DELIVERY_MODE
                            , DEFAULT_DELIVERY_TERMS_ID
                            , DEFAULT_DELIVERY_TERMS
                            , DEFAULT_PAYMENT_MODE_ID
                            , DEFAULT_PAYMENT_MODE
                            , DEFAULT_PAYMENT_TERMS_ID
                            , DEFAULT_PAYMENT_TERMS
                            , PAYMENT_TERMS_NUMBER_OF_DAYS
                            , PAYMENT_TERMS_NUMBER_OF_MONTHS
                            , CLASSIFICATION_GROUP_ID
                            , CLASSIFICATION_GROUP
                            , COMPANY_CHAIN_ID
                            , COMPANY_CHAIN
                            , CUSTOMER_GROUP_ID
                            , CUSTOMER_GROUP
                            , DIVISION_ID
                            , DIVISION
                            , LINE_OF_BUSINESS_ID
                            , LINE_OF_BUSINESS
                            , MARKUP_GROUP_ID
                            , MARKUP_GROUP
                            , PRICE_GROUP_ID
                            , PRICE_GROUP
                            , SALES_CHANNEL_ID
                            , SALES_CHANNEL
                            , SALES_DISTRICT_ID
                            , SALES_DISTRICT
                            , SALES_GROUP_ID
                            , SALES_GROUP
                            , SALES_POOL_ID
                            , SALES_POOL
                            , SEGMENT_ID
                            , SEGMENT
                            , SUB_SEGMENT_ID
                            , SUB_SEGMENT
                            , TAX_GROUP_ID
                            , TAX_GROUP
                            , PRIMARY_STREET
                            , PRIMARY_CITY
                            , PRIMARY_STATE
                            , PRIMARY_ZIP_CODE
                            , PRIMARY_COUNTRY
                            , PRIMARY_TIME_ZONE
                            , PRIMARY_ADDRESS_NAME
                            , PRIMARY_EMAIL_ADDRESS
                            , PRIMARY_FAX_NUMBER
                            , PRIMARY_PHONE_NUMBER
                            , INVOICE_STREET
                            , INVOICE_CITY
                            , INVOICE_STATE
                            , INVOICE_ZIP_CODE
                            , INVOICE_COUNTRY
                            , INVOICE_ADDRESS_NAME
                            , INVOICE_ADDRESS_LOCATION_ID
                            , REPORT_PARENT
                            , REPORT_PARENT_DIVISION_ID
                            , REPORT_PARENT_DIVISION
                            , REPORT_PARENT_SALES_DISTRICT_ID
                            , REPORT_PARENT_SALES_DISTRICT
                            , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                            , REPORT_PARENT_SALES_REPRESENTATIVE
                            , ALTERNATIVE_ROLLUP_1
                            , ALTERNATIVE_ROLLUP_2
                            , ALTERNATIVE_ROLLUP_3
                            , EXTERNAL_PRICING
                            , REPORTING_DEALER_ID
                            , REPORTING_DEALER
                            , MCS_NETWORK_ID
                            , REPORTING_DEALER_NAME_ID
                            , HK_HASH_KEY AS SRC_HK_HASH_KEY
                            , HK_EFFECTIVE_START_TIMESTAMP
                            , HK_EFFECTIVE_END_TIMESTAMP
                            , HK_CURRENT_FLAG AS SRC_HK_CURRENT_FLAG
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , HK_HASH_KEY AS TGT_HK_HASH_KEY
                            , 2 AS TIEBREAKER_COLUMN
                            FROM '  || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || '
                            WHERE HK_CURRENT_FLAG = TRUE
                            AND DIM_CUSTOMER_SNKEY IN (SELECT DIM_CUSTOMER_SNKEY FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ')
                            AND HK_HASH_KEY NOT IN (SELECT SRC_HK_HASH_KEY FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || '))
                            SELECT
                                DIM_CUSTOMER_KEY
                                , DIM_CUSTOMER_SNKEY
                                , SOURCE_NAME
                                , LEGAL_ENTITY
                                , CUSTOMER_ACCOUNT
                                , DIM_SOURCE_SYSTEM_SNKEY
                                , CUSTOMER_NAME
                                , RECORD_TYPE
                                , CUSTOMER_COMPANY_TYPE
                                , LEGACY_CUSTOMER
                                , LEGACY_CONSUMER_NUMBER
                                , ORGANIZATION_NUMBER
                                , INVOICE_ACCOUNT
                                , CUSTOMER_CURRENCY_CODE
                                , CUSTOMER_CURRENCY_NAME
                                , USE_CASH_DISCOUNT
                                , SALES_REPRESENTATIVE_ID
                                , SALES_REPRESENTATIVE
                                , CUSTOMER_IS_BLOCKED
                                , IS_PAST_DUE_CHECK
                                , CREDIT_LIMIT
                                , IS_MANDATORY_CREDIT_LIMIT
                                , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                                , GRACE_DAYS
                                , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                                , YEARLY_AVERAGE_DAYS_TO_PAY
                                , BUYING_GROUP_EXEMPT
                                , BUYING_GROUP_KICKER
                                , DEFAULT_CASH_DISCOUNT_ID
                                , DEFAULT_CASH_DISCOUNT
                                , DEFAULT_CASH_DISCOUNT_PERCENT
                                , DEFAULT_DELIVERY_MODE_ID
                                , DEFAULT_DELIVERY_MODE
                                , DEFAULT_DELIVERY_TERMS_ID
                                , DEFAULT_DELIVERY_TERMS
                                , DEFAULT_PAYMENT_MODE_ID
                                , DEFAULT_PAYMENT_MODE
                                , DEFAULT_PAYMENT_TERMS_ID
                                , DEFAULT_PAYMENT_TERMS
                                , PAYMENT_TERMS_NUMBER_OF_DAYS
                                , PAYMENT_TERMS_NUMBER_OF_MONTHS
                                , CLASSIFICATION_GROUP_ID
                                , CLASSIFICATION_GROUP
                                , COMPANY_CHAIN_ID
                                , COMPANY_CHAIN
                                , CUSTOMER_GROUP_ID
                                , CUSTOMER_GROUP
                                , DIVISION_ID
                                , DIVISION
                                , LINE_OF_BUSINESS_ID
                                , LINE_OF_BUSINESS
                                , MARKUP_GROUP_ID
                                , MARKUP_GROUP
                                , PRICE_GROUP_ID
                                , PRICE_GROUP
                                , SALES_CHANNEL_ID
                                , SALES_CHANNEL
                                , SALES_DISTRICT_ID
                                , SALES_DISTRICT
                                , SALES_GROUP_ID
                                , SALES_GROUP
                                , SALES_POOL_ID
                                , SALES_POOL
                                , SEGMENT_ID
                                , SEGMENT
                                , SUB_SEGMENT_ID
                                , SUB_SEGMENT
                                , TAX_GROUP_ID
                                , TAX_GROUP
                                , PRIMARY_STREET
                                , PRIMARY_CITY
                                , PRIMARY_STATE
                                , PRIMARY_ZIP_CODE
                                , PRIMARY_COUNTRY
                                , PRIMARY_TIME_ZONE
                                , PRIMARY_ADDRESS_NAME
                                , PRIMARY_EMAIL_ADDRESS
                                , PRIMARY_FAX_NUMBER
                                , PRIMARY_PHONE_NUMBER
                                , INVOICE_STREET
                                , INVOICE_CITY
                                , INVOICE_STATE
                                , INVOICE_ZIP_CODE
                                , INVOICE_COUNTRY
                                , INVOICE_ADDRESS_NAME
                                , INVOICE_ADDRESS_LOCATION_ID
                                , REPORT_PARENT
                                , REPORT_PARENT_DIVISION_ID
                                , REPORT_PARENT_DIVISION
                                , REPORT_PARENT_SALES_DISTRICT_ID
                                , REPORT_PARENT_SALES_DISTRICT
                                , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                                , REPORT_PARENT_SALES_REPRESENTATIVE
                                , ALTERNATIVE_ROLLUP_1
                                , ALTERNATIVE_ROLLUP_2
                                , ALTERNATIVE_ROLLUP_3
                                , EXTERNAL_PRICING
                                , REPORTING_DEALER_ID
                                , REPORTING_DEALER
                                , MCS_NETWORK_ID
                                , REPORTING_DEALER_NAME_ID
                                , SRC_HK_HASH_KEY
                                , HK_EFFECTIVE_START_TIMESTAMP
                                , HK_EFFECTIVE_END_TIMESTAMP
                                , SRC_HK_CURRENT_FLAG
                                , HK_SOURCE_NAME
                                , HK_SOFT_DELETE_FLAG
                                , HK_SOURCE_CREATED_TIMESTAMP
                                , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , HK_CREATED_JOB_RUN_ID
                                , HK_LAST_UPDATED_JOB_RUN_ID
                                , HK_CREATED_TIMESTAMP
                                , HK_LAST_UPDATED_TIMESTAMP
                                , HK_WAREHOUSE_ID
                                , TGT_HK_HASH_KEY
                                , TIEBREAKER_COLUMN
                                , row_number() over (partition by SOURCE_NAME, LEGAL_ENTITY, CUSTOMER_ACCOUNT order by HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC, TIEBREAKER_COLUMN ASC) as PK_ROW_NUMBER
                            FROM union_cte';
     
    EXECUTE IMMEDIATE :create_wrk_tbl3;

    /*
        4.	Read data from third working table and write to fourth working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_03_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_03_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_04_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_04_<YYYYMMDDHH24MISSFF3>

        a. Assign DML Indicator
            i. DML_IND = CHANGED-I: Indicates a change to a record, so insert
            ii. DML_IND = NEW-I: Indicates a new record, so insert
            iii. DML_IND = U: Indicates that this record is no longer active, so update
        b. Based on DML_IND, assign the following:
            i. HK_EFFECTIVE_END_TIMESTAMP: If DML_IND = 'U', the the start of the next active record. Else stays the same
            ii. HK_CURRENT_FLAG: If DML_IND = 'U', then FALSE. Else stays the same
        c. Filter out records assigned a DML_IND values of 'DROP'
    */
    v_proc_step := '4.4';
        LET create_wrk_tbl4 STRING DEFAULT '';                   
        create_wrk_tbl4 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_04_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                                DIM_CUSTOMER_KEY
                                , DIM_CUSTOMER_SNKEY
                                , SOURCE_NAME
                                , LEGAL_ENTITY
                                , CUSTOMER_ACCOUNT
                                , DIM_SOURCE_SYSTEM_SNKEY
                                , CUSTOMER_NAME
                                , RECORD_TYPE
                                , CUSTOMER_COMPANY_TYPE
                                , LEGACY_CUSTOMER
                                , LEGACY_CONSUMER_NUMBER
                                , ORGANIZATION_NUMBER
                                , INVOICE_ACCOUNT
                                , CUSTOMER_CURRENCY_CODE
                                , CUSTOMER_CURRENCY_NAME
                                , USE_CASH_DISCOUNT
                                , SALES_REPRESENTATIVE_ID
                                , SALES_REPRESENTATIVE
                                , CUSTOMER_IS_BLOCKED
                                , IS_PAST_DUE_CHECK
                                , CREDIT_LIMIT
                                , IS_MANDATORY_CREDIT_LIMIT
                                , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                                , GRACE_DAYS
                                , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                                , YEARLY_AVERAGE_DAYS_TO_PAY
                                , BUYING_GROUP_EXEMPT
                                , BUYING_GROUP_KICKER
                                , DEFAULT_CASH_DISCOUNT_ID
                                , DEFAULT_CASH_DISCOUNT
                                , DEFAULT_CASH_DISCOUNT_PERCENT
                                , DEFAULT_DELIVERY_MODE_ID
                                , DEFAULT_DELIVERY_MODE
                                , DEFAULT_DELIVERY_TERMS_ID
                                , DEFAULT_DELIVERY_TERMS
                                , DEFAULT_PAYMENT_MODE_ID
                                , DEFAULT_PAYMENT_MODE
                                , DEFAULT_PAYMENT_TERMS_ID
                                , DEFAULT_PAYMENT_TERMS
                                , PAYMENT_TERMS_NUMBER_OF_DAYS
                                , PAYMENT_TERMS_NUMBER_OF_MONTHS
                                , CLASSIFICATION_GROUP_ID
                                , CLASSIFICATION_GROUP
                                , COMPANY_CHAIN_ID
                                , COMPANY_CHAIN
                                , CUSTOMER_GROUP_ID
                                , CUSTOMER_GROUP
                                , DIVISION_ID
                                , DIVISION
                                , LINE_OF_BUSINESS_ID
                                , LINE_OF_BUSINESS
                                , MARKUP_GROUP_ID
                                , MARKUP_GROUP
                                , PRICE_GROUP_ID
                                , PRICE_GROUP
                                , SALES_CHANNEL_ID
                                , SALES_CHANNEL
                                , SALES_DISTRICT_ID
                                , SALES_DISTRICT
                                , SALES_GROUP_ID
                                , SALES_GROUP
                                , SALES_POOL_ID
                                , SALES_POOL
                                , SEGMENT_ID
                                , SEGMENT
                                , SUB_SEGMENT_ID
                                , SUB_SEGMENT
                                , TAX_GROUP_ID
                                , TAX_GROUP
                                , PRIMARY_STREET
                                , PRIMARY_CITY
                                , PRIMARY_STATE
                                , PRIMARY_ZIP_CODE
                                , PRIMARY_COUNTRY
                                , PRIMARY_TIME_ZONE
                                , PRIMARY_ADDRESS_NAME
                                , PRIMARY_EMAIL_ADDRESS
                                , PRIMARY_FAX_NUMBER
                                , PRIMARY_PHONE_NUMBER
                                , INVOICE_STREET
                                , INVOICE_CITY
                                , INVOICE_STATE
                                , INVOICE_ZIP_CODE
                                , INVOICE_COUNTRY
                                , INVOICE_ADDRESS_NAME
                                , INVOICE_ADDRESS_LOCATION_ID
                                , REPORT_PARENT
                                , REPORT_PARENT_DIVISION_ID
                                , REPORT_PARENT_DIVISION
                                , REPORT_PARENT_SALES_DISTRICT_ID
                                , REPORT_PARENT_SALES_DISTRICT
                                , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                                , REPORT_PARENT_SALES_REPRESENTATIVE
                                , ALTERNATIVE_ROLLUP_1
                                , ALTERNATIVE_ROLLUP_2
                                , ALTERNATIVE_ROLLUP_3
                                , EXTERNAL_PRICING
                                , REPORTING_DEALER_ID
                                , REPORTING_DEALER
                                , MCS_NETWORK_ID
                                , REPORTING_DEALER_NAME_ID
                                , HK_EFFECTIVE_START_TIMESTAMP
                                , CASE 
                                    WHEN TGT_HK_HASH_KEY IS NULL THEN ''NEW-I''
                                    WHEN TGT_HK_HASH_KEY = SRC_HK_HASH_KEY AND PK_ROW_NUMBER = 2 THEN ''U''
                                    WHEN TGT_HK_HASH_KEY != SRC_HK_HASH_KEY AND PK_ROW_NUMBER = 1 THEN ''CHANGED-I''
                                    ELSE ''DROP''
                                END AS DML_IND
                                , CASE
                                    WHEN DML_IND = ''U'' THEN LEAD(HK_EFFECTIVE_START_TIMESTAMP,1,HK_EFFECTIVE_END_TIMESTAMP) over (partition by SOURCE_NAME, LEGAL_ENTITY, CUSTOMER_ACCOUNT order by HK_SOURCE_LAST_UPDATED_TIMESTAMP ASC, TIEBREAKER_COLUMN DESC)
                                    ELSE HK_EFFECTIVE_END_TIMESTAMP
                                END AS HK_EFFECTIVE_END_TIMESTAMP
                                , CASE
                                    WHEN DML_IND = ''U'' THEN FALSE
                                    ELSE SRC_HK_CURRENT_FLAG
                                END AS HK_CURRENT_FLAG
                                , SRC_HK_HASH_KEY
                                , HK_SOURCE_NAME
                                , HK_SOFT_DELETE_FLAG
                                , HK_SOURCE_CREATED_TIMESTAMP
                                , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , HK_CREATED_JOB_RUN_ID
                                , HK_LAST_UPDATED_JOB_RUN_ID
                                , HK_CREATED_TIMESTAMP
                                , HK_LAST_UPDATED_TIMESTAMP
                                , HK_WAREHOUSE_ID
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP
                            || ' src ;';
     
    EXECUTE IMMEDIATE :create_wrk_tbl4;
    
    

     /*
        4.	Read data from fourth working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_04_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_CUSTOMER_PREP_03_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.DIM_CUSTOMER

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		tgt.DIM_CUSTOMER_KEY = src.DIM_CUSTOMER_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND IN  ('NEW-I', 'CHANGED-I')
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_04_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.DIM_CUSTOMER_KEY = tgt.DIM_CUSTOMER_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.HK_EFFECTIVE_END_TIMESTAMP = src.HK_EFFECTIVE_END_TIMESTAMP
                                    , tgt.HK_CURRENT_FLAG = FALSE
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND IN  (''NEW-I'', ''CHANGED-I'') then
                            INSERT
                                (
                                    DIM_CUSTOMER_KEY
                                    , DIM_CUSTOMER_SNKEY
                                    , SOURCE_NAME
                                    , LEGAL_ENTITY
                                    , CUSTOMER_ACCOUNT
                                    , DIM_SOURCE_SYSTEM_SNKEY
                                    , CUSTOMER_NAME
                                    , RECORD_TYPE
                                    , CUSTOMER_COMPANY_TYPE
                                    , LEGACY_CUSTOMER
                                    , LEGACY_CONSUMER_NUMBER
                                    , ORGANIZATION_NUMBER
                                    , INVOICE_ACCOUNT
                                    , CUSTOMER_CURRENCY_CODE
                                    , CUSTOMER_CURRENCY_NAME
                                    , USE_CASH_DISCOUNT
                                    , SALES_REPRESENTATIVE_ID
                                    , SALES_REPRESENTATIVE
                                    , CUSTOMER_IS_BLOCKED
                                    , IS_PAST_DUE_CHECK
                                    , CREDIT_LIMIT
                                    , IS_MANDATORY_CREDIT_LIMIT
                                    , IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                                    , GRACE_DAYS
                                    , CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                                    , YEARLY_AVERAGE_DAYS_TO_PAY
                                    , BUYING_GROUP_EXEMPT
                                    , BUYING_GROUP_KICKER
                                    , DEFAULT_CASH_DISCOUNT_ID
                                    , DEFAULT_CASH_DISCOUNT
                                    , DEFAULT_CASH_DISCOUNT_PERCENT
                                    , DEFAULT_DELIVERY_MODE_ID
                                    , DEFAULT_DELIVERY_MODE
                                    , DEFAULT_DELIVERY_TERMS_ID
                                    , DEFAULT_DELIVERY_TERMS
                                    , DEFAULT_PAYMENT_MODE_ID
                                    , DEFAULT_PAYMENT_MODE
                                    , DEFAULT_PAYMENT_TERMS_ID
                                    , DEFAULT_PAYMENT_TERMS
                                    , PAYMENT_TERMS_NUMBER_OF_DAYS
                                    , PAYMENT_TERMS_NUMBER_OF_MONTHS
                                    , CLASSIFICATION_GROUP_ID
                                    , CLASSIFICATION_GROUP
                                    , COMPANY_CHAIN_ID
                                    , COMPANY_CHAIN
                                    , CUSTOMER_GROUP_ID
                                    , CUSTOMER_GROUP
                                    , DIVISION_ID
                                    , DIVISION
                                    , LINE_OF_BUSINESS_ID
                                    , LINE_OF_BUSINESS
                                    , MARKUP_GROUP_ID
                                    , MARKUP_GROUP
                                    , PRICE_GROUP_ID
                                    , PRICE_GROUP
                                    , SALES_CHANNEL_ID
                                    , SALES_CHANNEL
                                    , SALES_DISTRICT_ID
                                    , SALES_DISTRICT
                                    , SALES_GROUP_ID
                                    , SALES_GROUP
                                    , SALES_POOL_ID
                                    , SALES_POOL
                                    , SEGMENT_ID
                                    , SEGMENT
                                    , SUB_SEGMENT_ID
                                    , SUB_SEGMENT
                                    , TAX_GROUP_ID
                                    , TAX_GROUP
                                    , PRIMARY_STREET
                                    , PRIMARY_CITY
                                    , PRIMARY_STATE
                                    , PRIMARY_ZIP_CODE
                                    , PRIMARY_COUNTRY
                                    , PRIMARY_TIME_ZONE
                                    , PRIMARY_ADDRESS_NAME
                                    , PRIMARY_EMAIL_ADDRESS
                                    , PRIMARY_FAX_NUMBER
                                    , PRIMARY_PHONE_NUMBER
                                    , INVOICE_STREET
                                    , INVOICE_CITY
                                    , INVOICE_STATE
                                    , INVOICE_ZIP_CODE
                                    , INVOICE_COUNTRY
                                    , INVOICE_ADDRESS_NAME
                                    , INVOICE_ADDRESS_LOCATION_ID
                                    , REPORT_PARENT
                                    , REPORT_PARENT_DIVISION_ID
                                    , REPORT_PARENT_DIVISION
                                    , REPORT_PARENT_SALES_DISTRICT_ID
                                    , REPORT_PARENT_SALES_DISTRICT
                                    , REPORT_PARENT_SALES_REPRESENTATIVE_ID
                                    , REPORT_PARENT_SALES_REPRESENTATIVE
                                    , ALTERNATIVE_ROLLUP_1
                                    , ALTERNATIVE_ROLLUP_2
                                    , ALTERNATIVE_ROLLUP_3
                                    , EXTERNAL_PRICING
                                    , REPORTING_DEALER_ID
                                    , REPORTING_DEALER
                                    , MCS_NETWORK_ID
                                    , REPORTING_DEALER_NAME_ID
                                    , HK_HASH_KEY
                                    , HK_EFFECTIVE_START_TIMESTAMP
                                    , HK_EFFECTIVE_END_TIMESTAMP
                                    , HK_CURRENT_FLAG
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                    src.DIM_CUSTOMER_KEY
                                    , src.DIM_CUSTOMER_SNKEY
                                    , src.SOURCE_NAME
                                    , src.LEGAL_ENTITY
                                    , src.CUSTOMER_ACCOUNT
                                    , src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.CUSTOMER_NAME
                                    , src.RECORD_TYPE
                                    , src.CUSTOMER_COMPANY_TYPE
                                    , src.LEGACY_CUSTOMER
                                    , src.LEGACY_CONSUMER_NUMBER
                                    , src.ORGANIZATION_NUMBER
                                    , src.INVOICE_ACCOUNT
                                    , src.CUSTOMER_CURRENCY_CODE
                                    , src.CUSTOMER_CURRENCY_NAME
                                    , src.USE_CASH_DISCOUNT
                                    , src.SALES_REPRESENTATIVE_ID
                                    , src.SALES_REPRESENTATIVE
                                    , src.CUSTOMER_IS_BLOCKED
                                    , src.IS_PAST_DUE_CHECK
                                    , src.CREDIT_LIMIT
                                    , src.IS_MANDATORY_CREDIT_LIMIT
                                    , src.IS_CREDIT_LIMIT_BLOCKING_EXCLUDED
                                    , src.GRACE_DAYS
                                    , src.CURRENT_PERIOD_AVERAGE_DAYS_TO_PAY
                                    , src.YEARLY_AVERAGE_DAYS_TO_PAY
                                    , src.BUYING_GROUP_EXEMPT
                                    , src.BUYING_GROUP_KICKER
                                    , src.DEFAULT_CASH_DISCOUNT_ID
                                    , src.DEFAULT_CASH_DISCOUNT
                                    , src.DEFAULT_CASH_DISCOUNT_PERCENT
                                    , src.DEFAULT_DELIVERY_MODE_ID
                                    , src.DEFAULT_DELIVERY_MODE
                                    , src.DEFAULT_DELIVERY_TERMS_ID
                                    , src.DEFAULT_DELIVERY_TERMS
                                    , src.DEFAULT_PAYMENT_MODE_ID
                                    , src.DEFAULT_PAYMENT_MODE
                                    , src.DEFAULT_PAYMENT_TERMS_ID
                                    , src.DEFAULT_PAYMENT_TERMS
                                    , src.PAYMENT_TERMS_NUMBER_OF_DAYS
                                    , src.PAYMENT_TERMS_NUMBER_OF_MONTHS
                                    , src.CLASSIFICATION_GROUP_ID
                                    , src.CLASSIFICATION_GROUP
                                    , src.COMPANY_CHAIN_ID
                                    , src.COMPANY_CHAIN
                                    , src.CUSTOMER_GROUP_ID
                                    , src.CUSTOMER_GROUP
                                    , src.DIVISION_ID
                                    , src.DIVISION
                                    , src.LINE_OF_BUSINESS_ID
                                    , src.LINE_OF_BUSINESS
                                    , src.MARKUP_GROUP_ID
                                    , src.MARKUP_GROUP
                                    , src.PRICE_GROUP_ID
                                    , src.PRICE_GROUP
                                    , src.SALES_CHANNEL_ID
                                    , src.SALES_CHANNEL
                                    , src.SALES_DISTRICT_ID
                                    , src.SALES_DISTRICT
                                    , src.SALES_GROUP_ID
                                    , src.SALES_GROUP
                                    , src.SALES_POOL_ID
                                    , src.SALES_POOL
                                    , src.SEGMENT_ID
                                    , src.SEGMENT
                                    , src.SUB_SEGMENT_ID
                                    , src.SUB_SEGMENT
                                    , src.TAX_GROUP_ID
                                    , src.TAX_GROUP
                                    , src.PRIMARY_STREET
                                    , src.PRIMARY_CITY
                                    , src.PRIMARY_STATE
                                    , src.PRIMARY_ZIP_CODE
                                    , src.PRIMARY_COUNTRY
                                    , src.PRIMARY_TIME_ZONE
                                    , src.PRIMARY_ADDRESS_NAME
                                    , src.PRIMARY_EMAIL_ADDRESS
                                    , src.PRIMARY_FAX_NUMBER
                                    , src.PRIMARY_PHONE_NUMBER
                                    , src.INVOICE_STREET
                                    , src.INVOICE_CITY
                                    , src.INVOICE_STATE
                                    , src.INVOICE_ZIP_CODE
                                    , src.INVOICE_COUNTRY
                                    , src.INVOICE_ADDRESS_NAME
                                    , src.INVOICE_ADDRESS_LOCATION_ID
                                    , src.REPORT_PARENT
                                    , src.REPORT_PARENT_DIVISION_ID
                                    , src.REPORT_PARENT_DIVISION
                                    , src.REPORT_PARENT_SALES_DISTRICT_ID
                                    , src.REPORT_PARENT_SALES_DISTRICT
                                    , src.REPORT_PARENT_SALES_REPRESENTATIVE_ID
                                    , src.REPORT_PARENT_SALES_REPRESENTATIVE
                                    , src.ALTERNATIVE_ROLLUP_1
                                    , src.ALTERNATIVE_ROLLUP_2
                                    , src.ALTERNATIVE_ROLLUP_3
                                    , src.EXTERNAL_PRICING
                                    , src.REPORTING_DEALER_ID
                                    , src.REPORTING_DEALER
                                    , src.MCS_NETWORK_ID
                                    , src.REPORTING_DEALER_NAME_ID
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_EFFECTIVE_START_TIMESTAMP
                                    , src.HK_EFFECTIVE_END_TIMESTAMP
                                    , src.HK_CURRENT_FLAG
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                    );';

        res := (EXECUTE IMMEDIATE :merge_statement);
        
        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '6';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '7';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging stored procedure completed
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '9';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;