
/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_DIM_WORKER
    CREATED BY     : Joshua Mills
    CREATED ON     : 04/10/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_DIM_WORKER(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_DIM_WORKER
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_DIM_WORKER';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'HCMWORKER';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'DIM_WORKER';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;
    
    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_WORKER_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS DIM_WORKER_KEY
                                , 0 AS DIM_WORKER_SNKEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , nvl(src.PERSONNELNUMBER, '''') AS WORKER_ID
                                , nvl(src.DIRPARTYTABLE_NAME, '''') AS WORKER_NAME
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                ON src.HK_SOURCE_NAME = tgt.SOURCE_NAME AND src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        

        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_WORKER_PREP_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_WORKER_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d.             a PK_ROW_NUMBER column should be included that is partitioned by the AK of the table ordered by a timestamp descending (latest AK record would have the highest PK_ROW_NUMBER value)
        e. Select only rows with PK_ROW_NUMBER = 1 
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash(SOURCE_NAME, ''~'', to_char(RECORD_ID)) AS DIM_WORKER_KEY
                            , hash(SOURCE_NAME, ''~'', to_char(RECORD_ID)) AS DIM_WORKER_SNKEY
                            , SOURCE_NAME
                            , RECORD_ID
							, case when SOURCE_NAME = '''' then -2 else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , WORKER_ID
                            , WORKER_NAME
                            , hash(SOURCE_NAME, ''~'', to_char(RECORD_ID), ''~'', WORKER_ID, ''~'', WORKER_NAME) AS SRC_HK_HASH_KEY
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by SOURCE_NAME, RECORD_ID order by HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' src 
                            QUALIFY PK_ROW_NUMBER = 1';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;

    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_DIM_WORKER_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.DIM_WORKER

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		tgt.DIM_WORKER_KEY = src.DIM_WORKER_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.DIM_WORKER_KEY = tgt.DIM_WORKER_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.WORKER_ID = src.WORKER_ID
                                    , tgt.WORKER_NAME = src.WORKER_NAME
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                           INSERT
                                (
                                    DIM_WORKER_KEY
                                    , DIM_WORKER_SNKEY
                                    , SOURCE_NAME
                                    , RECORD_ID
									, DIM_SOURCE_SYSTEM_SNKEY
                                    , WORKER_ID
                                    , WORKER_NAME
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                            VALUES
                                (
                                    src.DIM_WORKER_KEY
                                    , src.DIM_WORKER_SNKEY
                                    , src.SOURCE_NAME
                                    , src.RECORD_ID
									, src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.WORKER_ID
                                    , src.WORKER_NAME
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);
        
        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '6';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '7';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging stored procedure completed
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '9';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;
