/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_PICKING_LINE
    CREATED BY     : Joshua Mills
    CREATED ON     : 07/09/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_PICKING_LINE(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_PICKING_LINE
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_PICKING_LINE';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'WMSORDERTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_PICKING_LINE';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_PICKING_LINE_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_PICKING_LINE_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS PICK_COMPLETED_DATE_DIM_DATE_KEY
                                , 0 AS PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                                , 0 AS PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                                , 0 AS PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , 0 AS PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                , 0 AS PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                , 0 AS PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                                , 0 AS PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                                , 0 AS DIM_CUSTOMER_KEY
                                , 0 AS DIM_CUSTOMER_SNKEY
                                , 0 AS DIM_DELIVERY_MODE_KEY
                                , 0 AS DIM_DELIVERY_MODE_SNKEY
                                , 0 AS DIM_DELIVERY_TERM_KEY
                                , 0 AS DIM_DELIVERY_TERM_SNKEY
                                , 0 AS DIM_INVENTORY_KEY
                                , 0 AS DIM_INVENTORY_SNKEY
                                , 0 AS DIM_INVENTORY_TO_KEY
                                , 0 AS DIM_INVENTORY_TO_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , 0 AS DIM_SALES_ORDER_KEY
                                , 0 AS DIM_SALES_ORDER_SNKEY
                                , 0 AS DIM_SITE_KEY
                                , 0 AS DIM_SITE_SNKEY
                                , 0 AS DIM_WAREHOUSE_KEY
                                , 0 AS DIM_WAREHOUSE_SNKEY
                                , 0 AS DIM_WORKER_OPERATOR_KEY
                                , 0 AS DIM_WORKER_OPERATOR_SNKEY
                                , nvl(src.CUSTOMER, '''') AS CUSTOMER_ACCOUNT
                                , nvl(src.WMSORDER_DLVMODE, '''') AS DELIVERY_MODE_ID
                                , nvl(src.WMSORDER_DLVTERM, '''') AS DELIVERY_TERM_ID
                                , nvl(src.INVENTDIMID, '''') AS INVENTORY_DIMENSION_ID
                                , nvl(src.TOINVENTDIMID, '''') AS INVENTORY_DIMENSION_ID_TO
                                , nvl(src.ITEMID, '''') AS ITEM_ID
                                , nvl(src.DELIVERYPOSTALADDRESS, 0) AS RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , nvl(src.INVENTTRANSREFID, '''') AS SALES_ORDER_ID
                                , nvl(src.WMSPICKINGROUTE_PRINTMGMTSITEID, '''') AS SITE_ID
                                , nvl(src.WMSPICKINGROUTE_INVENTLOCATIONID, '''') AS WAREHOUSE_ID
                                , nvl(src.OPERATORWORKER, 0) AS RECORD_ID_OPERATOR
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_EXPEDITIONSTATUS, '''') AS EXPEDITION_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_FREIGHTSLIPTYPE, '''') AS FREIGHT_SLIP_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_STATUS, '''') AS PICKING_ORDER_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_TYPE, '''') AS PICKING_ORDER_TYPE
                                , nvl(src.WMSPICKINGROUTE_PRIORITY, 0) AS PICKING_ROUTE_PRIORITY
                                , nvl(src.TIMEXTENDERENUMTABLE5_ENUMVALUELABEL_TRANSTYPE, '''') AS PICKING_ROUTE_TRANSACTION_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE6_ENUMVALUELABEL_SHIPMENTTYPE, '''') AS SHIPMENT_TYPE
                                , case when nvl(src.OPTIMIZEDPICKING, 0) = 1 then ''Yes'' else ''No'' END AS IS_OPTIMIZED_PICKING
                                , case when nvl(src.PRERESERVED, 0) = 1 then ''Yes'' else ''No'' END AS IS_PRE_RESERVED
                                , case when nvl(src.ISRESERVED, 0) = 1 then ''Yes'' else ''No'' END AS IS_RESERVED
                                , case when nvl(src.RFS_PICKCOMPLETED, ''1900-01-01 00:00:00'') in (''1900-01-01 00:00:00'') then ''1950-01-01 00:00:00''   when src.RFS_PICKCOMPLETED < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31 00:00:00''   when src.RFS_PICKCOMPLETED > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31 00:00:00'' else src.RFS_PICKCOMPLETED END AS PICK_COMPLETED_DATETIME
                                , case when nvl(src.CREATEDDATETIME, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.CREATEDDATETIME < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.CREATEDDATETIME > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else dateadd(minute, nvl(src.TIMEZONEINFO1_TIMEBIAS, 0) * -1, nvl(src.CREATEDDATETIME, ''1950-01-01'')) END AS PICKING_LINE_CREATED_DATE
                                , case when nvl(src.DLVDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.DLVDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.DLVDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.DLVDATE END AS PICKING_LINE_SHIPPING_DATE_REQUESTED
                                , case when nvl(src.WMSPICKINGROUTE_DLVDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.WMSPICKINGROUTE_DLVDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.WMSPICKINGROUTE_DLVDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.WMSPICKINGROUTE_DLVDATE END AS PICKING_ROUTE_SHIP_DATE_REQUESTED
                                , to_time(dateadd(second, nvl(src.EXPEDITIONTIME, 0), to_timestamp(''00:00:00.000'',''HH24:MI:SS.FF''))) AS EXPENDITION_TIME_OF_DAY
                                , nvl(src.WMSORDER_FREIGHTZONE, '''') AS FREIGHT_ZONE
                                , nvl(src.INVENTTRANSID, '''') AS INVENTORY_TRANSACTION_ID
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.ORDERID, '''') AS ORDER_ID
                                , nvl(src.ROUTEID, '''') AS PICKING_ROUTE_ID
                                , nvl(src.WMSPICKINGROUTE_TRANSTYPE, 0) AS TRANSPORT_ORDER_TRANSACTION_TYPE
                                , nvl(src.QTY, 0) AS QUANTITY
                                , nvl(src.VOLUME, 0) AS ESTIMATED_VOLUME
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                    on src.HK_SOURCE_NAME = tgt.SOURCE_NAME and src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_PICKING_LINE_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_PICKING_LINE_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_PICKING_LINE_KEY
                            , src.SOURCE_NAME
                            , src.RECORD_ID
                            , case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.PICK_COMPLETED_DATETIME = ''1950-01-01 00:00:00'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS PICK_COMPLETED_DATE_DIM_DATE_KEY
                            , src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                            , case when src.PICKING_LINE_CREATED_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                            , src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                            , case when src.PICKING_LINE_SHIPPING_DATE_REQUESTED = ''1950-01-01'' then -2 else nvl(d4.DIM_DATE_KEY, -1) END AS PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                            , src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                            , case when src.PICKING_ROUTE_SHIP_DATE_REQUESTED = ''1950-01-01'' then -2 else nvl(d5.DIM_DATE_KEY, -1) END AS PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                            , src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                            , case when src.DIM_CUSTOMER_SNKEY = -2 then -2 else nvl(d6.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_KEY
                            , src.DIM_CUSTOMER_SNKEY
                            , case when src.DIM_DELIVERY_MODE_SNKEY = -2 then -2 else nvl(d7.DIM_DELIVERY_MODE_KEY, -1) END AS DIM_DELIVERY_MODE_KEY
                            , src.DIM_DELIVERY_MODE_SNKEY
                            , case when src.DIM_DELIVERY_TERM_SNKEY = -2 then -2 else nvl(d8.DIM_DELIVERY_TERM_KEY, -1) END AS DIM_DELIVERY_TERM_KEY
                            , src.DIM_DELIVERY_TERM_SNKEY
                            , case when src.DIM_INVENTORY_SNKEY = -2 then -2 else nvl(d9.DIM_INVENTORY_KEY, -1) END AS DIM_INVENTORY_KEY
                            , src.DIM_INVENTORY_SNKEY
                            , case when src.DIM_INVENTORY_TO_SNKEY = -2 then -2 else nvl(d10.DIM_INVENTORY_KEY, -1) END AS DIM_INVENTORY_TO_KEY
                            , src.DIM_INVENTORY_TO_SNKEY
                            , case when src.DIM_ITEM_SNKEY = -2 then -2 else nvl(d11.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
                            , src.DIM_ITEM_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d12.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = -2 then -2 else nvl(d13.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
                            , src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                            , case when src.DIM_SALES_ORDER_SNKEY = -2 then -2 else nvl(d14.DIM_SALES_ORDER_KEY, -1) END AS DIM_SALES_ORDER_KEY
                            , src.DIM_SALES_ORDER_SNKEY
                            , case when src.DIM_SITE_SNKEY = -2 then -2 else nvl(d15.DIM_SITE_KEY, -1) END AS DIM_SITE_KEY
                            , src.DIM_SITE_SNKEY
                            , case when src.DIM_WAREHOUSE_SNKEY = -2 then -2 else nvl(d16.DIM_WAREHOUSE_KEY, -1) END AS DIM_WAREHOUSE_KEY
                            , src.DIM_WAREHOUSE_SNKEY
                            , case when src.DIM_WORKER_OPERATOR_SNKEY = -2 then -2 else nvl(d17.DIM_WORKER_KEY, -1) END AS DIM_WORKER_OPERATOR_KEY
                            , src.DIM_WORKER_OPERATOR_SNKEY
                            , src.CUSTOMER_ACCOUNT
                            , src.DELIVERY_MODE_ID
                            , src.DELIVERY_TERM_ID
                            , src.INVENTORY_DIMENSION_ID
                            , src.INVENTORY_DIMENSION_ID_TO
                            , src.ITEM_ID
                            , src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                            , src.SALES_ORDER_ID
                            , src.SITE_ID
                            , src.WAREHOUSE_ID
                            , src.RECORD_ID_OPERATOR
                            , src.EXPEDITION_STATUS
                            , src.FREIGHT_SLIP_TYPE
                            , src.PICKING_ORDER_STATUS
                            , src.PICKING_ORDER_TYPE
                            , src.PICKING_ROUTE_PRIORITY
                            , src.PICKING_ROUTE_TRANSACTION_TYPE
                            , src.SHIPMENT_TYPE
                            , src.IS_OPTIMIZED_PICKING
                            , src.IS_PRE_RESERVED
                            , src.IS_RESERVED
                            , src.PICK_COMPLETED_DATETIME
                            , src.PICKING_LINE_CREATED_DATE
                            , src.PICKING_LINE_SHIPPING_DATE_REQUESTED
                            , src.PICKING_ROUTE_SHIP_DATE_REQUESTED
                            , src.EXPENDITION_TIME_OF_DAY
                            , src.FREIGHT_ZONE
                            , src.INVENTORY_TRANSACTION_ID
                            , src.LEGAL_ENTITY
                            , src.ORDER_ID
                            , src.PICKING_ROUTE_ID
                            , src.TRANSPORT_ORDER_TRANSACTION_TYPE
                            , src.QUANTITY
                            , src.ESTIMATED_VOLUME
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.CUSTOMER_ACCOUNT, ''~'', src.DELIVERY_MODE_ID, ''~'', src.DELIVERY_TERM_ID, ''~'', src.INVENTORY_DIMENSION_ID, ''~'', src.INVENTORY_DIMENSION_ID_TO, ''~'', src.ITEM_ID, ''~'', to_char(src.RECORD_ID_LOCATION_DELIVERY_ADDRESS), ''~'', src.SALES_ORDER_ID, ''~'', src.SITE_ID, ''~'', src.WAREHOUSE_ID, ''~'', to_char(src.RECORD_ID_OPERATOR), ''~'', src.EXPEDITION_STATUS, ''~'', src.FREIGHT_SLIP_TYPE, ''~'', src.PICKING_ORDER_STATUS, ''~'', src.PICKING_ORDER_TYPE, ''~'', to_char(src.PICKING_ROUTE_PRIORITY), ''~'', src.PICKING_ROUTE_TRANSACTION_TYPE, ''~'', src.SHIPMENT_TYPE, ''~'', src.IS_OPTIMIZED_PICKING, ''~'', src.IS_PRE_RESERVED, ''~'', src.IS_RESERVED, ''~'', to_char(src.PICK_COMPLETED_DATETIME, ''yyyymmddhh24missff3''), ''~'', to_char(src.PICKING_LINE_CREATED_DATE, ''yyyymmdd''), ''~'', to_char(src.PICKING_LINE_SHIPPING_DATE_REQUESTED, ''yyyymmdd''), ''~'', to_char(src.PICKING_ROUTE_SHIP_DATE_REQUESTED, ''yyyymmdd''), ''~'', src.EXPENDITION_TIME_OF_DAY, ''~'', src.FREIGHT_ZONE, ''~'', src.INVENTORY_TRANSACTION_ID, ''~'', src.LEGAL_ENTITY, ''~'', src.ORDER_ID, ''~'', src.PICKING_ROUTE_ID, ''~'', to_char(src.TRANSPORT_ORDER_TRANSACTION_TYPE), ''~'', to_char(src.QUANTITY), ''~'', to_char(src.ESTIMATED_VOLUME)) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID  order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            prep01.FACT_PICKING_LINE_KEY
                            , prep01.SOURCE_NAME
                            , prep01.RECORD_ID
                            , prep01.DIM_SOURCE_SYSTEM_KEY
                            , case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , prep01.PICK_COMPLETED_DATE_DIM_DATE_KEY
                            , case when prep01.PICK_COMPLETED_DATETIME = ''1950-01-01 00:00:00'' then -2 else hash('''', ''~'', to_char(prep01.PICK_COMPLETED_DATETIME, ''yyyymmdd'')) END AS PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                            , prep01.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                            , case when prep01.PICKING_LINE_CREATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.PICKING_LINE_CREATED_DATE, ''yyyymmdd'')) END AS PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                            , prep01.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                            , case when prep01.PICKING_LINE_SHIPPING_DATE_REQUESTED = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.PICKING_LINE_SHIPPING_DATE_REQUESTED, ''yyyymmdd'')) END AS PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                            , prep01.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                            , case when prep01.PICKING_ROUTE_SHIP_DATE_REQUESTED = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.PICKING_ROUTE_SHIP_DATE_REQUESTED, ''yyyymmdd'')) END AS PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                            , prep01.DIM_CUSTOMER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
                            , case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
									when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
								else DIM_CUSTOMER_SNKEY_RAW
								end as DIM_CUSTOMER_SNKEY
                            , prep01.DIM_DELIVERY_MODE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_MODE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_MODE_ID) END AS DIM_DELIVERY_MODE_SNKEY
                            , prep01.DIM_DELIVERY_TERM_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_TERM_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_TERM_ID) END AS DIM_DELIVERY_TERM_SNKEY
                            , prep01.DIM_INVENTORY_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.INVENTORY_DIMENSION_ID = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INVENTORY_DIMENSION_ID) END AS DIM_INVENTORY_SNKEY
                            , prep01.DIM_INVENTORY_TO_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.INVENTORY_DIMENSION_ID_TO = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INVENTORY_DIMENSION_ID_TO) END AS DIM_INVENTORY_TO_SNKEY
                            , prep01.DIM_ITEM_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.ITEM_ID = '''' then -2 else hash('''', ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.ITEM_ID) END AS DIM_ITEM_SNKEY
                            , prep01.DIM_LEGAL_ENTITY_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , prep01.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                            , case when nvl(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS)) END AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                            , prep01.DIM_SALES_ORDER_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.SALES_ORDER_ID = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_ORDER_ID) END AS DIM_SALES_ORDER_SNKEY
                            , prep01.DIM_SITE_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.SITE_ID = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SITE_ID) END AS DIM_SITE_SNKEY
                            , prep01.DIM_WAREHOUSE_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.WAREHOUSE_ID = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.WAREHOUSE_ID) END AS DIM_WAREHOUSE_SNKEY
                            , prep01.DIM_WORKER_OPERATOR_KEY
                            , case when nvl(prep01.RECORD_ID_OPERATOR, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_OPERATOR)) END AS DIM_WORKER_OPERATOR_SNKEY
                            , prep01.CUSTOMER_ACCOUNT
                            , prep01.DELIVERY_MODE_ID
                            , prep01.DELIVERY_TERM_ID
                            , prep01.INVENTORY_DIMENSION_ID
                            , prep01.INVENTORY_DIMENSION_ID_TO
                            , prep01.ITEM_ID
                            , prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                            , prep01.SALES_ORDER_ID
                            , prep01.SITE_ID
                            , prep01.WAREHOUSE_ID
                            , prep01.RECORD_ID_OPERATOR
                            , prep01.EXPEDITION_STATUS
                            , prep01.FREIGHT_SLIP_TYPE
                            , prep01.PICKING_ORDER_STATUS
                            , prep01.PICKING_ORDER_TYPE
                            , prep01.PICKING_ROUTE_PRIORITY
                            , prep01.PICKING_ROUTE_TRANSACTION_TYPE
                            , prep01.SHIPMENT_TYPE
                            , prep01.IS_OPTIMIZED_PICKING
                            , prep01.IS_PRE_RESERVED
                            , prep01.IS_RESERVED
                            , prep01.PICK_COMPLETED_DATETIME
                            , prep01.PICKING_LINE_CREATED_DATE
                            , prep01.PICKING_LINE_SHIPPING_DATE_REQUESTED
                            , prep01.PICKING_ROUTE_SHIP_DATE_REQUESTED
                            , prep01.EXPENDITION_TIME_OF_DAY
                            , prep01.FREIGHT_ZONE
                            , prep01.INVENTORY_TRANSACTION_ID
                            , prep01.LEGAL_ENTITY
                            , prep01.ORDER_ID
                            , prep01.PICKING_ROUTE_ID
                            , prep01.TRANSPORT_ORDER_TRANSACTION_TYPE
                            , prep01.QUANTITY
                            , prep01.ESTIMATED_VOLUME
                            , prep01.HK_HASH_KEY
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d6 ON
                                src.DIM_CUSTOMER_SNKEY = d6.DIM_CUSTOMER_SNKEY
                                and src.PICKING_LINE_SHIPPING_DATE_REQUESTED >= d6.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.PICKING_LINE_SHIPPING_DATE_REQUESTED < d6.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d7 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d7.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d8 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d8.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d9 ON
                                src.DIM_INVENTORY_SNKEY = d9.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d10 ON
                                src.DIM_INVENTORY_TO_SNKEY = d10.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d11 ON
                                src.DIM_ITEM_SNKEY = d11.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d12 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d12.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d13 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d13.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d14 ON
                                src.DIM_SALES_ORDER_SNKEY = d14.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SITE d15 ON
                                src.DIM_SITE_SNKEY = d15.DIM_SITE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d16 ON
                                src.DIM_WAREHOUSE_SNKEY = d16.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
                                src.DIM_WORKER_OPERATOR_SNKEY = d17.DIM_WORKER_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_PICKING_LINE_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_PICKING_LINE

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_PICKING_LINE_KEY = tgt.FACT_PICKING_LINE_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_PICKING_LINE_KEY = tgt.FACT_PICKING_LINE_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.PICK_COMPLETED_DATE_DIM_DATE_KEY = src.PICK_COMPLETED_DATE_DIM_DATE_KEY
                                    , tgt.PICK_COMPLETED_DATE_DIM_DATE_SNKEY = src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                                    , tgt.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY = src.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY = src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                    , tgt.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , tgt.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY = src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY = src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , tgt.DIM_CUSTOMER_KEY = src.DIM_CUSTOMER_KEY
                                    , tgt.DIM_CUSTOMER_SNKEY = src.DIM_CUSTOMER_SNKEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_MODE_SNKEY = src.DIM_DELIVERY_MODE_SNKEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_DELIVERY_TERM_SNKEY = src.DIM_DELIVERY_TERM_SNKEY
                                    , tgt.DIM_INVENTORY_KEY = src.DIM_INVENTORY_KEY
                                    , tgt.DIM_INVENTORY_SNKEY = src.DIM_INVENTORY_SNKEY
                                    , tgt.DIM_INVENTORY_TO_KEY = src.DIM_INVENTORY_TO_KEY
                                    , tgt.DIM_INVENTORY_TO_SNKEY = src.DIM_INVENTORY_TO_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_ORDER_SNKEY = src.DIM_SALES_ORDER_SNKEY
                                    , tgt.DIM_SITE_KEY = src.DIM_SITE_KEY
                                    , tgt.DIM_SITE_SNKEY = src.DIM_SITE_SNKEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WAREHOUSE_SNKEY = src.DIM_WAREHOUSE_SNKEY
                                    , tgt.DIM_WORKER_OPERATOR_KEY = src.DIM_WORKER_OPERATOR_KEY
                                    , tgt.DIM_WORKER_OPERATOR_SNKEY = src.DIM_WORKER_OPERATOR_SNKEY
                                    , tgt.CUSTOMER_ACCOUNT = src.CUSTOMER_ACCOUNT
                                    , tgt.DELIVERY_MODE_ID = src.DELIVERY_MODE_ID
                                    , tgt.DELIVERY_TERM_ID = src.DELIVERY_TERM_ID
                                    , tgt.INVENTORY_DIMENSION_ID = src.INVENTORY_DIMENSION_ID
                                    , tgt.INVENTORY_DIMENSION_ID_TO = src.INVENTORY_DIMENSION_ID_TO
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.RECORD_ID_LOCATION_DELIVERY_ADDRESS = src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                    , tgt.SALES_ORDER_ID = src.SALES_ORDER_ID
                                    , tgt.SITE_ID = src.SITE_ID
                                    , tgt.WAREHOUSE_ID = src.WAREHOUSE_ID
                                    , tgt.RECORD_ID_OPERATOR = src.RECORD_ID_OPERATOR
                                    , tgt.EXPEDITION_STATUS = src.EXPEDITION_STATUS
                                    , tgt.FREIGHT_SLIP_TYPE = src.FREIGHT_SLIP_TYPE
                                    , tgt.PICKING_ORDER_STATUS = src.PICKING_ORDER_STATUS
                                    , tgt.PICKING_ORDER_TYPE = src.PICKING_ORDER_TYPE
                                    , tgt.PICKING_ROUTE_PRIORITY = src.PICKING_ROUTE_PRIORITY
                                    , tgt.PICKING_ROUTE_TRANSACTION_TYPE = src.PICKING_ROUTE_TRANSACTION_TYPE
                                    , tgt.SHIPMENT_TYPE = src.SHIPMENT_TYPE
                                    , tgt.IS_OPTIMIZED_PICKING = src.IS_OPTIMIZED_PICKING
                                    , tgt.IS_PRE_RESERVED = src.IS_PRE_RESERVED
                                    , tgt.IS_RESERVED = src.IS_RESERVED
                                    , tgt.PICK_COMPLETED_DATETIME = src.PICK_COMPLETED_DATETIME
                                    , tgt.PICKING_LINE_CREATED_DATE = src.PICKING_LINE_CREATED_DATE
                                    , tgt.PICKING_LINE_SHIPPING_DATE_REQUESTED = src.PICKING_LINE_SHIPPING_DATE_REQUESTED
                                    , tgt.PICKING_ROUTE_SHIP_DATE_REQUESTED = src.PICKING_ROUTE_SHIP_DATE_REQUESTED
                                    , tgt.EXPENDITION_TIME_OF_DAY = src.EXPENDITION_TIME_OF_DAY
                                    , tgt.FREIGHT_ZONE = src.FREIGHT_ZONE
                                    , tgt.INVENTORY_TRANSACTION_ID = src.INVENTORY_TRANSACTION_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.ORDER_ID = src.ORDER_ID
                                    , tgt.PICKING_ROUTE_ID = src.PICKING_ROUTE_ID
                                    , tgt.TRANSPORT_ORDER_TRANSACTION_TYPE = src.TRANSPORT_ORDER_TRANSACTION_TYPE
                                    , tgt.QUANTITY = src.QUANTITY
                                    , tgt.ESTIMATED_VOLUME = src.ESTIMATED_VOLUME
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                	FACT_PICKING_LINE_KEY
                                	, SOURCE_NAME
                                	, RECORD_ID
                                	, DIM_SOURCE_SYSTEM_KEY
                                	, DIM_SOURCE_SYSTEM_SNKEY
                                	, PICK_COMPLETED_DATE_DIM_DATE_KEY
                                	, PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                                	, PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                                	, PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                	, PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                	, PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                	, PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                                	, PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                                	, DIM_CUSTOMER_KEY
                                	, DIM_CUSTOMER_SNKEY
                                	, DIM_DELIVERY_MODE_KEY
                                	, DIM_DELIVERY_MODE_SNKEY
                                	, DIM_DELIVERY_TERM_KEY
                                	, DIM_DELIVERY_TERM_SNKEY
                                	, DIM_INVENTORY_KEY
                                	, DIM_INVENTORY_SNKEY
                                	, DIM_INVENTORY_TO_KEY
                                	, DIM_INVENTORY_TO_SNKEY
                                	, DIM_ITEM_KEY
                                	, DIM_ITEM_SNKEY
                                	, DIM_LEGAL_ENTITY_KEY
                                	, DIM_LEGAL_ENTITY_SNKEY
                                	, DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                	, DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                	, DIM_SALES_ORDER_KEY
                                	, DIM_SALES_ORDER_SNKEY
                                	, DIM_SITE_KEY
                                	, DIM_SITE_SNKEY
                                	, DIM_WAREHOUSE_KEY
                                	, DIM_WAREHOUSE_SNKEY
                                	, DIM_WORKER_OPERATOR_KEY
                                	, DIM_WORKER_OPERATOR_SNKEY
                                	, CUSTOMER_ACCOUNT
                                	, DELIVERY_MODE_ID
                                	, DELIVERY_TERM_ID
                                	, INVENTORY_DIMENSION_ID
                                	, INVENTORY_DIMENSION_ID_TO
                                	, ITEM_ID
                                	, RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                	, SALES_ORDER_ID
                                	, SITE_ID
                                	, WAREHOUSE_ID
                                	, RECORD_ID_OPERATOR
                                	, EXPEDITION_STATUS
                                	, FREIGHT_SLIP_TYPE
                                	, PICKING_ORDER_STATUS
                                	, PICKING_ORDER_TYPE
                                	, PICKING_ROUTE_PRIORITY
                                	, PICKING_ROUTE_TRANSACTION_TYPE
                                	, SHIPMENT_TYPE
                                	, IS_OPTIMIZED_PICKING
                                	, IS_PRE_RESERVED
                                	, IS_RESERVED
                                	, PICK_COMPLETED_DATETIME
                                	, PICKING_LINE_CREATED_DATE
                                	, PICKING_LINE_SHIPPING_DATE_REQUESTED
                                	, PICKING_ROUTE_SHIP_DATE_REQUESTED
                                	, EXPENDITION_TIME_OF_DAY
                                	, FREIGHT_ZONE
                                	, INVENTORY_TRANSACTION_ID
                                	, LEGAL_ENTITY
                                	, ORDER_ID
                                	, PICKING_ROUTE_ID
                                	, TRANSPORT_ORDER_TRANSACTION_TYPE
                                	, QUANTITY
                                	, ESTIMATED_VOLUME
                                	, HK_HASH_KEY
                                	, HK_SOURCE_NAME
                                	, HK_SOFT_DELETE_FLAG
                                	, HK_SOURCE_CREATED_TIMESTAMP
                                	, HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, HK_CREATED_JOB_RUN_ID
                                	, HK_LAST_UPDATED_JOB_RUN_ID
                                	, HK_CREATED_TIMESTAMP
                                	, HK_LAST_UPDATED_TIMESTAMP
                                	, HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                	src.FACT_PICKING_LINE_KEY
                                	, src.SOURCE_NAME
                                	, src.RECORD_ID
                                	, src.DIM_SOURCE_SYSTEM_KEY
                                	, src.DIM_SOURCE_SYSTEM_SNKEY
                                	, src.PICK_COMPLETED_DATE_DIM_DATE_KEY
                                	, src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY
                                	, src.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                                	, src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                	, src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                	, src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                	, src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                                	, src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY
                                	, src.DIM_CUSTOMER_KEY
                                	, src.DIM_CUSTOMER_SNKEY
                                	, src.DIM_DELIVERY_MODE_KEY
                                	, src.DIM_DELIVERY_MODE_SNKEY
                                	, src.DIM_DELIVERY_TERM_KEY
                                	, src.DIM_DELIVERY_TERM_SNKEY
                                	, src.DIM_INVENTORY_KEY
                                	, src.DIM_INVENTORY_SNKEY
                                	, src.DIM_INVENTORY_TO_KEY
                                	, src.DIM_INVENTORY_TO_SNKEY
                                	, src.DIM_ITEM_KEY
                                	, src.DIM_ITEM_SNKEY
                                	, src.DIM_LEGAL_ENTITY_KEY
                                	, src.DIM_LEGAL_ENTITY_SNKEY
                                	, src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                	, src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                	, src.DIM_SALES_ORDER_KEY
                                	, src.DIM_SALES_ORDER_SNKEY
                                	, src.DIM_SITE_KEY
                                	, src.DIM_SITE_SNKEY
                                	, src.DIM_WAREHOUSE_KEY
                                	, src.DIM_WAREHOUSE_SNKEY
                                	, src.DIM_WORKER_OPERATOR_KEY
                                	, src.DIM_WORKER_OPERATOR_SNKEY
                                	, src.CUSTOMER_ACCOUNT
                                	, src.DELIVERY_MODE_ID
                                	, src.DELIVERY_TERM_ID
                                	, src.INVENTORY_DIMENSION_ID
                                	, src.INVENTORY_DIMENSION_ID_TO
                                	, src.ITEM_ID
                                	, src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                	, src.SALES_ORDER_ID
                                	, src.SITE_ID
                                	, src.WAREHOUSE_ID
                                	, src.RECORD_ID_OPERATOR
                                	, src.EXPEDITION_STATUS
                                	, src.FREIGHT_SLIP_TYPE
                                	, src.PICKING_ORDER_STATUS
                                	, src.PICKING_ORDER_TYPE
                                	, src.PICKING_ROUTE_PRIORITY
                                	, src.PICKING_ROUTE_TRANSACTION_TYPE
                                	, src.SHIPMENT_TYPE
                                	, src.IS_OPTIMIZED_PICKING
                                	, src.IS_PRE_RESERVED
                                	, src.IS_RESERVED
                                	, src.PICK_COMPLETED_DATETIME
                                	, src.PICKING_LINE_CREATED_DATE
                                	, src.PICKING_LINE_SHIPPING_DATE_REQUESTED
                                	, src.PICKING_ROUTE_SHIP_DATE_REQUESTED
                                	, src.EXPENDITION_TIME_OF_DAY
                                	, src.FREIGHT_ZONE
                                	, src.INVENTORY_TRANSACTION_ID
                                	, src.LEGAL_ENTITY
                                	, src.ORDER_ID
                                	, src.PICKING_ROUTE_ID
                                	, src.TRANSPORT_ORDER_TRANSACTION_TYPE
                                	, src.QUANTITY
                                	, src.ESTIMATED_VOLUME
                                	, src.SRC_HK_HASH_KEY
                                	, src.HK_SOURCE_NAME
                                	, src.HK_SOFT_DELETE_FLAG
                                	, src.HK_SOURCE_CREATED_TIMESTAMP
                                	, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, src.HK_CREATED_JOB_RUN_ID
                                	, src.HK_LAST_UPDATED_JOB_RUN_ID
                                	, src.HK_CREATED_TIMESTAMP
                                	, src.HK_LAST_UPDATED_TIMESTAMP
                                	, src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
              a.FACT_PICKING_LINE_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_PICK_COMPLETED_DATE_DIM_DATE_KEY
            , a.NEW_PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
            , a.NEW_PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
            , a.NEW_PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
            , a.NEW_DIM_CUSTOMER_KEY
            , a.NEW_DIM_DELIVERY_MODE_KEY
            , a.NEW_DIM_DELIVERY_TERM_KEY
            , a.NEW_DIM_INVENTORY_KEY
            , a.NEW_DIM_INVENTORY_TO_KEY
            , a.NEW_DIM_ITEM_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
            , a.NEW_DIM_SALES_ORDER_KEY
            , a.NEW_DIM_SITE_KEY
            , a.NEW_DIM_WAREHOUSE_KEY
            , a.NEW_DIM_WORKER_OPERATOR_KEY
        from (
            select 
                src.FACT_PICKING_LINE_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.PICK_COMPLETED_DATE_DIM_DATE_KEY
                , src.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                , src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                , src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                , src.DIM_CUSTOMER_KEY
                , src.DIM_DELIVERY_MODE_KEY
                , src.DIM_DELIVERY_TERM_KEY
                , src.DIM_INVENTORY_KEY
                , src.DIM_INVENTORY_TO_KEY
                , src.DIM_ITEM_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , src.DIM_SALES_ORDER_KEY
                , src.DIM_SITE_KEY
                , src.DIM_WAREHOUSE_KEY
                , src.DIM_WORKER_OPERATOR_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_PICK_COMPLETED_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_DATE_KEY, -1) AS NEW_PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                , nvl(d5.DIM_DATE_KEY, -1) AS NEW_PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                , nvl(d6.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
                , nvl(d7.DIM_DELIVERY_MODE_KEY, -1) AS NEW_DIM_DELIVERY_MODE_KEY
                , nvl(d8.DIM_DELIVERY_TERM_KEY, -1) AS NEW_DIM_DELIVERY_TERM_KEY
                , nvl(d9.DIM_INVENTORY_KEY, -1) AS NEW_DIM_INVENTORY_KEY
                , nvl(d10.DIM_INVENTORY_KEY, -1) AS NEW_DIM_INVENTORY_TO_KEY
                , nvl(d11.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                , nvl(d12.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d13.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , nvl(d14.DIM_SALES_ORDER_KEY, -1) AS NEW_DIM_SALES_ORDER_KEY
                , nvl(d15.DIM_SITE_KEY, -1) AS NEW_DIM_SITE_KEY
                , nvl(d16.DIM_WAREHOUSE_KEY, -1) AS NEW_DIM_WAREHOUSE_KEY
                , nvl(d17.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_OPERATOR_KEY
            from ' || :tgt_db || '.global.FACT_PICKING_LINE src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d6 ON
                                src.DIM_CUSTOMER_SNKEY = d6.DIM_CUSTOMER_SNKEY
                                and src.PICKING_LINE_SHIPPING_DATE_REQUESTED >= d6.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.PICKING_LINE_SHIPPING_DATE_REQUESTED < d6.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d7 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d7.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d8 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d8.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d9 ON
                                src.DIM_INVENTORY_SNKEY = d9.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d10 ON
                                src.DIM_INVENTORY_TO_SNKEY = d10.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d11 ON
                                src.DIM_ITEM_SNKEY = d11.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d12 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d12.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d13 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d13.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d14 ON
                                src.DIM_SALES_ORDER_SNKEY = d14.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SITE d15 ON
                                src.DIM_SITE_SNKEY = d15.DIM_SITE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d16 ON
                                src.DIM_WAREHOUSE_SNKEY = d16.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
                                src.DIM_WORKER_OPERATOR_SNKEY = d17.DIM_WORKER_SNKEY
            where 1=1
            and (
                (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                or (src.PICK_COMPLETED_DATE_DIM_DATE_KEY = -1 and src.PICK_COMPLETED_DATE_DIM_DATE_SNKEY != -1)
                or (src.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY = -1 and src.PICKING_LINE_CREATED_DATE_DIM_DATE_SNKEY != -1)
                or (src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = -1 and src.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY != -1)
                or (src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY = -1 and src.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_SNKEY != -1)
                or (src.DIM_CUSTOMER_KEY = -1 and src.DIM_CUSTOMER_SNKEY != -1)
                or (src.DIM_DELIVERY_MODE_KEY = -1 and src.DIM_DELIVERY_MODE_SNKEY != -1)
                or (src.DIM_DELIVERY_TERM_KEY = -1 and src.DIM_DELIVERY_TERM_SNKEY != -1)
                or (src.DIM_INVENTORY_KEY = -1 and src.DIM_INVENTORY_SNKEY != -1)
                or (src.DIM_INVENTORY_TO_KEY = -1 and src.DIM_INVENTORY_TO_SNKEY != -1)
                or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
                or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                or (src.DIM_LOCATION_DELIVERY_ADDRESS_KEY = -1 and src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY != -1)
                or (src.DIM_SALES_ORDER_KEY = -1 and src.DIM_SALES_ORDER_SNKEY != -1)
                or (src.DIM_SITE_KEY = -1 and src.DIM_SITE_SNKEY != -1)
                or (src.DIM_WAREHOUSE_KEY = -1 and src.DIM_WAREHOUSE_SNKEY != -1)
                or (src.DIM_WORKER_OPERATOR_KEY = -1 and src.DIM_WORKER_OPERATOR_SNKEY != -1)
                )
            ) a
        where 1=1
        and (
        (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
        or (a.PICK_COMPLETED_DATE_DIM_DATE_KEY != a.NEW_PICK_COMPLETED_DATE_DIM_DATE_KEY)
        or (a.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY != a.NEW_PICKING_LINE_CREATED_DATE_DIM_DATE_KEY)
        or (a.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY != a.NEW_PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY)
        or (a.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY != a.NEW_PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY)
        or (a.DIM_CUSTOMER_KEY != a.NEW_DIM_CUSTOMER_KEY)
        or (a.DIM_DELIVERY_MODE_KEY != a.NEW_DIM_DELIVERY_MODE_KEY)
        or (a.DIM_DELIVERY_TERM_KEY != a.NEW_DIM_DELIVERY_TERM_KEY)
        or (a.DIM_INVENTORY_KEY != a.NEW_DIM_INVENTORY_KEY)
        or (a.DIM_INVENTORY_TO_KEY != a.NEW_DIM_INVENTORY_TO_KEY)
        or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
        or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
        or (a.DIM_LOCATION_DELIVERY_ADDRESS_KEY != a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY)
        or (a.DIM_SALES_ORDER_KEY != a.NEW_DIM_SALES_ORDER_KEY)
        or (a.DIM_SITE_KEY != a.NEW_DIM_SITE_KEY)
        or (a.DIM_WAREHOUSE_KEY != a.NEW_DIM_WAREHOUSE_KEY)
        or (a.DIM_WORKER_OPERATOR_KEY != a.NEW_DIM_WORKER_OPERATOR_KEY)
            )
        ;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_PICKING_LINE_KEY
				, a.NEW_DIM_CUSTOMER_KEY
				, a.NEW_DIM_CUSTOMER_SNKEY
			from (select src.FACT_PICKING_LINE_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
						else DIM_CUSTOMER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_SNKEY
					, src.DIM_CUSTOMER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
				from ' || :tgt_db || '.global.FACT_PICKING_LINE src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.PICKING_LINE_SHIPPING_DATE_REQUESTED >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.PICKING_LINE_SHIPPING_DATE_REQUESTED < d18.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_SNKEY != NEW_DIM_CUSTOMER_SNKEY
				or src.DIM_CUSTOMER_KEY != NEW_DIM_CUSTOMER_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;


        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_PICKING_LINE_KEY = tgt.FACT_PICKING_LINE_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.PICK_COMPLETED_DATE_DIM_DATE_KEY = src.NEW_PICK_COMPLETED_DATE_DIM_DATE_KEY
                                    , tgt.PICKING_LINE_CREATED_DATE_DIM_DATE_KEY = src.NEW_PICKING_LINE_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = src.NEW_PICKING_LINE_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY = src.NEW_PICKING_ROUTE_SHIP_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.NEW_DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.NEW_DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_INVENTORY_KEY = src.NEW_DIM_INVENTORY_KEY
                                    , tgt.DIM_INVENTORY_TO_KEY = src.NEW_DIM_INVENTORY_TO_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.NEW_DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SITE_KEY = src.NEW_DIM_SITE_KEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.NEW_DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WORKER_OPERATOR_KEY = src.NEW_DIM_WORKER_OPERATOR_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_PICKING_LINE_KEY = tgt.FACT_PICKING_LINE_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_SNKEY = src.NEW_DIM_CUSTOMER_SNKEY
									, tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_customer);

		LET c5 CURSOR FOR res;

        LET key_fix_count_customer INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_customer := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;