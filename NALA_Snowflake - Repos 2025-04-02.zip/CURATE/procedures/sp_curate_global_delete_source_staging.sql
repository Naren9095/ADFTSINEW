/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_DELETE_SOURCE_STAGING
    CREATED BY     : Shawn Harris
    CREATED ON     : 12/15/2024
    PURPOSE        : Stored procedure for applying soft deletes to target tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT, TASK_NAME
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_DELETE_SOURCE_STAGING(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>,<TASK_NAME>);

    UPDATED        : Todd Riel
    COMMENTS       : Adding dynamic source name & establishing 120 day time fence 
                     to minimize processing time
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_DELETE_SOURCE_STAGING
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR,
TASK_NAME VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS 
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_DELETE_SOURCE_STAGING';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';

BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_name STRING := 'AXNALA';
    LET src_tbl STRING := '';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := :TASK_NAME;
    LET audit_db STRING := :ENVIRONMENT || '_AUDIT';
    LET audit_schema STRING := 'CONTROL';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
        src_name :='AXRETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
        src_name :='D365';
    END IF;

    ----Get the source/raw table and columns for joins for source>target
    LET qrysrc STRING := 'SELECT RAW_TABLE, PK_TGT_COLS, PK_CURATE_COLS
                             FROM ' || :audit_db ||'.'|| :audit_schema ||'.SOFT_HARD_DELETES_CONTROL
                             WHERE TARGET_TABLE = '''|| :tgt_tbl ||'''
                                 AND SOURCE_NAME = '''|| :src_name ||''';';
    res := (EXECUTE IMMEDIATE :qrysrc);

    LET cur_res CURSOR for res;
    LET raw_cols STRING := '';
    LET cur_cols STRING := '';

    FOR row_var IN cur_res DO
         src_tbl := row_var."RAW_TABLE";
         raw_cols := row_var."PK_TGT_COLS";
         cur_cols := row_var."PK_CURATE_COLS";
    END FOR;

    raw_cols := REPLACE( :raw_cols ,'RECID','TO_CHAR(RECID)');


    ----Get job id/timestamp for updated rows from the source table; cannot use rows bcz the updates are from DELETED rows, so no source if not this.
    LET qry STRING DEFAULT '';
    qry := 'SELECT MAX(HK_JOB_RUN_ID) AS HK_JOB_RUN_ID
        , MAX(HK_SOURCE_NAME) AS HK_SOURCE_NAME
        FROM ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ';';

     res := (EXECUTE IMMEDIATE :qry);
    
     LET cur_tgt_tbl CURSOR for res;
     LET hk_job_run_id STRING := '';
     LET hk_source_name := '';
     
     
     FOR row_var IN cur_tgt_tbl DO
         hk_job_run_id := row_var."HK_JOB_RUN_ID";
         hk_source_name := row_var."HK_SOURCE_NAME";
     END FOR;
   
    IF (:TASK_STEP_NUMBER = 2) THEN  --different than all other procs except this delete proc
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_ORDERS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */

LET hashvar STRING DEFAULT '';
hashvar := '1'; 

   v_proc_step := '4';
    LET create_wrk_tbl1 STRING DEFAULT '';

     create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
      || ' as
            SELECT
                tgt.'|| tgt_tbl ||'_KEY AS HASH_KEY
                    ,CASE WHEN src.HK_SOURCE_NAME IS NULL THEN TRUE ELSE FALSE END AS SOFT_DELETE
                    ,'''|| :CURR_TIMESTAMP ||''' AS HK_LAST_UPDATED_TIMESTAMP
                    ,'''|| :hk_job_run_id ||''' AS HK_JOB_RUN_ID
            FROM '|| :tgt_db ||'.'|| :tgt_schema ||'.'|| :tgt_tbl ||' tgt
            LEFT OUTER JOIN ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src
                ON tgt.'|| tgt_tbl ||'_KEY
                    = hash('''||:hk_source_name||''',''~'','||   replace(:raw_cols,',',',''~'',')   ||')
           WHERE tgt.HK_SOURCE_NAME = '''|| :hk_source_name ||'''
                AND tgt.HK_SOFT_DELETE_FLAG != SOFT_DELETE;
            ';
 ----replace hash 4 lines up with this one if it fails. Had to replace RECID with TO_CHAR(RECID)           
----let hashkey STRING := 'hash('''||:hk_source_name||''',''~'',src.'||   replace(:raw_cols,',',',''~'',src.')   ||')  ;';

EXECUTE IMMEDIATE :create_wrk_tbl1;


     /*
        4.	Read data from first working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_1_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_ORDERS_PREP_01_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_SALES_ORDERS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.SRC_HASH_KEY = tgt.<tgt_tbl_key variable>
        b.	Maybe later will have Delete functionality
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

     merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                         using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP || ' src 
                         ON src.HASH_KEY = tgt.'|| :tgt_tbl ||'_KEY
                         when matched AND tgt.HK_SOFT_DELETE_FLAG != src.SOFT_DELETE
                         then update
                                 set
                                     tgt.HK_SOFT_DELETE_FLAG = src.SOFT_DELETE
                                     , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_JOB_RUN_ID
                                     , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                                 ;';

    res:= (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        u_count := row_variable."number of rows updated";
        --i_count := row_variable."number of rows inserted";
        END FOR;
        
        --Logging insert row count
        v_proc_step := '6';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging stored procedure completed
        v_proc_step := '7';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '11';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
    
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END
;