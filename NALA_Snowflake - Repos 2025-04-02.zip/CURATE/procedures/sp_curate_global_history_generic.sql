CREATE OR REPLACE PROCEDURE GLOBAL.SP_GENERIC_EDW_HISTORY_DIM_SCD1("JOB_ID" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "KEY_COLUMNS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_GENERIC_EDW_HISTORY';
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'EDW_DWH';
   -- LET src_tbl STRING := src_tbl;        -- := 'DimPurchaseOrder';  -- get this as parameter
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    -- LET tgt_tbl STRING := tgt_tbl;        -- := 'DIM_PURCHASE_ORDER';     -- get this as parameter
    
    LET source_key STRING;
    LET transformation_columns STRING;
    LET variable_columns STRING;
    LET hash_columns STRING;
    LET insert_columns STRING;
    LET unknown_records STRING DEFAULT '';
    LET unrelated_records STRING DEFAULT '';
    LET unknown_res resultset;--STRING DEFAULT '' ;
    LET cur_statement STRING default '';
    LET unrelated_res resultset;

    Let src_columns_table STRING := :src_db || '.INFORMATION_SCHEMA.COLUMNS';
    Let tgt_columns_table STRING := :tgt_db || '.INFORMATION_SCHEMA.COLUMNS';
    
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISS') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    v_proc_step := '4';
    if (src_tbl = 'DIMARBUCKETS') THEN 
        source_key := 1;
    ELSE
    source_key := (SELECT COLUMN_NAME
                    FROM IDENTIFIER(:src_columns_table)
                    WHERE TABLE_NAME = :src_tbl
                     AND COLUMN_NAME LIKE '%KEY'); -- DIMPURCHASEORDERKEY
    END IF;
                    
    
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
    || ' as
                select 
                    *
                from '|| :src_db || '.' || :src_schema || '.' || :src_tbl || ' src
                    where ' || :source_key || ' not in (-1, -2)
            ';

        EXECUTE IMMEDIATE :create_wrk_tbl1;

        v_proc_step := '4.2';

        transformation_columns := (
                            select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION) AS TRANS_COLS
                    from
                (select t.column_name,
                        'nvl(' || t.column_name ||',' ||
                        case when data_type in ('TEXT') then ''''''
                						when data_type in ('BOOLEAN') then 'false'
                						when data_type in ('DATE') then '''1950-01-01'''
                						when data_type in ('TIMESTAMP_TZ') then '''1950-01-01 00:00:00'''
                					else '0' end
                        ||')::' ||
                         case data_type when 'TEXT' then 'VARCHAR' when 'NUMBER' then data_type || '(' || NUMERIC_PRECISION || ',' || numeric_scale || ')'
                                        else data_type end || ' as '|| t.column_name
                          as chk,t.data_type,t.numeric_precision,t.numeric_scale, ordinal_position
                from IDENTIFIER(:src_columns_table) t
                where table_schema = :src_schema        
                    and table_name = :src_tbl    
                    AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP')
                order by ordinal_position ) a 
        );

        key_columns := (SELECT REPLACE(:KEY_COLUMNS, ',', ', ''~'' ,'));
        
        
        LET create_wrk_tbl2 STRING DEFAULT '';  
        
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
                    select 
                       case when ''' || :TGT_TBL || ''' IN (''DIM_PURCHASE_ORDER'') then ''AXNALA'':: varchar else
                       nvl(
                            case 
                                when upper(DW_SOURCECODE) in (''AXNALA'',''AGGREGATE'') then ''AXNALA''
                                when upper(DW_SOURCECODE) in (''BUSINESSOBJECTS'') then ''ORACLE''
                                when upper(DW_SOURCECODE) in (''CUSTOM DATA'', ''VIEW'', ''FDN_KIT'', ''MANBASE_SFS'', ''MANBASE_SRA'', ''MAT_KIT'') then ''MANBASE''
                            else upper(DW_SOURCECODE) end , '''') :: varchar end as SOURCENAME
                        , ' || :transformation_columns || '
                        , nvl(src.DW_SOURCECODE, '''') :: varchar as HK_SOURCE_NAME
                        , false :: boolean as HK_SOFT_DELETE_FLAG
                        , ''1950-01-01 00:00:00'' :: timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
                        , nvl(src.DW_TIMESTAMP, ''1950-01-01 00:00:00'') :: timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
                        , ''-1'' :: varchar as HK_CREATED_JOB_RUN_ID
                        , nvl(src.DW_BATCH, ''-1'') :: varchar as HK_LAST_UPDATED_JOB_RUN_ID
                        , hash('|| :key_columns ||') :: number as '|| :tgt_tbl ||'_SNKEY
                    FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP || ' src
                    ';
    
     EXECUTE IMMEDIATE :create_wrk_tbl2;

        v_proc_step := '4.3';

        hash_columns := (
                            select  listagg(a.column_alias_out, ', ''~'', ') within group (order by a.table_name, a.ordinal_position)  as HASH_KEY
                from (select lower(
                                case when data_type in ('DATE', 'TIMESTAMP_TZ', 'NUMBER', 'BOOLEAN') then 'to_char('
                                    else ''
                                end
                                || 'src.' || column_name ||
                                case when data_type in ('DATE') then ', ''yyyymmdd'')'
                                    when data_type in ('TIMESTAMP_TZ') then ', ''yyyymmddhh24missff3'')'
                                    when data_type in ('NUMBER', 'BOOLEAN') then ')'
                                    else ''
                                end
                                ) as COLUMN_ALIAS_OUT
                            , table_name, ordinal_position
                        from IDENTIFIER(:src_columns_table)
                        where table_schema = :src_schema
                        and table_name = :src_tbl
                        AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP')
                    ) a
                group by a.table_name
                order by a.table_name
            );

        variable_columns := (
                    select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION)
                    from (
                        select 'src.' || column_name chk, ordinal_position from IDENTIFIER(:src_columns_table) 
                        where table_schema = :src_schema   
                        and table_name = :src_tbl 
                        AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP')
                        order by ordinal_position
                )
        );
        
        LET create_wrk_tbl3 STRING DEFAULT '';   
            
            create_wrk_tbl3 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP
            || ' as 
                        select 
                            hash(' || :key_columns || ') :: number as '|| :tgt_tbl ||'_KEY
                            , src.'|| :tgt_tbl ||'_SNKEY
                            , src.SOURCENAME as SOURCENAME
                            , '|| :variable_columns ||'
                            , case 
                                when src.SOURCENAME = '''' then -2
                                    else hash(src.SOURCENAME)
                                end :: number as DIM_SOURCE_SYSTEM_SNKEY
                            
                            , hash(src.SOURCENAME, ''~'', ' ||:hash_columns ||') :: number as HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , CURRENT_TIMESTAMP :: timestamp_tz as HK_CREATED_TIMESTAMP
                            , CURRENT_TIMESTAMP :: timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
                            , uuid_string() :: varchar as HK_WAREHOUSE_ID
                        FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' d1 on
                            src.'|| :tgt_tbl ||'_SNKEY = d1.'|| :tgt_tbl ||'_SNKEY
                        where d1.'|| :tgt_tbl ||'_SNKEY is null
                        ';
        
        EXECUTE IMMEDIATE :create_wrk_tbl3;

    
    v_proc_step := '5';
    
    insert_columns := (
            select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION)
                from (
                    select column_name chk, ordinal_position from IDENTIFIER(:tgt_columns_table) 
                    where table_schema = :tgt_schema   --:src_schema     
                    and table_name = :tgt_tbl --:src_tbl
                    and column_name != 'DIM_SOURCE_SYSTEM_SNKEY'
                    order by ordinal_position
                )
        );

    LET insert_statement STRING DEFAULT '';

    insert_statement := 'INSERT INTO ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || '(' || :insert_columns || ',DIM_SOURCE_SYSTEM_SNKEY)
                        SELECT
                            '|| :tgt_tbl ||'_KEY
                            , '|| :tgt_tbl ||'_SNKEY
                            , SOURCENAME
                            , '|| :variable_columns ||'
                            , HK_HASH_KEY
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , DIM_SOURCE_SYSTEM_SNKEY
                        FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP || ' src;';
        
        EXECUTE IMMEDIATE :insert_statement;

IF (src_tbl != 'DIMARBUCKETS') THEN
        v_proc_step := '5.1';

        unknown_records := 
                            'select *
                from (
                	select ''delete'' as OPERATION_TYPE, lower(t1.table_name) as TABLE_NAME
                		, ''delete from ' || :tgt_db || '.' || :tgt_schema || '.'' || lower(t1.table_name) || '' where '' || lower(c1.column_name) || '' = -1 and hk_warehouse_id = ''''UNKNOWN'''';'' as DELETE_VALUE
                	from ' || :tgt_db || '.information_schema.tables t1
                	inner join ' || :tgt_db || '.information_schema.columns c1 on
                		c1.table_schema = '''|| :tgt_schema ||''' and
                		c1.ordinal_position = 1 and
                		t1.table_name = c1.table_name
                	where t1.table_schema = '''|| :tgt_schema ||'''
                	and t1.table_name = '''|| :tgt_tbl ||'''
                    
                union all
                
                		select ''insert'' as OPERATION_TYPE, z.table_name
                			, ''insert into ' || :tgt_db || '.' || :tgt_schema || '.'' || z.table_name || '' ('' || listagg(z.column_name, '', '') within group (order by z.table_name, z.ordinal_position) || '')''
                			|| '' select '' || listagg(z.default_value, '', '') within group (order by z.table_name, z.ordinal_position) || '';'' as INSERT_VALUE
                		from (
                			select lower(table_name) as TABLE_NAME, lower(column_name) as COLUMN_NAME, data_type, ordinal_position
                				, ''''''''
                				|| case when data_type = ''NUMBER'' and numeric_scale = 0 then ''-1''
                                        when data_type = ''NUMBER'' and numeric_scale != 0 then ''0.00''
                						when column_name = ''HK_SOFT_DELETE_FLAG'' and data_type = ''BOOLEAN'' then ''0''
                						when data_type = ''BOOLEAN'' then ''1''
                						when data_type like ''TIMESTAMP%'' and column_name = ''HK_EFFECTIVE_END_TIMESTAMP'' then ''9000-01-01 00:00:00''
                						when data_type like ''TIMESTAMP%'' and column_name != ''HK_EFFECTIVE_END_TIMESTAMP'' then ''1950-01-01 00:00:00''
                						when data_type like ''DATE%'' then ''1950-01-01''
                					else ''UNKNOWN'' -- assuming this is TEXT data_type
                				end
                				|| '''''''' as DEFAULT_VALUE
                			from ' || :tgt_db || '.information_schema.columns
                			where table_schema = '''|| :tgt_schema ||'''
                	        and table_name  = '''|| :tgt_tbl ||'''
                		) z
                		group by z.table_name
                	)
                order by 1';

        unknown_res := (EXECUTE IMMEDIATE :unknown_records);

        LET cur_unknown CURSOR FOR unknown_res;

        FOR row_variable IN cur_unknown DO
            cur_statement := row_variable.delete_value;
            EXECUTE IMMEDIATE :cur_statement;
        END FOR;
        
        unrelated_records := 
                        'select *
            from (
                select ''delete'' as OPERATION_TYPE, lower(t1.table_name) as TABLE_NAME
                    , ''delete from ' || :tgt_db || '.' || :tgt_schema || '.'' || lower(t1.table_name) || '' where '' || lower(c1.column_name) || '' = -2 and hk_warehouse_id = ''''UNRELATED'''';'' as DELETE_VALUE
                from ' || :tgt_db || '.information_schema.tables t1
                inner join ' || :tgt_db || '.information_schema.columns c1 on
                    c1.table_schema = '''|| :tgt_schema ||''' and
                    c1.ordinal_position = 1 and
                    t1.table_name = c1.table_name
                where t1.table_schema = '''|| :tgt_schema ||'''
                and t1.table_name = '''|| :tgt_tbl ||'''
                
                union all
                
                    select ''insert'' as OPERATION_TYPE, z.table_name
                        , ''insert into ' || :tgt_db || '.' || :tgt_schema || '.'' || z.table_name || '' ('' || listagg(z.column_name, '', '') within group (order by z.table_name, z.ordinal_position) || '')''
                        || '' select '' || listagg(z.default_value, '', '') within group (order by z.table_name, z.ordinal_position) || '';'' as INSERT_VALUE
                    from (
                        select lower(table_name) as TABLE_NAME, lower(column_name) as COLUMN_NAME, data_type, ordinal_position
                            , ''''''''
                            || case when data_type = ''NUMBER'' and numeric_scale = 0 then ''-2''
                                    when data_type = ''NUMBER'' and numeric_scale != 0 then ''0.00''
                                    when column_name = ''HK_SOFT_DELETE_FLAG'' and data_type = ''BOOLEAN'' then ''0''
                                    when data_type = ''BOOLEAN'' then ''1''
                                    when data_type like ''TIMESTAMP%'' and column_name = ''HK_EFFECTIVE_END_TIMESTAMP'' then ''9000-01-01 00:00:00''
                                    when data_type like ''TIMESTAMP%'' and column_name != ''HK_EFFECTIVE_END_TIMESTAMP'' then ''1950-01-01 00:00:00''
                                    when data_type like ''DATE%'' then ''1950-01-01''
                                else ''UNRELATED'' -- assuming this is TEXT data_type
                            end
                            || '''''''' as DEFAULT_VALUE
                        from ' || :tgt_db || '.information_schema.columns
                        where table_schema = '''|| :tgt_schema ||'''
                        and table_name  = '''|| :tgt_tbl ||'''
                    ) z
                    group by z.table_name
                )
            order by 1'
            ;

            unrelated_res := (EXECUTE IMMEDIATE :unrelated_records);

            LET cur_unrelated CURSOR FOR unrelated_res;
    
            FOR row_variable IN cur_unrelated DO
                cur_statement := row_variable.delete_value;
                EXECUTE IMMEDIATE :cur_statement;
            END FOR;

END IF;
            return 'Completed the History Migration';
 

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            RETURN sqlerrm;
        WHEN EXPRESSION_ERROR THEN
            RETURN sqlerrm;
        WHEN OTHER THEN
            RETURN sqlerrm;
END;



CREATE OR REPLACE PROCEDURE GLOBAL.SP_GENERIC_EDW_HISTORY_DIM_SCD2("JOB_ID" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "KEY_COLUMNS" VARCHAR(16777216), "RAW_KEY" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_GENERIC_EDW_HISTORY';
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'EDW_DWH';
   -- LET src_tbl STRING := src_tbl;        -- := 'DimPurchaseOrder';  -- get this as parameter
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    -- LET tgt_tbl STRING := tgt_tbl;        -- := 'DIM_PURCHASE_ORDER';     -- get this as parameter
    
    LET source_key STRING;
    LET transformation_columns STRING;
    LET variable_columns STRING;
    LET hash_columns STRING;
    LET insert_columns STRING;
    LET unknown_records STRING DEFAULT '';
    LET unrelated_records STRING DEFAULT '';
    LET unknown_res resultset;--STRING DEFAULT '' ;
    LET cur_statement STRING default '';
    LET unrelated_res resultset;

    Let src_columns_table STRING := :src_db || '.INFORMATION_SCHEMA.COLUMNS';
    Let tgt_columns_table STRING := :tgt_db || '.INFORMATION_SCHEMA.COLUMNS';
    
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISS') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    v_proc_step := '4';
    source_key := RAW_KEY;
    /*(SELECT COLUMN_NAME
                    FROM IDENTIFIER(:src_columns_table)
                    WHERE TABLE_NAME = :src_tbl
                     AND COLUMN_NAME LIKE '%KEY'); -- DIMPURCHASEORDERKEY*/
                    
    
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
    || ' as
                select 
                    *
                from '|| :src_db || '.' || :src_schema || '.' || :src_tbl || ' src
                    where ' || :source_key || ' not in (-1, -2)
            ';

        EXECUTE IMMEDIATE :create_wrk_tbl1;

        v_proc_step := '4.2';

        transformation_columns := (
                            select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION) AS TRANS_COLS
                    from
                (select t.column_name,
                        'nvl(' || t.column_name ||',' ||
                        case when data_type in ('TEXT') then ''''''
                						when data_type in ('BOOLEAN') then 'false'
                						when data_type in ('DATE') then '''1950-01-01'''
                						when data_type in ('TIMESTAMP_TZ') then '''1950-01-01 00:00:00'''
                					else '0' end
                        ||')::' ||
                         case data_type when 'TEXT' then 'VARCHAR' when 'NUMBER' then data_type || '(' || NUMERIC_PRECISION || ',' || numeric_scale || ')'
                                        else data_type end || ' as '|| t.column_name
                          as chk,t.data_type,t.numeric_precision,t.numeric_scale, ordinal_position
                from IDENTIFIER(:src_columns_table) t
                where table_schema = :src_schema        
                    and table_name = :src_tbl    
                    AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP','VALIDFROM','VALIDTO','ISCURRENT','ISDELETED')
                order by ordinal_position ) a 
        );

        
        let timestamp_part_columns string default '';
        timestamp_part_columns := (select REPLACE(replace(:KEY_COLUMNS,'SOURCE_NAME,',''),'_',''));

        key_columns := (SELECT replace(REPLACE(:KEY_COLUMNS, ',', ', ''~'' ,'),'_',''));
        
        
        
        LET create_wrk_tbl2 STRING DEFAULT '';  
        
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
                    select 
                        nvl(
                            case 
                                when upper(DW_SOURCECODE) in (''AXNALA'') then ''AXNALA''
                                when upper(DW_SOURCECODE) in (''BUSINESSOBJECTS'') then ''ORACLE''
                                when upper(DW_SOURCECODE) in (''CUSTOM DATA'', ''VIEW'', ''FDN_KIT'', ''MANBASE_SFS'', ''MANBASE_SRA'', ''MAT_KIT'') then ''MANBASE''
                            else upper(DW_SOURCECODE) end , '''') :: varchar as SOURCENAME
                        , ' || :transformation_columns || '
                        
                        ,lag(src.validfrom) over (partition by ' || :timestamp_part_columns ||' order by src.validfrom) as PREV_HK_EFFECTIVE_START_TIMESTAMP
			, lead(src.validto) over (partition by ' || :timestamp_part_columns || ' order by src.validto) as NEXT_HK_EFFECTIVE_END_TIMESTAMP
			, case when nvl(src.validfrom, ''1900-01-01 00:00:00'') = ''1900-01-01 00:00:00'' then ''1950-01-01 00:00:00''
					when PREV_HK_EFFECTIVE_START_TIMESTAMP is null then ''1950-01-01 00:00:00''
				else src.validfrom
				end::timestamp_tz as HK_EFFECTIVE_START_TIMESTAMP
			, case when nvl(src.validto, ''9999-12-31 00:00:00'') = ''9999-12-31 00:00:00'' then ''9000-01-01 00:00:00''
					when NEXT_HK_EFFECTIVE_END_TIMESTAMP is null then ''9000-01-01 00:00:00''
				else src.validto
				end::timestamp_tz as HK_EFFECTIVE_END_TIMESTAMP
			, case when HK_EFFECTIVE_END_TIMESTAMP = ''9000-01-01 00:00:00'' then true
				else false
				end::boolean as HK_CURRENT_FLAG
                
                        , nvl(src.DW_SOURCECODE, '''') :: varchar as HK_SOURCE_NAME
                        , case when nvl(src.isdeleted, 0) = 1 then true
            				else false
            				end::boolean as HK_SOFT_DELETE_FLAG
                        , ''1950-01-01 00:00:00'' :: timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
                        , nvl(src.DW_TIMESTAMP, ''1950-01-01 00:00:00'') :: timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
                        , ''-1'' :: varchar as HK_CREATED_JOB_RUN_ID
                        , nvl(src.DW_BATCH, ''-1'') :: varchar as HK_LAST_UPDATED_JOB_RUN_ID
                        , hash('|| :key_columns ||') :: number as '|| :tgt_tbl ||'_SNKEY
                    FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP || ' src
                    ';

   
    
     EXECUTE IMMEDIATE :create_wrk_tbl2;

        v_proc_step := '4.3';

        hash_columns := (
                            select  listagg(a.column_alias_out, ', ''~'', ') within group (order by a.table_name, a.ordinal_position)  as HASH_KEY
                from (select lower(
                                case when data_type in ('DATE', 'TIMESTAMP_TZ', 'NUMBER', 'BOOLEAN') then 'to_char('
                                    else ''
                                end
                                || 'src.' || column_name ||
                                case when data_type in ('DATE') then ', ''yyyymmdd'')'
                                    when data_type in ('TIMESTAMP_TZ') then ', ''yyyymmddhh24missff3'')'
                                    when data_type in ('NUMBER', 'BOOLEAN') then ')'
                                    else ''
                                end
                                ) as COLUMN_ALIAS_OUT
                            , table_name, ordinal_position
                        from IDENTIFIER(:src_columns_table)
                        where table_schema = :src_schema
                        and table_name = :src_tbl
                        AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP','VALIDFROM','VALIDTO','ISCURRENT','ISDELETED')
                    ) a
                group by a.table_name
                order by a.table_name
            );

   
    
        variable_columns := (
                    select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION)
                    from (
                        select 'src.' || column_name chk, ordinal_position from IDENTIFIER(:src_columns_table) 
                        where table_schema = :src_schema   
                        and table_name = :src_tbl 
                        AND not column_name like any('HK%','DW%','%KEY','INCREMENTALTIMESTAMP','VALIDFROM','VALIDTO','ISCURRENT','ISDELETED')
                        order by ordinal_position
                )
        );

  
        
        LET create_wrk_tbl3 STRING DEFAULT '';   
            
            create_wrk_tbl3 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP
            || ' as 
                        select 
                            hash(' || :key_columns || ' , ''~'', to_char(src.HK_EFFECTIVE_START_TIMESTAMP, ''yyyymmddhh24missff3'')):: number as '|| :tgt_tbl ||'_KEY
                            , src.'|| :tgt_tbl ||'_SNKEY
                            , src.SOURCENAME as SOURCENAME
                            , '|| :variable_columns ||'
                            , case 
                                when src.SOURCENAME = '''' then -2
                                    else hash(src.SOURCENAME)
                                end :: number as DIM_SOURCE_SYSTEM_SNKEY
                            
                            , hash(src.SOURCENAME, ''~'', ' ||:hash_columns ||') :: number as HK_HASH_KEY
                            , src.HK_EFFECTIVE_START_TIMESTAMP,src.HK_EFFECTIVE_END_TIMESTAMP,src.HK_CURRENT_FLAG
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , CURRENT_TIMESTAMP :: timestamp_tz as HK_CREATED_TIMESTAMP
                            , CURRENT_TIMESTAMP :: timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
                            , uuid_string() :: varchar as HK_WAREHOUSE_ID
                        FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' d1 on
                            src.'|| :tgt_tbl ||'_SNKEY = d1.'|| :tgt_tbl ||'_SNKEY
                        where d1.'|| :tgt_tbl ||'_SNKEY is null
                        ';
        
        EXECUTE IMMEDIATE :create_wrk_tbl3;

    
    v_proc_step := '5';
    
    insert_columns := (
            select LISTAGG(chk,',') WITHIN GROUP (ORDER BY ORDINAL_POSITION)
                from (
                    select column_name chk, ordinal_position from IDENTIFIER(:tgt_columns_table) 
                    where table_schema = :tgt_schema   --:src_schema     
                    and table_name = :tgt_tbl --:src_tbl
                    and column_name != 'DIM_SOURCE_SYSTEM_SNKEY'
                    order by ordinal_position
                )
        );

    LET insert_statement STRING DEFAULT '';

    insert_statement := 'INSERT INTO ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || '(' || :insert_columns || ',DIM_SOURCE_SYSTEM_SNKEY)
                        SELECT
                            '|| :tgt_tbl ||'_KEY
                            , '|| :tgt_tbl ||'_SNKEY
                            , SOURCENAME
                            , '|| :variable_columns ||'
                            , HK_HASH_KEY
                            ,HK_EFFECTIVE_START_TIMESTAMP,HK_EFFECTIVE_END_TIMESTAMP,HK_CURRENT_FLAG
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , DIM_SOURCE_SYSTEM_SNKEY
                        FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_PREP_03_' || :CURR_FORMATTED_TIMESTAMP || ' src;';

        
        EXECUTE IMMEDIATE :insert_statement;

        v_proc_step := '5.1';

        unknown_records := 
                            'select *
                from (
                	select ''delete'' as OPERATION_TYPE, lower(t1.table_name) as TABLE_NAME
                		, ''delete from ' || :tgt_db || '.' || :tgt_schema || '.'' || lower(t1.table_name) || '' where '' || lower(c1.column_name) || '' = -1 and hk_warehouse_id = ''''UNKNOWN'''';'' as DELETE_VALUE
                	from ' || :tgt_db || '.information_schema.tables t1
                	inner join ' || :tgt_db || '.information_schema.columns c1 on
                		c1.table_schema = '''|| :tgt_schema ||''' and
                		c1.ordinal_position = 1 and
                		t1.table_name = c1.table_name
                	where t1.table_schema = '''|| :tgt_schema ||'''
                	and t1.table_name = '''|| :tgt_tbl ||'''
                    
                union all
                
                		select ''insert'' as OPERATION_TYPE, z.table_name
                			, ''insert into ' || :tgt_db || '.' || :tgt_schema || '.'' || z.table_name || '' ('' || listagg(z.column_name, '', '') within group (order by z.table_name, z.ordinal_position) || '')''
                			|| '' select '' || listagg(z.default_value, '', '') within group (order by z.table_name, z.ordinal_position) || '';'' as INSERT_VALUE
                		from (
                			select lower(table_name) as TABLE_NAME, lower(column_name) as COLUMN_NAME, data_type, ordinal_position
                				, ''''''''
                				|| case when data_type = ''NUMBER'' and numeric_scale = 0 then ''-1''
                                        when data_type = ''NUMBER'' and numeric_scale != 0 then ''0.00''
                						when column_name = ''HK_SOFT_DELETE_FLAG'' and data_type = ''BOOLEAN'' then ''0''
                						when data_type = ''BOOLEAN'' then ''1''
                						when data_type like ''TIMESTAMP%'' and column_name = ''HK_EFFECTIVE_END_TIMESTAMP'' then ''9000-01-01 00:00:00''
                						when data_type like ''TIMESTAMP%'' and column_name != ''HK_EFFECTIVE_END_TIMESTAMP'' then ''1950-01-01 00:00:00''
                						when data_type like ''DATE%'' then ''1950-01-01''
                					else ''UNKNOWN'' -- assuming this is TEXT data_type
                				end
                				|| '''''''' as DEFAULT_VALUE
                			from ' || :tgt_db || '.information_schema.columns
                			where table_schema = '''|| :tgt_schema ||'''
                	        and table_name  = '''|| :tgt_tbl ||'''
                		) z
                		group by z.table_name
                	)
                order by 1';

        unknown_res := (EXECUTE IMMEDIATE :unknown_records);

        LET cur_unknown CURSOR FOR unknown_res;

        FOR row_variable IN cur_unknown DO
            cur_statement := row_variable.delete_value;
            EXECUTE IMMEDIATE :cur_statement;
        END FOR;
        
        unrelated_records := 
                        'select *
            from (
                select ''delete'' as OPERATION_TYPE, lower(t1.table_name) as TABLE_NAME
                    , ''delete from ' || :tgt_db || '.' || :tgt_schema || '.'' || lower(t1.table_name) || '' where '' || lower(c1.column_name) || '' = -2 and hk_warehouse_id = ''''UNRELATED'''';'' as DELETE_VALUE
                from ' || :tgt_db || '.information_schema.tables t1
                inner join ' || :tgt_db || '.information_schema.columns c1 on
                    c1.table_schema = '''|| :tgt_schema ||''' and
                    c1.ordinal_position = 1 and
                    t1.table_name = c1.table_name
                where t1.table_schema = '''|| :tgt_schema ||'''
                and t1.table_name = '''|| :tgt_tbl ||'''
                
                union all
                
                    select ''insert'' as OPERATION_TYPE, z.table_name
                        , ''insert into ' || :tgt_db || '.' || :tgt_schema || '.'' || z.table_name || '' ('' || listagg(z.column_name, '', '') within group (order by z.table_name, z.ordinal_position) || '')''
                        || '' select '' || listagg(z.default_value, '', '') within group (order by z.table_name, z.ordinal_position) || '';'' as INSERT_VALUE
                    from (
                        select lower(table_name) as TABLE_NAME, lower(column_name) as COLUMN_NAME, data_type, ordinal_position
                            , ''''''''
                            || case when data_type = ''NUMBER'' and numeric_scale = 0 then ''-2''
                                    when data_type = ''NUMBER'' and numeric_scale != 0 then ''0.00''
                                    when column_name = ''HK_SOFT_DELETE_FLAG'' and data_type = ''BOOLEAN'' then ''0''
                                    when data_type = ''BOOLEAN'' then ''1''
                                    when data_type like ''TIMESTAMP%'' and column_name = ''HK_EFFECTIVE_END_TIMESTAMP'' then ''9000-01-01 00:00:00''
                                    when data_type like ''TIMESTAMP%'' and column_name != ''HK_EFFECTIVE_END_TIMESTAMP'' then ''1950-01-01 00:00:00''
                                    when data_type like ''DATE%'' then ''1950-01-01''
                                else ''UNRELATED'' -- assuming this is TEXT data_type
                            end
                            || '''''''' as DEFAULT_VALUE
                        from ' || :tgt_db || '.information_schema.columns
                        where table_schema = '''|| :tgt_schema ||'''
                        and table_name  = '''|| :tgt_tbl ||'''
                    ) z
                    group by z.table_name
                )
            order by 1'
            ;

            unrelated_res := (EXECUTE IMMEDIATE :unrelated_records);

            LET cur_unrelated CURSOR FOR unrelated_res;
    
            FOR row_variable IN cur_unrelated DO
                cur_statement := row_variable.delete_value;
                EXECUTE IMMEDIATE :cur_statement;
            END FOR;

            return 'Completed the History Migration';
 

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            RETURN sqlerrm;
        WHEN EXPRESSION_ERROR THEN
            RETURN sqlerrm;
        WHEN OTHER THEN
            RETURN sqlerrm;
END;