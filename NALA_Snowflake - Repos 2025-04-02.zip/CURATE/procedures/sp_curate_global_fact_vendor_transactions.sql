/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_VENDOR_TRANSACTIONS
    CREATED BY     : Bharath
    CREATED ON     : 02/07/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_VENDOR_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_VENDOR_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_VENDOR_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'VENDTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_VENDOR_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_VENDOR_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
        || ' as
                            select
                                0 AS FACT_VENDOR_TRANSACTIONS_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS DIM_CASH_DISCOUNT_KEY
                                , 0 AS DIM_CASH_DISCOUNT_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_LOCATION_KEY
                                , 0 AS DIM_LOCATION_SNKEY
                                , 0 AS DIM_VENDOR_INVOICE_KEY
                                , 0 AS DIM_VENDOR_INVOICE_SNKEY
                                , 0 AS DIM_VENDOR_PAYMENT_MODE_KEY
                                , 0 AS DIM_VENDOR_PAYMENT_MODE_SNKEY
                                , 0 AS DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                , 0 AS DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                -- , 0 AS DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                -- , 0 AS DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                , 0 AS DIM_WORKER_APPROVER_KEY
                                , 0 AS DIM_WORKER_APPROVER_SNKEY
                                , 0 AS ALIGNED_DUE_DATE_DIM_DATE_KEY
                                , 0 AS ALIGNED_DUE_DATE_DIM_DATE_SNKEY
                                , 0 AS APPROVED_DATE_DIM_DATE_KEY
                                , 0 AS APPROVED_DATE_DIM_DATE_SNKEY
                                , 0 AS CLOSED_DATE_DIM_DATE_KEY
                                , 0 AS CLOSED_DATE_DIM_DATE_SNKEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS DUE_DATE_DIM_DATE_KEY
                                , 0 AS DUE_DATE_DIM_DATE_SNKEY
                                , 0 AS LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                , 0 AS LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_KEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_SNKEY
                                , 0 AS CHECK_DATE_DIM_DATE_KEY
                                , 0 AS CHECK_DATE_DIM_DATE_SNKEY
                                , 0 AS INVOICE_DATE_DIM_DATE_KEY
                                , 0 AS INVOICE_DATE_DIM_DATE_SNKEY
                                , case when nvl(src.ALIGNEDDUEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.ALIGNEDDUEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.ALIGNEDDUEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.ALIGNEDDUEDATE END AS ALIGNED_DUE_DATE
                                , case when nvl(src.APPROVEDDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.APPROVEDDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.APPROVEDDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.APPROVEDDATE END AS APPROVED_DATE
                                , case when nvl(src.CLOSED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.CLOSED < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.CLOSED > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.CLOSED END AS CLOSED_DATE
                                , case when nvl(src.DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DOCUMENTDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DOCUMENTDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DOCUMENTDATE END AS DOCUMENT_DATE
                                , case when nvl(src.DUEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DUEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DUEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DUEDATE END AS DUE_DATE
                                , case when nvl(src.LASTSETTLEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.LASTSETTLEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.LASTSETTLEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.LASTSETTLEDATE END AS LAST_SETTLEMENT_DATE
                                , case when nvl(src.TRANSDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.TRANSDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.TRANSDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.TRANSDATE END AS TRANSACTION_DATE
                                , nvl(src.DOCUMENTNUM, '''')  AS DOCUMENT_NUMBER
                                , nvl(src.INVOICE, '''') AS INVOICE_ID
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.LASTSETTLEVOUCHER, '''') AS LAST_SETTLEMENT_VOUCHER
                                , nvl(src.VOUCHER, '''') AS VOUCHER
                                , nvl(src.AMOUNTCUR, 0) AS AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.AMOUNTMST, 0) AS AMOUNT_COMPANY_CURRENCY
                                , nvl(src.SETTLEAMOUNTCUR, 0) AS SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.SETTLEAMOUNTMST, 0) AS SETTLED_AMOUNT_COMPANY_CURRENCY
                                , nvl(src.SETTLEAMOUNTREPORTING, 0) AS SETTLED_AMOUNT_REPORTING_CURRENCY
                                , nvl(src.ACCOUNTNUM, '''') AS ACCOUNT_NUMBER
                                , nvl(src.APPROVER, 0) AS APPROVER
                                , nvl(src.CASHDISCCODE, '''') AS CASH_DISCOUNT_CODE
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(TO_CHAR(src.DEFAULTDIMENSION), '''') AS DEFAULT_DIMENSION
                                , nvl(src.PAYMMODE, '''') AS PAYMENT_MODE
                                , nvl(src.PAYMSPEC, '''') AS PAYMENT_SPECIFICATION
                                , nvl(src.REMITTANCELOCATION, 0) AS REMITTANCE_LOCATION
                                , NVL(src.CHECKDATE, ''1950-01-01'') AS CHECK_DATE
                                , nvl(src.PAYMENTTERMS,'''') AS PAYMENT_TERMS
                                , NVL(src.INVOICEDATE, ''1950-01-01'') AS INVOICE_DATE
                                ,src.INVOICE_FULL_STATUS
                                , CASE WHEN nvl(src.VOUCHER , '''') not like ''API%'' THEN 0 
                                        WHEN src.DOCUMENTDATE + src.NUMOFDAYS < ''1950-12-31'' THEN 0
                                        WHEN src.INVOICE_FULL_STATUS <> ''Settled'' and src.DOCUMENTDATE + src.NUMOFDAYS < CURRENT_TIMESTAMP then datediff(day,current_timestamp,src.DOCUMENTDATE + src.NUMOFDAYS)  
                                        WHEN src.INVOICE_FULL_STATUS <> ''Settled'' and src.DOCUMENTDATE + src.NUMOFDAYS > CURRENT_TIMESTAMP then 0
                                        WHEN src.AMOUNTCUR <> src.SETTLEAMOUNTCUR AND src.DOCUMENTDATE + src.NUMOFDAYS < src.LASTSETTLEDATE THEN datediff(day, src.DOCUMENTDATE + src.NUMOFDAYS , src.LASTSETTLEDATE)
                                        WHEN src.DOCUMENTDATE + src.NUMOFDAYS  < CURRENT_TIMESTAMP AND src.AMOUNTCUR > src.SETTLEAMOUNTCUR THEN DATEDIFF(day, src.DOCUMENTDATE + src.NUMOFDAYS , CURRENT_TIMESTAMP)
                                    ELSE 0 END AS DAYS_OVERDUE
                                , nvl(src.TRANSRECID, 0) AS SETTLED_TRANSACTION_RECORD_ID
                                , nvl(src.NUMOFDAYS, 0) AS DAYS_TO_PAY
                                , CASE WHEN src.INVOICE_FULL_STATUS = '''' then ''''
                                        WHEN src.INVOICE_FULL_STATUS in (''Settled'',''Open'') THEN ''Settled''
                                        WHEN src.INVOICE_FULL_STATUS = ''Pending'' THEN ''Pending'' 
                                    ELSE ''Settled'' END AS INVOICE_STATUS
                                    
                                , nvl(src.TRANSACTIONTYPE, '''') AS TRANSACTION_TYPE
                                , nvl(src.ISAPPROVED, '''') AS IS_APPROVED
                                , nvl(src.ISREVERSAL, '''') AS IS_REVERSAL
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from  (select src.*,nvl(CASE 
                            		WHEN NVL(src.VOUCHER ,'''') not like ''API%'' THEN ''''
                            		WHEN src.SETTLEAMOUNTCUR = 0 AND  src.TRANSRECID is not NULL then ''Pending''
                            		WHEN src.AMOUNTCUR <= src.SETTLEAMOUNTCUR AND src.TRANSRECID is not NULL THEN ''Settled''
                            		WHEN src.TRANSRECID is NULL THEN ''Pending'' 
                            		ELSE ''Open'' 
                            	 END,'''') AS INVOICE_FULL_STATUS 
                                 from
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src) src
							left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt on
								src.HK_SOURCE_NAME = tgt.SOURCE_NAME and
								src.RECID = tgt.RECORD_ID
							inner join (select min(date_value) as MIN_DATE_VALUE
											, max(date_value) as MAX_DATE_VALUE
										from ' || :tgt_db || '.' || :tgt_schema || '.DIM_DATE 
										where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31'')) dd1 on
								1=1
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') 
                                                and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_VENDOR_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_VENDOR_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
                            SELECT
                                hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_VENDOR_TRANSACTIONS_KEY
                                , src.SOURCE_NAME
                                , src.RECORD_ID
                                , case when src.SOURCE_NAME = '''' then -2
                                    else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                                , src.DIM_SOURCE_SYSTEM_SNKEY
                                , case when src.DIM_CASH_DISCOUNT_SNKEY = -2 then -2
                                    else nvl(d2.DIM_CASH_DISCOUNT_KEY, -1) END AS DIM_CASH_DISCOUNT_KEY
                                , src.DIM_CASH_DISCOUNT_SNKEY
                                , case when src.DIM_CURRENCY_SNKEY = -2 then -2
                                    else nvl(d3.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                                , src.DIM_CURRENCY_SNKEY
                                , case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2
                                    else nvl(d4.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
                                , src.DIM_DEFAULT_DIMENSION_SNKEY
                                , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2
                                    else nvl(d5.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                                , src.DIM_LEGAL_ENTITY_SNKEY
                                , case when src.DIM_LOCATION_SNKEY = -2 then -2
                                    else nvl(d6.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_KEY
                                , src.DIM_LOCATION_SNKEY
                                , case when src.DIM_VENDOR_INVOICE_SNKEY = -2 then -2
                                    else nvl(d7.DIM_VENDOR_KEY, -1) END AS DIM_VENDOR_INVOICE_KEY
                                , src.DIM_VENDOR_INVOICE_SNKEY
                                , case when src.DIM_VENDOR_PAYMENT_MODE_SNKEY = -2 then -2
                                    else nvl(d8.DIM_VENDOR_PAYMENT_MODE_KEY, -1) END AS DIM_VENDOR_PAYMENT_MODE_KEY
                                , src.DIM_VENDOR_PAYMENT_MODE_SNKEY
                                , case when src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY = -2 then -2
                                    else nvl(d9.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY, -1) END AS DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                , src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                -- , hash(src.TRANSACTION_TYPE, ''~'', src.IS_APPROVED, ''~'', src.IS_REVERSAL) AS DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                -- , src.DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                , case when src.DIM_WORKER_APPROVER_SNKEY = -2 then -2
                                    else nvl(d10.DIM_WORKER_KEY, -1)  END AS DIM_WORKER_APPROVER_KEY
                                , src.DIM_WORKER_APPROVER_SNKEY
                                , case when src.ALIGNED_DUE_DATE  = ''1950-01-01'' then -2
                                    else nvl(d11.DIM_DATE_KEY, -1) END AS ALIGNED_DUE_DATE_DIM_DATE_KEY
                                , src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY
                                , case when src.APPROVED_DATE  = ''1950-01-01'' then -2
                                    else nvl(d12.DIM_DATE_KEY, -1) END AS APPROVED_DATE_DIM_DATE_KEY
                                , src.APPROVED_DATE_DIM_DATE_SNKEY
                                , case when src.CLOSED_DATE  = ''1950-01-01'' then -2
                                    else nvl(d13.DIM_DATE_KEY, -1) END AS CLOSED_DATE_DIM_DATE_KEY
                                , src.CLOSED_DATE_DIM_DATE_SNKEY
                                , case when src.DOCUMENT_DATE  = ''1950-01-01'' then -2
                                    else nvl(d14.DIM_DATE_KEY, -1) END AS DOCUMENT_DATE_DIM_DATE_KEY
                                , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                , case when src.DUE_DATE  = ''1950-01-01'' then -2
                                    else nvl(d15.DIM_DATE_KEY, -1) END AS DUE_DATE_DIM_DATE_KEY
                                , src.DUE_DATE_DIM_DATE_SNKEY
                                , case when src.LAST_SETTLEMENT_DATE  = ''1950-01-01'' then -2
                                    else nvl(d16.DIM_DATE_KEY, -1) END AS LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                , src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                , case when src.TRANSACTION_DATE  = ''1950-01-01'' then -2
                                    else nvl(d17.DIM_DATE_KEY, -1) END AS TRANSACTION_DATE_DIM_DATE_KEY
                                , src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                , case when src.CHECK_DATE  = ''1950-01-01'' then -2
                                    else nvl(d18.DIM_DATE_KEY, -1) END AS CHECK_DATE_DIM_DATE_KEY
                                , src.CHECK_DATE_DIM_DATE_SNKEY
                                , case when src.INVOICE_DATE  = ''1950-01-01'' then -2
                                    else nvl(d19.DIM_DATE_KEY, -1) END AS INVOICE_DATE_DIM_DATE_KEY
                                , src.INVOICE_DATE_DIM_DATE_SNKEY
                                , src.ALIGNED_DUE_DATE
                                , src.APPROVED_DATE
                                , src.CLOSED_DATE
                                , src.DOCUMENT_DATE
                                , src.DUE_DATE
                                , src.LAST_SETTLEMENT_DATE
                                , src.TRANSACTION_DATE
                                , src.DOCUMENT_NUMBER
                                , src.INVOICE_ID
                                , src.LEGAL_ENTITY
                                , src.LAST_SETTLEMENT_VOUCHER
                                , src.VOUCHER
                                , src.AMOUNT_TRANSACTION_CURRENCY
                                , src.AMOUNT_COMPANY_CURRENCY
                                , src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                , src.SETTLED_AMOUNT_COMPANY_CURRENCY
                                , src.SETTLED_AMOUNT_REPORTING_CURRENCY
                                , src.ACCOUNT_NUMBER
                                , src.APPROVER
                                , src.CASH_DISCOUNT_CODE
                                , src.CURRENCY_CODE
                                , src.DEFAULT_DIMENSION
                                , src.PAYMENT_MODE
                                , src.PAYMENT_SPECIFICATION
                                , src.REMITTANCE_LOCATION
                                , src.CHECK_DATE
                                , src.PAYMENT_TERMS
                                , src.INVOICE_DATE
                                , src.DAYS_OVERDUE
                                , src.SETTLED_TRANSACTION_RECORD_ID
                                , src.DAYS_TO_PAY
                                , src.INVOICE_STATUS
                                , src.INVOICE_FULL_STATUS
                                , src.TRANSACTION_TYPE
                                , src.IS_APPROVED
                                , src.IS_REVERSAL
                                , hash(src.source_name, ''~'', to_char(src.record_id), ''~'',to_char(src.aligned_due_date, ''yyyymmdd''), ''~'', to_char(src.approved_date, ''yyyymmdd''), ''~'', to_char(src.closed_date, ''yyyymmdd''), ''~'', to_char(src.document_date, ''yyyymmdd''), ''~'', to_char(src.due_date, ''yyyymmdd''), ''~'', to_char(src.last_settlement_date, ''yyyymmdd''), ''~'', to_char(src.transaction_date, ''yyyymmdd''), ''~'', src.document_number, ''~'', src.invoice_id, ''~'', src.legal_entity, ''~'', src.last_settlement_voucher, ''~'', src.voucher, ''~'', to_char(src.amount_transaction_currency), ''~'', to_char(src.amount_company_currency), ''~'', to_char(src.settled_amount_transaction_currency), ''~'', to_char(src.settled_amount_company_currency), ''~'', to_char(src.settled_amount_reporting_currency), ''~'', src.account_number, ''~'', to_char(src.approver), ''~'', src.cash_discount_code, ''~'', src.currency_code, ''~'', src.default_dimension, ''~'', src.payment_mode, ''~'', src.payment_specification, ''~'', to_char(src.remittance_location), ''~'', to_char(src.check_date, ''yyyymmdd''), ''~'', src.payment_terms, ''~'', to_char(src.invoice_date, ''yyyymmdd''), ''~'', to_char(src.days_overdue), ''~'', to_char(src.settled_transaction_record_id), ''~'', to_char(src.days_to_pay), ''~'', src.invoice_status, ''~'', src.invoice_full_status, ''~'', src.transaction_type, ''~'', src.is_approved, ''~'', src.is_reversal) AS SRC_HK_HASH_KEY
                                , src.HK_SOURCE_NAME
                                , src.HK_SOFT_DELETE_FLAG
                                , src.HK_SOURCE_CREATED_TIMESTAMP
                                , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , src.HK_CREATED_JOB_RUN_ID
                                , src.HK_LAST_UPDATED_JOB_RUN_ID
                                , src.HK_CREATED_TIMESTAMP
                                , src.HK_LAST_UPDATED_TIMESTAMP
                                , src.HK_WAREHOUSE_ID
                                , CASE 
                                    WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                    WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                    ELSE ''DROP''
                                END AS DML_IND
                                , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (
                                SELECT 
                                    FACT_VENDOR_TRANSACTIONS_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , case when SOURCE_NAME = '''' then -2
                                        else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                                    , DIM_CASH_DISCOUNT_KEY
                                    , case when nvl(LEGAL_ENTITY,'''') = '''' or nvl(CASH_DISCOUNT_CODE, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'',CASH_DISCOUNT_CODE) END AS DIM_CASH_DISCOUNT_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , case when nvl(CURRENCY_CODE, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                                    , DIM_DEFAULT_DIMENSION_KEY
                                    , case when nvl(DEFAULT_DIMENSION, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , case when nvl(LEGAL_ENTITY, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                                    , DIM_LOCATION_KEY
                                    , case when nvl(REMITTANCE_LOCATION, 0) = 0 then -2
                                        else hash(SOURCE_NAME, ''~'', to_char(REMITTANCE_LOCATION)) END AS DIM_LOCATION_SNKEY
                                    , DIM_VENDOR_INVOICE_KEY
                                    , case when nvl(LEGAL_ENTITY,'''') = '''' or nvl(ACCOUNT_NUMBER, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', ACCOUNT_NUMBER) END AS DIM_VENDOR_INVOICE_SNKEY
                                    , DIM_VENDOR_PAYMENT_MODE_KEY
                                    , case when nvl(LEGAL_ENTITY,'''') = '''' or nvl(PAYMENT_MODE, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'',PAYMENT_MODE) END AS DIM_VENDOR_PAYMENT_MODE_SNKEY
                                    , DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                    , case when nvl(LEGAL_ENTITY,'''') = '''' or nvl(PAYMENT_MODE, '''') = '''' or nvl(PAYMENT_SPECIFICATION,'''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'',PAYMENT_MODE, ''~'',PAYMENT_SPECIFICATION) END AS DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                    -- , DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                    -- , hash(TRANSACTION_TYPE, ''~'', IS_APPROVED, ''~'',IS_REVERSAL) AS DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                    , DIM_WORKER_APPROVER_KEY
                                    , case when nvl(APPROVER, 0) = 0 then -2
                                        else hash(SOURCE_NAME, ''~'', TO_CHAR(APPROVER)) END AS DIM_WORKER_APPROVER_SNKEY
                                    , ALIGNED_DUE_DATE_DIM_DATE_KEY
                                    , case when ALIGNED_DUE_DATE = ''1950-01-01'' then -2 
                                        else hash('''', ''~'', to_char(ALIGNED_DUE_DATE, ''yyyymmdd'')) END AS ALIGNED_DUE_DATE_DIM_DATE_SNKEY
                                    , APPROVED_DATE_DIM_DATE_KEY
                                    , case when APPROVED_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(APPROVED_DATE, ''yyyymmdd'')) END AS APPROVED_DATE_DIM_DATE_SNKEY
                                    , CLOSED_DATE_DIM_DATE_KEY
                                    , case when CLOSED_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(CLOSED_DATE, ''yyyymmdd'')) END AS CLOSED_DATE_DIM_DATE_SNKEY
                                    , DOCUMENT_DATE_DIM_DATE_KEY
                                    , case when DOCUMENT_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , DUE_DATE_DIM_DATE_KEY
                                    , case when DUE_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DUE_DATE, ''yyyymmdd'')) END AS DUE_DATE_DIM_DATE_SNKEY
                                    , LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                    , case when LAST_SETTLEMENT_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(LAST_SETTLEMENT_DATE, ''yyyymmdd'')) END AS LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                    , TRANSACTION_DATE_DIM_DATE_KEY
                                    , case when TRANSACTION_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(TRANSACTION_DATE, ''yyyymmdd'')) END AS TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , CHECK_DATE_DIM_DATE_KEY
                                    , case when CHECK_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(CHECK_DATE, ''yyyymmdd'')) END AS CHECK_DATE_DIM_DATE_SNKEY
                                    , INVOICE_DATE_DIM_DATE_KEY
                                    , case when INVOICE_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(INVOICE_DATE, ''yyyymmdd'')) END AS INVOICE_DATE_DIM_DATE_SNKEY
                                    , ALIGNED_DUE_DATE
                                    , APPROVED_DATE
                                    , CLOSED_DATE
                                    , DOCUMENT_DATE
                                    , DUE_DATE
                                    , LAST_SETTLEMENT_DATE
                                    , TRANSACTION_DATE
                                    , DOCUMENT_NUMBER
                                    , INVOICE_ID
                                    , LEGAL_ENTITY
                                    , LAST_SETTLEMENT_VOUCHER
                                    , VOUCHER
                                    , AMOUNT_TRANSACTION_CURRENCY
                                    , AMOUNT_COMPANY_CURRENCY
                                    , SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                    , SETTLED_AMOUNT_COMPANY_CURRENCY
                                    , SETTLED_AMOUNT_REPORTING_CURRENCY
                                    , ACCOUNT_NUMBER
                                    , APPROVER
                                    , CASH_DISCOUNT_CODE
                                    , CURRENCY_CODE
                                    , DEFAULT_DIMENSION
                                    , PAYMENT_MODE
                                    , PAYMENT_SPECIFICATION
                                    , REMITTANCE_LOCATION
                                    , CHECK_DATE
                                    , PAYMENT_TERMS
                                    , INVOICE_DATE
                                    , DAYS_OVERDUE
                                    , SETTLED_TRANSACTION_RECORD_ID
                                    , DAYS_TO_PAY
                                    , INVOICE_STATUS
                                    , INVOICE_FULL_STATUS
                                    , TRANSACTION_TYPE
                                    , IS_APPROVED
                                    , IS_REVERSAL
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                    , TGT_HK_HASH_KEY
                                FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                                || ') src 
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CASH_DISCOUNT d2 ON
                                    src.DIM_CASH_DISCOUNT_SNKEY = d2.DIM_CASH_DISCOUNT_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d3 ON
                                    src.DIM_CURRENCY_SNKEY = d3.DIM_CURRENCY_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d4 ON
                                    src.DIM_DEFAULT_DIMENSION_SNKEY = d4.DIM_DEFAULT_DIMENSION_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d5 ON
                                    src.DIM_LEGAL_ENTITY_SNKEY = d5.DIM_LEGAL_ENTITY_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d6 ON
                                    src.DIM_LOCATION_SNKEY = d6.DIM_LOCATION_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR d7 ON
                                    src.DIM_VENDOR_INVOICE_SNKEY = d7.DIM_VENDOR_SNKEY
                                    and src.INVOICE_DATE >= d7.HK_EFFECTIVE_START_TIMESTAMP and src.INVOICE_DATE < d7.HK_EFFECTIVE_END_TIMESTAMP
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR_PAYMENT_MODE d8 ON
                                    src.DIM_VENDOR_PAYMENT_MODE_SNKEY = d8.DIM_VENDOR_PAYMENT_MODE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR_PAYMENT_SPECIFICATION d9 ON
                                    src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY = d9.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d10 ON
                                    src.DIM_WORKER_APPROVER_SNKEY = d10.DIM_WORKER_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d11 ON
                                    src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY = d11.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d12 ON
                                    src.APPROVED_DATE_DIM_DATE_SNKEY = d12.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d13 ON
                                    src.CLOSED_DATE_DIM_DATE_SNKEY = d13.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d14 ON
                                    src.DOCUMENT_DATE_DIM_DATE_SNKEY = d14.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d15 ON
                                    src.DUE_DATE_DIM_DATE_SNKEY = d15.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d16 ON
                                    src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY = d16.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d17 ON
                                    src.TRANSACTION_DATE_DIM_DATE_SNKEY = d17.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d18 ON
                                    src.CHECK_DATE_DIM_DATE_SNKEY = d18.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d19 ON
                                    src.INVOICE_DATE_DIM_DATE_SNKEY = d19.DIM_DATE_SNKEY
                                QUALIFY PK_ROW_NUMBER = 1 ';
    
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

    /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_VENDOR_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_VENDOR_TRANSACTIONS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_VENDOR_TRANSACTIONS_KEY = tgt.FACT_VENDOR_TRANSACTIONS_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_VENDOR_TRANSACTIONS_KEY = tgt.FACT_VENDOR_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.DIM_CASH_DISCOUNT_KEY = src.DIM_CASH_DISCOUNT_KEY
                                    , tgt.DIM_CASH_DISCOUNT_SNKEY = src.DIM_CASH_DISCOUNT_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_LOCATION_KEY = src.DIM_LOCATION_KEY
                                    , tgt.DIM_LOCATION_SNKEY = src.DIM_LOCATION_SNKEY
                                    , tgt.DIM_VENDOR_INVOICE_KEY = src.DIM_VENDOR_INVOICE_KEY
                                    , tgt.DIM_VENDOR_INVOICE_SNKEY = src.DIM_VENDOR_INVOICE_SNKEY
                                    , tgt.DIM_VENDOR_PAYMENT_MODE_KEY = src.DIM_VENDOR_PAYMENT_MODE_KEY
                                    , tgt.DIM_VENDOR_PAYMENT_MODE_SNKEY = src.DIM_VENDOR_PAYMENT_MODE_SNKEY
                                    , tgt.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY = src.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                    , tgt.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY = src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                    -- , tgt.DIM_VENDOR_TRANSACTION_DETAILS_KEY = src.DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                    -- , tgt.DIM_VENDOR_TRANSACTION_DETAILS_SNKEY = src.DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.DIM_WORKER_APPROVER_KEY
                                    , tgt.DIM_WORKER_APPROVER_SNKEY = src.DIM_WORKER_APPROVER_SNKEY
                                    , tgt.ALIGNED_DUE_DATE_DIM_DATE_KEY = src.ALIGNED_DUE_DATE_DIM_DATE_KEY
                                    , tgt.ALIGNED_DUE_DATE_DIM_DATE_SNKEY = src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY
                                    , tgt.APPROVED_DATE_DIM_DATE_KEY = src.APPROVED_DATE_DIM_DATE_KEY
                                    , tgt.APPROVED_DATE_DIM_DATE_SNKEY = src.APPROVED_DATE_DIM_DATE_SNKEY
                                    , tgt.CLOSED_DATE_DIM_DATE_KEY = src.CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.CLOSED_DATE_DIM_DATE_SNKEY = src.CLOSED_DATE_DIM_DATE_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.DUE_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_SNKEY = src.DUE_DATE_DIM_DATE_SNKEY
                                    , tgt.LAST_SETTLEMENT_DATE_DIM_DATE_KEY = src.LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                    , tgt.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY = src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_SNKEY = src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , tgt.CHECK_DATE_DIM_DATE_KEY = src.CHECK_DATE_DIM_DATE_KEY
                                    , tgt.CHECK_DATE_DIM_DATE_SNKEY = src.CHECK_DATE_DIM_DATE_SNKEY
                                    , tgt.INVOICE_DATE_DIM_DATE_KEY = src.INVOICE_DATE_DIM_DATE_KEY
                                    , tgt.INVOICE_DATE_DIM_DATE_SNKEY = src.INVOICE_DATE_DIM_DATE_SNKEY
                                    , tgt.ALIGNED_DUE_DATE = src.ALIGNED_DUE_DATE
                                    , tgt.APPROVED_DATE = src.APPROVED_DATE
                                    , tgt.CLOSED_DATE = src.CLOSED_DATE
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.DUE_DATE = src.DUE_DATE
                                    , tgt.LAST_SETTLEMENT_DATE = src.LAST_SETTLEMENT_DATE
                                    , tgt.TRANSACTION_DATE = src.TRANSACTION_DATE
                                    , tgt.DOCUMENT_NUMBER = src.DOCUMENT_NUMBER
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.LAST_SETTLEMENT_VOUCHER = src.LAST_SETTLEMENT_VOUCHER
                                    , tgt.VOUCHER = src.VOUCHER
                                    , tgt.AMOUNT_TRANSACTION_CURRENCY = src.AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.AMOUNT_COMPANY_CURRENCY = src.AMOUNT_COMPANY_CURRENCY
                                    , tgt.SETTLED_AMOUNT_TRANSACTION_CURRENCY = src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.SETTLED_AMOUNT_COMPANY_CURRENCY = src.SETTLED_AMOUNT_COMPANY_CURRENCY
                                    , tgt.SETTLED_AMOUNT_REPORTING_CURRENCY = src.SETTLED_AMOUNT_REPORTING_CURRENCY
                                    , tgt.ACCOUNT_NUMBER = src.ACCOUNT_NUMBER
                                    , tgt.APPROVER = src.APPROVER
                                    , tgt.CASH_DISCOUNT_CODE = src.CASH_DISCOUNT_CODE
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.PAYMENT_MODE = src.PAYMENT_MODE
                                    , tgt.PAYMENT_SPECIFICATION = src.PAYMENT_SPECIFICATION
                                    , tgt.REMITTANCE_LOCATION = src.REMITTANCE_LOCATION
                                    , tgt.CHECK_DATE = src.CHECK_DATE
                                    , tgt.PAYMENT_TERMS = src.PAYMENT_TERMS
                                    , tgt.INVOICE_DATE = src.INVOICE_DATE
                                    , tgt.DAYS_OVERDUE = src.DAYS_OVERDUE
                                    , tgt.SETTLED_TRANSACTION_RECORD_ID = src.SETTLED_TRANSACTION_RECORD_ID
                                    , tgt.DAYS_TO_PAY = src.DAYS_TO_PAY
                                    , tgt.INVOICE_STATUS = src.INVOICE_STATUS
                                    , tgt.INVOICE_FULL_STATUS = src.INVOICE_FULL_STATUS
                                    , tgt.TRANSACTION_TYPE = src.TRANSACTION_TYPE
                                    , tgt.IS_APPROVED = src.IS_APPROVED
                                    , tgt.IS_REVERSAL = src.IS_REVERSAL
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                    FACT_VENDOR_TRANSACTIONS_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , DIM_SOURCE_SYSTEM_SNKEY
                                    , DIM_CASH_DISCOUNT_KEY
                                    , DIM_CASH_DISCOUNT_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , DIM_CURRENCY_SNKEY
                                    , DIM_DEFAULT_DIMENSION_KEY
                                    , DIM_DEFAULT_DIMENSION_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , DIM_LEGAL_ENTITY_SNKEY
                                    , DIM_LOCATION_KEY
                                    , DIM_LOCATION_SNKEY
                                    , DIM_VENDOR_INVOICE_KEY
                                    , DIM_VENDOR_INVOICE_SNKEY
                                    , DIM_VENDOR_PAYMENT_MODE_KEY
                                    , DIM_VENDOR_PAYMENT_MODE_SNKEY
                                    , DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                    , DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                    -- , DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                    -- , DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                    , DIM_WORKER_APPROVER_KEY
                                    , DIM_WORKER_APPROVER_SNKEY
                                    , ALIGNED_DUE_DATE_DIM_DATE_KEY
                                    , ALIGNED_DUE_DATE_DIM_DATE_SNKEY
                                    , APPROVED_DATE_DIM_DATE_KEY
                                    , APPROVED_DATE_DIM_DATE_SNKEY
                                    , CLOSED_DATE_DIM_DATE_KEY
                                    , CLOSED_DATE_DIM_DATE_SNKEY
                                    , DOCUMENT_DATE_DIM_DATE_KEY
                                    , DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , DUE_DATE_DIM_DATE_KEY
                                    , DUE_DATE_DIM_DATE_SNKEY
                                    , LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                    , LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                    , TRANSACTION_DATE_DIM_DATE_KEY
                                    , TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , CHECK_DATE_DIM_DATE_KEY
                                    , CHECK_DATE_DIM_DATE_SNKEY
                                    , INVOICE_DATE_DIM_DATE_KEY
                                    , INVOICE_DATE_DIM_DATE_SNKEY
                                    , ALIGNED_DUE_DATE
                                    , APPROVED_DATE
                                    , CLOSED_DATE
                                    , DOCUMENT_DATE
                                    , DUE_DATE
                                    , LAST_SETTLEMENT_DATE
                                    , TRANSACTION_DATE
                                    , DOCUMENT_NUMBER
                                    , INVOICE_ID
                                    , LEGAL_ENTITY
                                    , LAST_SETTLEMENT_VOUCHER
                                    , VOUCHER
                                    , AMOUNT_TRANSACTION_CURRENCY
                                    , AMOUNT_COMPANY_CURRENCY
                                    , SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                    , SETTLED_AMOUNT_COMPANY_CURRENCY
                                    , SETTLED_AMOUNT_REPORTING_CURRENCY
                                    , ACCOUNT_NUMBER
                                    , APPROVER
                                    , CASH_DISCOUNT_CODE
                                    , CURRENCY_CODE
                                    , DEFAULT_DIMENSION
                                    , PAYMENT_MODE
                                    , PAYMENT_SPECIFICATION
                                    , REMITTANCE_LOCATION
                                    , CHECK_DATE
                                    , PAYMENT_TERMS
                                    , INVOICE_DATE
                                    , DAYS_OVERDUE
                                    , SETTLED_TRANSACTION_RECORD_ID
                                    , DAYS_TO_PAY
                                    , INVOICE_STATUS
                                    , INVOICE_FULL_STATUS
                                    , TRANSACTION_TYPE
                                    , IS_APPROVED
                                    , IS_REVERSAL
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                                VALUES
                                (
                                    src.FACT_VENDOR_TRANSACTIONS_KEY
                                    , src.SOURCE_NAME
                                    , src.RECORD_ID
                                    , src.DIM_SOURCE_SYSTEM_KEY
                                    , src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.DIM_CASH_DISCOUNT_KEY
                                    , src.DIM_CASH_DISCOUNT_SNKEY
                                    , src.DIM_CURRENCY_KEY
                                    , src.DIM_CURRENCY_SNKEY
                                    , src.DIM_DEFAULT_DIMENSION_KEY
                                    , src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , src.DIM_LEGAL_ENTITY_KEY
                                    , src.DIM_LEGAL_ENTITY_SNKEY
                                    , src.DIM_LOCATION_KEY
                                    , src.DIM_LOCATION_SNKEY
                                    , src.DIM_VENDOR_INVOICE_KEY
                                    , src.DIM_VENDOR_INVOICE_SNKEY
                                    , src.DIM_VENDOR_PAYMENT_MODE_KEY
                                    , src.DIM_VENDOR_PAYMENT_MODE_SNKEY
                                    , src.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                    , src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                                    -- , src.DIM_VENDOR_TRANSACTION_DETAILS_KEY
                                    -- , src.DIM_VENDOR_TRANSACTION_DETAILS_SNKEY
                                    , src.DIM_WORKER_APPROVER_KEY
                                    , src.DIM_WORKER_APPROVER_SNKEY
                                    , src.ALIGNED_DUE_DATE_DIM_DATE_KEY
                                    , src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY 
                                    , src.APPROVED_DATE_DIM_DATE_KEY
                                    , src.APPROVED_DATE_DIM_DATE_SNKEY
                                    , src.CLOSED_DATE_DIM_DATE_KEY
                                    , src.CLOSED_DATE_DIM_DATE_SNKEY
                                    , src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , src.DUE_DATE_DIM_DATE_KEY
                                    , src.DUE_DATE_DIM_DATE_SNKEY
                                    , src.LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                    , src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY
                                    , src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , src.CHECK_DATE_DIM_DATE_KEY
                                    , src.CHECK_DATE_DIM_DATE_SNKEY
                                    , src.INVOICE_DATE_DIM_DATE_KEY
                                    , src.INVOICE_DATE_DIM_DATE_SNKEY
                                    , src.ALIGNED_DUE_DATE
                                    , src.APPROVED_DATE
                                    , src.CLOSED_DATE
                                    , src.DOCUMENT_DATE
                                    , src.DUE_DATE
                                    , src.LAST_SETTLEMENT_DATE
                                    , src.TRANSACTION_DATE
                                    , src.DOCUMENT_NUMBER
                                    , src.INVOICE_ID
                                    , src.LEGAL_ENTITY
                                    , src.LAST_SETTLEMENT_VOUCHER
                                    , src.VOUCHER
                                    , src.AMOUNT_TRANSACTION_CURRENCY
                                    , src.AMOUNT_COMPANY_CURRENCY
                                    , src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                    , src.SETTLED_AMOUNT_COMPANY_CURRENCY
                                    , src.SETTLED_AMOUNT_REPORTING_CURRENCY
                                    , src.ACCOUNT_NUMBER
                                    , src.APPROVER
                                    , src.CASH_DISCOUNT_CODE
                                    , src.CURRENCY_CODE
                                    , src.DEFAULT_DIMENSION
                                    , src.PAYMENT_MODE
                                    , src.PAYMENT_SPECIFICATION
                                    , src.REMITTANCE_LOCATION
                                    , src.CHECK_DATE
                                    , src.PAYMENT_TERMS
                                    , src.INVOICE_DATE
                                    , src.DAYS_OVERDUE
                                    , src.SETTLED_TRANSACTION_RECORD_ID
                                    , src.DAYS_TO_PAY
                                    , src.INVOICE_STATUS
                                    , src.INVOICE_FULL_STATUS
                                    , src.TRANSACTION_TYPE
                                    , src.IS_APPROVED
                                    , src.IS_REVERSAL
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
            select 
                a.FACT_VENDOR_TRANSACTIONS_KEY
                , a.NEW_DIM_SOURCE_SYSTEM_KEY
                , a.NEW_DIM_CASH_DISCOUNT_KEY
                , a.NEW_DIM_CURRENCY_KEY
                , a.NEW_DIM_DEFAULT_DIMENSION_KEY
                , a.NEW_DIM_LEGAL_ENTITY_KEY
                , a.NEW_DIM_LOCATION_KEY
                , a.NEW_DIM_VENDOR_INVOICE_KEY
                , a.NEW_DIM_VENDOR_PAYMENT_MODE_KEY
                , a.NEW_DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                , a.NEW_DIM_WORKER_APPROVER_KEY
                , a.NEW_ALIGNED_DUE_DATE_DIM_DATE_KEY
                , a.NEW_APPROVED_DATE_DIM_DATE_KEY
                , a.NEW_CLOSED_DATE_DIM_DATE_KEY
                , a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                , a.NEW_DUE_DATE_DIM_DATE_KEY
                , a.NEW_LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                , a.NEW_TRANSACTION_DATE_DIM_DATE_KEY
                , a.NEW_CHECK_DATE_DIM_DATE_KEY
                , a.NEW_INVOICE_DATE_DIM_DATE_KEY
            from 
            (
                select 
                    src.FACT_VENDOR_TRANSACTIONS_KEY
                    , src.DIM_SOURCE_SYSTEM_KEY
                    , src.DIM_CASH_DISCOUNT_KEY
                    , src.DIM_CURRENCY_KEY
                    , src.DIM_DEFAULT_DIMENSION_KEY
                    , src.DIM_LEGAL_ENTITY_KEY
                    , src.DIM_LOCATION_KEY
                    , src.DIM_VENDOR_INVOICE_KEY
                    , src.DIM_VENDOR_PAYMENT_MODE_KEY
                    , src.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                    , src.DIM_WORKER_APPROVER_KEY
                    , src.ALIGNED_DUE_DATE_DIM_DATE_KEY
                    , src.APPROVED_DATE_DIM_DATE_KEY
                    , src.CLOSED_DATE_DIM_DATE_KEY
                    , src.DOCUMENT_DATE_DIM_DATE_KEY
                    , src.DUE_DATE_DIM_DATE_KEY
                    , src.LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                    , src.TRANSACTION_DATE_DIM_DATE_KEY
                    , src.CHECK_DATE_DIM_DATE_KEY
                    , src.INVOICE_DATE_DIM_DATE_KEY
                    , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                    , nvl(d2.DIM_CASH_DISCOUNT_KEY, -1) AS NEW_DIM_CASH_DISCOUNT_KEY
                    , nvl(d3.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                    , nvl(d4.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
                    , nvl(d5.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                    , nvl(d6.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_KEY
                    , nvl(d7.DIM_VENDOR_KEY, -1) AS NEW_DIM_VENDOR_INVOICE_KEY
                    , nvl(d8.DIM_VENDOR_PAYMENT_MODE_KEY, -1) AS NEW_DIM_VENDOR_PAYMENT_MODE_KEY
                    , nvl(d9.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY, -1) AS NEW_DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                    , nvl(d10.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_APPROVER_KEY
                    , nvl(d11.DIM_DATE_KEY, -1) AS NEW_ALIGNED_DUE_DATE_DIM_DATE_KEY
                    , nvl(d12.DIM_DATE_KEY, -1) AS NEW_APPROVED_DATE_DIM_DATE_KEY
                    , nvl(d13.DIM_DATE_KEY, -1) AS NEW_CLOSED_DATE_DIM_DATE_KEY
                    , nvl(d14.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
                    , nvl(d15.DIM_DATE_KEY, -1) AS NEW_DUE_DATE_DIM_DATE_KEY
                    , nvl(d16.DIM_DATE_KEY, -1) AS NEW_LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                    , nvl(d17.DIM_DATE_KEY, -1) AS NEW_TRANSACTION_DATE_DIM_DATE_KEY
                    , nvl(d18.DIM_DATE_KEY, -1) AS NEW_CHECK_DATE_DIM_DATE_KEY
                    , nvl(d19.DIM_DATE_KEY, -1) AS NEW_INVOICE_DATE_DIM_DATE_KEY
                from ' || :tgt_db || '.global.FACT_VENDOR_TRANSACTIONS src
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CASH_DISCOUNT d2 ON
                    src.DIM_CASH_DISCOUNT_SNKEY = d2.DIM_CASH_DISCOUNT_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d3 ON
                    src.DIM_CURRENCY_SNKEY = d3.DIM_CURRENCY_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d4 ON
                    src.DIM_DEFAULT_DIMENSION_SNKEY = d4.DIM_DEFAULT_DIMENSION_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d5 ON
                    src.DIM_LEGAL_ENTITY_SNKEY = d5.DIM_LEGAL_ENTITY_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d6 ON
                    src.DIM_LOCATION_SNKEY = d6.DIM_LOCATION_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR d7 ON
                    src.DIM_VENDOR_INVOICE_SNKEY = d7.DIM_VENDOR_SNKEY
                    and src.INVOICE_DATE >= d7.HK_EFFECTIVE_START_TIMESTAMP and src.INVOICE_DATE < d7.HK_EFFECTIVE_END_TIMESTAMP
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR_PAYMENT_MODE d8 ON
                    src.DIM_VENDOR_PAYMENT_MODE_SNKEY = d8.DIM_VENDOR_PAYMENT_MODE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_VENDOR_PAYMENT_SPECIFICATION d9 ON
                    src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY = d9.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d10 ON
                    src.DIM_WORKER_APPROVER_SNKEY = d10.DIM_WORKER_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d11 ON
                    src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY = d11.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d12 ON
                    src.APPROVED_DATE_DIM_DATE_SNKEY = d12.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d13 ON
                    src.CLOSED_DATE_DIM_DATE_SNKEY = d13.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d14 ON
                    src.DOCUMENT_DATE_DIM_DATE_SNKEY = d14.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d15 ON
                    src.DUE_DATE_DIM_DATE_SNKEY = d15.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d16 ON
                    src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY = d16.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d17 ON
                    src.TRANSACTION_DATE_DIM_DATE_SNKEY = d17.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d18 ON
                    src.CHECK_DATE_DIM_DATE_SNKEY = d18.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d19 ON
                    src.INVOICE_DATE_DIM_DATE_SNKEY = d19.DIM_DATE_SNKEY
                    where 1=1
                    and (
                            (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                            or (src.DIM_CASH_DISCOUNT_KEY = -1 and src.DIM_CASH_DISCOUNT_SNKEY != -1)
                            or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
                            or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
                            or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                            or (src.DIM_LOCATION_KEY = -1 and src.DIM_LOCATION_SNKEY != -1)
                            or (src.DIM_VENDOR_INVOICE_KEY = -1 and src.DIM_VENDOR_INVOICE_SNKEY != -1)
                            or (src.DIM_VENDOR_PAYMENT_MODE_KEY = -1 and src.DIM_VENDOR_PAYMENT_MODE_SNKEY != -1)
                            or (src.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY = -1 and src.DIM_VENDOR_PAYMENT_SPECIFICATION_SNKEY != -1)
                            or (src.DIM_WORKER_APPROVER_KEY = -1 and src.DIM_WORKER_APPROVER_SNKEY != -1)
                            or (src.ALIGNED_DUE_DATE_DIM_DATE_KEY = -1 and src.ALIGNED_DUE_DATE_DIM_DATE_SNKEY != -1)
                            or (src.APPROVED_DATE_DIM_DATE_KEY = -1 and src.APPROVED_DATE_DIM_DATE_SNKEY != -1)
                            or (src.CLOSED_DATE_DIM_DATE_KEY = -1 and src.CLOSED_DATE_DIM_DATE_SNKEY != -1)
                            or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
                            or (src.DUE_DATE_DIM_DATE_KEY = -1 and src.DUE_DATE_DIM_DATE_SNKEY != -1)
                            or (src.LAST_SETTLEMENT_DATE_DIM_DATE_KEY = -1 and src.LAST_SETTLEMENT_DATE_DIM_DATE_SNKEY != -1)
                            or (src.TRANSACTION_DATE_DIM_DATE_KEY = -1 and src.TRANSACTION_DATE_DIM_DATE_SNKEY != -1)
                            or (src.CHECK_DATE_DIM_DATE_KEY = -1 and src.CHECK_DATE_DIM_DATE_SNKEY != -1)
                            or (src.INVOICE_DATE_DIM_DATE_KEY = -1 and src.INVOICE_DATE_DIM_DATE_SNKEY != -1)
                    )
            )a
            where 1=1
            and (
                    (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
                    or (a.DIM_CASH_DISCOUNT_KEY != a.NEW_DIM_CASH_DISCOUNT_KEY)
                    or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
                    or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
                    or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
                    or (a.DIM_LOCATION_KEY != a.NEW_DIM_LOCATION_KEY)
                    or (a.DIM_VENDOR_INVOICE_KEY != a.NEW_DIM_VENDOR_INVOICE_KEY)
                    or (a.DIM_VENDOR_PAYMENT_MODE_KEY != a.NEW_DIM_VENDOR_PAYMENT_MODE_KEY)
                    or (a.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY != a.NEW_DIM_VENDOR_PAYMENT_SPECIFICATION_KEY)
                    or (a.DIM_WORKER_APPROVER_KEY != a.NEW_DIM_WORKER_APPROVER_KEY)
                    or (a.ALIGNED_DUE_DATE_DIM_DATE_KEY != a.NEW_ALIGNED_DUE_DATE_DIM_DATE_KEY)
                    or (a.APPROVED_DATE_DIM_DATE_KEY != a.NEW_APPROVED_DATE_DIM_DATE_KEY)
                    or (a.CLOSED_DATE_DIM_DATE_KEY != a.NEW_CLOSED_DATE_DIM_DATE_KEY)
                    or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
                    or (a.DUE_DATE_DIM_DATE_KEY != a.NEW_DUE_DATE_DIM_DATE_KEY)
                    or (a.LAST_SETTLEMENT_DATE_DIM_DATE_KEY != a.NEW_LAST_SETTLEMENT_DATE_DIM_DATE_KEY)
                    or (a.TRANSACTION_DATE_DIM_DATE_KEY != a.NEW_TRANSACTION_DATE_DIM_DATE_KEY)
                    or (a.CHECK_DATE_DIM_DATE_KEY != a.NEW_CHECK_DATE_DIM_DATE_KEY)
                    or (a.INVOICE_DATE_DIM_DATE_KEY != a.NEW_INVOICE_DATE_DIM_DATE_KEY)

                )
            ;';
            EXECUTE IMMEDIATE :late_dim_select;

        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_VENDOR_TRANSACTIONS_KEY = tgt.FACT_VENDOR_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_CASH_DISCOUNT_KEY = src.NEW_DIM_CASH_DISCOUNT_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LOCATION_KEY = src.NEW_DIM_LOCATION_KEY
                                    , tgt.DIM_VENDOR_INVOICE_KEY = src.NEW_DIM_VENDOR_INVOICE_KEY
                                    , tgt.DIM_VENDOR_PAYMENT_MODE_KEY = src.NEW_DIM_VENDOR_PAYMENT_MODE_KEY
                                    , tgt.DIM_VENDOR_PAYMENT_SPECIFICATION_KEY = src.NEW_DIM_VENDOR_PAYMENT_SPECIFICATION_KEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.NEW_DIM_WORKER_APPROVER_KEY
                                    , tgt.ALIGNED_DUE_DATE_DIM_DATE_KEY = src.NEW_ALIGNED_DUE_DATE_DIM_DATE_KEY
                                    , tgt.APPROVED_DATE_DIM_DATE_KEY = src.NEW_APPROVED_DATE_DIM_DATE_KEY
                                    , tgt.CLOSED_DATE_DIM_DATE_KEY = src.NEW_CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.NEW_DUE_DATE_DIM_DATE_KEY
                                    , tgt.LAST_SETTLEMENT_DATE_DIM_DATE_KEY = src.NEW_LAST_SETTLEMENT_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.NEW_TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.CHECK_DATE_DIM_DATE_KEY = src.NEW_CHECK_DATE_DIM_DATE_KEY
                                    , tgt.INVOICE_DATE_DIM_DATE_KEY = src.NEW_INVOICE_DATE_DIM_DATE_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);
    
        --Logging stored procedure completed
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '11';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;