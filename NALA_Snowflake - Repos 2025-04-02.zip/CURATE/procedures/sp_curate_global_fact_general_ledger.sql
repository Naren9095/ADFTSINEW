/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_GENERAL_LEDGER
    CREATED BY     : Joshua Mills
    CREATED ON     : 08/08/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_GENERAL_LEDGER(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_GENERAL_LEDGER
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_GENERAL_LEDGER';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'GENERALJOURNALACCOUNTENTRY';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_GENERAL_LEDGER';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_GENERAL_LEDGER_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_GENERAL_LEDGER_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS ACCOUNTING_DATE_DIM_DATE_KEY
                                , 0 AS ACCOUNTING_DATE_DIM_DATE_SNKEY
                                , 0 AS ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                                , 0 AS ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS CREATED_DATE_DIM_DATE_KEY
                                , 0 AS CREATED_DATE_DIM_DATE_SNKEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                                , 0 AS DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                                , 0 AS DIM_LEDGER_KEY
                                , 0 AS DIM_LEDGER_SNKEY
                                , 0 AS DIM_LEDGER_DIMENSION_KEY
                                , 0 AS DIM_LEDGER_DIMENSION_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_MAIN_ACCOUNT_KEY
                                , 0 AS DIM_MAIN_ACCOUNT_SNKEY
                                , 0 AS DIM_REASON_KEY
                                , 0 AS DIM_REASON_SNKEY
                                , nvl(src.TRANSACTIONCURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(src.GENERALJOURNALENTRY_FISCALCALENDARPERIOD, 0) AS RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                                , nvl(src.GENERALJOURNALENTRY_LEDGER, 0) AS RECORD_ID_LEDGER
                                , CASE WHEN nvl(to_char(src.LEDGERDIMENSION), '''') = ''0'' THEN ''''
                                    ELSE nvl(to_char(src.LEDGERDIMENSION), '''') END AS LEDGER_DIMENSION
                                , nvl(src.MAINACCOUNT, 0) AS RECORD_ID_MAIN_ACCOUNT
                                , nvl(src.REASONREF, 0) AS RECORD_ID_REASON
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_JOURNALCATEGORY, '''') AS JOURNAL_CATEGORY
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_POSTINGTYPE, '''') AS POSTING_TYPE
                                , case when nvl(src.ISCORRECTION, 0) = 1 then ''Yes'' else ''No'' END AS IS_CORRECTION
                                , case when nvl(src.ISCREDIT, 0) = 1 then ''Yes'' else ''No'' END AS IS_CREDIT
                                , case when nvl(src.GENERALJOURNALENTRY_ACCOUNTINGDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.GENERALJOURNALENTRY_ACCOUNTINGDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.GENERALJOURNALENTRY_ACCOUNTINGDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.GENERALJOURNALENTRY_ACCOUNTINGDATE END AS ACCOUNTING_DATE
                                , case when nvl(src.GENERALJOURNALENTRY_ACKNOWLEDGEMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.GENERALJOURNALENTRY_ACKNOWLEDGEMENTDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.GENERALJOURNALENTRY_ACKNOWLEDGEMENTDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.GENERALJOURNALENTRY_ACKNOWLEDGEMENTDATE END AS ACKNOWLEDGEMENT_DATE
                                , case when nvl(date(src.CREATEDDATETIME), ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when date(src.CREATEDDATETIME) < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when date(src.CREATEDDATETIME) > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else date(src.CREATEDDATETIME) END AS CREATED_DATE
                                , case when nvl(GENERALJOURNALENTRY_DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when GENERALJOURNALENTRY_DOCUMENTDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when GENERALJOURNALENTRY_DOCUMENTDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else GENERALJOURNALENTRY_DOCUMENTDATE END AS DOCUMENT_DATE
                                , nvl(src.GENERALJOURNALENTRY_DOCUMENTNUMBER, '''') AS DOCUMENT_NUMBER
                                , nvl(src.LEDGERACCOUNT, '''') AS LEDGER_ACCOUNT
                                , nvl(src.GENERALJOURNALENTRY_SUBLEDGERVOUCHERDATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.GENERALJOURNALENTRY_JOURNALNUMBER, '''') AS JOURNAL_NUMBER
                                , nvl(src.GENERALJOURNALENTRY_SUBLEDGERVOUCHER, '''') AS VOUCHER
                                , nvl(src.QUANTITY, 0) AS QUANTITY
                                , nvl(src.ACCOUNTINGCURRENCYAMOUNT, 0) AS ACCOUNTING_CURRENCY_AMOUNT
                                , nvl(src.REPORTINGCURRENCYAMOUNT, 0) AS REPORTING_CURRENCY_AMOUNT
                                , nvl(src.TRANSACTIONCURRENCYAMOUNT, 0) AS TRANSACTION_CURRENCY_AMOUNT
                                , nvl(src.LEDGERJOURNALTABLE_JOURNALNAME, '''') AS JOURNAL_NAME
                                , case when nvl(src.LEDGERJOURNALTRANS_TXT, '''') != '''' then ''Yes''
									else ''No'' END AS JOURNAL_TEXT
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                on src.HK_SOURCE_NAME = tgt.SOURCE_NAME and src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_GENERAL_LEDGER_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_GENERAL_LEDGER_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_GENERAL_LEDGER_KEY
                            , src.SOURCE_NAME
                            , src.RECORD_ID
                            , case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.ACCOUNTING_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS ACCOUNTING_DATE_DIM_DATE_KEY
                            , src.ACCOUNTING_DATE_DIM_DATE_SNKEY
                            , case when src.ACKNOWLEDGEMENT_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                            , src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                            , case when src.CREATED_DATE = ''1950-01-01'' then -2 else nvl(d4.DIM_DATE_KEY, -1) END AS CREATED_DATE_DIM_DATE_KEY
                            , src.CREATED_DATE_DIM_DATE_SNKEY
                            , case when src.DOCUMENT_DATE = ''1950-01-01'' then -2 else nvl(d5.DIM_DATE_KEY, -1) END AS DOCUMENT_DATE_DIM_DATE_KEY
                            , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d6.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                            , src.DIM_CURRENCY_SNKEY
                            , case when src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY = -2 then -2 else nvl(d7.DIM_FINANCIAL_CALENDAR_PERIOD_KEY, -1) END AS DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                            , src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                            , case when src.DIM_LEDGER_SNKEY = -2 then -2 else nvl(d8.DIM_LEDGER_KEY, -1) END AS DIM_LEDGER_KEY
                            , src.DIM_LEDGER_SNKEY
                            , case when src.DIM_LEDGER_DIMENSION_SNKEY = -2 then -2 else nvl(d9.DIM_LEDGER_DIMENSION_KEY, -1) END AS DIM_LEDGER_DIMENSION_KEY
                            , src.DIM_LEDGER_DIMENSION_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d10.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_MAIN_ACCOUNT_SNKEY = -2 then -2 else nvl(d11.DIM_MAIN_ACCOUNT_KEY, -1) END AS DIM_MAIN_ACCOUNT_KEY
                            , src.DIM_MAIN_ACCOUNT_SNKEY
                            , case when src.DIM_REASON_SNKEY = -2 then -2 else nvl(d12.DIM_REASON_KEY, -1) END AS DIM_REASON_KEY
                            , src.DIM_REASON_SNKEY
                            , src.CURRENCY_CODE
                            , src.RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                            , src.RECORD_ID_LEDGER
                            , src.LEDGER_DIMENSION
                            , src.RECORD_ID_MAIN_ACCOUNT
                            , src.RECORD_ID_REASON
                            , src.JOURNAL_CATEGORY
                            , src.POSTING_TYPE
                            , src.IS_CORRECTION
                            , src.IS_CREDIT
                            , src.ACCOUNTING_DATE
                            , src.ACKNOWLEDGEMENT_DATE
                            , src.CREATED_DATE
                            , src.DOCUMENT_DATE
                            , src.DOCUMENT_NUMBER
                            , src.LEDGER_ACCOUNT
                            , src.LEGAL_ENTITY
                            , src.JOURNAL_NUMBER
                            , src.VOUCHER
                            , src.QUANTITY
                            , src.ACCOUNTING_CURRENCY_AMOUNT
                            , src.REPORTING_CURRENCY_AMOUNT
                            , src.TRANSACTION_CURRENCY_AMOUNT
                            , src.JOURNAL_NAME
                            , src.JOURNAL_TEXT
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.CURRENCY_CODE, ''~'', to_char(src.RECORD_ID_FINANCIAL_CALENDAR_PERIOD), ''~'', to_char(src.RECORD_ID_LEDGER), ''~'', src.LEDGER_DIMENSION, ''~'', to_char(src.RECORD_ID_MAIN_ACCOUNT), ''~'', to_char(src.RECORD_ID_REASON), ''~'', src.JOURNAL_CATEGORY, ''~'', src.POSTING_TYPE, ''~'', src.IS_CORRECTION, ''~'', src.IS_CREDIT, ''~'', to_char(src.ACCOUNTING_DATE, ''yyyymmdd''), ''~'', to_char(src.ACKNOWLEDGEMENT_DATE, ''yyyymmdd''), ''~'', to_char(src.CREATED_DATE, ''yyyymmdd''), ''~'', to_char(src.DOCUMENT_DATE, ''yyyymmdd''), ''~'', src.DOCUMENT_NUMBER, ''~'', src.LEDGER_ACCOUNT, ''~'', src.LEGAL_ENTITY, ''~'', src.JOURNAL_NUMBER, ''~'', src.VOUCHER, ''~'', to_char(src.QUANTITY), ''~'', to_char(src.ACCOUNTING_CURRENCY_AMOUNT), ''~'', to_char(src.REPORTING_CURRENCY_AMOUNT), ''~'', to_char(src.TRANSACTION_CURRENCY_AMOUNT), ''~'', src.JOURNAL_NAME, ''~'', src.JOURNAL_TEXT) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            FACT_GENERAL_LEDGER_KEY
                            , SOURCE_NAME
                            , RECORD_ID
                            , DIM_SOURCE_SYSTEM_KEY
                            , case when SOURCE_NAME = '''' then -2 else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , ACCOUNTING_DATE_DIM_DATE_KEY
                            , case when ACCOUNTING_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(ACCOUNTING_DATE, ''yyyymmdd'')) END AS ACCOUNTING_DATE_DIM_DATE_SNKEY
                            , ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                            , case when ACKNOWLEDGEMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(ACKNOWLEDGEMENT_DATE, ''yyyymmdd'')) END AS ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                            , CREATED_DATE_DIM_DATE_KEY
                            , case when CREATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(CREATED_DATE, ''yyyymmdd'')) END AS CREATED_DATE_DIM_DATE_SNKEY
                            , DOCUMENT_DATE_DIM_DATE_KEY
                            , case when DOCUMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
                            , DIM_CURRENCY_KEY
                            , case when nvl(CURRENCY_CODE, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                            , DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                            , case when nvl(RECORD_ID_FINANCIAL_CALENDAR_PERIOD, 0) = 0 then -2 else hash(SOURCE_NAME, ''~'', to_char(RECORD_ID_FINANCIAL_CALENDAR_PERIOD)) END AS DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                            , DIM_LEDGER_KEY
                            , case when nvl(RECORD_ID_LEDGER, 0) = 0 then -2 else hash(SOURCE_NAME, ''~'', to_char(RECORD_ID_LEDGER)) END AS DIM_LEDGER_SNKEY
                            , DIM_LEDGER_DIMENSION_KEY
                            , case when nvl(LEDGER_DIMENSION, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', LEDGER_DIMENSION) END AS DIM_LEDGER_DIMENSION_SNKEY
                            , DIM_LEGAL_ENTITY_KEY
                            , case when nvl(LEGAL_ENTITY, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , DIM_MAIN_ACCOUNT_KEY
                            , case when nvl(RECORD_ID_MAIN_ACCOUNT, 0) = 0 then -2 else hash(SOURCE_NAME, ''~'', to_char(RECORD_ID_MAIN_ACCOUNT)) END AS DIM_MAIN_ACCOUNT_SNKEY
                            , DIM_REASON_KEY
                            , case when nvl(RECORD_ID_REASON, 0) = 0 then -2 else hash(SOURCE_NAME, ''~'', to_char(RECORD_ID_REASON)) END AS DIM_REASON_SNKEY
                            , CURRENCY_CODE
                            , RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                            , RECORD_ID_LEDGER
                            , LEDGER_DIMENSION
                            , RECORD_ID_MAIN_ACCOUNT
                            , RECORD_ID_REASON
                            , JOURNAL_CATEGORY
                            , POSTING_TYPE
                            , IS_CORRECTION
                            , IS_CREDIT
                            , ACCOUNTING_DATE
                            , ACKNOWLEDGEMENT_DATE
                            , CREATED_DATE
                            , DOCUMENT_DATE
                            , DOCUMENT_NUMBER
                            , LEDGER_ACCOUNT
                            , LEGAL_ENTITY
                            , JOURNAL_NUMBER
                            , VOUCHER
                            , QUANTITY
                            , ACCOUNTING_CURRENCY_AMOUNT
                            , REPORTING_CURRENCY_AMOUNT
                            , TRANSACTION_CURRENCY_AMOUNT
                            , JOURNAL_NAME
                            , JOURNAL_TEXT
                            , HK_HASH_KEY
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ') src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.ACCOUNTING_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.CREATED_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d6 ON
                                src.DIM_CURRENCY_SNKEY = d6.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_FINANCIAL_CALENDAR_PERIOD d7 ON
                                src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY = d7.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER d8 ON
                                src.DIM_LEDGER_SNKEY = d8.DIM_LEDGER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d9 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d9.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d10 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d10.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MAIN_ACCOUNT d11 ON
                                src.DIM_MAIN_ACCOUNT_SNKEY = d11.DIM_MAIN_ACCOUNT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REASON d12 ON
                                src.DIM_REASON_SNKEY = d12.DIM_REASON_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_GENERAL_LEDGER_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_GENERAL_LEDGER

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_GENERAL_LEDGER_KEY = tgt.FACT_GENERAL_LEDGER_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_GENERAL_LEDGER_KEY = tgt.FACT_GENERAL_LEDGER_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.ACCOUNTING_DATE_DIM_DATE_KEY = src.ACCOUNTING_DATE_DIM_DATE_KEY
                                    , tgt.ACCOUNTING_DATE_DIM_DATE_SNKEY = src.ACCOUNTING_DATE_DIM_DATE_SNKEY
                                    , tgt.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY = src.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                                    , tgt.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY = src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.CREATED_DATE_DIM_DATE_KEY = src.CREATED_DATE_DIM_DATE_KEY
                                    , tgt.CREATED_DATE_DIM_DATE_SNKEY = src.CREATED_DATE_DIM_DATE_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_FINANCIAL_CALENDAR_PERIOD_KEY = src.DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                                    , tgt.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY = src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                                    , tgt.DIM_LEDGER_KEY = src.DIM_LEDGER_KEY
                                    , tgt.DIM_LEDGER_SNKEY = src.DIM_LEDGER_SNKEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_SNKEY = src.DIM_LEDGER_DIMENSION_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_MAIN_ACCOUNT_KEY = src.DIM_MAIN_ACCOUNT_KEY
                                    , tgt.DIM_MAIN_ACCOUNT_SNKEY = src.DIM_MAIN_ACCOUNT_SNKEY
                                    , tgt.DIM_REASON_KEY = src.DIM_REASON_KEY
                                    , tgt.DIM_REASON_SNKEY = src.DIM_REASON_SNKEY
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.RECORD_ID_FINANCIAL_CALENDAR_PERIOD = src.RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                                    , tgt.RECORD_ID_LEDGER = src.RECORD_ID_LEDGER
                                    , tgt.LEDGER_DIMENSION = src.LEDGER_DIMENSION
                                    , tgt.RECORD_ID_MAIN_ACCOUNT = src.RECORD_ID_MAIN_ACCOUNT
                                    , tgt.RECORD_ID_REASON = src.RECORD_ID_REASON
                                    , tgt.JOURNAL_CATEGORY = src.JOURNAL_CATEGORY
                                    , tgt.POSTING_TYPE = src.POSTING_TYPE
                                    , tgt.IS_CORRECTION = src.IS_CORRECTION
                                    , tgt.IS_CREDIT = src.IS_CREDIT
                                    , tgt.ACCOUNTING_DATE = src.ACCOUNTING_DATE
                                    , tgt.ACKNOWLEDGEMENT_DATE = src.ACKNOWLEDGEMENT_DATE
                                    , tgt.CREATED_DATE = src.CREATED_DATE
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.DOCUMENT_NUMBER = src.DOCUMENT_NUMBER
                                    , tgt.LEDGER_ACCOUNT = src.LEDGER_ACCOUNT
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.JOURNAL_NUMBER = src.JOURNAL_NUMBER
                                    , tgt.VOUCHER = src.VOUCHER
                                    , tgt.QUANTITY = src.QUANTITY
                                    , tgt.ACCOUNTING_CURRENCY_AMOUNT = src.ACCOUNTING_CURRENCY_AMOUNT
                                    , tgt.REPORTING_CURRENCY_AMOUNT = src.REPORTING_CURRENCY_AMOUNT
                                    , tgt.TRANSACTION_CURRENCY_AMOUNT = src.TRANSACTION_CURRENCY_AMOUNT
                                    , tgt.JOURNAL_NAME = src.JOURNAL_NAME
                                    , tgt.JOURNAL_TEXT = src.JOURNAL_TEXT
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                    FACT_GENERAL_LEDGER_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , DIM_SOURCE_SYSTEM_SNKEY
                                    , ACCOUNTING_DATE_DIM_DATE_KEY
                                    , ACCOUNTING_DATE_DIM_DATE_SNKEY
                                    , ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                                    , ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                                    , CREATED_DATE_DIM_DATE_KEY
                                    , CREATED_DATE_DIM_DATE_SNKEY
                                    , DOCUMENT_DATE_DIM_DATE_KEY
                                    , DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , DIM_CURRENCY_SNKEY
                                    , DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                                    , DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                                    , DIM_LEDGER_KEY
                                    , DIM_LEDGER_SNKEY
                                    , DIM_LEDGER_DIMENSION_KEY
                                    , DIM_LEDGER_DIMENSION_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , DIM_LEGAL_ENTITY_SNKEY
                                    , DIM_MAIN_ACCOUNT_KEY
                                    , DIM_MAIN_ACCOUNT_SNKEY
                                    , DIM_REASON_KEY
                                    , DIM_REASON_SNKEY
                                    , CURRENCY_CODE
                                    , RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                                    , RECORD_ID_LEDGER
                                    , LEDGER_DIMENSION
                                    , RECORD_ID_MAIN_ACCOUNT
                                    , RECORD_ID_REASON
                                    , JOURNAL_CATEGORY
                                    , POSTING_TYPE
                                    , IS_CORRECTION
                                    , IS_CREDIT
                                    , ACCOUNTING_DATE
                                    , ACKNOWLEDGEMENT_DATE
                                    , CREATED_DATE
                                    , DOCUMENT_DATE
                                    , DOCUMENT_NUMBER
                                    , LEDGER_ACCOUNT
                                    , LEGAL_ENTITY
                                    , JOURNAL_NUMBER
                                    , VOUCHER
                                    , QUANTITY
                                    , ACCOUNTING_CURRENCY_AMOUNT
                                    , REPORTING_CURRENCY_AMOUNT
                                    , TRANSACTION_CURRENCY_AMOUNT
                                    , JOURNAL_NAME
                                    , JOURNAL_TEXT
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                    src.FACT_GENERAL_LEDGER_KEY
                                    , src.SOURCE_NAME
                                    , src.RECORD_ID
                                    , src.DIM_SOURCE_SYSTEM_KEY
                                    , src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.ACCOUNTING_DATE_DIM_DATE_KEY
                                    , src.ACCOUNTING_DATE_DIM_DATE_SNKEY
                                    , src.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                                    , src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY
                                    , src.CREATED_DATE_DIM_DATE_KEY
                                    , src.CREATED_DATE_DIM_DATE_SNKEY
                                    , src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , src.DIM_CURRENCY_KEY
                                    , src.DIM_CURRENCY_SNKEY
                                    , src.DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                                    , src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                                    , src.DIM_LEDGER_KEY
                                    , src.DIM_LEDGER_SNKEY
                                    , src.DIM_LEDGER_DIMENSION_KEY
                                    , src.DIM_LEDGER_DIMENSION_SNKEY
                                    , src.DIM_LEGAL_ENTITY_KEY
                                    , src.DIM_LEGAL_ENTITY_SNKEY
                                    , src.DIM_MAIN_ACCOUNT_KEY
                                    , src.DIM_MAIN_ACCOUNT_SNKEY
                                    , src.DIM_REASON_KEY
                                    , src.DIM_REASON_SNKEY
                                    , src.CURRENCY_CODE
                                    , src.RECORD_ID_FINANCIAL_CALENDAR_PERIOD
                                    , src.RECORD_ID_LEDGER
                                    , src.LEDGER_DIMENSION
                                    , src.RECORD_ID_MAIN_ACCOUNT
                                    , src.RECORD_ID_REASON
                                    , src.JOURNAL_CATEGORY
                                    , src.POSTING_TYPE
                                    , src.IS_CORRECTION
                                    , src.IS_CREDIT
                                    , src.ACCOUNTING_DATE
                                    , src.ACKNOWLEDGEMENT_DATE
                                    , src.CREATED_DATE
                                    , src.DOCUMENT_DATE
                                    , src.DOCUMENT_NUMBER
                                    , src.LEDGER_ACCOUNT
                                    , src.LEGAL_ENTITY
                                    , src.JOURNAL_NUMBER
                                    , src.VOUCHER
                                    , src.QUANTITY
                                    , src.ACCOUNTING_CURRENCY_AMOUNT
                                    , src.REPORTING_CURRENCY_AMOUNT
                                    , src.TRANSACTION_CURRENCY_AMOUNT
                                    , src.JOURNAL_NAME
                                    , src.JOURNAL_TEXT
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
            a.FACT_GENERAL_LEDGER_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_ACCOUNTING_DATE_DIM_DATE_KEY
            , a.NEW_ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
            , a.NEW_CREATED_DATE_DIM_DATE_KEY
            , a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
            , a.NEW_DIM_CURRENCY_KEY
            , a.NEW_DIM_FINANCIAL_CALENDAR_PERIOD_KEY
            , a.NEW_DIM_LEDGER_KEY
            , a.NEW_DIM_LEDGER_DIMENSION_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_MAIN_ACCOUNT_KEY
            , a.NEW_DIM_REASON_KEY
        from (
            select 
                src.FACT_GENERAL_LEDGER_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.ACCOUNTING_DATE_DIM_DATE_KEY
                , src.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                , src.CREATED_DATE_DIM_DATE_KEY
                , src.DOCUMENT_DATE_DIM_DATE_KEY
                , src.DIM_CURRENCY_KEY
                , src.DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                , src.DIM_LEDGER_KEY
                , src.DIM_LEDGER_DIMENSION_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_MAIN_ACCOUNT_KEY
                , src.DIM_REASON_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_ACCOUNTING_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_DATE_KEY, -1) AS NEW_CREATED_DATE_DIM_DATE_KEY
                , nvl(d5.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
                , nvl(d6.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                , nvl(d7.DIM_FINANCIAL_CALENDAR_PERIOD_KEY, -1) AS NEW_DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                , nvl(d8.DIM_LEDGER_KEY, -1) AS NEW_DIM_LEDGER_KEY
                , nvl(d9.DIM_LEDGER_DIMENSION_KEY, -1) AS NEW_DIM_LEDGER_DIMENSION_KEY
                , nvl(d10.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d11.DIM_MAIN_ACCOUNT_KEY, -1) AS NEW_DIM_MAIN_ACCOUNT_KEY
                , nvl(d12.DIM_REASON_KEY, -1) AS NEW_DIM_REASON_KEY
            from ' || :tgt_db || '.global.FACT_GENERAL_LEDGER src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.ACCOUNTING_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.CREATED_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d6 ON
                                src.DIM_CURRENCY_SNKEY = d6.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_FINANCIAL_CALENDAR_PERIOD d7 ON
                                src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY = d7.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER d8 ON
                                src.DIM_LEDGER_SNKEY = d8.DIM_LEDGER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d9 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d9.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d10 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d10.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MAIN_ACCOUNT d11 ON
                                src.DIM_MAIN_ACCOUNT_SNKEY = d11.DIM_MAIN_ACCOUNT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REASON d12 ON
                                src.DIM_REASON_SNKEY = d12.DIM_REASON_SNKEY
                where 1=1
                and (
                    (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                    or (src.ACCOUNTING_DATE_DIM_DATE_KEY = -1 and src.ACCOUNTING_DATE_DIM_DATE_SNKEY != -1)
                    or (src.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY = -1 and src.ACKNOWLEDGEMENT_DATE_DIM_DATE_SNKEY != -1)
                    or (src.CREATED_DATE_DIM_DATE_KEY = -1 and src.CREATED_DATE_DIM_DATE_SNKEY != -1)
                    or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
                    or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
                    or (src.DIM_FINANCIAL_CALENDAR_PERIOD_KEY = -1 and src.DIM_FINANCIAL_CALENDAR_PERIOD_SNKEY != -1)
                    or (src.DIM_LEDGER_KEY = -1 and src.DIM_LEDGER_SNKEY != -1)
                    or (src.DIM_LEDGER_DIMENSION_KEY = -1 and src.DIM_LEDGER_DIMENSION_SNKEY != -1)
                    or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                    or (src.DIM_MAIN_ACCOUNT_KEY = -1 and src.DIM_MAIN_ACCOUNT_SNKEY != -1)
                    or (src.DIM_REASON_KEY = -1 and src.DIM_REASON_SNKEY != -1)
                    )
                ) a
            where 1=1
            and (
            (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
            or (a.ACCOUNTING_DATE_DIM_DATE_KEY != a.NEW_ACCOUNTING_DATE_DIM_DATE_KEY)
            or (a.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY != a.NEW_ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY)
            or (a.CREATED_DATE_DIM_DATE_KEY != a.NEW_CREATED_DATE_DIM_DATE_KEY)
            or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
            or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
            or (a.DIM_FINANCIAL_CALENDAR_PERIOD_KEY != a.NEW_DIM_FINANCIAL_CALENDAR_PERIOD_KEY)
            or (a.DIM_LEDGER_KEY != a.NEW_DIM_LEDGER_KEY)
            or (a.DIM_LEDGER_DIMENSION_KEY != a.NEW_DIM_LEDGER_DIMENSION_KEY)
            or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
            or (a.DIM_MAIN_ACCOUNT_KEY != a.NEW_DIM_MAIN_ACCOUNT_KEY)
            or (a.DIM_REASON_KEY != a.NEW_DIM_REASON_KEY)
                )
            ;';
            EXECUTE IMMEDIATE :late_dim_select;

        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_GENERAL_LEDGER_KEY = tgt.FACT_GENERAL_LEDGER_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.ACCOUNTING_DATE_DIM_DATE_KEY = src.NEW_ACCOUNTING_DATE_DIM_DATE_KEY
                                    , tgt.ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY = src.NEW_ACKNOWLEDGEMENT_DATE_DIM_DATE_KEY
                                    , tgt.CREATED_DATE_DIM_DATE_KEY = src.NEW_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_FINANCIAL_CALENDAR_PERIOD_KEY = src.NEW_DIM_FINANCIAL_CALENDAR_PERIOD_KEY
                                    , tgt.DIM_LEDGER_KEY = src.NEW_DIM_LEDGER_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.NEW_DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_MAIN_ACCOUNT_KEY = src.NEW_DIM_MAIN_ACCOUNT_KEY
                                    , tgt.DIM_REASON_KEY = src.NEW_DIM_REASON_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);
    
        --Logging stored procedure completed
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '11';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;