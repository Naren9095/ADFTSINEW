/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_INVENTORY_TRANSACTIONS
    CREATED BY     : Bharath
    CREATED ON     : 07/07/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_INVENTORY_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_INVENTORY_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_INVENTORY_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'INVENTTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_INVENTORY_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_INVENTORY_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
        || ' as
                            select
                                0 AS FACT_INVENTORY_TRANSACTIONS_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS DATE_CLOSED_DIM_DATE_KEY
                                , 0 AS DATE_CLOSED_DIM_DATE_SNKEY
                                , 0 AS DATE_EXPECTED_DIM_DATE_KEY
                                , 0 AS DATE_EXPECTED_DIM_DATE_SNKEY
                                , 0 AS DATE_FINANCIAL_DIM_DATE_KEY
                                , 0 AS DATE_FINANCIAL_DIM_DATE_SNKEY
                                , 0 AS DATE_PHYSICAL_DIM_DATE_KEY
                                , 0 AS DATE_PHYSICAL_DIM_DATE_SNKEY
                                , 0 AS INVENTORY_DATE_DIM_DATE_KEY
                                , 0 AS INVENTORY_DATE_DIM_DATE_SNKEY
                                , 0 AS SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                , 0 AS SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                , 0 AS SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                , 0 AS SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                , 0 AS STATUS_DATE_DIM_DATE_KEY
                                , 0 AS STATUS_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_INVENTORY_KEY
                                , 0 AS DIM_INVENTORY_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(src.INVENTDIMID, '''') AS INVENTORY_DIMENSION_ID
                                , nvl(src.ITEMID, '''') AS ITEM_ID
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_FINANCIALSTATUS, '''') AS FINANCIAL_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_REFERENCECATEGORY, '''') AS REFERENCE_CATEGORY
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_STATUSISSUE, '''') AS STATUS_ISSUE
                                , nvl(src.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_STATUSRECEIPT, '''') AS STATUS_RECEIPT
                                , case when nvl(src.DATECLOSED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATECLOSED < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATECLOSED > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATECLOSED END AS DATE_CLOSED
                                , case when nvl(src.DATEEXPECTED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATEEXPECTED < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATEEXPECTED > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATEEXPECTED END AS DATE_EXPECTED
                                , case when nvl(src.DATEFINANCIAL, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATEFINANCIAL < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATEFINANCIAL > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATEFINANCIAL END AS DATE_FINANCIAL
                                , case when nvl(src.DATEPHYSICAL, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATEPHYSICAL < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATEPHYSICAL > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATEPHYSICAL END AS DATE_PHYSICAL
                                , case when nvl(src.DATEINVENT, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATEINVENT < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATEINVENT > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATEINVENT END AS INVENTORY_DATE
                                , case when nvl(src.SHIPPINGDATECONFIRMED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.SHIPPINGDATECONFIRMED < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.SHIPPINGDATECONFIRMED > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.SHIPPINGDATECONFIRMED END AS SHIPPING_DATE_CONFIRMED
                                , case when nvl(src.SHIPPINGDATEREQUESTED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.SHIPPINGDATEREQUESTED < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.SHIPPINGDATEREQUESTED > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.SHIPPINGDATEREQUESTED END AS SHIPPING_DATE_REQUESTED
                                , case when nvl(src.DATESTATUS, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
                                        when src.DATESTATUS < dd1.MIN_DATE_VALUE then ''1951-12-31''
                                        when src.DATESTATUS > dd1.MAX_DATE_VALUE then ''9951-12-31''
                                    else src.DATESTATUS END AS STATUS_DATE
                                , nvl(src.INVENTTRANSORIGIN_INVENTTRANSID, '''') AS INVENTORY_TRANSACTION_ID
                                , nvl(src.INVOICEID, '''') AS INVOICE_ID
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.PACKINGSLIPID, '''') AS PACKING_SLIP_ID
                                , nvl(src.PICKINGROUTEID, '''') AS PICKING_ROUTE_ID
                                , nvl(src.INVENTTRANSORIGIN_REFERENCEID, '''') AS REFERENCE_ID
                                , nvl(src.VOUCHER, '''') AS VOUCHER
                                , nvl(src.VOUCHERPHYSICAL, '''') AS VOUCHER_PHYSICAL
                                , nvl(src.QTY, 0) AS QUANTITY
                                , nvl(src.QTYSETTLED, 0) AS QUANTITY_SETTLED
                                , nvl(src.COSTAMOUNTADJUSTMENT, 0) AS COST_AMOUNT_ADJUSTMENT
                                , nvl(src.COSTAMOUNTOPERATIONS, 0) AS COST_AMOUNT_OPERATIONS
                                , nvl(src.COSTAMOUNTPHYSICAL, 0) AS COST_AMOUNT_PHYSICAL
                                , nvl(src.COSTAMOUNTPOSTED, 0) AS COST_AMOUNT_POSTED
                                , nvl(src.COSTAMOUNTSETTLED, 0) AS COST_AMOUNT_SETTLED
                                , nvl(src.COSTAMOUNTSTD, 0) AS COST_AMOUNT_STANDARD
                                , '''' AS INVENTORY_SITE_ID
                                , '''' AS INVENTORY_WAREHOUSE_ID
                                , cast(to_char(src.DATEPHYSICAL, ''yyyymm'') as number) AS DATE_PHYSICAL_ID
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src
							left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt on
								src.HK_SOURCE_NAME = tgt.SOURCE_NAME and
								src.RECID = tgt.RECORD_ID
							inner join (select min(date_value) as MIN_DATE_VALUE
											, max(date_value) as MAX_DATE_VALUE
										from ' || :tgt_db || '.' || :tgt_schema || '.DIM_DATE 
										where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31'')) dd1 on
								1=1
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') 
                                                and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_INVENTORY_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_INVENTORY_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
                            SELECT
                                hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_INVENTORY_TRANSACTIONS_KEY
                                , src.SOURCE_NAME
                                , src.RECORD_ID
                                , case when src.SOURCE_NAME = '''' then -2
                                    else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                                , src.DIM_SOURCE_SYSTEM_SNKEY
                                , case when src.DATE_CLOSED = ''1950-01-01'' then -2
                                    else nvl(d2.DIM_DATE_KEY, -1) END AS DATE_CLOSED_DIM_DATE_KEY
                                , src.DATE_CLOSED_DIM_DATE_SNKEY
                                , case when src.DATE_EXPECTED = ''1950-01-01'' then -2
                                    else nvl(d3.DIM_DATE_KEY, -1) END AS DATE_EXPECTED_DIM_DATE_KEY
                                , src.DATE_EXPECTED_DIM_DATE_SNKEY
                                , case when src.DATE_FINANCIAL = ''1950-01-01'' then -2
                                    else nvl(d4.DIM_DATE_KEY, -1) END AS DATE_FINANCIAL_DIM_DATE_KEY
                                , src.DATE_FINANCIAL_DIM_DATE_SNKEY
                                , case when src.DATE_PHYSICAL = ''1950-01-01'' then -2
                                    else nvl(d5.DIM_DATE_KEY, -1) END AS DATE_PHYSICAL_DIM_DATE_KEY
                                , src.DATE_PHYSICAL_DIM_DATE_SNKEY
                                , case when src.INVENTORY_DATE = ''1950-01-01'' then -2
                                    else nvl(d6.DIM_DATE_KEY, -1) END AS INVENTORY_DATE_DIM_DATE_KEY
                                , src.INVENTORY_DATE_DIM_DATE_SNKEY
                                , case when src.SHIPPING_DATE_CONFIRMED = ''1950-01-01'' then -2
                                    else nvl(d7.DIM_DATE_KEY, -1) END AS SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                , src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                , case when src.SHIPPING_DATE_REQUESTED = ''1950-01-01'' then -2
                                    else nvl(d8.DIM_DATE_KEY, -1) END AS SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                , src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                , case when src.STATUS_DATE = ''1950-01-01'' then -2
                                    else nvl(d9.DIM_DATE_KEY, -1) END AS STATUS_DATE_DIM_DATE_KEY
                                , src.STATUS_DATE_DIM_DATE_SNKEY
                                , case when src.DIM_CURRENCY_SNKEY = -2 then -2
                                    else nvl(d10.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                                , src.DIM_CURRENCY_SNKEY
                                , case when src.DIM_INVENTORY_SNKEY = -2 then -2
                                    else nvl(d11.DIM_INVENTORY_KEY, -1) END AS DIM_INVENTORY_KEY
                                , src.DIM_INVENTORY_SNKEY
                                , case when src.DIM_ITEM_SNKEY = -2 then -2
                                    else nvl(d12.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
                                , src.DIM_ITEM_SNKEY
                                , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2
                                    else nvl(d13.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                                , src.DIM_LEGAL_ENTITY_SNKEY
                                , src.CURRENCY_CODE
                                , src.INVENTORY_DIMENSION_ID
                                , src.ITEM_ID
                                , src.FINANCIAL_STATUS
                                , src.REFERENCE_CATEGORY
                                , src.STATUS_ISSUE
                                , src.STATUS_RECEIPT
                                , src.DATE_CLOSED
                                , src.DATE_EXPECTED
                                , src.DATE_FINANCIAL
                                , src.DATE_PHYSICAL
                                , src.INVENTORY_DATE
                                , src.SHIPPING_DATE_CONFIRMED
                                , src.SHIPPING_DATE_REQUESTED
                                , src.STATUS_DATE
                                , src.INVENTORY_TRANSACTION_ID
                                , src.INVOICE_ID
                                , src.LEGAL_ENTITY
                                , src.PACKING_SLIP_ID
                                , src.PICKING_ROUTE_ID
                                , src.REFERENCE_ID
                                , src.VOUCHER
                                , src.VOUCHER_PHYSICAL
                                , src.QUANTITY
                                , src.QUANTITY_SETTLED
                                , src.COST_AMOUNT_ADJUSTMENT
                                , src.COST_AMOUNT_OPERATIONS
                                , src.COST_AMOUNT_PHYSICAL
                                , src.COST_AMOUNT_POSTED
                                , src.COST_AMOUNT_SETTLED
                                , src.COST_AMOUNT_STANDARD
                                , src.INVENTORY_SITE_ID
                                , src.INVENTORY_WAREHOUSE_ID
                                , src.DATE_PHYSICAL_ID
                                , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.CURRENCY_CODE, ''~'', src.INVENTORY_DIMENSION_ID, ''~'', src.ITEM_ID, ''~'', src.FINANCIAL_STATUS, ''~'', src.REFERENCE_CATEGORY, ''~'', src.STATUS_ISSUE, ''~'', src.STATUS_RECEIPT, ''~'', to_char(src.DATE_CLOSED, ''yyyymmdd''), ''~'', to_char(src.DATE_EXPECTED, ''yyyymmdd''), ''~'', to_char(src.DATE_FINANCIAL, ''yyyymmdd''), ''~'', to_char(src.DATE_PHYSICAL, ''yyyymmdd''), ''~'', to_char(src.INVENTORY_DATE, ''yyyymmdd''), ''~'', to_char(src.SHIPPING_DATE_CONFIRMED, ''yyyymmdd''), ''~'', to_char(src.SHIPPING_DATE_REQUESTED, ''yyyymmdd''), ''~'', to_char(src.STATUS_DATE, ''yyyymmdd''), ''~'', src.INVENTORY_TRANSACTION_ID, ''~'', src.INVOICE_ID, ''~'', src.LEGAL_ENTITY, ''~'', src.PACKING_SLIP_ID, ''~'', src.PICKING_ROUTE_ID, ''~'', src.REFERENCE_ID, ''~'', src.VOUCHER, ''~'', src.VOUCHER_PHYSICAL, ''~'', to_char(src.QUANTITY), ''~'', to_char(src.QUANTITY_SETTLED), ''~'', to_char(src.COST_AMOUNT_ADJUSTMENT), ''~'', to_char(src.COST_AMOUNT_OPERATIONS), ''~'', to_char(src.COST_AMOUNT_PHYSICAL), ''~'', to_char(src.COST_AMOUNT_POSTED), ''~'', to_char(src.COST_AMOUNT_SETTLED), ''~'', to_char(src.COST_AMOUNT_STANDARD), ''~'', src.INVENTORY_SITE_ID, ''~'', src.INVENTORY_WAREHOUSE_ID, ''~'', to_char(src.DATE_PHYSICAL_ID)) AS SRC_HK_HASH_KEY
                                , src.HK_SOURCE_NAME
                                , src.HK_SOFT_DELETE_FLAG
                                , src.HK_SOURCE_CREATED_TIMESTAMP
                                , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , src.HK_CREATED_JOB_RUN_ID
                                , src.HK_LAST_UPDATED_JOB_RUN_ID
                                , src.HK_CREATED_TIMESTAMP
                                , src.HK_LAST_UPDATED_TIMESTAMP
                                , src.HK_WAREHOUSE_ID
                                , CASE 
                                    WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                    WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                    ELSE ''DROP''
                                END AS DML_IND
                                , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (
                                SELECT 
                                    FACT_INVENTORY_TRANSACTIONS_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , case when SOURCE_NAME = '''' then -2
                                        else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                                    , DATE_CLOSED_DIM_DATE_KEY
                                    , case when DATE_CLOSED = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DATE_CLOSED, ''yyyymmdd'')) END AS DATE_CLOSED_DIM_DATE_SNKEY
                                    , DATE_EXPECTED_DIM_DATE_KEY
                                    , case when DATE_EXPECTED = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DATE_EXPECTED, ''yyyymmdd'')) END AS DATE_EXPECTED_DIM_DATE_SNKEY
                                    , DATE_FINANCIAL_DIM_DATE_KEY
                                    , case when DATE_FINANCIAL = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DATE_FINANCIAL, ''yyyymmdd'')) END AS DATE_FINANCIAL_DIM_DATE_SNKEY
                                    , DATE_PHYSICAL_DIM_DATE_KEY
                                    , case when DATE_PHYSICAL = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(DATE_PHYSICAL, ''yyyymmdd'')) END AS DATE_PHYSICAL_DIM_DATE_SNKEY
                                    , INVENTORY_DATE_DIM_DATE_KEY
                                    , case when INVENTORY_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(INVENTORY_DATE, ''yyyymmdd'')) END AS INVENTORY_DATE_DIM_DATE_SNKEY
                                    , SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                    , case when SHIPPING_DATE_CONFIRMED = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(SHIPPING_DATE_CONFIRMED, ''yyyymmdd'')) END AS SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                    , SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , case when SHIPPING_DATE_REQUESTED = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(SHIPPING_DATE_REQUESTED, ''yyyymmdd'')) END AS SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , STATUS_DATE_DIM_DATE_KEY
                                    , case when STATUS_DATE = ''1950-01-01'' then -2
                                        else hash('''', ''~'', to_char(STATUS_DATE, ''yyyymmdd'')) END AS STATUS_DATE_DIM_DATE_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , case when nvl(CURRENCY_CODE, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                                    , DIM_INVENTORY_KEY
                                    , case when nvl(LEGAL_ENTITY, '''') = '''' or nvl(INVENTORY_DIMENSION_ID, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', INVENTORY_DIMENSION_ID) END AS DIM_INVENTORY_SNKEY
                                    , DIM_ITEM_KEY
                                    , case when nvl(LEGAL_ENTITY, '''') = '''' or nvl(ITEM_ID, '''') = '''' then -2
                                        else hash('''', ''~'', LEGAL_ENTITY, ''~'', ITEM_ID) END AS DIM_ITEM_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , case when nvl(LEGAL_ENTITY, '''') = '''' then -2
                                        else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                                    , CURRENCY_CODE
                                    , INVENTORY_DIMENSION_ID
                                    , ITEM_ID
                                    , FINANCIAL_STATUS
                                    , REFERENCE_CATEGORY
                                    , STATUS_ISSUE
                                    , STATUS_RECEIPT
                                    , DATE_CLOSED
                                    , DATE_EXPECTED
                                    , DATE_FINANCIAL
                                    , DATE_PHYSICAL
                                    , INVENTORY_DATE
                                    , SHIPPING_DATE_CONFIRMED
                                    , SHIPPING_DATE_REQUESTED
                                    , STATUS_DATE
                                    , INVENTORY_TRANSACTION_ID
                                    , INVOICE_ID
                                    , LEGAL_ENTITY
                                    , PACKING_SLIP_ID
                                    , PICKING_ROUTE_ID
                                    , REFERENCE_ID
                                    , VOUCHER
                                    , VOUCHER_PHYSICAL
                                    , QUANTITY
                                    , QUANTITY_SETTLED
                                    , COST_AMOUNT_ADJUSTMENT
                                    , COST_AMOUNT_OPERATIONS
                                    , COST_AMOUNT_PHYSICAL
                                    , COST_AMOUNT_POSTED
                                    , COST_AMOUNT_SETTLED
                                    , COST_AMOUNT_STANDARD
                                    , INVENTORY_SITE_ID
                                    , INVENTORY_WAREHOUSE_ID
                                    , DATE_PHYSICAL_ID
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                    , TGT_HK_HASH_KEY
                                FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                                || ') src 
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                    src.DATE_CLOSED_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                    src.DATE_EXPECTED_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                    src.DATE_FINANCIAL_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                    src.DATE_PHYSICAL_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                                    src.INVENTORY_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                                    src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d8 ON
                                    src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = d8.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d9 ON
                                    src.STATUS_DATE_DIM_DATE_SNKEY = d9.DIM_DATE_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d10 ON
                                    src.DIM_CURRENCY_SNKEY = d10.DIM_CURRENCY_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d11 ON
                                    src.DIM_INVENTORY_SNKEY = d11.DIM_INVENTORY_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d12 ON
                                    src.DIM_ITEM_SNKEY = d12.DIM_ITEM_SNKEY
                                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d13 ON
                                    src.DIM_LEGAL_ENTITY_SNKEY = d13.DIM_LEGAL_ENTITY_SNKEY
                                QUALIFY PK_ROW_NUMBER = 1 ';
    
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

    /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_INVENTORY_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_INVENTORY_TRANSACTIONS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_INVENTORY_TRANSACTIONS_KEY = tgt.FACT_INVENTORY_TRANSACTIONS_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_INVENTORY_TRANSACTIONS_KEY = tgt.FACT_INVENTORY_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.DATE_CLOSED_DIM_DATE_KEY = src.DATE_CLOSED_DIM_DATE_KEY
                                    , tgt.DATE_CLOSED_DIM_DATE_SNKEY = src.DATE_CLOSED_DIM_DATE_SNKEY
                                    , tgt.DATE_EXPECTED_DIM_DATE_KEY = src.DATE_EXPECTED_DIM_DATE_KEY
                                    , tgt.DATE_EXPECTED_DIM_DATE_SNKEY = src.DATE_EXPECTED_DIM_DATE_SNKEY
                                    , tgt.DATE_FINANCIAL_DIM_DATE_KEY = src.DATE_FINANCIAL_DIM_DATE_KEY
                                    , tgt.DATE_FINANCIAL_DIM_DATE_SNKEY = src.DATE_FINANCIAL_DIM_DATE_SNKEY
                                    , tgt.DATE_PHYSICAL_DIM_DATE_KEY = src.DATE_PHYSICAL_DIM_DATE_KEY
                                    , tgt.DATE_PHYSICAL_DIM_DATE_SNKEY = src.DATE_PHYSICAL_DIM_DATE_SNKEY
                                    , tgt.INVENTORY_DATE_DIM_DATE_KEY = src.INVENTORY_DATE_DIM_DATE_KEY
                                    , tgt.INVENTORY_DATE_DIM_DATE_SNKEY = src.INVENTORY_DATE_DIM_DATE_SNKEY
                                    , tgt.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY = src.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                    , tgt.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY = src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                    , tgt.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = src.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , tgt.STATUS_DATE_DIM_DATE_KEY = src.STATUS_DATE_DIM_DATE_KEY
                                    , tgt.STATUS_DATE_DIM_DATE_SNKEY = src.STATUS_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_INVENTORY_KEY = src.DIM_INVENTORY_KEY
                                    , tgt.DIM_INVENTORY_SNKEY = src.DIM_INVENTORY_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.INVENTORY_DIMENSION_ID = src.INVENTORY_DIMENSION_ID
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.FINANCIAL_STATUS = src.FINANCIAL_STATUS
                                    , tgt.REFERENCE_CATEGORY = src.REFERENCE_CATEGORY
                                    , tgt.STATUS_ISSUE = src.STATUS_ISSUE
                                    , tgt.STATUS_RECEIPT = src.STATUS_RECEIPT
                                    , tgt.DATE_CLOSED = src.DATE_CLOSED
                                    , tgt.DATE_EXPECTED = src.DATE_EXPECTED
                                    , tgt.DATE_FINANCIAL = src.DATE_FINANCIAL
                                    , tgt.DATE_PHYSICAL = src.DATE_PHYSICAL
                                    , tgt.INVENTORY_DATE = src.INVENTORY_DATE
                                    , tgt.SHIPPING_DATE_CONFIRMED = src.SHIPPING_DATE_CONFIRMED
                                    , tgt.SHIPPING_DATE_REQUESTED = src.SHIPPING_DATE_REQUESTED
                                    , tgt.STATUS_DATE = src.STATUS_DATE
                                    , tgt.INVENTORY_TRANSACTION_ID = src.INVENTORY_TRANSACTION_ID
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.PACKING_SLIP_ID = src.PACKING_SLIP_ID
                                    , tgt.PICKING_ROUTE_ID = src.PICKING_ROUTE_ID
                                    , tgt.REFERENCE_ID = src.REFERENCE_ID
                                    , tgt.VOUCHER = src.VOUCHER
                                    , tgt.VOUCHER_PHYSICAL = src.VOUCHER_PHYSICAL
                                    , tgt.QUANTITY = src.QUANTITY
                                    , tgt.QUANTITY_SETTLED = src.QUANTITY_SETTLED
                                    , tgt.COST_AMOUNT_ADJUSTMENT = src.COST_AMOUNT_ADJUSTMENT
                                    , tgt.COST_AMOUNT_OPERATIONS = src.COST_AMOUNT_OPERATIONS
                                    , tgt.COST_AMOUNT_PHYSICAL = src.COST_AMOUNT_PHYSICAL
                                    , tgt.COST_AMOUNT_POSTED = src.COST_AMOUNT_POSTED
                                    , tgt.COST_AMOUNT_SETTLED = src.COST_AMOUNT_SETTLED
                                    , tgt.COST_AMOUNT_STANDARD = src.COST_AMOUNT_STANDARD
                                    , tgt.INVENTORY_SITE_ID = src.INVENTORY_SITE_ID
                                    , tgt.INVENTORY_WAREHOUSE_ID = src.INVENTORY_WAREHOUSE_ID
                                    , tgt.DATE_PHYSICAL_ID = src.DATE_PHYSICAL_ID
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                    FACT_INVENTORY_TRANSACTIONS_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , DIM_SOURCE_SYSTEM_SNKEY
                                    , DATE_CLOSED_DIM_DATE_KEY
                                    , DATE_CLOSED_DIM_DATE_SNKEY
                                    , DATE_EXPECTED_DIM_DATE_KEY
                                    , DATE_EXPECTED_DIM_DATE_SNKEY
                                    , DATE_FINANCIAL_DIM_DATE_KEY
                                    , DATE_FINANCIAL_DIM_DATE_SNKEY
                                    , DATE_PHYSICAL_DIM_DATE_KEY
                                    , DATE_PHYSICAL_DIM_DATE_SNKEY
                                    , INVENTORY_DATE_DIM_DATE_KEY
                                    , INVENTORY_DATE_DIM_DATE_SNKEY
                                    , SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                    , SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                    , SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , STATUS_DATE_DIM_DATE_KEY
                                    , STATUS_DATE_DIM_DATE_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , DIM_CURRENCY_SNKEY
                                    , DIM_INVENTORY_KEY
                                    , DIM_INVENTORY_SNKEY
                                    , DIM_ITEM_KEY
                                    , DIM_ITEM_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , DIM_LEGAL_ENTITY_SNKEY
                                    , CURRENCY_CODE
                                    , INVENTORY_DIMENSION_ID
                                    , ITEM_ID
                                    , FINANCIAL_STATUS
                                    , REFERENCE_CATEGORY
                                    , STATUS_ISSUE
                                    , STATUS_RECEIPT
                                    , DATE_CLOSED
                                    , DATE_EXPECTED
                                    , DATE_FINANCIAL
                                    , DATE_PHYSICAL
                                    , INVENTORY_DATE
                                    , SHIPPING_DATE_CONFIRMED
                                    , SHIPPING_DATE_REQUESTED
                                    , STATUS_DATE
                                    , INVENTORY_TRANSACTION_ID
                                    , INVOICE_ID
                                    , LEGAL_ENTITY
                                    , PACKING_SLIP_ID
                                    , PICKING_ROUTE_ID
                                    , REFERENCE_ID
                                    , VOUCHER
                                    , VOUCHER_PHYSICAL
                                    , QUANTITY
                                    , QUANTITY_SETTLED
                                    , COST_AMOUNT_ADJUSTMENT
                                    , COST_AMOUNT_OPERATIONS
                                    , COST_AMOUNT_PHYSICAL
                                    , COST_AMOUNT_POSTED
                                    , COST_AMOUNT_SETTLED
                                    , COST_AMOUNT_STANDARD
                                    , INVENTORY_SITE_ID
                                    , INVENTORY_WAREHOUSE_ID
                                    , DATE_PHYSICAL_ID
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                                VALUES
                                (
                                    src.FACT_INVENTORY_TRANSACTIONS_KEY
                                    , src.SOURCE_NAME
                                    , src.RECORD_ID
                                    , src.DIM_SOURCE_SYSTEM_KEY
                                    , src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.DATE_CLOSED_DIM_DATE_KEY
                                    , src.DATE_CLOSED_DIM_DATE_SNKEY
                                    , src.DATE_EXPECTED_DIM_DATE_KEY
                                    , src.DATE_EXPECTED_DIM_DATE_SNKEY
                                    , src.DATE_FINANCIAL_DIM_DATE_KEY
                                    , src.DATE_FINANCIAL_DIM_DATE_SNKEY
                                    , src.DATE_PHYSICAL_DIM_DATE_KEY
                                    , src.DATE_PHYSICAL_DIM_DATE_SNKEY
                                    , src.INVENTORY_DATE_DIM_DATE_KEY
                                    , src.INVENTORY_DATE_DIM_DATE_SNKEY
                                    , src.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                    , src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY
                                    , src.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY
                                    , src.STATUS_DATE_DIM_DATE_KEY
                                    , src.STATUS_DATE_DIM_DATE_SNKEY
                                    , src.DIM_CURRENCY_KEY
                                    , src.DIM_CURRENCY_SNKEY
                                    , src.DIM_INVENTORY_KEY
                                    , src.DIM_INVENTORY_SNKEY
                                    , src.DIM_ITEM_KEY
                                    , src.DIM_ITEM_SNKEY
                                    , src.DIM_LEGAL_ENTITY_KEY
                                    , src.DIM_LEGAL_ENTITY_SNKEY
                                    , src.CURRENCY_CODE
                                    , src.INVENTORY_DIMENSION_ID
                                    , src.ITEM_ID
                                    , src.FINANCIAL_STATUS
                                    , src.REFERENCE_CATEGORY
                                    , src.STATUS_ISSUE
                                    , src.STATUS_RECEIPT
                                    , src.DATE_CLOSED
                                    , src.DATE_EXPECTED
                                    , src.DATE_FINANCIAL
                                    , src.DATE_PHYSICAL
                                    , src.INVENTORY_DATE
                                    , src.SHIPPING_DATE_CONFIRMED
                                    , src.SHIPPING_DATE_REQUESTED
                                    , src.STATUS_DATE
                                    , src.INVENTORY_TRANSACTION_ID
                                    , src.INVOICE_ID
                                    , src.LEGAL_ENTITY
                                    , src.PACKING_SLIP_ID
                                    , src.PICKING_ROUTE_ID
                                    , src.REFERENCE_ID
                                    , src.VOUCHER
                                    , src.VOUCHER_PHYSICAL
                                    , src.QUANTITY
                                    , src.QUANTITY_SETTLED
                                    , src.COST_AMOUNT_ADJUSTMENT
                                    , src.COST_AMOUNT_OPERATIONS
                                    , src.COST_AMOUNT_PHYSICAL
                                    , src.COST_AMOUNT_POSTED
                                    , src.COST_AMOUNT_SETTLED
                                    , src.COST_AMOUNT_STANDARD
                                    , src.INVENTORY_SITE_ID
                                    , src.INVENTORY_WAREHOUSE_ID
                                    , src.DATE_PHYSICAL_ID
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
        || ' as 
            select 
                a.FACT_INVENTORY_TRANSACTIONS_KEY
                , a.NEW_DIM_SOURCE_SYSTEM_KEY
                , a.NEW_DATE_CLOSED_DIM_DATE_KEY
                , a.NEW_DATE_EXPECTED_DIM_DATE_KEY
                , a.NEW_DATE_FINANCIAL_DIM_DATE_KEY
                , a.NEW_DATE_PHYSICAL_DIM_DATE_KEY
                , a.NEW_INVENTORY_DATE_DIM_DATE_KEY
                , a.NEW_SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                , a.NEW_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                , a.NEW_STATUS_DATE_DIM_DATE_KEY
                , a.NEW_DIM_CURRENCY_KEY
                , a.NEW_DIM_INVENTORY_KEY
                , a.NEW_DIM_ITEM_KEY
                , a.NEW_DIM_LEGAL_ENTITY_KEY
            from 
            (
                select 
                    src.FACT_INVENTORY_TRANSACTIONS_KEY
                    , src.DIM_SOURCE_SYSTEM_KEY
                    , src.DATE_CLOSED_DIM_DATE_KEY
                    , src.DATE_EXPECTED_DIM_DATE_KEY
                    , src.DATE_FINANCIAL_DIM_DATE_KEY
                    , src.DATE_PHYSICAL_DIM_DATE_KEY
                    , src.INVENTORY_DATE_DIM_DATE_KEY
                    , src.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                    , src.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                    , src.STATUS_DATE_DIM_DATE_KEY
                    , src.DIM_CURRENCY_KEY
                    , src.DIM_INVENTORY_KEY
                    , src.DIM_ITEM_KEY
                    , src.DIM_LEGAL_ENTITY_KEY
                    , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                    , nvl(d2.DIM_DATE_KEY, -1) AS NEW_DATE_CLOSED_DIM_DATE_KEY
                    , nvl(d3.DIM_DATE_KEY, -1) AS NEW_DATE_EXPECTED_DIM_DATE_KEY
                    , nvl(d4.DIM_DATE_KEY, -1) AS NEW_DATE_FINANCIAL_DIM_DATE_KEY
                    , nvl(d5.DIM_DATE_KEY, -1) AS NEW_DATE_PHYSICAL_DIM_DATE_KEY
                    , nvl(d6.DIM_DATE_KEY, -1) AS NEW_INVENTORY_DATE_DIM_DATE_KEY
                    , nvl(d7.DIM_DATE_KEY, -1) AS NEW_SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                    , nvl(d8.DIM_DATE_KEY, -1) AS NEW_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                    , nvl(d9.DIM_DATE_KEY, -1) AS NEW_STATUS_DATE_DIM_DATE_KEY
                    , nvl(d10.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                    , nvl(d11.DIM_INVENTORY_KEY, -1) AS NEW_DIM_INVENTORY_KEY
                    , nvl(d12.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                    , nvl(d13.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                from ' || :tgt_db || '.global.FACT_INVENTORY_TRANSACTIONS src
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                    src.DATE_CLOSED_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                    src.DATE_EXPECTED_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                    src.DATE_FINANCIAL_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                    src.DATE_PHYSICAL_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                    src.INVENTORY_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                    src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d8 ON
                    src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY = d8.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d9 ON
                    src.STATUS_DATE_DIM_DATE_SNKEY = d9.DIM_DATE_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d10 ON
                    src.DIM_CURRENCY_SNKEY = d10.DIM_CURRENCY_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d11 ON
                    src.DIM_INVENTORY_SNKEY = d11.DIM_INVENTORY_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d12 ON
                    src.DIM_ITEM_SNKEY = d12.DIM_ITEM_SNKEY
                LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d13 ON
                    src.DIM_LEGAL_ENTITY_SNKEY = d13.DIM_LEGAL_ENTITY_SNKEY
                    where 1=1
                    and (
                            (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                        or (src.DATE_CLOSED_DIM_DATE_KEY = -1 and src.DATE_CLOSED_DIM_DATE_SNKEY != -1)
                        or (src.DATE_EXPECTED_DIM_DATE_KEY = -1 and src.DATE_EXPECTED_DIM_DATE_SNKEY != -1)
                        or (src.DATE_FINANCIAL_DIM_DATE_KEY = -1 and src.DATE_FINANCIAL_DIM_DATE_SNKEY != -1)
                        or (src.DATE_PHYSICAL_DIM_DATE_KEY = -1 and src.DATE_PHYSICAL_DIM_DATE_SNKEY != -1)
                        or (src.INVENTORY_DATE_DIM_DATE_KEY = -1 and src.INVENTORY_DATE_DIM_DATE_SNKEY != -1)
                        or (src.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY = -1 and src.SHIPPING_DATE_CONFIRMED_DIM_DATE_SNKEY != -1)
                        or (src.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = -1 and src.SHIPPING_DATE_REQUESTED_DIM_DATE_SNKEY != -1)
                        or (src.STATUS_DATE_DIM_DATE_KEY = -1 and src.STATUS_DATE_DIM_DATE_SNKEY != -1)
                        or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
                        or (src.DIM_INVENTORY_KEY = -1 and src.DIM_INVENTORY_SNKEY != -1)
                        or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
                        or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                    )
            )a
            where 1=1
            and (
                        (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
                    or (a.DATE_CLOSED_DIM_DATE_KEY != a.NEW_DATE_CLOSED_DIM_DATE_KEY)
                    or (a.DATE_EXPECTED_DIM_DATE_KEY != a.NEW_DATE_EXPECTED_DIM_DATE_KEY)
                    or (a.DATE_FINANCIAL_DIM_DATE_KEY != a.NEW_DATE_FINANCIAL_DIM_DATE_KEY)
                    or (a.DATE_PHYSICAL_DIM_DATE_KEY != a.NEW_DATE_PHYSICAL_DIM_DATE_KEY)
                    or (a.INVENTORY_DATE_DIM_DATE_KEY != a.NEW_INVENTORY_DATE_DIM_DATE_KEY)
                    or (a.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY != a.NEW_SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY)
                    or (a.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY != a.NEW_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY)
                    or (a.STATUS_DATE_DIM_DATE_KEY != a.NEW_STATUS_DATE_DIM_DATE_KEY)
                    or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
                    or (a.DIM_INVENTORY_KEY != a.NEW_DIM_INVENTORY_KEY)
                    or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
                    or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
                )
            ;';
            EXECUTE IMMEDIATE :late_dim_select;

        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_INVENTORY_TRANSACTIONS_KEY = tgt.FACT_INVENTORY_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DATE_CLOSED_DIM_DATE_KEY = src.NEW_DATE_CLOSED_DIM_DATE_KEY
                                    , tgt.DATE_EXPECTED_DIM_DATE_KEY = src.NEW_DATE_EXPECTED_DIM_DATE_KEY
                                    , tgt.DATE_FINANCIAL_DIM_DATE_KEY = src.NEW_DATE_FINANCIAL_DIM_DATE_KEY
                                    , tgt.DATE_PHYSICAL_DIM_DATE_KEY = src.NEW_DATE_PHYSICAL_DIM_DATE_KEY
                                    , tgt.INVENTORY_DATE_DIM_DATE_KEY = src.NEW_INVENTORY_DATE_DIM_DATE_KEY
                                    , tgt.SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY = src.NEW_SHIPPING_DATE_CONFIRMED_DIM_DATE_KEY
                                    , tgt.SHIPPING_DATE_REQUESTED_DIM_DATE_KEY = src.NEW_SHIPPING_DATE_REQUESTED_DIM_DATE_KEY
                                    , tgt.STATUS_DATE_DIM_DATE_KEY = src.NEW_STATUS_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_INVENTORY_KEY = src.NEW_DIM_INVENTORY_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);
    
        --Logging stored procedure completed
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '11';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;