/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_REBATE_TRANSACTIONS
    CREATED BY     : Joshua Mills
    CREATED ON     : 02/01/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_REBATE_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_REBATE_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_REBATE_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'PDSREBATETABLE';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_REBATE_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_REBATE_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_REBATE_TRANSACTIONS_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.DATAAREAID AS LEGAL_ENTITY
                                , src.PDSREBATEID AS REBATE_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS REBATE_PROCESSED_DATE_DIM_DATE_KEY
                                , 0 AS REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                                , 0 AS REBATE_CALCULATED_DATE_DIM_DATE_KEY
                                , 0 AS REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_CUSTOMER_ORDER_KEY
                                , 0 AS DIM_CUSTOMER_ORDER_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_LEDGER_DIMENSION_KEY
                                , 0 AS DIM_LEDGER_DIMENSION_SNKEY
                                , 0 AS DIM_LEDGER_DIMENSION_OFFSET_KEY
                                , 0 AS DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_MERCHANDISING_EVENT_KEY
                                , 0 AS DIM_MERCHANDISING_EVENT_SNKEY
                                , 0 AS DIM_REBATE_KEY
                                , 0 AS DIM_REBATE_SNKEY
                                , 0 AS DIM_TRADE_PROMOTION_KEY
                                , 0 AS DIM_TRADE_PROMOTION_SNKEY
                                , 0 AS INVOICE_KEY
                                , coalesce(src.CUSTINVOICEJOUR_ORDERACCOUNT, src.CUSTACCOUNT, '''') AS CUSTOMER_ACCOUNT
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , case when nvl(to_char(src.DEFAULTDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.DEFAULTDIMENSION), '''') end AS DEFAULT_DIMENSION
                                , case when nvl(to_char(src.OFFSETDEFAULTDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.OFFSETDEFAULTDIMENSION), '''') end AS DEFAULT_DIMENSION_OFFSET
                                , nvl(src.ITEMID, '''') AS ITEM_ID
                                , case when nvl(to_char(src.LEDGERDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.LEDGERDIMENSION), '''') end AS LEDGER_DIMENSION
                                , case when nvl(to_char(src.OFFSETLEDGERDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.OFFSETLEDGERDIMENSION), '''') end AS LEDGER_DIMENSION_OFFSET
                                , nvl(src.TAMMERCHANDISINGEVENTID, '''') AS MERCHANDISING_EVENT_ID
                                , nvl(src.PDSREBATETYPE, '''') AS REBATE_TYPE_ID
                                , nvl(src.TAMMERCHANDISINGEVENT_PROMOTIONID, '''') AS TRADE_PROMOTION_ID
                                , nvl(src.CUSTINVOICETRANSREFRECID, 0) AS RECORD_ID_INVOICE
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_PDSREBATEAMTTYPE, '''') AS REBATE_AMOUNT_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_PDSPAYMTTYPE, '''') AS REBATE_PAYMENT_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_PDSREBATESTATUS, '''') AS REBATE_STATUS
                                , case when nvl(src.PDSPROCESSDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.PDSPROCESSDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.PDSPROCESSDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.PDSPROCESSDATE END AS REBATE_PROCESSED_DATE
                                , case when nvl(src.REBATECALCDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.REBATECALCDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.REBATECALCDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.REBATECALCDATE END AS REBATE_CALCULATED_DATE
                                , nvl(src.PDSSTARTINGREBATEAMT, 0) AS REBATE_AMOUNT
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                    on src.HK_SOURCE_NAME = tgt.SOURCE_NAME 
    and 
        src.DATAAREAID = tgt.LEGAL_ENTITY 
    and 
        src.PDSREBATEID = tgt.REBATE_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_REBATE_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_REBATE_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.REBATE_ID) AS FACT_REBATE_TRANSACTIONS_KEY
                            , src.SOURCE_NAME
                            , src.LEGAL_ENTITY
                            , src.REBATE_ID
                            , case when src.SOURCE_NAME = ''''  then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.REBATE_PROCESSED_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS REBATE_PROCESSED_DATE_DIM_DATE_KEY
                            , src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                            , case when src.REBATE_CALCULATED_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS REBATE_CALCULATED_DATE_DIM_DATE_KEY
                            , src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d4.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                            , src.DIM_CURRENCY_SNKEY
                            , case when src.DIM_CUSTOMER_ORDER_SNKEY = -2 then -2 else nvl(d5.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_ORDER_KEY
                            , src.DIM_CUSTOMER_ORDER_SNKEY
                            , case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2 else nvl(d6.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
                            , src.DIM_DEFAULT_DIMENSION_SNKEY
                            , case when src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = -2 then -2 else nvl(d7.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_OFFSET_KEY
                            , src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                            , case when src.DIM_ITEM_SNKEY = -2 then -2 else nvl(d8.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
                            , src.DIM_ITEM_SNKEY
                            , case when src.DIM_LEDGER_DIMENSION_SNKEY = -2 then -2 else nvl(d9.DIM_LEDGER_DIMENSION_KEY, -1) END AS DIM_LEDGER_DIMENSION_KEY
                            , src.DIM_LEDGER_DIMENSION_SNKEY
                            , case when src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = -2 then -2 else nvl(d10.DIM_LEDGER_DIMENSION_KEY, -1) END AS DIM_LEDGER_DIMENSION_OFFSET_KEY
                            , src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d11.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_MERCHANDISING_EVENT_SNKEY = -2 then -2 else nvl(d12.DIM_MERCHANDISING_EVENT_KEY, -1) END AS DIM_MERCHANDISING_EVENT_KEY
                            , src.DIM_MERCHANDISING_EVENT_SNKEY
                            , case when src.DIM_REBATE_SNKEY = -2 then -2 else nvl(d13.DIM_REBATE_KEY, -1) END AS DIM_REBATE_KEY
                            , src.DIM_REBATE_SNKEY
                            , case when src.DIM_TRADE_PROMOTION_SNKEY = -2 then -2 else nvl(d14.DIM_TRADE_PROMOTION_KEY, -1) END AS DIM_TRADE_PROMOTION_KEY
                            , src.DIM_TRADE_PROMOTION_SNKEY
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID_INVOICE), ''~'', src.ITEM_ID) AS INVOICE_KEY
                            , src.CUSTOMER_ACCOUNT
                            , src.CURRENCY_CODE
                            , src.DEFAULT_DIMENSION
                            , src.DEFAULT_DIMENSION_OFFSET
                            , src.ITEM_ID
                            , src.LEDGER_DIMENSION
                            , src.LEDGER_DIMENSION_OFFSET
                            , src.MERCHANDISING_EVENT_ID
                            , src.REBATE_TYPE_ID
                            , src.TRADE_PROMOTION_ID
                            , src.RECORD_ID_INVOICE
                            , src.REBATE_AMOUNT_TYPE
                            , src.REBATE_PAYMENT_TYPE
                            , src.REBATE_STATUS
                            , src.REBATE_PROCESSED_DATE
                            , src.REBATE_CALCULATED_DATE
                            , src.REBATE_AMOUNT
                            , hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.REBATE_ID, ''~'', src.CUSTOMER_ACCOUNT, ''~'', src.CURRENCY_CODE, ''~'', src.DEFAULT_DIMENSION, ''~'', src.DEFAULT_DIMENSION_OFFSET, ''~'', src.ITEM_ID, ''~'', src.LEDGER_DIMENSION, ''~'', src.LEDGER_DIMENSION_OFFSET, ''~'', src.MERCHANDISING_EVENT_ID, ''~'', src.REBATE_TYPE_ID, ''~'', src.TRADE_PROMOTION_ID, ''~'', to_char(src.RECORD_ID_INVOICE), ''~'', src.REBATE_AMOUNT_TYPE, ''~'', src.REBATE_PAYMENT_TYPE, ''~'', src.REBATE_STATUS, ''~'', to_char(src.REBATE_PROCESSED_DATE, ''yyyymmdd''), ''~'', to_char(src.REBATE_CALCULATED_DATE, ''yyyymmdd''), ''~'', to_char(src.REBATE_AMOUNT)) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.LEGAL_ENTITY, src.REBATE_ID  order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            prep01.FACT_REBATE_TRANSACTIONS_KEY
                            , prep01.SOURCE_NAME
                            , prep01.LEGAL_ENTITY
                            , prep01.REBATE_ID
                            , prep01.DIM_SOURCE_SYSTEM_KEY
                            , case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , prep01.REBATE_PROCESSED_DATE_DIM_DATE_KEY
                            , case when prep01.REBATE_PROCESSED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.REBATE_PROCESSED_DATE, ''yyyymmdd'')) END AS REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                            , prep01.REBATE_CALCULATED_DATE_DIM_DATE_KEY
                            , case when prep01.REBATE_CALCULATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.REBATE_CALCULATED_DATE, ''yyyymmdd'')) END AS REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                            , prep01.DIM_CURRENCY_KEY
                            , case when nvl(prep01.CURRENCY_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                            , prep01.DIM_CUSTOMER_ORDER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
							, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
							, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
									when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
								else DIM_CUSTOMER_ORDER_SNKEY_RAW
								end as DIM_CUSTOMER_ORDER_SNKEY
                            , prep01.DIM_DEFAULT_DIMENSION_KEY
                            , case when nvl(prep01.DEFAULT_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
                            , prep01.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                            , case when nvl(prep01.DEFAULT_DIMENSION_OFFSET, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION_OFFSET) END AS DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                            , prep01.DIM_ITEM_KEY
                            , case when prep01.LEGAL_ENTITY = '''' or prep01.ITEM_ID = '''' then -2 else hash('''', ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.ITEM_ID) END AS DIM_ITEM_SNKEY
                            , prep01.DIM_LEDGER_DIMENSION_KEY
                            , case when nvl(prep01.LEDGER_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEDGER_DIMENSION) END AS DIM_LEDGER_DIMENSION_SNKEY
                            , prep01.DIM_LEDGER_DIMENSION_OFFSET_KEY
                            , case when nvl(prep01.LEDGER_DIMENSION_OFFSET, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEDGER_DIMENSION_OFFSET) END AS DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                            , prep01.DIM_LEGAL_ENTITY_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , prep01.DIM_MERCHANDISING_EVENT_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.MERCHANDISING_EVENT_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.MERCHANDISING_EVENT_ID) END AS DIM_MERCHANDISING_EVENT_SNKEY
                            , prep01.DIM_REBATE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.REBATE_TYPE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.REBATE_TYPE_ID) END AS DIM_REBATE_SNKEY
                            , prep01.DIM_TRADE_PROMOTION_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.TRADE_PROMOTION_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.TRADE_PROMOTION_ID) END AS DIM_TRADE_PROMOTION_SNKEY
                            , prep01.INVOICE_KEY
                            , prep01.CUSTOMER_ACCOUNT
                            , prep01.CURRENCY_CODE
                            , prep01.DEFAULT_DIMENSION
                            , prep01.DEFAULT_DIMENSION_OFFSET
                            , prep01.ITEM_ID
                            , prep01.LEDGER_DIMENSION
                            , prep01.LEDGER_DIMENSION_OFFSET
                            , prep01.MERCHANDISING_EVENT_ID
                            , prep01.REBATE_TYPE_ID
                            , prep01.TRADE_PROMOTION_ID
                            , prep01.RECORD_ID_INVOICE
                            , prep01.REBATE_AMOUNT_TYPE
                            , prep01.REBATE_PAYMENT_TYPE
                            , prep01.REBATE_STATUS
                            , prep01.REBATE_PROCESSED_DATE
                            , prep01.REBATE_CALCULATED_DATE
                            , prep01.REBATE_AMOUNT
                            , prep01.HK_HASH_KEY
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d4 ON
                                src.DIM_CURRENCY_SNKEY = d4.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d5 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d5.DIM_CUSTOMER_SNKEY
                                AND src.REBATE_PROCESSED_DATE >= d5.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.REBATE_PROCESSED_DATE < d5.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d6 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d6.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d7 ON
                                src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = d7.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d8 ON
                                src.DIM_ITEM_SNKEY = d8.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d9 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d9.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d10 ON
                                src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = d10.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d11 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d11.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MERCHANDISING_EVENT d12 ON
                                src.DIM_MERCHANDISING_EVENT_SNKEY = d12.DIM_MERCHANDISING_EVENT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REBATE d13 ON
                                src.DIM_REBATE_SNKEY = d13.DIM_REBATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TRADE_PROMOTION d14 ON
                                src.DIM_TRADE_PROMOTION_SNKEY = d14.DIM_TRADE_PROMOTION_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_REBATE_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_REBATE_TRANSACTIONS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_REBATE_TRANSACTIONS_KEY = tgt.FACT_REBATE_TRANSACTIONS_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_REBATE_TRANSACTIONS_KEY = tgt.FACT_REBATE_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.REBATE_ID = src.REBATE_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.REBATE_PROCESSED_DATE_DIM_DATE_KEY = src.REBATE_PROCESSED_DATE_DIM_DATE_KEY
                                    , tgt.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY = src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                                    , tgt.REBATE_CALCULATED_DATE_DIM_DATE_KEY = src.REBATE_CALCULATED_DATE_DIM_DATE_KEY
                                    , tgt.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY = src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_SNKEY = src.DIM_CUSTOMER_ORDER_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_KEY = src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_SNKEY = src.DIM_LEDGER_DIMENSION_SNKEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_KEY = src.DIM_LEDGER_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_MERCHANDISING_EVENT_KEY = src.DIM_MERCHANDISING_EVENT_KEY
                                    , tgt.DIM_MERCHANDISING_EVENT_SNKEY = src.DIM_MERCHANDISING_EVENT_SNKEY
                                    , tgt.DIM_REBATE_KEY = src.DIM_REBATE_KEY
                                    , tgt.DIM_REBATE_SNKEY = src.DIM_REBATE_SNKEY
                                    , tgt.DIM_TRADE_PROMOTION_KEY = src.DIM_TRADE_PROMOTION_KEY
                                    , tgt.DIM_TRADE_PROMOTION_SNKEY = src.DIM_TRADE_PROMOTION_SNKEY
                                    , tgt.CUSTOMER_ACCOUNT = src.CUSTOMER_ACCOUNT
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.DEFAULT_DIMENSION_OFFSET = src.DEFAULT_DIMENSION_OFFSET
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.LEDGER_DIMENSION = src.LEDGER_DIMENSION
                                    , tgt.LEDGER_DIMENSION_OFFSET = src.LEDGER_DIMENSION_OFFSET
                                    , tgt.MERCHANDISING_EVENT_ID = src.MERCHANDISING_EVENT_ID
                                    , tgt.REBATE_TYPE_ID = src.REBATE_TYPE_ID
                                    , tgt.TRADE_PROMOTION_ID = src.TRADE_PROMOTION_ID
                                    , tgt.RECORD_ID_INVOICE = src.RECORD_ID_INVOICE
                                    , tgt.REBATE_AMOUNT_TYPE = src.REBATE_AMOUNT_TYPE
                                    , tgt.REBATE_PAYMENT_TYPE = src.REBATE_PAYMENT_TYPE
                                    , tgt.REBATE_STATUS = src.REBATE_STATUS
                                    , tgt.REBATE_PROCESSED_DATE = src.REBATE_PROCESSED_DATE
                                    , tgt.REBATE_CALCULATED_DATE = src.REBATE_CALCULATED_DATE
                                    , tgt.REBATE_AMOUNT = src.REBATE_AMOUNT
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                	FACT_REBATE_TRANSACTIONS_KEY
                                	, SOURCE_NAME
                                	, LEGAL_ENTITY
                                	, REBATE_ID
                                	, DIM_SOURCE_SYSTEM_KEY
                                	, DIM_SOURCE_SYSTEM_SNKEY
                                	, REBATE_PROCESSED_DATE_DIM_DATE_KEY
                                	, REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                                	, REBATE_CALCULATED_DATE_DIM_DATE_KEY
                                	, REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                                	, DIM_CURRENCY_KEY
                                	, DIM_CURRENCY_SNKEY
                                	, DIM_CUSTOMER_ORDER_KEY
                                	, DIM_CUSTOMER_ORDER_SNKEY
                                	, DIM_DEFAULT_DIMENSION_KEY
                                	, DIM_DEFAULT_DIMENSION_SNKEY
                                	, DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                	, DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                	, DIM_ITEM_KEY
                                	, DIM_ITEM_SNKEY
                                	, DIM_LEDGER_DIMENSION_KEY
                                	, DIM_LEDGER_DIMENSION_SNKEY
                                	, DIM_LEDGER_DIMENSION_OFFSET_KEY
                                	, DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                	, DIM_LEGAL_ENTITY_KEY
                                	, DIM_LEGAL_ENTITY_SNKEY
                                	, DIM_MERCHANDISING_EVENT_KEY
                                	, DIM_MERCHANDISING_EVENT_SNKEY
                                	, DIM_REBATE_KEY
                                	, DIM_REBATE_SNKEY
                                	, DIM_TRADE_PROMOTION_KEY
                                	, DIM_TRADE_PROMOTION_SNKEY
                                	, INVOICE_KEY
                                	, CUSTOMER_ACCOUNT
                                	, CURRENCY_CODE
                                	, DEFAULT_DIMENSION
                                	, DEFAULT_DIMENSION_OFFSET
                                	, ITEM_ID
                                	, LEDGER_DIMENSION
                                	, LEDGER_DIMENSION_OFFSET
                                	, MERCHANDISING_EVENT_ID
                                	, REBATE_TYPE_ID
                                	, TRADE_PROMOTION_ID
                                	, RECORD_ID_INVOICE
                                	, REBATE_AMOUNT_TYPE
                                	, REBATE_PAYMENT_TYPE
                                	, REBATE_STATUS
                                	, REBATE_PROCESSED_DATE
                                	, REBATE_CALCULATED_DATE
                                	, REBATE_AMOUNT
                                	, HK_HASH_KEY
                                	, HK_SOURCE_NAME
                                	, HK_SOFT_DELETE_FLAG
                                	, HK_SOURCE_CREATED_TIMESTAMP
                                	, HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, HK_CREATED_JOB_RUN_ID
                                	, HK_LAST_UPDATED_JOB_RUN_ID
                                	, HK_CREATED_TIMESTAMP
                                	, HK_LAST_UPDATED_TIMESTAMP
                                	, HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                	src.FACT_REBATE_TRANSACTIONS_KEY
                                	, src.SOURCE_NAME
                                	, src.LEGAL_ENTITY
                                	, src.REBATE_ID
                                	, src.DIM_SOURCE_SYSTEM_KEY
                                	, src.DIM_SOURCE_SYSTEM_SNKEY
                                	, src.REBATE_PROCESSED_DATE_DIM_DATE_KEY
                                	, src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY
                                	, src.REBATE_CALCULATED_DATE_DIM_DATE_KEY
                                	, src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY
                                	, src.DIM_CURRENCY_KEY
                                	, src.DIM_CURRENCY_SNKEY
                                	, src.DIM_CUSTOMER_ORDER_KEY
                                	, src.DIM_CUSTOMER_ORDER_SNKEY
                                	, src.DIM_DEFAULT_DIMENSION_KEY
                                	, src.DIM_DEFAULT_DIMENSION_SNKEY
                                	, src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                	, src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                	, src.DIM_ITEM_KEY
                                	, src.DIM_ITEM_SNKEY
                                	, src.DIM_LEDGER_DIMENSION_KEY
                                	, src.DIM_LEDGER_DIMENSION_SNKEY
                                	, src.DIM_LEDGER_DIMENSION_OFFSET_KEY
                                	, src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                	, src.DIM_LEGAL_ENTITY_KEY
                                	, src.DIM_LEGAL_ENTITY_SNKEY
                                	, src.DIM_MERCHANDISING_EVENT_KEY
                                	, src.DIM_MERCHANDISING_EVENT_SNKEY
                                	, src.DIM_REBATE_KEY
                                	, src.DIM_REBATE_SNKEY
                                	, src.DIM_TRADE_PROMOTION_KEY
                                	, src.DIM_TRADE_PROMOTION_SNKEY
                                	, src.INVOICE_KEY
                                	, src.CUSTOMER_ACCOUNT
                                	, src.CURRENCY_CODE
                                	, src.DEFAULT_DIMENSION
                                	, src.DEFAULT_DIMENSION_OFFSET
                                	, src.ITEM_ID
                                	, src.LEDGER_DIMENSION
                                	, src.LEDGER_DIMENSION_OFFSET
                                	, src.MERCHANDISING_EVENT_ID
                                	, src.REBATE_TYPE_ID
                                	, src.TRADE_PROMOTION_ID
                                	, src.RECORD_ID_INVOICE
                                	, src.REBATE_AMOUNT_TYPE
                                	, src.REBATE_PAYMENT_TYPE
                                	, src.REBATE_STATUS
                                	, src.REBATE_PROCESSED_DATE
                                	, src.REBATE_CALCULATED_DATE
                                	, src.REBATE_AMOUNT
                                	, src.SRC_HK_HASH_KEY
                                	, src.HK_SOURCE_NAME
                                	, src.HK_SOFT_DELETE_FLAG
                                	, src.HK_SOURCE_CREATED_TIMESTAMP
                                	, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, src.HK_CREATED_JOB_RUN_ID
                                	, src.HK_LAST_UPDATED_JOB_RUN_ID
                                	, src.HK_CREATED_TIMESTAMP
                                	, src.HK_LAST_UPDATED_TIMESTAMP
                                	, src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
              a.FACT_REBATE_TRANSACTIONS_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_REBATE_PROCESSED_DATE_DIM_DATE_KEY
            , a.NEW_REBATE_CALCULATED_DATE_DIM_DATE_KEY
            , a.NEW_DIM_CURRENCY_KEY
            , a.NEW_DIM_CUSTOMER_ORDER_KEY
            , a.NEW_DIM_DEFAULT_DIMENSION_KEY
            , a.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
            , a.NEW_DIM_ITEM_KEY
            , a.NEW_DIM_LEDGER_DIMENSION_KEY
            , a.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_MERCHANDISING_EVENT_KEY
            , a.NEW_DIM_REBATE_KEY
            , a.NEW_DIM_TRADE_PROMOTION_KEY
        from (
            select 
                src.FACT_REBATE_TRANSACTIONS_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.REBATE_PROCESSED_DATE_DIM_DATE_KEY
                , src.REBATE_CALCULATED_DATE_DIM_DATE_KEY
                , src.DIM_CURRENCY_KEY
                , src.DIM_CUSTOMER_ORDER_KEY
                , src.DIM_DEFAULT_DIMENSION_KEY
                , src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                , src.DIM_ITEM_KEY
                , src.DIM_LEDGER_DIMENSION_KEY
                , src.DIM_LEDGER_DIMENSION_OFFSET_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_MERCHANDISING_EVENT_KEY
                , src.DIM_REBATE_KEY
                , src.DIM_TRADE_PROMOTION_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_REBATE_PROCESSED_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_REBATE_CALCULATED_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                , nvl(d5.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
                , nvl(d6.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
                , nvl(d7.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
                , nvl(d8.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                , nvl(d9.DIM_LEDGER_DIMENSION_KEY, -1) AS NEW_DIM_LEDGER_DIMENSION_KEY
                , nvl(d10.DIM_LEDGER_DIMENSION_KEY, -1) AS NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
                , nvl(d11.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d12.DIM_MERCHANDISING_EVENT_KEY, -1) AS NEW_DIM_MERCHANDISING_EVENT_KEY
                , nvl(d13.DIM_REBATE_KEY, -1) AS NEW_DIM_REBATE_KEY
                , nvl(d14.DIM_TRADE_PROMOTION_KEY, -1) AS NEW_DIM_TRADE_PROMOTION_KEY
            from ' || :tgt_db || '.global.FACT_REBATE_TRANSACTIONS src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d4 ON
                                src.DIM_CURRENCY_SNKEY = d4.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d5 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d5.DIM_CUSTOMER_SNKEY
                                AND src.REBATE_PROCESSED_DATE >= d5.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.REBATE_PROCESSED_DATE < d5.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d6 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d6.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d7 ON
                                src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = d7.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d8 ON
                                src.DIM_ITEM_SNKEY = d8.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d9 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d9.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d10 ON
                                src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = d10.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d11 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d11.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MERCHANDISING_EVENT d12 ON
                                src.DIM_MERCHANDISING_EVENT_SNKEY = d12.DIM_MERCHANDISING_EVENT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REBATE d13 ON
                                src.DIM_REBATE_SNKEY = d13.DIM_REBATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TRADE_PROMOTION d14 ON
                                src.DIM_TRADE_PROMOTION_SNKEY = d14.DIM_TRADE_PROMOTION_SNKEY
            where 1=1
            and (
                (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                or (src.REBATE_PROCESSED_DATE_DIM_DATE_KEY = -1 and src.REBATE_PROCESSED_DATE_DIM_DATE_SNKEY != -1)
                or (src.REBATE_CALCULATED_DATE_DIM_DATE_KEY = -1 and src.REBATE_CALCULATED_DATE_DIM_DATE_SNKEY != -1)
                or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
                or (src.DIM_CUSTOMER_ORDER_KEY = -1 and src.DIM_CUSTOMER_ORDER_SNKEY != -1)
                or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
                or (src.DIM_DEFAULT_DIMENSION_OFFSET_KEY = -1 and src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY != -1)
                or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
                or (src.DIM_LEDGER_DIMENSION_KEY = -1 and src.DIM_LEDGER_DIMENSION_SNKEY != -1)
                or (src.DIM_LEDGER_DIMENSION_OFFSET_KEY = -1 and src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY != -1)
                or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                or (src.DIM_MERCHANDISING_EVENT_KEY = -1 and src.DIM_MERCHANDISING_EVENT_SNKEY != -1)
                or (src.DIM_REBATE_KEY = -1 and src.DIM_REBATE_SNKEY != -1)
                or (src.DIM_TRADE_PROMOTION_KEY = -1 and src.DIM_TRADE_PROMOTION_SNKEY != -1)
                )
            ) a
        where 1=1
        and (
        (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
        or (a.REBATE_PROCESSED_DATE_DIM_DATE_KEY != a.NEW_REBATE_PROCESSED_DATE_DIM_DATE_KEY)
        or (a.REBATE_CALCULATED_DATE_DIM_DATE_KEY != a.NEW_REBATE_CALCULATED_DATE_DIM_DATE_KEY)
        or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
        or (a.DIM_CUSTOMER_ORDER_KEY != a.NEW_DIM_CUSTOMER_ORDER_KEY)
        or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
        or (a.DIM_DEFAULT_DIMENSION_OFFSET_KEY != a.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY)
        or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
        or (a.DIM_LEDGER_DIMENSION_KEY != a.NEW_DIM_LEDGER_DIMENSION_KEY)
        or (a.DIM_LEDGER_DIMENSION_OFFSET_KEY != a.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY)
        or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
        or (a.DIM_MERCHANDISING_EVENT_KEY != a.NEW_DIM_MERCHANDISING_EVENT_KEY)
        or (a.DIM_REBATE_KEY != a.NEW_DIM_REBATE_KEY)
        or (a.DIM_TRADE_PROMOTION_KEY != a.NEW_DIM_TRADE_PROMOTION_KEY)
            )
        ;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_REBATE_TRANSACTIONS_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_SNKEY
			from (select src.FACT_REBATE_TRANSACTIONS_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
						else DIM_CUSTOMER_ORDER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_ORDER_SNKEY
					, src.DIM_CUSTOMER_ORDER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
				from ' || :tgt_db || '.global.FACT_REBATE_TRANSACTIONS src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.REBATE_PROCESSED_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.REBATE_PROCESSED_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_ORDER_SNKEY != NEW_DIM_CUSTOMER_ORDER_SNKEY
				or src.DIM_CUSTOMER_ORDER_KEY != NEW_DIM_CUSTOMER_ORDER_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;


        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_REBATE_TRANSACTIONS_KEY = tgt.FACT_REBATE_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.REBATE_PROCESSED_DATE_DIM_DATE_KEY = src.NEW_REBATE_PROCESSED_DATE_DIM_DATE_KEY
                                    , tgt.REBATE_CALCULATED_DATE_DIM_DATE_KEY = src.NEW_REBATE_CALCULATED_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_KEY = src.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.NEW_DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_KEY = src.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_MERCHANDISING_EVENT_KEY = src.NEW_DIM_MERCHANDISING_EVENT_KEY
                                    , tgt.DIM_REBATE_KEY = src.NEW_DIM_REBATE_KEY
                                    , tgt.DIM_TRADE_PROMOTION_KEY = src.NEW_DIM_TRADE_PROMOTION_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_REBATE_TRANSACTIONS_KEY = tgt.FACT_REBATE_TRANSACTIONS_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_ORDER_SNKEY = src.NEW_DIM_CUSTOMER_ORDER_SNKEY
									, tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_customer);

		LET c5 CURSOR FOR res;

        LET key_fix_count_customer INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_customer := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;