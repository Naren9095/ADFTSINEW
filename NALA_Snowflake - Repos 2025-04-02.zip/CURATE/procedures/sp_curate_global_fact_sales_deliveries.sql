/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_SALES_DELIVERIES
    CREATED BY     : Joshua Mills
    CREATED ON     : 07/11/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_SALES_DELIVERIES(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_SALES_DELIVERIES
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_SALES_DELIVERIES';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'CUSTPACKINGSLIPTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_SALES_DELIVERIES';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_DELIVERIES_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_SALES_DELIVERIES_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS DELIVERY_DATE_DIM_DATE_KEY
                                , 0 AS DELIVERY_DATE_DIM_DATE_SNKEY
                                , 0 AS DHL_DELIVERY_DATE_DIM_DATE_KEY
                                , 0 AS DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                                , 0 AS SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                                , 0 AS SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                                , 0 AS SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                                , 0 AS SHIP_DATE_DIM_DATE_KEY
                                , 0 AS SHIP_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_BUSINESS_UNIT_KEY
                                , 0 AS DIM_BUSINESS_UNIT_SNKEY
                                , 0 AS DIM_CAMPAIGN_KEY
                                , 0 AS DIM_CAMPAIGN_SNKEY
                                , 0 AS DIM_CUSTOMER_INVOICE_KEY
                                , 0 AS DIM_CUSTOMER_INVOICE_SNKEY
                                , 0 AS DIM_CUSTOMER_ORDER_KEY
                                , 0 AS DIM_CUSTOMER_ORDER_SNKEY
                                , 0 AS DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , 0 AS DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                                , 0 AS DIM_DELIVERY_MODE_KEY
                                , 0 AS DIM_DELIVERY_MODE_SNKEY
                                , 0 AS DIM_DELIVERY_TERM_KEY
                                , 0 AS DIM_DELIVERY_TERM_SNKEY
                                , 0 AS DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , 0 AS DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , 0 AS DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , 0 AS DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , 0 AS DIM_INVENTORY_KEY
                                , 0 AS DIM_INVENTORY_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , 0 AS DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , 0 AS DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , 0 AS DIM_SALES_GROUP_KEY
                                , 0 AS DIM_SALES_GROUP_SNKEY
                                , 0 AS DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , 0 AS DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , 0 AS DIM_SALES_ORDER_KEY
                                , 0 AS DIM_SALES_ORDER_SNKEY
                                , 0 AS DIM_SALES_POOL_KEY
                                , 0 AS DIM_SALES_POOL_SNKEY
                                , 0 AS DIM_SALES_PRICE_GROUP_KEY
                                , 0 AS DIM_SALES_PRICE_GROUP_SNKEY
                                , 0 AS DIM_SHIPPING_CARRIER_KEY
                                , 0 AS DIM_SHIPPING_CARRIER_SNKEY
                                , 0 AS DIM_SHIPPING_CARRIER_PACKAGE_KEY
                                , 0 AS DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                                , 0 AS DIM_UNIT_OF_MEASURE_SALES_KEY
                                , 0 AS DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , 0 AS DIM_WAREHOUSE_KEY
                                , 0 AS DIM_WAREHOUSE_SNKEY
                                , 0 AS DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , 0 AS DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , 0 AS DIM_WORKER_SALES_TAKER_KEY
                                , 0 AS DIM_WORKER_SALES_TAKER_SNKEY
                                , nvl(src.DEFAULTDIMENSION_BUSINESS_UNIT, '''') AS BUSINESS_UNIT_ID
                                , nvl(src.SALESTABLE_SMMCAMPAIGNID, '''') AS CAMPAIGN_ID
                                , nvl(src.CUSTPACKINGSLIPJOUR_INVOICEACCOUNT, '''') AS CUSTOMER_ACCOUNT_INVOICE
                                , nvl(src.CUSTPACKINGSLIPJOUR_ORDERACCOUNT, '''') AS CUSTOMER_ACCOUNT_ORDER
                                , nvl(src.SALESTABLE_MARKUPGROUP, '''') AS CUSTOMER_MARKUP_GROUP_ID
                                , nvl(to_char(src.DEFAULTDIMENSION), '''') AS DEFAULT_DIMENSION
                                , nvl(src.CUSTPACKINGSLIPJOUR_DLVMODE, '''') AS DELIVERY_MODE_ID
                                , nvl(src.CUSTPACKINGSLIPJOUR_DLVTERM, '''') AS DELIVERY_TERM_ID
                                , nvl(src.INVENTDIM1_CONFIGID, '''') AS CONFIGURATION_ID
                                , nvl(src.TRANSACTIONCODE, '''') AS INTRA_STAT_TRANSACTION_CODE
                                , nvl(src.INVENTDIMID, '''') AS INVENTORY_DIMENSION_ID
                                , nvl(src.ITEMID, '''') AS ITEM_ID
                                , nvl(src.DELIVERYPOSTALADDRESS, 0) AS RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , nvl(src.CUSTPACKINGSLIPJOUR_INVOICEPOSTALADDRESS, 0) AS RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , nvl(src.SALESGROUP, '''') AS SALES_GROUP_ID
                                , nvl(src.SALESTABLE_LINEDISC, '''') AS SALES_LINE_DISCOUNT_GROUP_ID
                                , nvl(src.SALESTABLE_SALESPOOLID, '''') AS SALES_POOL_ID
                                , nvl(src.SALESTABLE_PRICEGROUPID, '''') AS SALES_PRICE_GROUP_ID
                                , nvl(src.CUSTPACKINGSLIPJOUR_SHIPCARRIERID, '''') AS SHIPPING_CARRIER_ID
                                , nvl(src.SALESUNIT, '''') AS UNIT_OF_MEASURE_CODE_SALES
                                , nvl(src.CUSTPACKINGSLIPJOUR_INVENTLOCATIONID, '''') AS WAREHOUSE_ID
                                , nvl(src.SALESTABLE_WORKERSALESRESPONSIBLE, 0) AS RECORD_ID_SALES_RESPONSIBLE
                                , nvl(src.CUSTPACKINGSLIPJOUR_WORKERSALESTAKER, 0) AS RECORD_ID_SALES_TAKER
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_DOCUMENTSTATUS, '''') AS DOCUMENT_STATUS
                                , case when src.INVENTDIM1_CONFIGID = ''FLR'' and (src.SALESLINE_LINEDISC <> 0 or src.SALESLINE_LINEPERCENT <> 0) then ''3''   when src.INVENTDIM1_CONFIGID <> ''FLR'' and src.SALESTABLE_LINEDISC like ''%FLR%'' and src.SALESLINE_LINEPERCENT <> 0 then ''2''   when src.INVENTDIM1_CONFIGID = ''FLR'' and (src.SALESLINE_LINEDISC = 0 or src.SALESLINE_LINEPERCENT = 0) then ''1'' else ''0'' END AS SRC_FLOOR_SAMPLE_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_RETURNSTATUSHEADER, '''') AS HEADER_RETURN_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_SALESSTATUSHEADER, '''') AS HEADER_SALES_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_RETURNSTATUSLINE, '''') AS RETURN_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE5_ENUMVALUELABEL_SALESSTATUSLINE, '''') AS SALES_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE6_ENUMVALUELABEL_SALESTYPE, '''') AS SALES_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE7_ENUMVALUELABEL_SHIPCARRIERDLVTYPE, '''') AS SHIP_CARRIER_DELIVERY_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE9_ENUMVALUELABEL_TRADELINEDLVTYPE, '''') AS TRADE_LINE_DELIVERY_TYPE
                                , case when nvl(src.SALESTABLE_ATAGENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_AT_AGENT_TRANSACTION
                                , case when nvl(src.SALESTABLE_SHIPCARRIERBLINDSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_BLIND_SHIPMENT
                                , case when nvl(src.SALESTABLE_SHIPCARRIEREXPEDITEDSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_EXPEDITED_SHIPMENT
                                , case when SRC_FLOOR_SAMPLE_TYPE in (''2'', ''3'') then ''Yes'' else ''No'' END AS IS_FLOOR_SAMPLE_DISCOUNT
                                , case when nvl(src.ITEMID, '''') != '''' then ''Yes'' else ''No'' END AS IS_ITEM_TRANSACTION
                                , case when nvl(src.SALESLINE_COMPLETE, 0) = 1 then ''Yes'' else ''No'' END AS IS_LINE_DELIVERY_COMPLETE
                                , case when nvl(src.SALESTABLE_ORDERBLOCKED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_BLOCKED
                                , case when nvl(src.SALESLINE_ORDERBLOCKED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_LINE_BLOCKED
                                , case when nvl(src.SALESTABLE_MCRORDERSTOPPED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_LOCKED
                                , case when nvl(src.SALESLINE_SCRAP, 0) = 1 then ''Yes'' else ''No'' END AS IS_RETURNED_ITEM_SCRAP
                                , case when nvl(src.SALESTABLE_SHIPCARRIERFUELSURCHARGE, 0) = 1 then ''Yes'' else ''No'' END AS IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , case when nvl(src.SALESLINE_STOCKEDPRODUCT, 0) = 1 then ''Yes'' else ''No'' END AS IS_STOCKED_PRODUCT
                                , case when nvl(src.MCRSALESLINEDROPSHIPMENT_DROPSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS DROP_SHIPMENT
                                , nvl(src.PDMSTATUS_NAME, '''') AS ITEM_STATUS
                                , case when nvl(src.DELIVERYDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.DELIVERYDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.DELIVERYDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.DELIVERYDATE END AS DELIVERY_DATE
                                , case when nvl(src.SHIPCARRIERTRACKING_NTT_DELIVERYDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.SHIPCARRIERTRACKING_NTT_DELIVERYDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.SHIPCARRIERTRACKING_NTT_DELIVERYDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.SHIPCARRIERTRACKING_NTT_DELIVERYDATE END AS DHL_DELIVERY_DATE
                                , case when nvl(src.CUSTPACKINGSLIPJOUR_DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.CUSTPACKINGSLIPJOUR_DOCUMENTDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.CUSTPACKINGSLIPJOUR_DOCUMENTDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.CUSTPACKINGSLIPJOUR_DOCUMENTDATE END AS DOCUMENT_DATE
                                , case when nvl(SALESLINESHIPPINGDATECONFIRMED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when SALESLINESHIPPINGDATECONFIRMED < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when SALESLINESHIPPINGDATECONFIRMED > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else SALESLINESHIPPINGDATECONFIRMED END AS SALES_LINE_CONFIRMED_SHIPPING_DATE
                                , case when nvl(src.SALESLINESHIPPINGDATEREQUESTED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.SALESLINESHIPPINGDATEREQUESTED < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.SALESLINESHIPPINGDATEREQUESTED > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.SALESLINESHIPPINGDATEREQUESTED END AS SALES_LINE_REQUESTED_SHIPPING_DATE
                                ,  case when nvl(nvl(src.SHIPCARRIERPACKAGE1_ORIG_SHIPDATE, src.SHIPCARRIERPACKAGE2_SHIPDATE), ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when nvl(src.SHIPCARRIERPACKAGE1_ORIG_SHIPDATE, src.SHIPCARRIERPACKAGE2_SHIPDATE) < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when nvl(src.SHIPCARRIERPACKAGE1_ORIG_SHIPDATE, src.SHIPCARRIERPACKAGE2_SHIPDATE) > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else nvl(src.SHIPCARRIERPACKAGE1_ORIG_SHIPDATE, src.SHIPCARRIERPACKAGE2_SHIPDATE) END AS SHIP_DATE
                                , nvl(src.CUSTPACKINGSLIPJOUR_BILLOFLADINGID, '''') AS BILL_OF_LADING_ID
                                , nvl(src.SHIPCARRIERPACKAGE1_ORIG_CARRIERID, '''') AS CARRIER_ID
                                , nvl(src.SHIPCARRIERPACKAGE1_ORIG_CARRIERNAME, '''') AS CARRIER_NAME
                                , nvl(src.CUSTPACKINGSLIPJOUR_INTERNALPACKINGSLIPID, '''') AS INTERNAL_PACKING_SLIP_ID
                                , nvl(src.INVENTTRANSID, '''') AS INVENTORY_TRANSACTION_ID
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.CUSTPACKINGSLIPJOUR_LEDGERVOUCHER, '''') AS LEDGER_VOUCHER
                                , nvl(src.LINENUM, 0) AS LINE_NUMBER
                                , nvl(src.ORIGSALESID, '''') AS ORIGINAL_SALES_ORDER_ID
                                , nvl(src.PACKINGSLIPID, '''') AS PACKING_SLIP_ID
                                , nvl(src.CUSTPACKINGSLIPJOUR_PURCHASEORDER, '''') AS PURCHASE_ORDER_ID
                                , nvl(src.SALESID, '''') AS SALES_ORDER_ID
                                , nvl(src.INVENTQTY, 0) AS INVENTORY_QUANTITY
                                , nvl(src.QTY, 0) AS RECEIPT_QUANTITY
                                , nvl(src.PRICEUNIT, 0) AS PRICE_UNIT
                                , nvl(src.VALUEMST, 0) AS AMOUNT_COMPANY_CURRENCY
                                , nvl(src.SHIPCARRIERTRACKING_TRACKINGNUMBER, '''') AS TRACKING_NUMBER
                                , nvl(src.TIMEXTENDERENUMTABLE8_ENUMVALUELABEL_NTT_DELIVERYSTATUS, '''') AS DELIVERY_STATUS
                                , nvl(src.CUSTPACKINGSLIPJOUR_EBCOVERRIDESTATUS, '''') AS EBC_OVERRIDE_STATUS
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                    on src.HK_SOURCE_NAME = tgt.SOURCE_NAME 
    and 
        src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_DELIVERIES_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_DELIVERIES_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_SALES_DELIVERIES_KEY
                            , src.SOURCE_NAME
                            , src.RECORD_ID
                            , case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.DELIVERY_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS DELIVERY_DATE_DIM_DATE_KEY
                            , src.DELIVERY_DATE_DIM_DATE_SNKEY
                            , case when src.DHL_DELIVERY_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS DHL_DELIVERY_DATE_DIM_DATE_KEY
                            , src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                            , case when src.DOCUMENT_DATE = ''1950-01-01'' then -2 else nvl(d4.DIM_DATE_KEY, -1) END AS DOCUMENT_DATE_DIM_DATE_KEY
                            , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                            , case when src.SALES_LINE_CONFIRMED_SHIPPING_DATE = ''1950-01-01'' then -2 else nvl(d5.DIM_DATE_KEY, -1) END AS SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                            , src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                            , case when src.SALES_LINE_REQUESTED_SHIPPING_DATE = ''1950-01-01'' then -2 else nvl(d6.DIM_DATE_KEY, -1) END AS SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                            , src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                            , case when src.SHIP_DATE = ''1950-01-01'' then -2 else nvl(d7.DIM_DATE_KEY, -1) END AS SHIP_DATE_DIM_DATE_KEY
                            , src.SHIP_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_BUSINESS_UNIT_SNKEY = -2 then -2 else nvl(d8.DIM_BUSINESS_UNIT_KEY, -1) END AS DIM_BUSINESS_UNIT_KEY
                            , src.DIM_BUSINESS_UNIT_SNKEY
                            , case when src.DIM_CAMPAIGN_SNKEY = -2 then -2 else nvl(d9.DIM_CAMPAIGN_KEY, -1) END AS DIM_CAMPAIGN_KEY
                            , src.DIM_CAMPAIGN_SNKEY
                            , case when src.DIM_CUSTOMER_INVOICE_SNKEY = -2 then -2 else nvl(d10.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_INVOICE_KEY
                            , src.DIM_CUSTOMER_INVOICE_SNKEY
                            , case when src.DIM_CUSTOMER_ORDER_SNKEY = -2 then -2 else nvl(d11.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_ORDER_KEY
                            , src.DIM_CUSTOMER_ORDER_SNKEY
                            , case when src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = -2 then -2 else nvl(d12.DIM_CUSTOMER_MARKUP_GROUP_KEY, -1) END AS DIM_CUSTOMER_MARKUP_GROUP_KEY
                            , src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            , case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2 else nvl(d13.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
                            , src.DIM_DEFAULT_DIMENSION_SNKEY
                            , case when src.DIM_DELIVERY_MODE_SNKEY = -2 then -2 else nvl(d14.DIM_DELIVERY_MODE_KEY, -1) END AS DIM_DELIVERY_MODE_KEY
                            , src.DIM_DELIVERY_MODE_SNKEY
                            , case when src.DIM_DELIVERY_TERM_SNKEY = -2 then -2 else nvl(d15.DIM_DELIVERY_TERM_KEY, -1) END AS DIM_DELIVERY_TERM_KEY
                            , src.DIM_DELIVERY_TERM_SNKEY
                            , case when src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = -2 then -2 else nvl(d16.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY, -1) END AS DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                            , src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            , case when src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = -2 then -2 else nvl(d17.DIM_INTRA_STAT_TRANSACTION_CODE_KEY, -1) END AS DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                            , src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            , case when src.DIM_INVENTORY_SNKEY = -2 then -2 else nvl(d18.DIM_INVENTORY_KEY, -1) END AS DIM_INVENTORY_KEY
                            , src.DIM_INVENTORY_SNKEY
                            , case when src.DIM_ITEM_SNKEY = -2 then -2 else nvl(d19.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
                            , src.DIM_ITEM_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d20.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = -2 then -2 else nvl(d21.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
                            , src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                            , case when src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = -2 then -2 else nvl(d22.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_INVOICE_ADDRESS_KEY
                            , src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                            , case when src.DIM_SALES_GROUP_SNKEY = -2 then -2 else nvl(d23.DIM_SALES_GROUP_KEY, -1) END AS DIM_SALES_GROUP_KEY
                            , src.DIM_SALES_GROUP_SNKEY
                            , case when src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = -2 then -2 else nvl(d24.DIM_SALES_LINE_DISCOUNT_GROUP_KEY, -1) END AS DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                            , src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            , case when src.DIM_SALES_ORDER_SNKEY = -2 then -2 else nvl(d25.DIM_SALES_ORDER_KEY, -1) END AS DIM_SALES_ORDER_KEY
                            , src.DIM_SALES_ORDER_SNKEY
                            , case when src.DIM_SALES_POOL_SNKEY = -2 then -2 else nvl(d26.DIM_SALES_POOL_KEY, -1) END AS DIM_SALES_POOL_KEY
                            , src.DIM_SALES_POOL_SNKEY
                            , case when src.DIM_SALES_PRICE_GROUP_SNKEY = -2 then -2 else nvl(d27.DIM_SALES_PRICE_GROUP_KEY, -1) END AS DIM_SALES_PRICE_GROUP_KEY
                            , src.DIM_SALES_PRICE_GROUP_SNKEY
                            , case when src.DIM_SHIPPING_CARRIER_SNKEY = -2 then -2 else nvl(d28.DIM_SHIPPING_CARRIER_KEY, -1) END AS DIM_SHIPPING_CARRIER_KEY
                            , src.DIM_SHIPPING_CARRIER_SNKEY
                            , case when src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY = -2 then -2 else nvl(d29.DIM_SHIPPING_CARRIER_KEY, -1) END AS DIM_SHIPPING_CARRIER_PACKAGE_KEY
                            , src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                            , case when src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = -2 then -2 else nvl(d30.DIM_UNIT_OF_MEASURE_KEY, -1) END AS DIM_UNIT_OF_MEASURE_SALES_KEY
                            , src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                            , case when src.DIM_WAREHOUSE_SNKEY = -2 then -2 else nvl(d31.DIM_WAREHOUSE_KEY, -1) END AS DIM_WAREHOUSE_KEY
                            , src.DIM_WAREHOUSE_SNKEY
                            , case when src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = -2 then -2 else nvl(d32.DIM_WORKER_KEY, -1) END AS DIM_WORKER_SALES_RESPONSIBLE_KEY
                            , src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                            , case when src.DIM_WORKER_SALES_TAKER_SNKEY = -2 then -2 else nvl(d33.DIM_WORKER_KEY, -1) END AS DIM_WORKER_SALES_TAKER_KEY
                            , src.DIM_WORKER_SALES_TAKER_SNKEY
                            , src.BUSINESS_UNIT_ID
                            , src.CAMPAIGN_ID
                            , src.CUSTOMER_ACCOUNT_INVOICE
                            , src.CUSTOMER_ACCOUNT_ORDER
                            , src.CUSTOMER_MARKUP_GROUP_ID
                            , src.DEFAULT_DIMENSION
                            , src.DELIVERY_MODE_ID
                            , src.DELIVERY_TERM_ID
                            , src.CONFIGURATION_ID
                            , src.INTRA_STAT_TRANSACTION_CODE
                            , src.INVENTORY_DIMENSION_ID
                            , src.ITEM_ID
                            , src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                            , src.RECORD_ID_LOCATION_INVOICE_ADDRESS
                            , src.SALES_GROUP_ID
                            , src.SALES_LINE_DISCOUNT_GROUP_ID
                            , src.SALES_POOL_ID
                            , src.SALES_PRICE_GROUP_ID
                            , src.SHIPPING_CARRIER_ID
                            , src.UNIT_OF_MEASURE_CODE_SALES
                            , src.WAREHOUSE_ID
                            , src.RECORD_ID_SALES_RESPONSIBLE
                            , src.RECORD_ID_SALES_TAKER
                            , src.DOCUMENT_STATUS
                            , src.FLOOR_SAMPLE_TYPE
                            , src.HEADER_RETURN_STATUS
                            , src.HEADER_SALES_STATUS
                            , src.RETURN_STATUS
                            , src.SALES_STATUS
                            , src.SALES_TYPE
                            , src.SHIP_CARRIER_DELIVERY_TYPE
                            , src.TRADE_LINE_DELIVERY_TYPE
                            , src.IS_AT_AGENT_TRANSACTION
                            , src.IS_BLIND_SHIPMENT
                            , src.IS_EXPEDITED_SHIPMENT
                            , src.IS_FLOOR_SAMPLE_DISCOUNT
                            , src.IS_ITEM_TRANSACTION
                            , src.IS_LINE_DELIVERY_COMPLETE
                            , src.IS_ORDER_BLOCKED
                            , src.IS_ORDER_LINE_BLOCKED
                            , src.IS_ORDER_LOCKED
                            , src.IS_RETURNED_ITEM_SCRAP
                            , src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                            , src.IS_STOCKED_PRODUCT
                            , src.DROP_SHIPMENT
                            , src.ITEM_STATUS
                            , src.DELIVERY_DATE
                            , src.DHL_DELIVERY_DATE
                            , src.DOCUMENT_DATE
                            , src.SALES_LINE_CONFIRMED_SHIPPING_DATE
                            , src.SALES_LINE_REQUESTED_SHIPPING_DATE
                            , src.SHIP_DATE
                            , src.BILL_OF_LADING_ID
                            , src.CARRIER_ID
                            , src.CARRIER_NAME
                            , src.INTERNAL_PACKING_SLIP_ID
                            , src.INVENTORY_TRANSACTION_ID
                            , src.LEGAL_ENTITY
                            , src.LEDGER_VOUCHER
                            , src.LINE_NUMBER
                            , src.ORIGINAL_SALES_ORDER_ID
                            , src.PACKING_SLIP_ID
                            , src.PURCHASE_ORDER_ID
                            , src.SALES_ORDER_ID
                            , src.INVENTORY_QUANTITY
                            , src.RECEIPT_QUANTITY
                            , src.PRICE_UNIT
                            , src.AMOUNT_COMPANY_CURRENCY
                            , src.TRACKING_NUMBER
                            , src.DELIVERY_STATUS
                            , src.EBC_OVERRIDE_STATUS
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.BUSINESS_UNIT_ID, ''~'', src.CAMPAIGN_ID, ''~'', src.CUSTOMER_ACCOUNT_INVOICE, ''~'', src.CUSTOMER_ACCOUNT_ORDER, ''~'', src.CUSTOMER_MARKUP_GROUP_ID, ''~'', src.DEFAULT_DIMENSION, ''~'', src.DELIVERY_MODE_ID, ''~'', src.DELIVERY_TERM_ID, ''~'', src.CONFIGURATION_ID, ''~'', src.INTRA_STAT_TRANSACTION_CODE, ''~'', src.INVENTORY_DIMENSION_ID, ''~'', src.ITEM_ID, ''~'', to_char(src.RECORD_ID_LOCATION_DELIVERY_ADDRESS), ''~'', to_char(src.RECORD_ID_LOCATION_INVOICE_ADDRESS), ''~'', src.SALES_GROUP_ID, ''~'', src.SALES_LINE_DISCOUNT_GROUP_ID, ''~'', src.SALES_POOL_ID, ''~'', src.SALES_PRICE_GROUP_ID, ''~'', src.SHIPPING_CARRIER_ID, ''~'', src.UNIT_OF_MEASURE_CODE_SALES, ''~'', src.WAREHOUSE_ID, ''~'', to_char(src.RECORD_ID_SALES_RESPONSIBLE), ''~'', to_char(src.RECORD_ID_SALES_TAKER), ''~'', src.DOCUMENT_STATUS, ''~'', src.FLOOR_SAMPLE_TYPE, ''~'', src.HEADER_RETURN_STATUS, ''~'', src.HEADER_SALES_STATUS, ''~'', src.RETURN_STATUS, ''~'', src.SALES_STATUS, ''~'', src.SALES_TYPE, ''~'', src.SHIP_CARRIER_DELIVERY_TYPE, ''~'', src.TRADE_LINE_DELIVERY_TYPE, ''~'', src.IS_AT_AGENT_TRANSACTION, ''~'', src.IS_BLIND_SHIPMENT, ''~'', src.IS_EXPEDITED_SHIPMENT, ''~'', src.IS_FLOOR_SAMPLE_DISCOUNT, ''~'', src.IS_ITEM_TRANSACTION, ''~'', src.IS_LINE_DELIVERY_COMPLETE, ''~'', src.IS_ORDER_BLOCKED, ''~'', src.IS_ORDER_LINE_BLOCKED, ''~'', src.IS_ORDER_LOCKED, ''~'', src.IS_RETURNED_ITEM_SCRAP, ''~'', src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE, ''~'', src.IS_STOCKED_PRODUCT, ''~'', src.DROP_SHIPMENT, ''~'', src.ITEM_STATUS, ''~'', to_char(src.DELIVERY_DATE, ''yyyymmdd''), ''~'', to_char(src.DHL_DELIVERY_DATE, ''yyyymmdd''), ''~'', to_char(src.DOCUMENT_DATE, ''yyyymmdd''), ''~'', to_char(src.SALES_LINE_CONFIRMED_SHIPPING_DATE, ''yyyymmdd''), ''~'', to_char(src.SALES_LINE_REQUESTED_SHIPPING_DATE, ''yyyymmdd''), ''~'', to_char(src.SHIP_DATE, ''yyyymmdd''), ''~'', src.BILL_OF_LADING_ID, ''~'', src.CARRIER_ID, ''~'', src.CARRIER_NAME, ''~'', src.INTERNAL_PACKING_SLIP_ID, ''~'', src.INVENTORY_TRANSACTION_ID, ''~'', src.LEGAL_ENTITY, ''~'', src.LEDGER_VOUCHER, ''~'', to_char(src.LINE_NUMBER), ''~'', src.ORIGINAL_SALES_ORDER_ID, ''~'', src.PACKING_SLIP_ID, ''~'', src.PURCHASE_ORDER_ID, ''~'', src.SALES_ORDER_ID, ''~'', to_char(src.INVENTORY_QUANTITY), ''~'', to_char(src.RECEIPT_QUANTITY), ''~'', to_char(src.PRICE_UNIT), ''~'', to_char(src.AMOUNT_COMPANY_CURRENCY), ''~'', src.TRACKING_NUMBER, ''~'', src.DELIVERY_STATUS, ''~'', src.EBC_OVERRIDE_STATUS) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            prep01.FACT_SALES_DELIVERIES_KEY
                            , prep01.SOURCE_NAME
                            , prep01.RECORD_ID
                            , prep01.DIM_SOURCE_SYSTEM_KEY
                            , case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , prep01.DELIVERY_DATE_DIM_DATE_KEY
                            , case when prep01.DELIVERY_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DELIVERY_DATE, ''yyyymmdd'')) END AS DELIVERY_DATE_DIM_DATE_SNKEY
                            , prep01.DHL_DELIVERY_DATE_DIM_DATE_KEY
                            , case when prep01.DHL_DELIVERY_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DHL_DELIVERY_DATE, ''yyyymmdd'')) END AS DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                            , prep01.DOCUMENT_DATE_DIM_DATE_KEY
                            , case when prep01.DOCUMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
                            , prep01.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                            , case when prep01.SALES_LINE_CONFIRMED_SHIPPING_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.SALES_LINE_CONFIRMED_SHIPPING_DATE, ''yyyymmdd'')) END AS SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                            , prep01.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                            , case when prep01.SALES_LINE_REQUESTED_SHIPPING_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.SALES_LINE_REQUESTED_SHIPPING_DATE, ''yyyymmdd'')) END AS SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                            , prep01.SHIP_DATE_DIM_DATE_KEY
                            , case when prep01.SHIP_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.SHIP_DATE, ''yyyymmdd'')) END AS SHIP_DATE_DIM_DATE_SNKEY
                            , prep01.DIM_BUSINESS_UNIT_KEY
                            , case when nvl(prep01.BUSINESS_UNIT_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.BUSINESS_UNIT_ID) END AS DIM_BUSINESS_UNIT_SNKEY
                            , prep01.DIM_CAMPAIGN_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CAMPAIGN_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CAMPAIGN_ID) END AS DIM_CAMPAIGN_SNKEY
                            , prep01.DIM_CUSTOMER_INVOICE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
							, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
							, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
									when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
								else DIM_CUSTOMER_INVOICE_SNKEY_RAW
								end as DIM_CUSTOMER_INVOICE_SNKEY
                            , prep01.DIM_CUSTOMER_ORDER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
							, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
							, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
									when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
								else DIM_CUSTOMER_ORDER_SNKEY_RAW
								end as DIM_CUSTOMER_ORDER_SNKEY
                            , prep01.DIM_CUSTOMER_MARKUP_GROUP_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_MARKUP_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_MARKUP_GROUP_ID) END AS DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            , prep01.DIM_DEFAULT_DIMENSION_KEY
                            , case when nvl(prep01.DEFAULT_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
                            , prep01.DIM_DELIVERY_MODE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_MODE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_MODE_ID) END AS DIM_DELIVERY_MODE_SNKEY
                            , prep01.DIM_DELIVERY_TERM_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_TERM_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_TERM_ID) END AS DIM_DELIVERY_TERM_SNKEY
                            , prep01.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CONFIGURATION_ID, '''') = '''' or nvl(prep01.ITEM_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CONFIGURATION_ID, ''~'', prep01.ITEM_ID) END AS DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            , prep01.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.INTRA_STAT_TRANSACTION_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INTRA_STAT_TRANSACTION_CODE) END AS DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            , prep01.DIM_INVENTORY_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.INVENTORY_DIMENSION_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INVENTORY_DIMENSION_ID) END AS DIM_INVENTORY_SNKEY
                            , prep01.DIM_ITEM_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.ITEM_ID, '''') = '''' then -2 else hash('''', ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.ITEM_ID) END AS DIM_ITEM_SNKEY
                            , prep01.DIM_LEGAL_ENTITY_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , prep01.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                            , case when nvl(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS)) END AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                            , prep01.DIM_LOCATION_INVOICE_ADDRESS_KEY
                            , case when nvl(prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS)) END AS DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                            , prep01.DIM_SALES_GROUP_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_GROUP_ID) END AS DIM_SALES_GROUP_SNKEY
                            , prep01.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_LINE_DISCOUNT_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_LINE_DISCOUNT_GROUP_ID) END AS DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            , prep01.DIM_SALES_ORDER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.ORIGINAL_SALES_ORDER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.ORIGINAL_SALES_ORDER_ID) END AS DIM_SALES_ORDER_SNKEY
                            , prep01.DIM_SALES_POOL_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_POOL_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_POOL_ID) END AS DIM_SALES_POOL_SNKEY
                            , prep01.DIM_SALES_PRICE_GROUP_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_PRICE_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_PRICE_GROUP_ID) END AS DIM_SALES_PRICE_GROUP_SNKEY
                            , prep01.DIM_SHIPPING_CARRIER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SHIPPING_CARRIER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SHIPPING_CARRIER_ID) END AS DIM_SHIPPING_CARRIER_SNKEY
                            , prep01.DIM_SHIPPING_CARRIER_PACKAGE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CARRIER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CARRIER_ID) END AS DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                            , prep01.DIM_UNIT_OF_MEASURE_SALES_KEY
                            , case when nvl(prep01.UNIT_OF_MEASURE_CODE_SALES, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.UNIT_OF_MEASURE_CODE_SALES) END AS DIM_UNIT_OF_MEASURE_SALES_SNKEY
                            , prep01.DIM_WAREHOUSE_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.WAREHOUSE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.WAREHOUSE_ID) END AS DIM_WAREHOUSE_SNKEY
                            , prep01.DIM_WORKER_SALES_RESPONSIBLE_KEY
                            , case when nvl(prep01.RECORD_ID_SALES_RESPONSIBLE, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_SALES_RESPONSIBLE)) END AS DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                            , prep01.DIM_WORKER_SALES_TAKER_KEY
                            , case when nvl(prep01.RECORD_ID_SALES_TAKER, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_SALES_TAKER)) END AS DIM_WORKER_SALES_TAKER_SNKEY
                            , prep01.BUSINESS_UNIT_ID
                            , prep01.CAMPAIGN_ID
                            , prep01.CUSTOMER_ACCOUNT_INVOICE
                            , prep01.CUSTOMER_ACCOUNT_ORDER
                            , prep01.CUSTOMER_MARKUP_GROUP_ID
                            , prep01.DEFAULT_DIMENSION
                            , prep01.DELIVERY_MODE_ID
                            , prep01.DELIVERY_TERM_ID
                            , prep01.CONFIGURATION_ID
                            , prep01.INTRA_STAT_TRANSACTION_CODE
                            , prep01.INVENTORY_DIMENSION_ID
                            , prep01.ITEM_ID
                            , prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                            , prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS
                            , prep01.SALES_GROUP_ID
                            , prep01.SALES_LINE_DISCOUNT_GROUP_ID
                            , prep01.SALES_POOL_ID
                            , prep01.SALES_PRICE_GROUP_ID
                            , prep01.SHIPPING_CARRIER_ID
                            , prep01.UNIT_OF_MEASURE_CODE_SALES
                            , prep01.WAREHOUSE_ID
                            , prep01.RECORD_ID_SALES_RESPONSIBLE
                            , prep01.RECORD_ID_SALES_TAKER
                            , prep01.DOCUMENT_STATUS
                            , prep01.SRC_FLOOR_SAMPLE_TYPE AS FLOOR_SAMPLE_TYPE
                            , prep01.HEADER_RETURN_STATUS
                            , prep01.HEADER_SALES_STATUS
                            , prep01.RETURN_STATUS
                            , prep01.SALES_STATUS
                            , prep01.SALES_TYPE
                            , prep01.SHIP_CARRIER_DELIVERY_TYPE
                            , prep01.TRADE_LINE_DELIVERY_TYPE
                            , prep01.IS_AT_AGENT_TRANSACTION
                            , prep01.IS_BLIND_SHIPMENT
                            , prep01.IS_EXPEDITED_SHIPMENT
                            , prep01.IS_FLOOR_SAMPLE_DISCOUNT
                            , prep01.IS_ITEM_TRANSACTION
                            , prep01.IS_LINE_DELIVERY_COMPLETE
                            , prep01.IS_ORDER_BLOCKED
                            , prep01.IS_ORDER_LINE_BLOCKED
                            , prep01.IS_ORDER_LOCKED
                            , prep01.IS_RETURNED_ITEM_SCRAP
                            , prep01.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                            , prep01.IS_STOCKED_PRODUCT
                            , prep01.DROP_SHIPMENT
                            , prep01.ITEM_STATUS
                            , prep01.DELIVERY_DATE
                            , prep01.DHL_DELIVERY_DATE
                            , prep01.DOCUMENT_DATE
                            , prep01.SALES_LINE_CONFIRMED_SHIPPING_DATE
                            , prep01.SALES_LINE_REQUESTED_SHIPPING_DATE
                            , prep01.SHIP_DATE
                            , prep01.BILL_OF_LADING_ID
                            , prep01.CARRIER_ID
                            , prep01.CARRIER_NAME
                            , prep01.INTERNAL_PACKING_SLIP_ID
                            , prep01.INVENTORY_TRANSACTION_ID
                            , prep01.LEGAL_ENTITY
                            , prep01.LEDGER_VOUCHER
                            , prep01.LINE_NUMBER
                            , prep01.ORIGINAL_SALES_ORDER_ID
                            , prep01.PACKING_SLIP_ID
                            , prep01.PURCHASE_ORDER_ID
                            , prep01.SALES_ORDER_ID
                            , prep01.INVENTORY_QUANTITY
                            , prep01.RECEIPT_QUANTITY
                            , prep01.PRICE_UNIT
                            , prep01.AMOUNT_COMPANY_CURRENCY
                            , prep01.TRACKING_NUMBER
                            , prep01.DELIVERY_STATUS
                            , prep01.EBC_OVERRIDE_STATUS
                            , prep01.HK_HASH_KEY
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
								DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
								DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DELIVERY_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                                src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                                src.SHIP_DATE_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_BUSINESS_UNIT d8 ON
                                src.DIM_BUSINESS_UNIT_SNKEY = d8.DIM_BUSINESS_UNIT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CAMPAIGN d9 ON
                                src.DIM_CAMPAIGN_SNKEY = d9.DIM_CAMPAIGN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d10 ON
                                src.DIM_CUSTOMER_INVOICE_SNKEY = d10.DIM_CUSTOMER_SNKEY
                                and src.DELIVERY_DATE >= d10.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.DELIVERY_DATE < d10.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d11 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d11.DIM_CUSTOMER_SNKEY
                                and src.DELIVERY_DATE >= d11.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.DELIVERY_DATE < d11.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_MARKUP_GROUP d12 ON
                                src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = d12.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d13 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d13.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d14 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d14.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d15 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d15.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_GLOBAL_TRADE_ITEM_NUMBER d16 ON
                                src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = d16.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INTRA_STAT_TRANSACTION_CODE d17 ON
                                src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = d17.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d18 ON
                                src.DIM_INVENTORY_SNKEY = d18.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d19 ON
                                src.DIM_ITEM_SNKEY = d19.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d20 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d20.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d21 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d21.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d22 ON
                                src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = d22.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_GROUP d23 ON
                                src.DIM_SALES_GROUP_SNKEY = d23.DIM_SALES_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_LINE_DISCOUNT_GROUP d24 ON
                                src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = d24.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d25 ON
                                src.DIM_SALES_ORDER_SNKEY = d25.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_POOL d26 ON
                                src.DIM_SALES_POOL_SNKEY = d26.DIM_SALES_POOL_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PRICE_GROUP d27 ON
                                src.DIM_SALES_PRICE_GROUP_SNKEY = d27.DIM_SALES_PRICE_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d28 ON
                                src.DIM_SHIPPING_CARRIER_SNKEY = d28.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d29 ON
                                src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY = d29.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_UNIT_OF_MEASURE d30 ON
                                src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = d30.DIM_UNIT_OF_MEASURE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d31 ON
                                src.DIM_WAREHOUSE_SNKEY = d31.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d32 ON
                                src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = d32.DIM_WORKER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d33 ON
                                src.DIM_WORKER_SALES_TAKER_SNKEY = d33.DIM_WORKER_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_DELIVERIES_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_SALES_DELIVERIES

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_SALES_DELIVERIES_KEY = tgt.FACT_SALES_DELIVERIES_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_SALES_DELIVERIES_KEY = tgt.FACT_SALES_DELIVERIES_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_KEY = src.DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_SNKEY = src.DELIVERY_DATE_DIM_DATE_SNKEY
                                    , tgt.DHL_DELIVERY_DATE_DIM_DATE_KEY = src.DHL_DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DHL_DELIVERY_DATE_DIM_DATE_SNKEY = src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY = src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY = src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                                    , tgt.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY = src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY = src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                                    , tgt.SHIP_DATE_DIM_DATE_KEY = src.SHIP_DATE_DIM_DATE_KEY
                                    , tgt.SHIP_DATE_DIM_DATE_SNKEY = src.SHIP_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_BUSINESS_UNIT_KEY = src.DIM_BUSINESS_UNIT_KEY
                                    , tgt.DIM_BUSINESS_UNIT_SNKEY = src.DIM_BUSINESS_UNIT_SNKEY
                                    , tgt.DIM_CAMPAIGN_KEY = src.DIM_CAMPAIGN_KEY
                                    , tgt.DIM_CAMPAIGN_SNKEY = src.DIM_CAMPAIGN_SNKEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.DIM_CUSTOMER_INVOICE_SNKEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_SNKEY = src.DIM_CUSTOMER_ORDER_SNKEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_KEY = src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_MODE_SNKEY = src.DIM_DELIVERY_MODE_SNKEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_DELIVERY_TERM_SNKEY = src.DIM_DELIVERY_TERM_SNKEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                    , tgt.DIM_INVENTORY_KEY = src.DIM_INVENTORY_KEY
                                    , tgt.DIM_INVENTORY_SNKEY = src.DIM_INVENTORY_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_KEY = src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                    , tgt.DIM_SALES_GROUP_KEY = src.DIM_SALES_GROUP_KEY
                                    , tgt.DIM_SALES_GROUP_SNKEY = src.DIM_SALES_GROUP_SNKEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_ORDER_SNKEY = src.DIM_SALES_ORDER_SNKEY
                                    , tgt.DIM_SALES_POOL_KEY = src.DIM_SALES_POOL_KEY
                                    , tgt.DIM_SALES_POOL_SNKEY = src.DIM_SALES_POOL_SNKEY
                                    , tgt.DIM_SALES_PRICE_GROUP_KEY = src.DIM_SALES_PRICE_GROUP_KEY
                                    , tgt.DIM_SALES_PRICE_GROUP_SNKEY = src.DIM_SALES_PRICE_GROUP_SNKEY
                                    , tgt.DIM_SHIPPING_CARRIER_KEY = src.DIM_SHIPPING_CARRIER_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_SNKEY = src.DIM_SHIPPING_CARRIER_SNKEY
                                    , tgt.DIM_SHIPPING_CARRIER_PACKAGE_KEY = src.DIM_SHIPPING_CARRIER_PACKAGE_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY = src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_KEY = src.DIM_UNIT_OF_MEASURE_SALES_KEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_SNKEY = src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WAREHOUSE_SNKEY = src.DIM_WAREHOUSE_SNKEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_KEY = src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                    , tgt.DIM_WORKER_SALES_TAKER_KEY = src.DIM_WORKER_SALES_TAKER_KEY
                                    , tgt.DIM_WORKER_SALES_TAKER_SNKEY = src.DIM_WORKER_SALES_TAKER_SNKEY
                                    , tgt.BUSINESS_UNIT_ID = src.BUSINESS_UNIT_ID
                                    , tgt.CAMPAIGN_ID = src.CAMPAIGN_ID
                                    , tgt.CUSTOMER_ACCOUNT_INVOICE = src.CUSTOMER_ACCOUNT_INVOICE
                                    , tgt.CUSTOMER_ACCOUNT_ORDER = src.CUSTOMER_ACCOUNT_ORDER
                                    , tgt.CUSTOMER_MARKUP_GROUP_ID = src.CUSTOMER_MARKUP_GROUP_ID
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.DELIVERY_MODE_ID = src.DELIVERY_MODE_ID
                                    , tgt.DELIVERY_TERM_ID = src.DELIVERY_TERM_ID
                                    , tgt.CONFIGURATION_ID = src.CONFIGURATION_ID
                                    , tgt.INTRA_STAT_TRANSACTION_CODE = src.INTRA_STAT_TRANSACTION_CODE
                                    , tgt.INVENTORY_DIMENSION_ID = src.INVENTORY_DIMENSION_ID
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.RECORD_ID_LOCATION_DELIVERY_ADDRESS = src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                    , tgt.RECORD_ID_LOCATION_INVOICE_ADDRESS = src.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                    , tgt.SALES_GROUP_ID = src.SALES_GROUP_ID
                                    , tgt.SALES_LINE_DISCOUNT_GROUP_ID = src.SALES_LINE_DISCOUNT_GROUP_ID
                                    , tgt.SALES_POOL_ID = src.SALES_POOL_ID
                                    , tgt.SALES_PRICE_GROUP_ID = src.SALES_PRICE_GROUP_ID
                                    , tgt.SHIPPING_CARRIER_ID = src.SHIPPING_CARRIER_ID
                                    , tgt.UNIT_OF_MEASURE_CODE_SALES = src.UNIT_OF_MEASURE_CODE_SALES
                                    , tgt.WAREHOUSE_ID = src.WAREHOUSE_ID
                                    , tgt.RECORD_ID_SALES_RESPONSIBLE = src.RECORD_ID_SALES_RESPONSIBLE
                                    , tgt.RECORD_ID_SALES_TAKER = src.RECORD_ID_SALES_TAKER
                                    , tgt.DOCUMENT_STATUS = src.DOCUMENT_STATUS
                                    , tgt.FLOOR_SAMPLE_TYPE = src.FLOOR_SAMPLE_TYPE
                                    , tgt.HEADER_RETURN_STATUS = src.HEADER_RETURN_STATUS
                                    , tgt.HEADER_SALES_STATUS = src.HEADER_SALES_STATUS
                                    , tgt.RETURN_STATUS = src.RETURN_STATUS
                                    , tgt.SALES_STATUS = src.SALES_STATUS
                                    , tgt.SALES_TYPE = src.SALES_TYPE
                                    , tgt.SHIP_CARRIER_DELIVERY_TYPE = src.SHIP_CARRIER_DELIVERY_TYPE
                                    , tgt.TRADE_LINE_DELIVERY_TYPE = src.TRADE_LINE_DELIVERY_TYPE
                                    , tgt.IS_AT_AGENT_TRANSACTION = src.IS_AT_AGENT_TRANSACTION
                                    , tgt.IS_BLIND_SHIPMENT = src.IS_BLIND_SHIPMENT
                                    , tgt.IS_EXPEDITED_SHIPMENT = src.IS_EXPEDITED_SHIPMENT
                                    , tgt.IS_FLOOR_SAMPLE_DISCOUNT = src.IS_FLOOR_SAMPLE_DISCOUNT
                                    , tgt.IS_ITEM_TRANSACTION = src.IS_ITEM_TRANSACTION
                                    , tgt.IS_LINE_DELIVERY_COMPLETE = src.IS_LINE_DELIVERY_COMPLETE
                                    , tgt.IS_ORDER_BLOCKED = src.IS_ORDER_BLOCKED
                                    , tgt.IS_ORDER_LINE_BLOCKED = src.IS_ORDER_LINE_BLOCKED
                                    , tgt.IS_ORDER_LOCKED = src.IS_ORDER_LOCKED
                                    , tgt.IS_RETURNED_ITEM_SCRAP = src.IS_RETURNED_ITEM_SCRAP
                                    , tgt.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE = src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                    , tgt.IS_STOCKED_PRODUCT = src.IS_STOCKED_PRODUCT
                                    , tgt.DROP_SHIPMENT = src.DROP_SHIPMENT
                                    , tgt.ITEM_STATUS = src.ITEM_STATUS
                                    , tgt.DELIVERY_DATE = src.DELIVERY_DATE
                                    , tgt.DHL_DELIVERY_DATE = src.DHL_DELIVERY_DATE
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.SALES_LINE_CONFIRMED_SHIPPING_DATE = src.SALES_LINE_CONFIRMED_SHIPPING_DATE
                                    , tgt.SALES_LINE_REQUESTED_SHIPPING_DATE = src.SALES_LINE_REQUESTED_SHIPPING_DATE
                                    , tgt.SHIP_DATE = src.SHIP_DATE
                                    , tgt.BILL_OF_LADING_ID = src.BILL_OF_LADING_ID
                                    , tgt.CARRIER_ID = src.CARRIER_ID
                                    , tgt.CARRIER_NAME = src.CARRIER_NAME
                                    , tgt.INTERNAL_PACKING_SLIP_ID = src.INTERNAL_PACKING_SLIP_ID
                                    , tgt.INVENTORY_TRANSACTION_ID = src.INVENTORY_TRANSACTION_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.LEDGER_VOUCHER = src.LEDGER_VOUCHER
                                    , tgt.LINE_NUMBER = src.LINE_NUMBER
                                    , tgt.ORIGINAL_SALES_ORDER_ID = src.ORIGINAL_SALES_ORDER_ID
                                    , tgt.PACKING_SLIP_ID = src.PACKING_SLIP_ID
                                    , tgt.PURCHASE_ORDER_ID = src.PURCHASE_ORDER_ID
                                    , tgt.SALES_ORDER_ID = src.SALES_ORDER_ID
                                    , tgt.INVENTORY_QUANTITY = src.INVENTORY_QUANTITY
                                    , tgt.RECEIPT_QUANTITY = src.RECEIPT_QUANTITY
                                    , tgt.PRICE_UNIT = src.PRICE_UNIT
                                    , tgt.AMOUNT_COMPANY_CURRENCY = src.AMOUNT_COMPANY_CURRENCY
                                    , tgt.TRACKING_NUMBER = src.TRACKING_NUMBER
                                    , tgt.DELIVERY_STATUS = src.DELIVERY_STATUS
                                    , tgt.EBC_OVERRIDE_STATUS = src.EBC_OVERRIDE_STATUS
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                	FACT_SALES_DELIVERIES_KEY
                                	, SOURCE_NAME
                                	, RECORD_ID
                                	, DIM_SOURCE_SYSTEM_KEY
                                	, DIM_SOURCE_SYSTEM_SNKEY
                                	, DELIVERY_DATE_DIM_DATE_KEY
                                	, DELIVERY_DATE_DIM_DATE_SNKEY
                                	, DHL_DELIVERY_DATE_DIM_DATE_KEY
                                	, DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                                	, DOCUMENT_DATE_DIM_DATE_KEY
                                	, DOCUMENT_DATE_DIM_DATE_SNKEY
                                	, SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                                	, SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                                	, SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                                	, SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                                	, SHIP_DATE_DIM_DATE_KEY
                                	, SHIP_DATE_DIM_DATE_SNKEY
                                	, DIM_BUSINESS_UNIT_KEY
                                	, DIM_BUSINESS_UNIT_SNKEY
                                	, DIM_CAMPAIGN_KEY
                                	, DIM_CAMPAIGN_SNKEY
                                	, DIM_CUSTOMER_INVOICE_KEY
                                	, DIM_CUSTOMER_INVOICE_SNKEY
                                	, DIM_CUSTOMER_ORDER_KEY
                                	, DIM_CUSTOMER_ORDER_SNKEY
                                	, DIM_CUSTOMER_MARKUP_GROUP_KEY
                                	, DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                	, DIM_DEFAULT_DIMENSION_KEY
                                	, DIM_DEFAULT_DIMENSION_SNKEY
                                	, DIM_DELIVERY_MODE_KEY
                                	, DIM_DELIVERY_MODE_SNKEY
                                	, DIM_DELIVERY_TERM_KEY
                                	, DIM_DELIVERY_TERM_SNKEY
                                	, DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                	, DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                	, DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                	, DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                	, DIM_INVENTORY_KEY
                                	, DIM_INVENTORY_SNKEY
                                	, DIM_ITEM_KEY
                                	, DIM_ITEM_SNKEY
                                	, DIM_LEGAL_ENTITY_KEY
                                	, DIM_LEGAL_ENTITY_SNKEY
                                	, DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                	, DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                	, DIM_LOCATION_INVOICE_ADDRESS_KEY
                                	, DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                	, DIM_SALES_GROUP_KEY
                                	, DIM_SALES_GROUP_SNKEY
                                	, DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                	, DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                	, DIM_SALES_ORDER_KEY
                                	, DIM_SALES_ORDER_SNKEY
                                	, DIM_SALES_POOL_KEY
                                	, DIM_SALES_POOL_SNKEY
                                	, DIM_SALES_PRICE_GROUP_KEY
                                	, DIM_SALES_PRICE_GROUP_SNKEY
                                	, DIM_SHIPPING_CARRIER_KEY
                                	, DIM_SHIPPING_CARRIER_SNKEY
                                	, DIM_SHIPPING_CARRIER_PACKAGE_KEY
                                	, DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                                	, DIM_UNIT_OF_MEASURE_SALES_KEY
                                	, DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                	, DIM_WAREHOUSE_KEY
                                	, DIM_WAREHOUSE_SNKEY
                                	, DIM_WORKER_SALES_RESPONSIBLE_KEY
                                	, DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                	, DIM_WORKER_SALES_TAKER_KEY
                                	, DIM_WORKER_SALES_TAKER_SNKEY
                                	, BUSINESS_UNIT_ID
                                	, CAMPAIGN_ID
                                	, CUSTOMER_ACCOUNT_INVOICE
                                	, CUSTOMER_ACCOUNT_ORDER
                                	, CUSTOMER_MARKUP_GROUP_ID
                                	, DEFAULT_DIMENSION
                                	, DELIVERY_MODE_ID
                                	, DELIVERY_TERM_ID
                                	, CONFIGURATION_ID
                                	, INTRA_STAT_TRANSACTION_CODE
                                	, INVENTORY_DIMENSION_ID
                                	, ITEM_ID
                                	, RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                	, RECORD_ID_LOCATION_INVOICE_ADDRESS
                                	, SALES_GROUP_ID
                                	, SALES_LINE_DISCOUNT_GROUP_ID
                                	, SALES_POOL_ID
                                	, SALES_PRICE_GROUP_ID
                                	, SHIPPING_CARRIER_ID
                                	, UNIT_OF_MEASURE_CODE_SALES
                                	, WAREHOUSE_ID
                                	, RECORD_ID_SALES_RESPONSIBLE
                                	, RECORD_ID_SALES_TAKER
                                	, DOCUMENT_STATUS
                                	, FLOOR_SAMPLE_TYPE
                                	, HEADER_RETURN_STATUS
                                	, HEADER_SALES_STATUS
                                	, RETURN_STATUS
                                	, SALES_STATUS
                                	, SALES_TYPE
                                	, SHIP_CARRIER_DELIVERY_TYPE
                                	, TRADE_LINE_DELIVERY_TYPE
                                	, IS_AT_AGENT_TRANSACTION
                                	, IS_BLIND_SHIPMENT
                                	, IS_EXPEDITED_SHIPMENT
                                	, IS_FLOOR_SAMPLE_DISCOUNT
                                	, IS_ITEM_TRANSACTION
                                	, IS_LINE_DELIVERY_COMPLETE
                                	, IS_ORDER_BLOCKED
                                	, IS_ORDER_LINE_BLOCKED
                                	, IS_ORDER_LOCKED
                                	, IS_RETURNED_ITEM_SCRAP
                                	, IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                	, IS_STOCKED_PRODUCT
                                	, DROP_SHIPMENT
                                	, ITEM_STATUS
                                	, DELIVERY_DATE
                                	, DHL_DELIVERY_DATE
                                	, DOCUMENT_DATE
                                	, SALES_LINE_CONFIRMED_SHIPPING_DATE
                                	, SALES_LINE_REQUESTED_SHIPPING_DATE
                                	, SHIP_DATE
                                	, BILL_OF_LADING_ID
                                	, CARRIER_ID
                                	, CARRIER_NAME
                                	, INTERNAL_PACKING_SLIP_ID
                                	, INVENTORY_TRANSACTION_ID
                                	, LEGAL_ENTITY
                                	, LEDGER_VOUCHER
                                	, LINE_NUMBER
                                	, ORIGINAL_SALES_ORDER_ID
                                	, PACKING_SLIP_ID
                                	, PURCHASE_ORDER_ID
                                	, SALES_ORDER_ID
                                	, INVENTORY_QUANTITY
                                	, RECEIPT_QUANTITY
                                	, PRICE_UNIT
                                	, AMOUNT_COMPANY_CURRENCY
                                	, TRACKING_NUMBER
                                	, DELIVERY_STATUS
                                	, EBC_OVERRIDE_STATUS
                                	, HK_HASH_KEY
                                	, HK_SOURCE_NAME
                                	, HK_SOFT_DELETE_FLAG
                                	, HK_SOURCE_CREATED_TIMESTAMP
                                	, HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, HK_CREATED_JOB_RUN_ID
                                	, HK_LAST_UPDATED_JOB_RUN_ID
                                	, HK_CREATED_TIMESTAMP
                                	, HK_LAST_UPDATED_TIMESTAMP
                                	, HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                	src.FACT_SALES_DELIVERIES_KEY
                                	, src.SOURCE_NAME
                                	, src.RECORD_ID
                                	, src.DIM_SOURCE_SYSTEM_KEY
                                	, src.DIM_SOURCE_SYSTEM_SNKEY
                                	, src.DELIVERY_DATE_DIM_DATE_KEY
                                	, src.DELIVERY_DATE_DIM_DATE_SNKEY
                                	, src.DHL_DELIVERY_DATE_DIM_DATE_KEY
                                	, src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY
                                	, src.DOCUMENT_DATE_DIM_DATE_KEY
                                	, src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                	, src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                                	, src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY
                                	, src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                                	, src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY
                                	, src.SHIP_DATE_DIM_DATE_KEY
                                	, src.SHIP_DATE_DIM_DATE_SNKEY
                                	, src.DIM_BUSINESS_UNIT_KEY
                                	, src.DIM_BUSINESS_UNIT_SNKEY
                                	, src.DIM_CAMPAIGN_KEY
                                	, src.DIM_CAMPAIGN_SNKEY
                                	, src.DIM_CUSTOMER_INVOICE_KEY
                                	, src.DIM_CUSTOMER_INVOICE_SNKEY
                                	, src.DIM_CUSTOMER_ORDER_KEY
                                	, src.DIM_CUSTOMER_ORDER_SNKEY
                                	, src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                	, src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                	, src.DIM_DEFAULT_DIMENSION_KEY
                                	, src.DIM_DEFAULT_DIMENSION_SNKEY
                                	, src.DIM_DELIVERY_MODE_KEY
                                	, src.DIM_DELIVERY_MODE_SNKEY
                                	, src.DIM_DELIVERY_TERM_KEY
                                	, src.DIM_DELIVERY_TERM_SNKEY
                                	, src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                	, src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                	, src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                	, src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                	, src.DIM_INVENTORY_KEY
                                	, src.DIM_INVENTORY_SNKEY
                                	, src.DIM_ITEM_KEY
                                	, src.DIM_ITEM_SNKEY
                                	, src.DIM_LEGAL_ENTITY_KEY
                                	, src.DIM_LEGAL_ENTITY_SNKEY
                                	, src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                	, src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                	, src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                	, src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                	, src.DIM_SALES_GROUP_KEY
                                	, src.DIM_SALES_GROUP_SNKEY
                                	, src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                	, src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                	, src.DIM_SALES_ORDER_KEY
                                	, src.DIM_SALES_ORDER_SNKEY
                                	, src.DIM_SALES_POOL_KEY
                                	, src.DIM_SALES_POOL_SNKEY
                                	, src.DIM_SALES_PRICE_GROUP_KEY
                                	, src.DIM_SALES_PRICE_GROUP_SNKEY
                                	, src.DIM_SHIPPING_CARRIER_KEY
                                	, src.DIM_SHIPPING_CARRIER_SNKEY
                                	, src.DIM_SHIPPING_CARRIER_PACKAGE_KEY
                                	, src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY
                                	, src.DIM_UNIT_OF_MEASURE_SALES_KEY
                                	, src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                	, src.DIM_WAREHOUSE_KEY
                                	, src.DIM_WAREHOUSE_SNKEY
                                	, src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                	, src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                	, src.DIM_WORKER_SALES_TAKER_KEY
                                	, src.DIM_WORKER_SALES_TAKER_SNKEY
                                	, src.BUSINESS_UNIT_ID
                                	, src.CAMPAIGN_ID
                                	, src.CUSTOMER_ACCOUNT_INVOICE
                                	, src.CUSTOMER_ACCOUNT_ORDER
                                	, src.CUSTOMER_MARKUP_GROUP_ID
                                	, src.DEFAULT_DIMENSION
                                	, src.DELIVERY_MODE_ID
                                	, src.DELIVERY_TERM_ID
                                	, src.CONFIGURATION_ID
                                	, src.INTRA_STAT_TRANSACTION_CODE
                                	, src.INVENTORY_DIMENSION_ID
                                	, src.ITEM_ID
                                	, src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                	, src.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                	, src.SALES_GROUP_ID
                                	, src.SALES_LINE_DISCOUNT_GROUP_ID
                                	, src.SALES_POOL_ID
                                	, src.SALES_PRICE_GROUP_ID
                                	, src.SHIPPING_CARRIER_ID
                                	, src.UNIT_OF_MEASURE_CODE_SALES
                                	, src.WAREHOUSE_ID
                                	, src.RECORD_ID_SALES_RESPONSIBLE
                                	, src.RECORD_ID_SALES_TAKER
                                	, src.DOCUMENT_STATUS
                                	, src.FLOOR_SAMPLE_TYPE
                                	, src.HEADER_RETURN_STATUS
                                	, src.HEADER_SALES_STATUS
                                	, src.RETURN_STATUS
                                	, src.SALES_STATUS
                                	, src.SALES_TYPE
                                	, src.SHIP_CARRIER_DELIVERY_TYPE
                                	, src.TRADE_LINE_DELIVERY_TYPE
                                	, src.IS_AT_AGENT_TRANSACTION
                                	, src.IS_BLIND_SHIPMENT
                                	, src.IS_EXPEDITED_SHIPMENT
                                	, src.IS_FLOOR_SAMPLE_DISCOUNT
                                	, src.IS_ITEM_TRANSACTION
                                	, src.IS_LINE_DELIVERY_COMPLETE
                                	, src.IS_ORDER_BLOCKED
                                	, src.IS_ORDER_LINE_BLOCKED
                                	, src.IS_ORDER_LOCKED
                                	, src.IS_RETURNED_ITEM_SCRAP
                                	, src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                	, src.IS_STOCKED_PRODUCT
                                	, src.DROP_SHIPMENT
                                	, src.ITEM_STATUS
                                	, src.DELIVERY_DATE
                                	, src.DHL_DELIVERY_DATE
                                	, src.DOCUMENT_DATE
                                	, src.SALES_LINE_CONFIRMED_SHIPPING_DATE
                                	, src.SALES_LINE_REQUESTED_SHIPPING_DATE
                                	, src.SHIP_DATE
                                	, src.BILL_OF_LADING_ID
                                	, src.CARRIER_ID
                                	, src.CARRIER_NAME
                                	, src.INTERNAL_PACKING_SLIP_ID
                                	, src.INVENTORY_TRANSACTION_ID
                                	, src.LEGAL_ENTITY
                                	, src.LEDGER_VOUCHER
                                	, src.LINE_NUMBER
                                	, src.ORIGINAL_SALES_ORDER_ID
                                	, src.PACKING_SLIP_ID
                                	, src.PURCHASE_ORDER_ID
                                	, src.SALES_ORDER_ID
                                	, src.INVENTORY_QUANTITY
                                	, src.RECEIPT_QUANTITY
                                	, src.PRICE_UNIT
                                	, src.AMOUNT_COMPANY_CURRENCY
                                	, src.TRACKING_NUMBER
                                	, src.DELIVERY_STATUS
                                	, src.EBC_OVERRIDE_STATUS
                                	, src.SRC_HK_HASH_KEY
                                	, src.HK_SOURCE_NAME
                                	, src.HK_SOFT_DELETE_FLAG
                                	, src.HK_SOURCE_CREATED_TIMESTAMP
                                	, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, src.HK_CREATED_JOB_RUN_ID
                                	, src.HK_LAST_UPDATED_JOB_RUN_ID
                                	, src.HK_CREATED_TIMESTAMP
                                	, src.HK_LAST_UPDATED_TIMESTAMP
                                	, src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
              a.FACT_SALES_DELIVERIES_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_DELIVERY_DATE_DIM_DATE_KEY
            , a.NEW_DHL_DELIVERY_DATE_DIM_DATE_KEY
            , a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
            , a.NEW_SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
            , a.NEW_SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
            , a.NEW_SHIP_DATE_DIM_DATE_KEY
            , a.NEW_DIM_BUSINESS_UNIT_KEY
            , a.NEW_DIM_CAMPAIGN_KEY
            , a.NEW_DIM_CUSTOMER_INVOICE_KEY
            , a.NEW_DIM_CUSTOMER_ORDER_KEY
            , a.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
            , a.NEW_DIM_DEFAULT_DIMENSION_KEY
            , a.NEW_DIM_DELIVERY_MODE_KEY
            , a.NEW_DIM_DELIVERY_TERM_KEY
            , a.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
            , a.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
            , a.NEW_DIM_INVENTORY_KEY
            , a.NEW_DIM_ITEM_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
            , a.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
            , a.NEW_DIM_SALES_GROUP_KEY
            , a.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
            , a.NEW_DIM_SALES_ORDER_KEY
            , a.NEW_DIM_SALES_POOL_KEY
            , a.NEW_DIM_SALES_PRICE_GROUP_KEY
            , a.NEW_DIM_SHIPPING_CARRIER_KEY
            , a.NEW_DIM_SHIPPING_CARRIER_PACKAGE_KEY
            , a.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
            , a.NEW_DIM_WAREHOUSE_KEY
            , a.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
            , a.NEW_DIM_WORKER_SALES_TAKER_KEY
        from (
            select 
                src.FACT_SALES_DELIVERIES_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.DELIVERY_DATE_DIM_DATE_KEY
                , src.DHL_DELIVERY_DATE_DIM_DATE_KEY
                , src.DOCUMENT_DATE_DIM_DATE_KEY
                , src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                , src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                , src.SHIP_DATE_DIM_DATE_KEY
                , src.DIM_BUSINESS_UNIT_KEY
                , src.DIM_CAMPAIGN_KEY
                , src.DIM_CUSTOMER_INVOICE_KEY
                , src.DIM_CUSTOMER_ORDER_KEY
                , src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                , src.DIM_DEFAULT_DIMENSION_KEY
                , src.DIM_DELIVERY_MODE_KEY
                , src.DIM_DELIVERY_TERM_KEY
                , src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                , src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                , src.DIM_INVENTORY_KEY
                , src.DIM_ITEM_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                , src.DIM_SALES_GROUP_KEY
                , src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                , src.DIM_SALES_ORDER_KEY
                , src.DIM_SALES_POOL_KEY
                , src.DIM_SALES_PRICE_GROUP_KEY
                , src.DIM_SHIPPING_CARRIER_KEY
                , src.DIM_SHIPPING_CARRIER_PACKAGE_KEY
                , src.DIM_UNIT_OF_MEASURE_SALES_KEY
                , src.DIM_WAREHOUSE_KEY
                , src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                , src.DIM_WORKER_SALES_TAKER_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_DELIVERY_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_DHL_DELIVERY_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
                , nvl(d5.DIM_DATE_KEY, -1) AS NEW_SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                , nvl(d6.DIM_DATE_KEY, -1) AS NEW_SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                , nvl(d7.DIM_DATE_KEY, -1) AS NEW_SHIP_DATE_DIM_DATE_KEY
                , nvl(d8.DIM_BUSINESS_UNIT_KEY, -1) AS NEW_DIM_BUSINESS_UNIT_KEY
                , nvl(d9.DIM_CAMPAIGN_KEY, -1) AS NEW_DIM_CAMPAIGN_KEY
                , nvl(d10.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
                , nvl(d11.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
                , nvl(d12.DIM_CUSTOMER_MARKUP_GROUP_KEY, -1) AS NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
                , nvl(d13.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
                , nvl(d14.DIM_DELIVERY_MODE_KEY, -1) AS NEW_DIM_DELIVERY_MODE_KEY
                , nvl(d15.DIM_DELIVERY_TERM_KEY, -1) AS NEW_DIM_DELIVERY_TERM_KEY
                , nvl(d16.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY, -1) AS NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                , nvl(d17.DIM_INTRA_STAT_TRANSACTION_CODE_KEY, -1) AS NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                , nvl(d18.DIM_INVENTORY_KEY, -1) AS NEW_DIM_INVENTORY_KEY
                , nvl(d19.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                , nvl(d20.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d21.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , nvl(d22.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
                , nvl(d23.DIM_SALES_GROUP_KEY, -1) AS NEW_DIM_SALES_GROUP_KEY
                , nvl(d24.DIM_SALES_LINE_DISCOUNT_GROUP_KEY, -1) AS NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                , nvl(d25.DIM_SALES_ORDER_KEY, -1) AS NEW_DIM_SALES_ORDER_KEY
                , nvl(d26.DIM_SALES_POOL_KEY, -1) AS NEW_DIM_SALES_POOL_KEY
                , nvl(d27.DIM_SALES_PRICE_GROUP_KEY, -1) AS NEW_DIM_SALES_PRICE_GROUP_KEY
                , nvl(d28.DIM_SHIPPING_CARRIER_KEY, -1) AS NEW_DIM_SHIPPING_CARRIER_KEY
                , nvl(d29.DIM_SHIPPING_CARRIER_KEY, -1) AS NEW_DIM_SHIPPING_CARRIER_PACKAGE_KEY
                , nvl(d30.DIM_UNIT_OF_MEASURE_KEY, -1) AS NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
                , nvl(d31.DIM_WAREHOUSE_KEY, -1) AS NEW_DIM_WAREHOUSE_KEY
                , nvl(d32.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
                , nvl(d33.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_SALES_TAKER_KEY
            from ' || :tgt_db || '.global.FACT_SALES_DELIVERIES src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DELIVERY_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                                src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                                src.SHIP_DATE_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_BUSINESS_UNIT d8 ON
                                src.DIM_BUSINESS_UNIT_SNKEY = d8.DIM_BUSINESS_UNIT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CAMPAIGN d9 ON
                                src.DIM_CAMPAIGN_SNKEY = d9.DIM_CAMPAIGN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d10 ON
                                src.DIM_CUSTOMER_INVOICE_SNKEY = d10.DIM_CUSTOMER_SNKEY
                                and src.DELIVERY_DATE >= d10.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.DELIVERY_DATE < d10.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d11 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d11.DIM_CUSTOMER_SNKEY
                                and src.DELIVERY_DATE >= d11.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.DELIVERY_DATE < d11.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_MARKUP_GROUP d12 ON
                                src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = d12.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d13 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d13.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d14 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d14.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d15 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d15.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_GLOBAL_TRADE_ITEM_NUMBER d16 ON
                                src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = d16.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INTRA_STAT_TRANSACTION_CODE d17 ON
                                src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = d17.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d18 ON
                                src.DIM_INVENTORY_SNKEY = d18.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d19 ON
                                src.DIM_ITEM_SNKEY = d19.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d20 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d20.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d21 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d21.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d22 ON
                                src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = d22.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_GROUP d23 ON
                                src.DIM_SALES_GROUP_SNKEY = d23.DIM_SALES_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_LINE_DISCOUNT_GROUP d24 ON
                                src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = d24.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d25 ON
                                src.DIM_SALES_ORDER_SNKEY = d25.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_POOL d26 ON
                                src.DIM_SALES_POOL_SNKEY = d26.DIM_SALES_POOL_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PRICE_GROUP d27 ON
                                src.DIM_SALES_PRICE_GROUP_SNKEY = d27.DIM_SALES_PRICE_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d28 ON
                                src.DIM_SHIPPING_CARRIER_SNKEY = d28.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d29 ON
                                src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY = d29.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_UNIT_OF_MEASURE d30 ON
                                src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = d30.DIM_UNIT_OF_MEASURE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d31 ON
                                src.DIM_WAREHOUSE_SNKEY = d31.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d32 ON
                                src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = d32.DIM_WORKER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d33 ON
                                src.DIM_WORKER_SALES_TAKER_SNKEY = d33.DIM_WORKER_SNKEY
            where 1=1
            and (
                (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                or (src.DELIVERY_DATE_DIM_DATE_KEY = -1 and src.DELIVERY_DATE_DIM_DATE_SNKEY != -1)
                or (src.DHL_DELIVERY_DATE_DIM_DATE_KEY = -1 and src.DHL_DELIVERY_DATE_DIM_DATE_SNKEY != -1)
                or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
                or (src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY = -1 and src.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_SNKEY != -1)
                or (src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY = -1 and src.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_SNKEY != -1)
                or (src.SHIP_DATE_DIM_DATE_KEY = -1 and src.SHIP_DATE_DIM_DATE_SNKEY != -1)
                or (src.DIM_BUSINESS_UNIT_KEY = -1 and src.DIM_BUSINESS_UNIT_SNKEY != -1)
                or (src.DIM_CAMPAIGN_KEY = -1 and src.DIM_CAMPAIGN_SNKEY != -1)
                or (src.DIM_CUSTOMER_INVOICE_KEY = -1 and src.DIM_CUSTOMER_INVOICE_SNKEY != -1)
                or (src.DIM_CUSTOMER_ORDER_KEY = -1 and src.DIM_CUSTOMER_ORDER_SNKEY != -1)
                or (src.DIM_CUSTOMER_MARKUP_GROUP_KEY = -1 and src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY != -1)
                or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
                or (src.DIM_DELIVERY_MODE_KEY = -1 and src.DIM_DELIVERY_MODE_SNKEY != -1)
                or (src.DIM_DELIVERY_TERM_KEY = -1 and src.DIM_DELIVERY_TERM_SNKEY != -1)
                or (src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = -1 and src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY != -1)
                or (src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = -1 and src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY != -1)
                or (src.DIM_INVENTORY_KEY = -1 and src.DIM_INVENTORY_SNKEY != -1)
                or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
                or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                or (src.DIM_LOCATION_DELIVERY_ADDRESS_KEY = -1 and src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY != -1)
                or (src.DIM_LOCATION_INVOICE_ADDRESS_KEY = -1 and src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY != -1)
                or (src.DIM_SALES_GROUP_KEY = -1 and src.DIM_SALES_GROUP_SNKEY != -1)
                or (src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = -1 and src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY != -1)
                or (src.DIM_SALES_ORDER_KEY = -1 and src.DIM_SALES_ORDER_SNKEY != -1)
                or (src.DIM_SALES_POOL_KEY = -1 and src.DIM_SALES_POOL_SNKEY != -1)
                or (src.DIM_SALES_PRICE_GROUP_KEY = -1 and src.DIM_SALES_PRICE_GROUP_SNKEY != -1)
                or (src.DIM_SHIPPING_CARRIER_KEY = -1 and src.DIM_SHIPPING_CARRIER_SNKEY != -1)
                or (src.DIM_SHIPPING_CARRIER_PACKAGE_KEY = -1 and src.DIM_SHIPPING_CARRIER_PACKAGE_SNKEY != -1)
                or (src.DIM_UNIT_OF_MEASURE_SALES_KEY = -1 and src.DIM_UNIT_OF_MEASURE_SALES_SNKEY != -1)
                or (src.DIM_WAREHOUSE_KEY = -1 and src.DIM_WAREHOUSE_SNKEY != -1)
                or (src.DIM_WORKER_SALES_RESPONSIBLE_KEY = -1 and src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY != -1)
                or (src.DIM_WORKER_SALES_TAKER_KEY = -1 and src.DIM_WORKER_SALES_TAKER_SNKEY != -1)
                )
            ) a
        where 1=1
        and (
        (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
        or (a.DELIVERY_DATE_DIM_DATE_KEY != a.NEW_DELIVERY_DATE_DIM_DATE_KEY)
        or (a.DHL_DELIVERY_DATE_DIM_DATE_KEY != a.NEW_DHL_DELIVERY_DATE_DIM_DATE_KEY)
        or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
        or (a.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY != a.NEW_SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY)
        or (a.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY != a.NEW_SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY)
        or (a.SHIP_DATE_DIM_DATE_KEY != a.NEW_SHIP_DATE_DIM_DATE_KEY)
        or (a.DIM_BUSINESS_UNIT_KEY != a.NEW_DIM_BUSINESS_UNIT_KEY)
        or (a.DIM_CAMPAIGN_KEY != a.NEW_DIM_CAMPAIGN_KEY)
        or (a.DIM_CUSTOMER_INVOICE_KEY != a.NEW_DIM_CUSTOMER_INVOICE_KEY)
        or (a.DIM_CUSTOMER_ORDER_KEY != a.NEW_DIM_CUSTOMER_ORDER_KEY)
        or (a.DIM_CUSTOMER_MARKUP_GROUP_KEY != a.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY)
        or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
        or (a.DIM_DELIVERY_MODE_KEY != a.NEW_DIM_DELIVERY_MODE_KEY)
        or (a.DIM_DELIVERY_TERM_KEY != a.NEW_DIM_DELIVERY_TERM_KEY)
        or (a.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY != a.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY)
        or (a.DIM_INTRA_STAT_TRANSACTION_CODE_KEY != a.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY)
        or (a.DIM_INVENTORY_KEY != a.NEW_DIM_INVENTORY_KEY)
        or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
        or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
        or (a.DIM_LOCATION_DELIVERY_ADDRESS_KEY != a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY)
        or (a.DIM_LOCATION_INVOICE_ADDRESS_KEY != a.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY)
        or (a.DIM_SALES_GROUP_KEY != a.NEW_DIM_SALES_GROUP_KEY)
        or (a.DIM_SALES_LINE_DISCOUNT_GROUP_KEY != a.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY)
        or (a.DIM_SALES_ORDER_KEY != a.NEW_DIM_SALES_ORDER_KEY)
        or (a.DIM_SALES_POOL_KEY != a.NEW_DIM_SALES_POOL_KEY)
        or (a.DIM_SALES_PRICE_GROUP_KEY != a.NEW_DIM_SALES_PRICE_GROUP_KEY)
        or (a.DIM_SHIPPING_CARRIER_KEY != a.NEW_DIM_SHIPPING_CARRIER_KEY)
        or (a.DIM_SHIPPING_CARRIER_PACKAGE_KEY != a.NEW_DIM_SHIPPING_CARRIER_PACKAGE_KEY)
        or (a.DIM_UNIT_OF_MEASURE_SALES_KEY != a.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY)
        or (a.DIM_WAREHOUSE_KEY != a.NEW_DIM_WAREHOUSE_KEY)
        or (a.DIM_WORKER_SALES_RESPONSIBLE_KEY != a.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY)
        or (a.DIM_WORKER_SALES_TAKER_KEY != a.NEW_DIM_WORKER_SALES_TAKER_KEY)
            )
        ;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_SALES_DELIVERIES_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_SNKEY
				, a.NEW_DIM_CUSTOMER_INVOICE_KEY
				, a.NEW_DIM_CUSTOMER_INVOICE_SNKEY
			from (select src.FACT_SALES_DELIVERIES_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
						else DIM_CUSTOMER_ORDER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_ORDER_SNKEY
					, src.DIM_CUSTOMER_ORDER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
					
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
					, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
							when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
						else DIM_CUSTOMER_INVOICE_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_INVOICE_SNKEY
					, src.DIM_CUSTOMER_INVOICE_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
				from ' || :tgt_db || '.global.FACT_SALES_DELIVERIES src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.DELIVERY_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.DELIVERY_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
				
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
					DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
					DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d17 ON
					NEW_DIM_CUSTOMER_INVOICE_SNKEY = d17.DIM_CUSTOMER_SNKEY and
					src.DELIVERY_DATE >= d17.HK_EFFECTIVE_START_TIMESTAMP and
					src.DELIVERY_DATE < d17.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_ORDER_SNKEY != NEW_DIM_CUSTOMER_ORDER_SNKEY
				or src.DIM_CUSTOMER_ORDER_KEY != NEW_DIM_CUSTOMER_ORDER_KEY
				or src.DIM_CUSTOMER_INVOICE_SNKEY != NEW_DIM_CUSTOMER_INVOICE_SNKEY
				or src.DIM_CUSTOMER_INVOICE_KEY != NEW_DIM_CUSTOMER_INVOICE_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;


        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_SALES_DELIVERIES_KEY = tgt.FACT_SALES_DELIVERIES_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_KEY = src.NEW_DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DHL_DELIVERY_DATE_DIM_DATE_KEY = src.NEW_DHL_DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY = src.NEW_SALES_LINE_CONFIRMED_SHIPPING_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY = src.NEW_SALES_LINE_REQUESTED_SHIPPING_DATE_DIM_DATE_KEY
                                    , tgt.SHIP_DATE_DIM_DATE_KEY = src.NEW_SHIP_DATE_DIM_DATE_KEY
                                    , tgt.DIM_BUSINESS_UNIT_KEY = src.NEW_DIM_BUSINESS_UNIT_KEY
                                    , tgt.DIM_CAMPAIGN_KEY = src.NEW_DIM_CAMPAIGN_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_KEY = src.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.NEW_DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.NEW_DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = src.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = src.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                    , tgt.DIM_INVENTORY_KEY = src.NEW_DIM_INVENTORY_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_KEY = src.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
                                    , tgt.DIM_SALES_GROUP_KEY = src.NEW_DIM_SALES_GROUP_KEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = src.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.NEW_DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_POOL_KEY = src.NEW_DIM_SALES_POOL_KEY
                                    , tgt.DIM_SALES_PRICE_GROUP_KEY = src.NEW_DIM_SALES_PRICE_GROUP_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_KEY = src.NEW_DIM_SHIPPING_CARRIER_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_PACKAGE_KEY = src.NEW_DIM_SHIPPING_CARRIER_PACKAGE_KEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_KEY = src.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.NEW_DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_KEY = src.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
                                    , tgt.DIM_WORKER_SALES_TAKER_KEY = src.NEW_DIM_WORKER_SALES_TAKER_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_SALES_DELIVERIES_KEY = tgt.FACT_SALES_DELIVERIES_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_ORDER_SNKEY = src.NEW_DIM_CUSTOMER_ORDER_SNKEY
									, tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
									, tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.NEW_DIM_CUSTOMER_INVOICE_SNKEY
									, tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_customer);

		LET c5 CURSOR FOR res;

        LET key_fix_count_customer INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_customer := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;