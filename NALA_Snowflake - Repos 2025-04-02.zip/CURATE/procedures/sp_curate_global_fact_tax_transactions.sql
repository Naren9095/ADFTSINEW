/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_TAX_TRANSACTIONS
    CREATED BY     : Joshua Mills
    CREATED ON     : 08/08/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_TAX_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_TAX_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_TAX_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'TAXTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_TAX_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TAX_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_TAX_TRANSACTIONS_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_KEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_TAX_KEY
                                , 0 AS DIM_TAX_SNKEY
                                , 0 AS DIM_TAX_GROUP_KEY
                                , 0 AS DIM_TAX_GROUP_SNKEY
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(src.TAXCODE, '''') AS TAX_ID
                                , nvl(src.TAXGROUP, '''') AS TAX_GROUP_ID
                                , case when nvl(src.TRANSDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.TRANSDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.TRANSDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.TRANSDATE END AS TRANSACTION_DATE
                                , nvl(src.INVENTTRANSID, '''') AS INVENTORY_TRANSACTION_ID
                                , nvl(src.INVOICEID, '''') AS INVOICE_ID
                                , nvl(src.JOURNALNUM, '''') AS JOURNAL_NUMBER
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.VOUCHER, '''') AS VOUCHER
                                , nvl(src.TAXAMOUNT, 0) AS TAX_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.TAXAMOUNTCUR, 0) AS TAX_AMOUNT_SETTLEMENT_CURRENCY
                                , nvl(src.TAXBASEAMOUNT, 0) AS BASE_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.TAXBASEAMOUNTCUR, 0) AS BASE_AMOUNT_SETTLEMENT_CURRENCY
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                on src.HK_SOURCE_NAME = tgt.SOURCE_NAME and src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TAX_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TAX_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_TAX_TRANSACTIONS_KEY
                            , src.SOURCE_NAME
                            , src.RECORD_ID
                            , case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.TRANSACTION_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS TRANSACTION_DATE_DIM_DATE_KEY
                            , src.TRANSACTION_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d3.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                            , src.DIM_CURRENCY_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d4.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_TAX_SNKEY = -2 then -2 else nvl(d5.DIM_TAX_KEY, -1) END AS DIM_TAX_KEY
                            , src.DIM_TAX_SNKEY
                            , case when src.DIM_TAX_GROUP_SNKEY = -2 then -2 else nvl(d6.DIM_TAX_GROUP_KEY, -1) END AS DIM_TAX_GROUP_KEY
                            , src.DIM_TAX_GROUP_SNKEY
                            , src.CURRENCY_CODE
                            , src.TAX_ID
                            , src.TAX_GROUP_ID
                            , src.TRANSACTION_DATE
                            , src.INVENTORY_TRANSACTION_ID
                            , src.INVOICE_ID
                            , src.JOURNAL_NUMBER
                            , src.LEGAL_ENTITY
                            , src.VOUCHER
                            , src.TAX_AMOUNT_TRANSACTION_CURRENCY
                            , src.TAX_AMOUNT_SETTLEMENT_CURRENCY
                            , src.BASE_AMOUNT_TRANSACTION_CURRENCY
                            , src.BASE_AMOUNT_SETTLEMENT_CURRENCY
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.CURRENCY_CODE, ''~'', src.TAX_ID, ''~'', src.TAX_GROUP_ID, ''~'', to_char(src.TRANSACTION_DATE, ''yyyymmdd''), ''~'', src.INVENTORY_TRANSACTION_ID, ''~'', src.INVOICE_ID, ''~'', src.JOURNAL_NUMBER, ''~'', src.LEGAL_ENTITY, ''~'', src.VOUCHER, ''~'', to_char(src.TAX_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.TAX_AMOUNT_SETTLEMENT_CURRENCY), ''~'', to_char(src.BASE_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.BASE_AMOUNT_SETTLEMENT_CURRENCY)) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            FACT_TAX_TRANSACTIONS_KEY
                            , SOURCE_NAME
                            , RECORD_ID
                            , DIM_SOURCE_SYSTEM_KEY
                            , case when SOURCE_NAME = '''' then -2 else hash(SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , TRANSACTION_DATE_DIM_DATE_KEY
                            , case when TRANSACTION_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(TRANSACTION_DATE, ''yyyymmdd'')) END AS TRANSACTION_DATE_DIM_DATE_SNKEY
                            , DIM_CURRENCY_KEY
                            , case when nvl(CURRENCY_CODE, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                            , DIM_LEGAL_ENTITY_KEY
                            , case when nvl(LEGAL_ENTITY, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , DIM_TAX_KEY
                            , case when nvl(LEGAL_ENTITY, '''') = '''' or nvl(TAX_ID, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', TAX_ID) END AS DIM_TAX_SNKEY
                            , DIM_TAX_GROUP_KEY
                            , case when nvl(LEGAL_ENTITY, '''') = '''' or nvl(TAX_GROUP_ID, '''') = '''' then -2 else hash(SOURCE_NAME, ''~'', LEGAL_ENTITY, ''~'', TAX_GROUP_ID) END AS DIM_TAX_GROUP_SNKEY
                            , CURRENCY_CODE
                            , TAX_ID
                            , TAX_GROUP_ID
                            , TRANSACTION_DATE
                            , INVENTORY_TRANSACTION_ID
                            , INVOICE_ID
                            , JOURNAL_NUMBER
                            , LEGAL_ENTITY
                            , VOUCHER
                            , TAX_AMOUNT_TRANSACTION_CURRENCY
                            , TAX_AMOUNT_SETTLEMENT_CURRENCY
                            , BASE_AMOUNT_TRANSACTION_CURRENCY
                            , BASE_AMOUNT_SETTLEMENT_CURRENCY
                            , HK_HASH_KEY
                            , HK_SOURCE_NAME
                            , HK_SOFT_DELETE_FLAG
                            , HK_SOURCE_CREATED_TIMESTAMP
                            , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , HK_CREATED_JOB_RUN_ID
                            , HK_LAST_UPDATED_JOB_RUN_ID
                            , HK_CREATED_TIMESTAMP
                            , HK_LAST_UPDATED_TIMESTAMP
                            , HK_WAREHOUSE_ID
                            , TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ') src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.TRANSACTION_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d3 ON
                                src.DIM_CURRENCY_SNKEY = d3.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d4 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d4.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX d5 ON
                                src.DIM_TAX_SNKEY = d5.DIM_TAX_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d6 ON
                                src.DIM_TAX_GROUP_SNKEY = d6.DIM_TAX_GROUP_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TAX_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_TAX_TRANSACTIONS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_TAX_TRANSACTIONS_KEY = tgt.FACT_TAX_TRANSACTIONS_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_TAX_TRANSACTIONS_KEY = tgt.FACT_TAX_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_SNKEY = src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_TAX_KEY = src.DIM_TAX_KEY
                                    , tgt.DIM_TAX_SNKEY = src.DIM_TAX_SNKEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.DIM_TAX_GROUP_KEY
                                    , tgt.DIM_TAX_GROUP_SNKEY = src.DIM_TAX_GROUP_SNKEY
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.TAX_ID = src.TAX_ID
                                    , tgt.TAX_GROUP_ID = src.TAX_GROUP_ID
                                    , tgt.TRANSACTION_DATE = src.TRANSACTION_DATE
                                    , tgt.INVENTORY_TRANSACTION_ID = src.INVENTORY_TRANSACTION_ID
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.JOURNAL_NUMBER = src.JOURNAL_NUMBER
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.VOUCHER = src.VOUCHER
                                    , tgt.TAX_AMOUNT_TRANSACTION_CURRENCY = src.TAX_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.TAX_AMOUNT_SETTLEMENT_CURRENCY = src.TAX_AMOUNT_SETTLEMENT_CURRENCY
                                    , tgt.BASE_AMOUNT_TRANSACTION_CURRENCY = src.BASE_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.BASE_AMOUNT_SETTLEMENT_CURRENCY = src.BASE_AMOUNT_SETTLEMENT_CURRENCY
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                    FACT_TAX_TRANSACTIONS_KEY
                                    , SOURCE_NAME
                                    , RECORD_ID
                                    , DIM_SOURCE_SYSTEM_KEY
                                    , DIM_SOURCE_SYSTEM_SNKEY
                                    , TRANSACTION_DATE_DIM_DATE_KEY
                                    , TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , DIM_CURRENCY_KEY
                                    , DIM_CURRENCY_SNKEY
                                    , DIM_LEGAL_ENTITY_KEY
                                    , DIM_LEGAL_ENTITY_SNKEY
                                    , DIM_TAX_KEY
                                    , DIM_TAX_SNKEY
                                    , DIM_TAX_GROUP_KEY
                                    , DIM_TAX_GROUP_SNKEY
                                    , CURRENCY_CODE
                                    , TAX_ID
                                    , TAX_GROUP_ID
                                    , TRANSACTION_DATE
                                    , INVENTORY_TRANSACTION_ID
                                    , INVOICE_ID
                                    , JOURNAL_NUMBER
                                    , LEGAL_ENTITY
                                    , VOUCHER
                                    , TAX_AMOUNT_TRANSACTION_CURRENCY
                                    , TAX_AMOUNT_SETTLEMENT_CURRENCY
                                    , BASE_AMOUNT_TRANSACTION_CURRENCY
                                    , BASE_AMOUNT_SETTLEMENT_CURRENCY
                                    , HK_HASH_KEY
                                    , HK_SOURCE_NAME
                                    , HK_SOFT_DELETE_FLAG
                                    , HK_SOURCE_CREATED_TIMESTAMP
                                    , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , HK_CREATED_JOB_RUN_ID
                                    , HK_LAST_UPDATED_JOB_RUN_ID
                                    , HK_CREATED_TIMESTAMP
                                    , HK_LAST_UPDATED_TIMESTAMP
                                    , HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                    src.FACT_TAX_TRANSACTIONS_KEY
                                    , src.SOURCE_NAME
                                    , src.RECORD_ID
                                    , src.DIM_SOURCE_SYSTEM_KEY
                                    , src.DIM_SOURCE_SYSTEM_SNKEY
                                    , src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , src.DIM_CURRENCY_KEY
                                    , src.DIM_CURRENCY_SNKEY
                                    , src.DIM_LEGAL_ENTITY_KEY
                                    , src.DIM_LEGAL_ENTITY_SNKEY
                                    , src.DIM_TAX_KEY
                                    , src.DIM_TAX_SNKEY
                                    , src.DIM_TAX_GROUP_KEY
                                    , src.DIM_TAX_GROUP_SNKEY
                                    , src.CURRENCY_CODE
                                    , src.TAX_ID
                                    , src.TAX_GROUP_ID
                                    , src.TRANSACTION_DATE
                                    , src.INVENTORY_TRANSACTION_ID
                                    , src.INVOICE_ID
                                    , src.JOURNAL_NUMBER
                                    , src.LEGAL_ENTITY
                                    , src.VOUCHER
                                    , src.TAX_AMOUNT_TRANSACTION_CURRENCY
                                    , src.TAX_AMOUNT_SETTLEMENT_CURRENCY
                                    , src.BASE_AMOUNT_TRANSACTION_CURRENCY
                                    , src.BASE_AMOUNT_SETTLEMENT_CURRENCY
                                    , src.SRC_HK_HASH_KEY
                                    , src.HK_SOURCE_NAME
                                    , src.HK_SOFT_DELETE_FLAG
                                    , src.HK_SOURCE_CREATED_TIMESTAMP
                                    , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , src.HK_CREATED_JOB_RUN_ID
                                    , src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , src.HK_CREATED_TIMESTAMP
                                    , src.HK_LAST_UPDATED_TIMESTAMP
                                    , src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
            a.FACT_TAX_TRANSACTIONS_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_TRANSACTION_DATE_DIM_DATE_KEY
            , a.NEW_DIM_CURRENCY_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_TAX_KEY
            , a.NEW_DIM_TAX_GROUP_KEY
        from (
            select 
                src.FACT_TAX_TRANSACTIONS_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.TRANSACTION_DATE_DIM_DATE_KEY
                , src.DIM_CURRENCY_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_TAX_KEY
                , src.DIM_TAX_GROUP_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_TRANSACTION_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                , nvl(d4.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d5.DIM_TAX_KEY, -1) AS NEW_DIM_TAX_KEY
                , nvl(d6.DIM_TAX_GROUP_KEY, -1) AS NEW_DIM_TAX_GROUP_KEY
            from ' || :tgt_db || '.global.FACT_TAX_TRANSACTIONS src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.TRANSACTION_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d3 ON
                                src.DIM_CURRENCY_SNKEY = d3.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d4 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d4.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX d5 ON
                                src.DIM_TAX_SNKEY = d5.DIM_TAX_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d6 ON
                                src.DIM_TAX_GROUP_SNKEY = d6.DIM_TAX_GROUP_SNKEY
                where 1=1
                and (
                    (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                    or (src.TRANSACTION_DATE_DIM_DATE_KEY = -1 and src.TRANSACTION_DATE_DIM_DATE_SNKEY != -1)
                    or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
                    or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                    or (src.DIM_TAX_KEY = -1 and src.DIM_TAX_SNKEY != -1)
                    or (src.DIM_TAX_GROUP_KEY = -1 and src.DIM_TAX_GROUP_SNKEY != -1)
                    )
                ) a
            where 1=1
            and (
            (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
            or (a.TRANSACTION_DATE_DIM_DATE_KEY != a.NEW_TRANSACTION_DATE_DIM_DATE_KEY)
            or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
            or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
            or (a.DIM_TAX_KEY != a.NEW_DIM_TAX_KEY)
            or (a.DIM_TAX_GROUP_KEY != a.NEW_DIM_TAX_GROUP_KEY)
                )
            ;';
            EXECUTE IMMEDIATE :late_dim_select;

        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_TAX_TRANSACTIONS_KEY = tgt.FACT_TAX_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.NEW_TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_TAX_KEY = src.NEW_DIM_TAX_KEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.NEW_DIM_TAX_GROUP_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);
    
        --Logging stored procedure completed
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '11';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;