CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_SALES_INVOICES("TASK_KEY" NUMBER(38,0), "TASK_STEP_NUMBER" NUMBER(38,0), "TASK_INSTANCE_KEY" NUMBER(38,0), "JOB_ID" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_SALES_INVOICES';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'CUSTINVOICETRANS';
    LET src_tbl2 STRING := 'CUSTINVOICETRANS_STANDARDCOST';
    LET src_tbl3 STRINg := 'CUSTINVOICETRANS_COGSFIFO';
    LET src_tbl4 STRING := 'CUSTINVOICETRANS_COGSXLS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_SALES_INVOICES';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

     CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_SALES_INVOICES_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , src.DATAAREAID AS LEGAL_ENTITY
                                , src.ITEMID AS ITEM_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS DELIVERY_DATE_DIM_DATE_KEY
                                , 0 AS DELIVERY_DATE_DIM_DATE_SNKEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS DUE_DATE_DIM_DATE_KEY
                                , 0 AS DUE_DATE_DIM_DATE_SNKEY
                                , 0 AS INVOICE_DATE_DIM_DATE_KEY
                                , 0 AS INVOICE_DATE_DIM_DATE_SNKEY
                                , 0 AS MANUFACTURED_DATE_DIM_DATE_KEY
                                , 0 AS MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , 0 AS ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , 0 AS ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , 0 AS RELATED_ORDER_DATE_DIM_DATE_KEY
                                , 0 AS RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , 0 AS RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , 0 AS RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , 0 AS RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , 0 AS RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , 0 AS SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , 0 AS SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_BUSINESS_UNIT_KEY
                                , 0 AS DIM_BUSINESS_UNIT_SNKEY
                                , 0 AS DIM_CAMPAIGN_KEY
                                , 0 AS DIM_CAMPAIGN_SNKEY
                                , 0 AS DIM_COMMISSION_GROUP_KEY
                                , 0 AS DIM_COMMISSION_GROUP_SNKEY
                                , 0 AS DIM_COST_KEY
                                , 0 AS DIM_COST_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_CUSTOMER_INVOICE_KEY
                                , 0 AS DIM_CUSTOMER_INVOICE_SNKEY
                                , 0 AS DIM_CUSTOMER_ORDER_KEY
                                , 0 AS DIM_CUSTOMER_ORDER_SNKEY
                                , 0 AS DIM_CUSTOMER_GROUP_KEY
                                , 0 AS DIM_CUSTOMER_GROUP_SNKEY
                                , 0 AS DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , 0 AS DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                                , 0 AS DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , 0 AS DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , 0 AS DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , 0 AS DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , 0 AS DIM_INVENTORY_KEY
                                , 0 AS DIM_INVENTORY_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_ITEM_STATUS_KEY
                                , 0 AS DIM_ITEM_STATUS_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_LINE_RETURN_REASON_KEY
                                , 0 AS DIM_LINE_RETURN_REASON_SNKEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , 0 AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , 0 AS DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , 0 AS DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , 0 AS DIM_DELIVERY_MODE_KEY
                                , 0 AS DIM_DELIVERY_MODE_SNKEY
                                , 0 AS DIM_DELIVERY_TERM_KEY
                                , 0 AS DIM_DELIVERY_TERM_SNKEY
                                , 0 AS DIM_PAYMENT_TERMS_KEY
                                , 0 AS DIM_PAYMENT_TERMS_SNKEY
                                , 0 AS DIM_PROCUREMENT_CATEGORY_KEY
                                , 0 AS DIM_PROCUREMENT_CATEGORY_SNKEY
                                , 0 AS DIM_RETURN_DISPOSITION_KEY
                                , 0 AS DIM_RETURN_DISPOSITION_SNKEY
                                , 0 AS DIM_RETURN_REASON_KEY
                                , 0 AS DIM_RETURN_REASON_SNKEY
                                , 0 AS DIM_SALES_GROUP_KEY
                                , 0 AS DIM_SALES_GROUP_SNKEY
                                , 0 AS DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , 0 AS DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , 0 AS DIM_SALES_ORDER_KEY
                                , 0 AS DIM_SALES_ORDER_SNKEY
                                , 0 AS DIM_SALES_ORIGIN_KEY
                                , 0 AS DIM_SALES_ORIGIN_SNKEY
                                , 0 AS DIM_SALES_POOL_KEY
                                , 0 AS DIM_SALES_POOL_SNKEY
                                , 0 AS DIM_SALES_PRICE_GROUP_KEY
                                , 0 AS DIM_SALES_PRICE_GROUP_SNKEY
                                , 0 AS DIM_TAX_GROUP_KEY
                                , 0 AS DIM_TAX_GROUP_SNKEY
                                , 0 AS DIM_TAX_ITEM_GROUP_KEY
                                , 0 AS DIM_TAX_ITEM_GROUP_SNKEY
                                , 0 AS DIM_UNIT_OF_MEASURE_SALES_KEY
                                , 0 AS DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , 0 AS DIM_WAREHOUSE_KEY
                                , 0 AS DIM_WAREHOUSE_SNKEY
                                , 0 AS DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , 0 AS DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , 0 AS DIM_WORKER_SALES_TAKER_KEY
                                , 0 AS DIM_WORKER_SALES_TAKER_SNKEY
                                , 0 AS INVOICE_KEY
                                , nvl(src.DEFAULTDIMENSION_BUSINESS_UNIT, '''') AS BUSINESS_UNIT_ID
                                , nvl(src.SALESTABLE_SMMCAMPAIGNID, '''') AS CAMPAIGN_ID
                                , nvl(src.SALESTABLE_COMMISSIONGROUP, '''') AS COMMISSION_GROUP_ID
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(src.SALESTABLE_INVOICEACCOUNT, '''') AS CUSTOMER_ACCOUNT_INVOICE
                                , nvl(src.CUSTINVOICEJOUR_ORDERACCOUNT, '''') AS CUSTOMER_ACCOUNT_ORDER
                                , nvl(src.CUSTINVOICEJOUR_CUSTGROUP, '''') AS CUSTOMER_GROUP_ID
                                , nvl(src.SALESTABLE_MARKUPGROUP, '''') AS CUSTOMER_MARKUP_GROUP_ID
                                , nvl(to_char(src.DEFAULTDIMENSION), '''') AS DEFAULT_DIMENSION
                                , nvl(src.INVENTDIM1_CONFIGID, '''') AS CONFIGURATION_ID
                                , nvl(src.TRANSACTIONCODE, '''') AS INTRA_STAT_TRANSACTION_CODE
                                , nvl(src.INVENTDIMID, '''') AS INVENTORY_DIMENSION_ID
                                , nvl(src.PDMSTATUS_NAME, '''') AS ITEM_STATUS
                                , nvl(src.SALESLINE1_TPX_RETURNREASONCODEID, '''') AS LINE_RETURN_REASON_ID
                                , case when src.DATAAREAID in (''415'', ''740'') then nvl(left(src.SALESLINE1_TPX_RETURNREASONCODEID, 1), '''')
									else nvl(src.SALESTABLE_RETURNREASONCODEID, '''')
									end AS LINE_RETURN_REASON_GROUP_ID
                                , nvl(src.DELIVERYPOSTALADDRESS, 0) AS RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , nvl(src.CUSTINVOICEJOUR_INVOICEPOSTALADDRESS, 0) AS RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , nvl(src.MCRDLVMODE, '''') AS DELIVERY_MODE_ID
                                , nvl(src.CUSTINVOICEJOUR_DLVTERM, '''') AS DELIVERY_TERM_ID
                                , nvl(src.CUSTINVOICEJOUR_PAYMENT, '''') AS PAYMENT_TERMS_ID
                                , nvl(src.SALESCATEGORY, 0) AS PROCUREMENT_CATEGORY
                                , nvl(src.RETURNDISPOSITIONCODEID, '''') AS RETURN_DISPOSITION_ID
                                , nvl(src.CUSTINVOICEJOUR_RETURNREASONCODEID, '''') AS RETURN_REASON_ID
                                , nvl(src.SALESGROUP, '''') AS SALES_GROUP_ID
                                , nvl(src.SALESTABLE_LINEDISC, '''') AS SALES_LINE_DISCOUNT_GROUP_ID
                                , nvl(src.ORIGSALESID, '''') AS SALES_ORDER_ID
                                , nvl(src.CUSTINVOICEJOUR_SALESORIGINID, '''') AS SALES_ORIGIN_ID
                                , nvl(src.SALESTABLE_SALESPOOLID, '''') AS SALES_POOL_ID
                                , nvl(src.SALESTABLE_PRICEGROUPID, '''') AS SALES_PRICE_GROUP_ID
                                , nvl(src.TAXGROUP, '''') AS TAX_GROUP_ID
                                , nvl(src.TAXITEMGROUP, '''') AS TAX_ITEM_GROUP_ID
                                , nvl(src.SALESUNIT, '''') AS UNIT_OF_MEASURE_CODE_SALES
                                , nvl(src.CUSTINVOICEJOUR_INVENTLOCATIONID, '''') AS WAREHOUSE_ID
                                , nvl(src.SALESTABLE_WORKERSALESRESPONSIBLE, 0) AS RECORD_ID_SALES_RESPONSIBLE
                                , nvl(src.CUSTINVOICEJOUR_WORKERSALESTAKER, 0) AS RECORD_ID_SALES_TAKER
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_DOCUMENTSTATUS, '''') AS DOCUMENT_STATUS
                                , case when src.INVENTDIM1_CONFIGID = ''FLR'' and (src.LINEDISC <> 0 or src.LINEPERCENT <> 0) then ''Build and Discount''
										when src.INVENTDIM1_CONFIGID <> ''FLR'' and src.SALESTABLE_LINEDISC like ''%FLR%'' and src.LINEPERCENT <> 0 then ''Discount Only''
										when src.INVENTDIM1_CONFIGID = ''FLR'' and (src.LINEDISC = 0 or src.LINEPERCENT = 0) then ''Build Only''
									else ''Non Sample''
									end AS FLOOR_SAMPLE_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_RETURNSTATUSHEADER, '''') AS HEADER_RETURN_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_SALESSTATUSHEADER, '''') AS HEADER_SALES_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_RETURNSTATUSLINE, '''') AS RETURN_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE5_ENUMVALUELABEL_SALESSTATUSLINE, '''') AS SALES_STATUS
                                , nvl(src.TIMEXTENDERENUMTABLE6_ENUMVALUELABEL_SALESTYPE, '''') AS SALES_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE7_ENUMVALUELABEL_SHIPCARRIERDLVTYPE, '''') AS SHIP_CARRIER_DELIVERY_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE8_ENUMVALUELABEL_TRADELINEDLVTYPE, '''') AS TRADE_LINE_DELIVERY_TYPE
                                , case when nvl(src.SALESTABLE_ATAGENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_AT_AGENT_TRANSACTION
                                , case when nvl(src.SALESTABLE_SHIPCARRIERBLINDSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_BLIND_SHIPMENT
                                , case when nvl(src.SALESTABLE_SHIPCARRIEREXPEDIITEDSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_EXPEDITED_SHIPMENT
                                , case when FLOOR_SAMPLE_TYPE in (''Build and Discount'', ''Discount Only'') then ''Yes'' else ''No'' END AS IS_FLOOR_SAMPLE_DISCOUNT
                                , case when nvl(src.ITEMID, '''') != '''' then ''Yes'' else ''No'' END AS IS_ITEM_TRANSACTION
                                , case when nvl(src.SALESLINE1_COMPLETE, 0) = 1 then ''Yes'' else ''No'' END AS IS_LINE_DELIVERY_COMPLETE
                                , case when nvl(src.SALESTABLE_ORDERBLOCKED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_BLOCKED
                                , case when nvl(src.SALESLINE1_ORDERBLOCKED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_LINE_BLOCKED
                                , case when nvl(src.SALESTABLE_MCRORDERSTOPPED, 0) = 1 then ''Yes'' else ''No'' END AS IS_ORDER_LOCKED
                                , case when nvl(src.SALESLINE1_SCRAP, 0) = 1 then ''Yes'' else ''No'' END AS IS_RETURNED_ITEM_SCRAP
                                , case when nvl(src.SALESTABLE_SHIPCARRIERFUELSURCHARGE, 0) = 1 then ''Yes'' else ''No'' END AS IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , case when nvl(src.SALESLINE1_STOCKEDPRODUCT, 0) = 1 then ''Yes'' else ''No'' END AS IS_STOCKED_PRODUCT
                                , case when nvl(src.MCRSALESLINEDROPSHIPMENT_DROPSHIPMENT, 0) = 1 then ''Yes'' else ''No'' END AS DROP_SHIPMENT
                                , case when nvl(src.DLVDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.DLVDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.DLVDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.DLVDATE
									end as DELIVERY_DATE
								, case when nvl(src.CUSTINVOICEJOUR_DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.CUSTINVOICEJOUR_DOCUMENTDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.CUSTINVOICEJOUR_DOCUMENTDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.CUSTINVOICEJOUR_DOCUMENTDATE
									end as DOCUMENT_DATE
								, case when nvl(src.CUSTINVOICEJOUR_DUEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.CUSTINVOICEJOUR_DUEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.CUSTINVOICEJOUR_DUEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.CUSTINVOICEJOUR_DUEDATE
									end as DUE_DATE
								, case when nvl(src.INVOICEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.INVOICEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.INVOICEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.INVOICEDATE
									end as INVOICE_DATE
								, case when nvl(src.SALESLINE1_TPX_MANUFACTUREDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.SALESLINE1_TPX_MANUFACTUREDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.SALESLINE1_TPX_MANUFACTUREDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.SALESLINE1_TPX_MANUFACTUREDATE
									end as MANUFACTURED_DATE
								, case when nvl(src.SALESLINE2_CREATEDDATETIME, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.SALESLINE2_CREATEDDATETIME < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.SALESLINE2_CREATEDDATETIME > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else dateadd(minute, nvl(src.TIMEZONEINFO1_TIMEBIAS, 0) * -1, nvl(src.SALESLINE2_CREATEDDATETIME, ''1950-01-01''))
									end as ORIGINATING_ORDER_CREATED_DATE
								, case when nvl(src.SALESLINE1_TPX_RELATEDORDERDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.SALESLINE1_TPX_RELATEDORDERDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.SALESLINE1_TPX_RELATEDORDERDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.SALESLINE1_TPX_RELATEDORDERDATE
									end as RELATED_ORDER_DATE
								, case when nvl(src.RETURNARRIVALDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.RETURNARRIVALDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.RETURNARRIVALDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.RETURNARRIVALDATE
									end as RETURN_ARRIVAL_DATE
								, case when nvl(src.RETURNCLOSEDDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.RETURNCLOSEDDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.RETURNCLOSEDDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else src.RETURNCLOSEDDATE
									end as RETURN_CLOSED_DATE
								, case when nvl(src.SALESLINE1_CREATEDDATETIME, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
										when src.SALESLINE1_CREATEDDATETIME < dd1.MIN_DATE_VALUE then ''1951-12-31''
										when src.SALESLINE1_CREATEDDATETIME > dd1.MAX_DATE_VALUE then ''9951-12-31''
									else dateadd(minute, nvl(src.TIMEZONEINFO3_TIMEBIAS, 0) * -1, nvl(src.SALESLINE1_CREATEDDATETIME, ''1950-01-01''))
									end as SALES_LINE_CREATED_DATE
								, nvl(src.INVENTTRANSID, '''') AS INVENTORY_TRANSACTION_ID
                                , nvl(src.INVOICEID, '''') AS INVOICE_ID
                                , nvl(src.CUSTINVOICEJOUR_LEDGERVOUCHER, '''') AS LEDGER_VOUCHER
                                , nvl(src.LINENUM, 0) AS LINE_NUMBER
                                , nvl(src.ORIGSALESID, '''') AS ORIGINAL_SALES_ORDER_ID
                                , dateadd(second, nvl(src.SALESLINE1_TPX_PRODUCTIONTIME, 0), ''1900-01-01'')::TIMESTAMP_TZ AS PRODUCTION_TIME
                                , nvl(src.CUSTINVOICEJOUR_PURCHASEORDER, '''') AS PURCHASE_ORDER_ID
                                , nvl(src.SALESLINE2_SALESID, '''') AS ORIGINATING_ORDER_SALES_ID
                                , nvl(src.SALESLINE1_TPX_REGISTRYNUMBER, '''') AS REGISTRY_NUMBER
                                , nvl(src.INVENTQTY, 0) AS INVENTORY_QUANTITY
                                , nvl(src.QTY, 0) AS INVOICE_QUANTITY
                                , nvl(src.QTYPHYSICAL, 0) AS PHYSICAL_QUANTITY
                                , nvl(src.PRICEUNIT, 0) AS PRICE_UNIT
                                , nvl(src.SALESPRICE, 0) AS SALES_PRICE
                                , nvl(src.COMMISSAMOUNTCUR, 0) AS COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.COMMISSAMOUNTMST, 0) AS COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , nvl(src.LINEAMOUNT, 0) AS LINE_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.LINEAMOUNTMST, 0) AS LINE_AMOUNT_COMPANY_CURRENCY
                                , nvl(src.TAXAMOUNT, 0) AS TAX_AMOUNT_TRANSACTION_CURRENCY
                                , nvl(src.TAXAMOUNTMST, 0) AS TAX_AMOUNT_COMPANY_CURRENCY
                                , nvl(src.DISCPERCENT, 0) AS DISCOUNT_PERCENT
                                , nvl(src.DISCAMOUNT, 0) AS DISCOUNT_AMOUNT
                                , nvl(src.LINEDISC, 0) AS LINE_DISCOUNT
                                , nvl(src.LINEPERCENT, 0) AS LINE_DISCOUNT_PERCENT
                                , 0::NUMBER(25,16) AS FLOOR_LINE_DISCOUNT
                                , nvl(src.SUMLINEDISC, 0) AS LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , nvl(src.SUMLINEDISCMST, 0) AS LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , round(
									case when nvl(src.COGS_ITEMCOSTS1_STANDARDCOST, 0) != 0 then src.COGS_ITEMCOSTS1_STANDARDCOST
										else -- this is the STANDARD_COST calc:
										coalesce(src.INVENTITEMPRICE1_STANDARDCOST, src.INVENTITEMPRICE2_STANDARDCOST, src.INVENTITEMPRICE3_STANDARDCOST, src.INVENTITEMPRICE4_STANDARDCOST, 0)
										end
									, 4)::number(25,16) AS COST_OF_GOODS_SOLD
								, nvl(src.COGS_ITEMCOSTS1_FIXEDOVERHEAD, 0) AS FIXED_OVERHEAD
                                , nvl(src.COGS_ITEMCOSTS1_LABOR, 0) AS LABOR
                                , nvl(src.COGS_ITEMCOSTS1_MATERIAL, 0) AS MATERIAL
                                , nvl(src.COGS_ITEMCOSTS1_VARIABLE_OVERHEAD, 0) AS VARIABLE_OVERHEAD
                                , nvl(src.COGS_ITEMCOSTS2_FIXEDOVERHEAD, 0) AS FROZEN_FIXED_OVERHEAD
                                , nvl(src.COGS_ITEMCOSTS2_LABOR, 0) AS FROZEN_LABOR
                                , nvl(src.COGS_ITEMCOSTS2_MATERIAL, 0) AS FROZEN_MATERIAL
                                , case when nvl(src.COGS_ITEMCOSTS2_STANDARDCOST, 0) != 0 then src.COGS_ITEMCOSTS2_STANDARDCOST
									else -- this is the FROZEN_STANDARD_COST calc:
									coalesce(src.INVENTITEMPRICE6_STANDARDCOST, src.INVENTITEMPRICE7_STANDARDCOST, src.INVENTITEMPRICE8_STANDARDCOST, src.INVENTITEMPRICE9_STANDARDCOST, 0)
									end AS FROZEN_COST_OF_GOODS_SOLD
                                , nvl(src.COGS_ITEMCOSTS2_VARIABLE_OVERHEAD, 0) AS FROZEN_VARIABLE_OVERHEAD
                                , coalesce(src.INVENTITEMPRICE1_STANDARDCOST, src.INVENTITEMPRICE2_STANDARDCOST, src.INVENTITEMPRICE3_STANDARDCOST, src.INVENTITEMPRICE4_STANDARDCOST, 0) AS STANDARD_COST
                                , coalesce(src.INVENTITEMPRICE6_STANDARDCOST, src.INVENTITEMPRICE7_STANDARDCOST, src.INVENTITEMPRICE8_STANDARDCOST, src.INVENTITEMPRICE9_STANDARDCOST, 0) AS FROZEN_STANDARD_COST
                                , nvl(src.MCRSALESLINEPRICEOVERRIDE2_REASONCODE, '''') AS PRICE_OVERRIDE_REASON_CODE
                                , nvl(src.TPXPRICEOVERRIDEREASONTABLE_DESCRIPTION, '''') AS PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , NVL(case when src.HK_SOURCE_NAME = ''AXNALA'' and IS_FLOOR_SAMPLE_DISCOUNT = ''Yes'' and LINE_AMOUNT_TRANSACTION_CURRENCY = 0 then (LINE_AMOUNT_TRANSACTION_CURRENCY + LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY)   when src.HK_SOURCE_NAME = ''AXNALA'' and IS_FLOOR_SAMPLE_DISCOUNT = ''Yes'' and LINE_AMOUNT_TRANSACTION_CURRENCY <> 0 and LINE_DISCOUNT = 0 then (LINE_AMOUNT_TRANSACTION_CURRENCY + LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY - (INVOICE_QUANTITY * LINE_DISCOUNT))   when src.HK_SOURCE_NAME = ''AXNALA'' and IS_FLOOR_SAMPLE_DISCOUNT = ''Yes'' and LINE_AMOUNT_TRANSACTION_CURRENCY <> 0 and LINE_DISCOUNT <> 0 then (LINE_AMOUNT_TRANSACTION_CURRENCY + LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY)   when src.HK_SOURCE_NAME = ''AXNALA'' and IS_FLOOR_SAMPLE_DISCOUNT = ''No'' then LINE_AMOUNT_TRANSACTION_CURRENCY   when src.HK_SOURCE_NAME != ''AXNALA'' then LINE_AMOUNT_TRANSACTION_CURRENCY else nvl(LINE_AMOUNT_TRANSACTION_CURRENCY,0) END,0) AS ISLR
                                , abs(src.RECID) AS RECORD_ID_POS
                                , nvl(src.TIMEXTENDERENUMTABLE9_ENUMVALUELABEL_PRICETYPE, '''') AS PRICE_TYPE
                                , coalesce(src.INVENTITEMPRICE1_ACTIVATIONDATE, src.INVENTITEMPRICE2_ACTIVATIONDATE, src.INVENTITEMPRICE3_ACTIVATIONDATE, src.INVENTITEMPRICE4_ACTIVATIONDATE, ''1950-01-01'') AS ACTIVATION_DATE
                                , coalesce(src.INVENTITEMPRICE1_CREATEDDATETIME, src.INVENTITEMPRICE2_CREATEDDATETIME, src.INVENTITEMPRICE3_CREATEDDATETIME, src.INVENTITEMPRICE4_CREATEDDATETIME, ''1950-01-01 00:00:00'') AS CREATED_DATETIME
								, nvl(src.CUSTINVOICEJOUR_JOURNALNUM, '''') as JOURNAL_NUMBER
								, nvl(src.CUSTINVOICEJOUR_JOURNALNAME, '''') as JOURNAL_NAME
								, nvl(src.INVENTDIM1_INVENTSITEID, '''') as INVENTORY_SITE_ID
                                , nvl(src3.SALESLINE1_CURRENCYCODE,'''') AS COGSFIFO_CURRENCY_CODE
                                    , nvl(src3.SALESLINE1_SALESSTATUS,0) AS COGSFIFO_SALES_STATUS
                                    , nvl(src3.SALESLINE1_COSTPRICE,0) AS COGSFIFO_COST_PRICE
                                    , nvl(src3.SALESLINE1_SALESQTY,0) AS COGSFIFO_SALES_QTY
                                    , nvl(src3.LEDGER1_ACCOUNTINGCURRENCY,'''') AS COGSFIFO_ACCOUNTING_CURRENCY
                                    , nvl(src3.INVENTTRANS1_KITPARENTINVENTTRANSID,'''') AS COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                    , nvl(src3.INVENTTRANS1_KITBOMLEVEL,0) AS COGSFIFO_KIT_BOM_LEVEL
                                    , nvl(src3.INVENTTRANS1_COSTAMOUNTPOSTED,0) AS COGSFIFO_COST_AMOUNT_POSTED
                                    , nvl(src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT,0) AS COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                    , nvl(src3.INVENTTRANS1_KITIDENTIFIER,'''') AS COGSFIFO_KIT_IDENTIFIER
                                    , nvl(src3.EXCHANGERATE1_FROMCURRENCYCODE,'''') AS COGSFIFO_FROM_CURRENCY_CODE
                                    , nvl(src3.EXCHANGERATE1_TOCURRENCYCODE,'''') AS COGSFIFO_TO_CURRENCY_CODE
                                    , nvl(src3.EXCHANGERATE1_EXCHANGERATE,0) AS COGSFIFO_EXCHANGE_RATE
                                     , nvl(
                                        (case when nvl(src3.SALESLINE1_SALESSTATUS,0) <> 3 
                                            then (src3.SALESLINE1_COSTPRICE
                                                * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end)
                                                )
                                                * nvl(src3.SALESLINE1_SALESQTY, 0)
                                         else (case when (src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) is null
                                                then (src3.SALESLINE1_COSTPRICE 
                                                    * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                        then src3.EXCHANGERATE1_EXCHRATE
                                                        else 1
                                                        end)
                                                    ) * nvl(src3.SALESLINE1_SALESQTY, 0)
                                                else (((src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) * - 1) 
                                                * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end))
                                                end)
                                            end)
                                         ,0) as COGSFIFO_COST_OF_GOODS_SOLD
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            
                            
                            from (select cit1.HK_SOURCE_NAME, cit1.HK_JOB_RUN_ID, cit1.HK_CREATED_TIMESTAMP, cit1.HK_WAREHOUSE_ID, cit1.RECID, cit1.DATAAREAID, cit1.ITEMID, cit1.CURRENCYCODE, cit1.DEFAULTDIMENSION, cit1.TRANSACTIONCODE, cit1.INVENTDIMID, cit1.DELIVERYPOSTALADDRESS, cit1.MCRDLVMODE, cit1.SALESCATEGORY, cit1.RETURNDISPOSITIONCODEID, cit1.SALESGROUP, cit1.ORIGSALESID, cit1.TAXGROUP, cit1.TAXITEMGROUP, cit1.SALESUNIT, cit1.DLVDATE, cit1.INVOICEDATE, cit1.RETURNARRIVALDATE, cit1.RETURNCLOSEDDATE, cit1.INVENTTRANSID, cit1.INVOICEID, cit1.LINENUM, cit1.INVENTQTY, cit1.QTY, cit1.QTYPHYSICAL, cit1.PRICEUNIT, cit1.SALESPRICE, cit1.COMMISSAMOUNTCUR, cit1.COMMISSAMOUNTMST, cit1.LINEAMOUNT, cit1.LINEAMOUNTMST, cit1.TAXAMOUNT, cit1.TAXAMOUNTMST, cit1.DISCPERCENT, cit1.DISCAMOUNT, cit1.LINEDISC, cit1.LINEPERCENT, cit1.SUMLINEDISC, cit1.SUMLINEDISCMST, cit1.MODIFIEDDATETIME, cit1.DEFAULTDIMENSION_BUSINESS_UNIT, cit1.DEFAULTDIMENSION_MODIFIEDDATETIME, cit1.SALESTABLE_SMMCAMPAIGNID, cit1.SALESTABLE_COMMISSIONGROUP, cit1.SALESTABLE_INVOICEACCOUNT, cit1.SALESTABLE_MARKUPGROUP, cit1.SALESTABLE_RETURNREASONCODEID, cit1.SALESTABLE_LINEDISC, cit1.SALESTABLE_SALESPOOLID, cit1.SALESTABLE_PRICEGROUPID, cit1.SALESTABLE_WORKERSALESRESPONSIBLE, cit1.SALESTABLE_ATAGENT, cit1.SALESTABLE_SHIPCARRIERBLINDSHIPMENT, cit1.SALESTABLE_SHIPCARRIEREXPEDIITEDSHIPMENT, cit1.SALESTABLE_ORDERBLOCKED, cit1.SALESTABLE_MCRORDERSTOPPED, cit1.SALESTABLE_SHIPCARRIERFUELSURCHARGE, cit1.SALESTABLE_INVENTSITEID, cit1.SALESTABLE_MODIFIEDDATETIME, cit1.CUSTINVOICEJOUR_ORDERACCOUNT, cit1.CUSTINVOICEJOUR_CUSTGROUP, cit1.CUSTINVOICEJOUR_INVOICEPOSTALADDRESS, cit1.CUSTINVOICEJOUR_DLVTERM, cit1.CUSTINVOICEJOUR_PAYMENT, cit1.CUSTINVOICEJOUR_RETURNREASONCODEID, cit1.CUSTINVOICEJOUR_SALESORIGINID, cit1.CUSTINVOICEJOUR_INVENTLOCATIONID, cit1.CUSTINVOICEJOUR_WORKERSALESTAKER, cit1.CUSTINVOICEJOUR_DOCUMENTDATE, cit1.CUSTINVOICEJOUR_DUEDATE, cit1.CUSTINVOICEJOUR_LEDGERVOUCHER, cit1.CUSTINVOICEJOUR_PURCHASEORDER, cit1.CUSTINVOICEJOUR_MODIFIEDDATETIME, cit1.INVENTDIM1_CONFIGID, cit1.INVENTDIM1_INVENTSITEID, cit1.INVENTDIM1_MODIFIEDDATETIME, cit1.INVENTDIMCOMBINATION_PDMSTATUS, cit1.INVENTDIMCOMBINATION_MODIFIEDDATETIME, cit1.SALESLINE1_TPX_RETURNREASONCODEID, cit1.SALESLINE1_LINEDISC, cit1.SALESLINE1_LINEPERCENT, cit1.SALESLINE1_COMPLETE, cit1.SALESLINE1_ORDERBLOCKED, cit1.SALESLINE1_SCRAP, cit1.SALESLINE1_STOCKEDPRODUCT, cit1.SALESLINE1_TPX_MANUFACTUREDATE, cit1.SALESLINE1_TPX_RELATEDORDERDATE, cit1.SALESLINE1_CREATEDDATETIME, cit1.SALESLINE1_TPX_PRODUCTIONTIME, cit1.SALESLINE1_TPX_REGISTRYNUMBER, cit1.SALESLINE1_MODIFIEDDATETIME, cit1.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_DOCUMENTSTATUS, cit1.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_RETURNSTATUSHEADER, cit1.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_SALESSTATUSHEADER, cit1.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_RETURNSTATUSLINE, cit1.TIMEXTENDERENUMTABLE5_ENUMVALUELABEL_SALESSTATUSLINE, cit1.TIMEXTENDERENUMTABLE6_ENUMVALUELABEL_SALESTYPE, cit1.TIMEXTENDERENUMTABLE7_ENUMVALUELABEL_SHIPCARRIERDLVTYPE, cit1.TIMEXTENDERENUMTABLE8_ENUMVALUELABEL_TRADELINEDLVTYPE, cit1.MCRSALESLINEDROPSHIPMENT_DROPSHIPMENT, cit1.SALESLINE2_CREATEDDATETIME, cit1.SALESLINE2_INVENTDIMID, cit1.SALESLINE2_SALESID, cit1.SALESLINE2_MODIFIEDDATETIME, cit1.DATAAREA1_TIMEZONE, cit1.TIMEZONEINFO1_TIMEBIAS, cit1.DATAAREA3_TIMEZONE, cit1.TIMEZONEINFO3_TIMEBIAS, cit1.COGS_ITEMCOSTS1_STANDARDCOST, cit1.COGS_ITEMCOSTS1_FIXEDOVERHEAD, cit1.COGS_ITEMCOSTS1_LABOR, cit1.COGS_ITEMCOSTS1_MATERIAL, cit1.COGS_ITEMCOSTS1_VARIABLE_OVERHEAD, cit1.COGS_ITEMCOSTS1_MODIFIEDDATETIME, cit1.COGS_ITEMCOSTS2_STANDARDCOST, cit1.COGS_ITEMCOSTS2_FIXEDOVERHEAD, cit1.COGS_ITEMCOSTS2_LABOR, cit1.COGS_ITEMCOSTS2_MATERIAL, cit1.COGS_ITEMCOSTS2_VARIABLE_OVERHEAD, cit1.COGS_ITEMCOSTS2_MODIFIEDDATETIME
								, citsc1.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE1_STANDARDCOST
								, citsc2.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE2_STANDARDCOST
								, citsc3.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE3_STANDARDCOST
								, citsc4.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE4_STANDARDCOST
								, citsc6.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE6_STANDARDCOST
								, citsc7.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE7_STANDARDCOST
								, citsc8.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE8_STANDARDCOST
								, citsc9.INVENTITEMPRICE_STANDARDCOST as INVENTITEMPRICE9_STANDARDCOST
                                , citsc1.INVENTITEMPRICE_ACTIVATIONDATE AS INVENTITEMPRICE1_ACTIVATIONDATE
                                , citsc2.INVENTITEMPRICE_ACTIVATIONDATE AS INVENTITEMPRICE2_ACTIVATIONDATE
                                , citsc3.INVENTITEMPRICE_ACTIVATIONDATE AS INVENTITEMPRICE3_ACTIVATIONDATE
                                , citsc4.INVENTITEMPRICE_ACTIVATIONDATE AS INVENTITEMPRICE4_ACTIVATIONDATE
                                , citsc1.INVENTITEMPRICE_CREATEDDATETIME AS INVENTITEMPRICE1_CREATEDDATETIME
                                , citsc2.INVENTITEMPRICE_CREATEDDATETIME AS INVENTITEMPRICE2_CREATEDDATETIME
                                , citsc3.INVENTITEMPRICE_CREATEDDATETIME AS INVENTITEMPRICE3_CREATEDDATETIME
                                , citsc4.INVENTITEMPRICE_CREATEDDATETIME AS INVENTITEMPRICE4_CREATEDDATETIME
                                , cit1.TIMEXTENDERENUMTABLE9_ENUMVALUELABEL_PRICETYPE
								, cit1.MCRSALESLINEPRICEOVERRIDE1_RECID, cit1.MCRSALESLINEPRICEOVERRIDE2_REASONCODE, cit1.TPXPRICEOVERRIDEREASONTABLE_DESCRIPTION,
                                cit1.LATEST_MODIFIEDDATETIME
								, cit1.CUSTINVOICEJOUR_JOURNALNUM
								, cit1.CUSTINVOICEJOUR_JOURNALNAME
								, cit1.PDMSTATUS_NAME
							from ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' cit1
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc1 on
								citsc1.STANDARDCOST_SOURCE = ''iip1'' and
								cit1.RECID = citsc1.RECID and
								cit1.DATAAREAID = citsc1.DATAAREAID and
								cit1.ITEMID = citsc1.ITEMID and
								cit1.INVENTDIM1_CONFIGID = citsc1.INVENTDIM_CONFIGID and
								cit1.INVENTDIM1_INVENTSITEID = citsc1.INVENTDIM_INVENTSITEID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc2 on
								citsc2.STANDARDCOST_SOURCE = ''iip2'' and
								cit1.RECID = citsc2.RECID and
								cit1.DATAAREAID = citsc2.DATAAREAID and
								cit1.ITEMID = citsc2.ITEMID and
								cit1.INVENTDIM1_INVENTSITEID = citsc2.INVENTDIM_INVENTSITEID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc3 on
								citsc3.STANDARDCOST_SOURCE = ''iip3'' and
								cit1.RECID = citsc3.RECID and
								cit1.DATAAREAID = citsc3.DATAAREAID and
								cit1.ITEMID = citsc3.ITEMID and
								cit1.INVENTDIM1_CONFIGID = citsc3.INVENTDIM_CONFIGID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc4 on
								citsc4.STANDARDCOST_SOURCE = ''iip4'' and
								cit1.RECID = citsc4.RECID and
								cit1.DATAAREAID = citsc4.DATAAREAID and
								cit1.ITEMID = citsc4.ITEMID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc6 on
								citsc6.STANDARDCOST_SOURCE = ''iip6'' and
								cit1.DATAAREAID = citsc6.DATAAREAID and
								cit1.ITEMID = citsc6.ITEMID and
								cit1.INVENTDIM1_CONFIGID = citsc6.INVENTDIM_CONFIGID and
								cit1.INVENTDIM1_INVENTSITEID = citsc6.INVENTDIM_INVENTSITEID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc7 on
								citsc7.STANDARDCOST_SOURCE = ''iip7'' and
								cit1.DATAAREAID = citsc7.DATAAREAID and
								cit1.ITEMID = citsc7.ITEMID and
								cit1.INVENTDIM1_INVENTSITEID = citsc7.INVENTDIM_INVENTSITEID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc8 on
								citsc8.STANDARDCOST_SOURCE = ''iip8'' and
								cit1.DATAAREAID = citsc8.DATAAREAID and
								cit1.ITEMID = citsc8.ITEMID and
								cit1.INVENTDIM1_CONFIGID = citsc8.INVENTDIM_CONFIGID
							left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc9 on
								citsc9.STANDARDCOST_SOURCE = ''iip9'' and
								cit1.DATAAREAID = citsc9.DATAAREAID and
								cit1.ITEMID = citsc9.ITEMID
                    ) src
							left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt on
								src.HK_SOURCE_NAME = tgt.SOURCE_NAME and
								src.RECID = tgt.RECORD_ID and
								src.DATAAREAID = tgt.LEGAL_ENTITY and
								src.ITEMID = tgt.ITEM_ID
							inner join (select min(date_value) as MIN_DATE_VALUE
											, max(date_value) as MAX_DATE_VALUE
										from ' || :tgt_db || '.' || :tgt_schema || '.DIM_DATE 
										where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31'')) dd1 on
								1=1

                            LEFT JOIN ' || :src_db || '.' || :src_schema || '.' || :src_tbl3 || ' src3 on
                                src.DATAAREAID = src3.SALESLINE1_DATAAREAID
                                    and src.INVENTTRANSID = src3.SALESLINE1_INVENTTRANSID
                            
							where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        
        
        
        
        /*
        1.	Read data from first target/source/first working tables and write to second working table
        SOURCE:	CURATE internal table and RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01a_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_01_<YYYYMMDDHH24MISSFF3>_001a

        a.            should retrieve existing data where COGSFIFO_COSTOFGOODSSOLD is going to change
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1a';
    LET create_wrk_tbl1a STRING DEFAULT '';

   create_wrk_tbl1a := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01a_' || :CURR_FORMATTED_TIMESTAMP
     || ' as 
                            select
                                fsi1.FACT_SALES_INVOICES_KEY
                                , fsi1.SOURCE_NAME
                                , fsi1.RECORD_ID
                                , fsi1.LEGAL_ENTITY
                                , fsi1.ITEM_ID
                                , fsi1.DIM_SOURCE_SYSTEM_KEY
                                , fsi1.DIM_SOURCE_SYSTEM_SNKEY
                                , fsi1.DELIVERY_DATE_DIM_DATE_KEY
                                , fsi1.DELIVERY_DATE_DIM_DATE_SNKEY
                                , fsi1.DOCUMENT_DATE_DIM_DATE_KEY
                                , fsi1.DOCUMENT_DATE_DIM_DATE_SNKEY
                                , fsi1.DUE_DATE_DIM_DATE_KEY
                                , fsi1.DUE_DATE_DIM_DATE_SNKEY
                                , fsi1.INVOICE_DATE_DIM_DATE_KEY
                                , fsi1.INVOICE_DATE_DIM_DATE_SNKEY
                                , fsi1.MANUFACTURED_DATE_DIM_DATE_KEY
                                , fsi1.MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , fsi1.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , fsi1.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , fsi1.RELATED_ORDER_DATE_DIM_DATE_KEY
                                , fsi1.RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , fsi1.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , fsi1.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , fsi1.RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , fsi1.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , fsi1.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , fsi1.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , fsi1.DIM_BUSINESS_UNIT_KEY
                                , fsi1.DIM_BUSINESS_UNIT_SNKEY
                                , fsi1.DIM_CAMPAIGN_KEY
                                , fsi1.DIM_CAMPAIGN_SNKEY
                                , fsi1.DIM_COMMISSION_GROUP_KEY
                                , fsi1.DIM_COMMISSION_GROUP_SNKEY
                                , fsi1.DIM_COST_KEY
                                , fsi1.DIM_COST_SNKEY
                                , fsi1.DIM_CURRENCY_KEY
                                , fsi1.DIM_CURRENCY_SNKEY
                                , fsi1.DIM_CUSTOMER_INVOICE_KEY
                                , fsi1.DIM_CUSTOMER_INVOICE_SNKEY
                                , fsi1.DIM_CUSTOMER_ORDER_KEY
                                , fsi1.DIM_CUSTOMER_ORDER_SNKEY
                                , fsi1.DIM_CUSTOMER_GROUP_KEY
                                , fsi1.DIM_CUSTOMER_GROUP_SNKEY
                                , fsi1.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , fsi1.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , fsi1.DIM_DEFAULT_DIMENSION_KEY
                                , fsi1.DIM_DEFAULT_DIMENSION_SNKEY
                                , fsi1.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , fsi1.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , fsi1.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , fsi1.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , fsi1.DIM_INVENTORY_KEY
                                , fsi1.DIM_INVENTORY_SNKEY
                                , fsi1.DIM_ITEM_KEY
                                , fsi1.DIM_ITEM_SNKEY
                                , fsi1.DIM_ITEM_STATUS_KEY
                                , fsi1.DIM_ITEM_STATUS_SNKEY
                                , fsi1.DIM_LEGAL_ENTITY_KEY
                                , fsi1.DIM_LEGAL_ENTITY_SNKEY
                                , fsi1.DIM_LINE_RETURN_REASON_KEY
                                , fsi1.DIM_LINE_RETURN_REASON_SNKEY
                                , fsi1.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , fsi1.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , fsi1.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , fsi1.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , fsi1.DIM_DELIVERY_MODE_KEY
                                , fsi1.DIM_DELIVERY_MODE_SNKEY
                                , fsi1.DIM_DELIVERY_TERM_KEY
                                , fsi1.DIM_DELIVERY_TERM_SNKEY
                                , fsi1.DIM_PAYMENT_TERMS_KEY
                                , fsi1.DIM_PAYMENT_TERMS_SNKEY
                                , fsi1.DIM_PROCUREMENT_CATEGORY_KEY
                                , fsi1.DIM_PROCUREMENT_CATEGORY_SNKEY
                                , fsi1.DIM_RETURN_DISPOSITION_KEY
                                , fsi1.DIM_RETURN_DISPOSITION_SNKEY
                                , fsi1.DIM_RETURN_REASON_KEY
                                , fsi1.DIM_RETURN_REASON_SNKEY
                                , fsi1.DIM_SALES_GROUP_KEY
                                , fsi1.DIM_SALES_GROUP_SNKEY
                                , fsi1.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , fsi1.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , fsi1.DIM_SALES_ORDER_KEY
                                , fsi1.DIM_SALES_ORDER_SNKEY
                                , fsi1.DIM_SALES_ORIGIN_KEY
                                , fsi1.DIM_SALES_ORIGIN_SNKEY
                                , fsi1.DIM_SALES_POOL_KEY
                                , fsi1.DIM_SALES_POOL_SNKEY
                                , fsi1.DIM_SALES_PRICE_GROUP_KEY
                                , fsi1.DIM_SALES_PRICE_GROUP_SNKEY
                                , fsi1.DIM_TAX_GROUP_KEY
                                , fsi1.DIM_TAX_GROUP_SNKEY
                                , fsi1.DIM_TAX_ITEM_GROUP_KEY
                                , fsi1.DIM_TAX_ITEM_GROUP_SNKEY
                                , fsi1.DIM_UNIT_OF_MEASURE_SALES_KEY
                                , fsi1.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , fsi1.DIM_WAREHOUSE_KEY
                                , fsi1.DIM_WAREHOUSE_SNKEY
                                , fsi1.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , fsi1.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , fsi1.DIM_WORKER_SALES_TAKER_KEY
                                , fsi1.DIM_WORKER_SALES_TAKER_SNKEY
                                , fsi1.INVOICE_KEY
                                , fsi1.BUSINESS_UNIT_ID
                                , fsi1.CAMPAIGN_ID
                                , fsi1.COMMISSION_GROUP_ID
                                , fsi1.CURRENCY_CODE
                                , fsi1.CUSTOMER_ACCOUNT_INVOICE
                                , fsi1.CUSTOMER_ACCOUNT_ORDER
                                , fsi1.CUSTOMER_GROUP_ID
                                , fsi1.CUSTOMER_MARKUP_GROUP_ID
                                , fsi1.DEFAULT_DIMENSION
                                , fsi1.CONFIGURATION_ID
                                , fsi1.INTRA_STAT_TRANSACTION_CODE
                                , fsi1.INVENTORY_DIMENSION_ID
                                , fsi1.ITEM_STATUS
                                , fsi1.LINE_RETURN_REASON_ID
                                , fsi1.LINE_RETURN_REASON_GROUP_ID
                                , fsi1.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , fsi1.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , fsi1.DELIVERY_MODE_ID
                                , fsi1.DELIVERY_TERM_ID
                                , fsi1.PAYMENT_TERMS_ID
                                , fsi1.PROCUREMENT_CATEGORY
                                , fsi1.RETURN_DISPOSITION_ID
                                , fsi1.RETURN_REASON_ID
                                , fsi1.SALES_GROUP_ID
                                , fsi1.SALES_LINE_DISCOUNT_GROUP_ID
                                , fsi1.SALES_ORDER_ID
                                , fsi1.SALES_ORIGIN_ID
                                , fsi1.SALES_POOL_ID
                                , fsi1.SALES_PRICE_GROUP_ID
                                , fsi1.TAX_GROUP_ID
                                , fsi1.TAX_ITEM_GROUP_ID
                                , fsi1.UNIT_OF_MEASURE_CODE_SALES
                                , fsi1.WAREHOUSE_ID
                                , fsi1.RECORD_ID_SALES_RESPONSIBLE
                                , fsi1.RECORD_ID_SALES_TAKER
                                , fsi1.DOCUMENT_STATUS
                                , fsi1.FLOOR_SAMPLE_TYPE
                                , fsi1.HEADER_RETURN_STATUS
                                , fsi1.HEADER_SALES_STATUS
                                , fsi1.RETURN_STATUS
                                , fsi1.SALES_STATUS
                                , fsi1.SALES_TYPE
                                , fsi1.SHIP_CARRIER_DELIVERY_TYPE
                                , fsi1.TRADE_LINE_DELIVERY_TYPE
                                , fsi1.IS_AT_AGENT_TRANSACTION
                                , fsi1.IS_BLIND_SHIPMENT
                                , fsi1.IS_EXPEDITED_SHIPMENT
                                , fsi1.IS_FLOOR_SAMPLE_DISCOUNT
                                , fsi1.IS_ITEM_TRANSACTION
                                , fsi1.IS_LINE_DELIVERY_COMPLETE
                                , fsi1.IS_ORDER_BLOCKED
                                , fsi1.IS_ORDER_LINE_BLOCKED
                                , fsi1.IS_ORDER_LOCKED
                                , fsi1.IS_RETURNED_ITEM_SCRAP
                                , fsi1.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , fsi1.IS_STOCKED_PRODUCT
                                , fsi1.DROP_SHIPMENT
                                , fsi1.DELIVERY_DATE
								, fsi1.DOCUMENT_DATE
								, fsi1.DUE_DATE
								, fsi1.INVOICE_DATE
								, fsi1.MANUFACTURED_DATE
								, fsi1.ORIGINATING_ORDER_CREATED_DATE
								, fsi1.RELATED_ORDER_DATE
								, fsi1.RETURN_ARRIVAL_DATE
								, fsi1.RETURN_CLOSED_DATE
								, fsi1.SALES_LINE_CREATED_DATE
								, fsi1.INVENTORY_TRANSACTION_ID
                                , fsi1.INVOICE_ID
                                , fsi1.LEDGER_VOUCHER
                                , fsi1.LINE_NUMBER
                                , fsi1.ORIGINAL_SALES_ORDER_ID
                                , fsi1.PRODUCTION_TIME
                                , fsi1.PURCHASE_ORDER_ID
                                , fsi1.ORIGINATING_ORDER_SALES_ID
                                , fsi1.REGISTRY_NUMBER
                                , fsi1.INVENTORY_QUANTITY
                                , fsi1.INVOICE_QUANTITY
                                , fsi1.PHYSICAL_QUANTITY
                                , fsi1.PRICE_UNIT
                                , fsi1.SALES_PRICE
                                , fsi1.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , fsi1.LINE_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.LINE_AMOUNT_COMPANY_CURRENCY
                                , fsi1.TAX_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.TAX_AMOUNT_COMPANY_CURRENCY
                                , fsi1.DISCOUNT_PERCENT
                                , fsi1.DISCOUNT_AMOUNT
                                , fsi1.LINE_DISCOUNT
                                , fsi1.LINE_DISCOUNT_PERCENT
                                , fsi1.FLOOR_LINE_DISCOUNT
                                , fsi1.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , fsi1.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , fsi1.COST_OF_GOODS_SOLD
								, fsi1.FIXED_OVERHEAD
                                , fsi1.LABOR
                                , fsi1.MATERIAL
                                , fsi1.VARIABLE_OVERHEAD
                                , fsi1.FROZEN_FIXED_OVERHEAD
                                , fsi1.FROZEN_LABOR
                                , fsi1.FROZEN_MATERIAL
                                , fsi1.FROZEN_COST_OF_GOODS_SOLD
                                , fsi1.FROZEN_VARIABLE_OVERHEAD
                                , fsi1.STANDARD_COST
                                , fsi1.FROZEN_STANDARD_COST
                                , fsi1.PRICE_OVERRIDE_REASON_CODE
                                , fsi1.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , fsi1.ISLR
                                , fsi1.RECORD_ID_POS
                                , fsi1.PRICE_TYPE
                                , fsi1.ACTIVATION_DATE
                                , fsi1.CREATED_DATETIME
								, fsi1.JOURNAL_NUMBER
								, fsi1.JOURNAL_NAME
								, fsi1.INVENTORY_SITE_ID
                                ,nvl(src3.SALESLINE1_CURRENCYCODE, '''') as COGSFIFO_CURRENCY_CODE
                                ,nvl(src3.SALESLINE1_SALESSTATUS, 0) as COGSFIFO_SALES_STATUS
                                ,nvl(src3.SALESLINE1_COSTPRICE, 0) as COGSFIFO_COST_PRICE
                                ,nvl(src3.SALESLINE1_SALESQTY, 0) as COGSFIFO_SALES_QTY
                                ,nvl(src3.LEDGER1_ACCOUNTINGCURRENCY, '''') as COGSFIFO_ACCOUNTING_CURRENCY
                                ,nvl(src3.INVENTTRANS1_KITPARENTINVENTTRANSID, '''') as COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                ,nvl(src3.INVENTTRANS1_KITBOMLEVEL, 0) as COGSFIFO_KIT_BOM_LEVEL
                                ,nvl(src3.INVENTTRANS1_COSTAMOUNTPOSTED, 0) as COGSFIFO_COST_AMOUNT_POSTED
                                ,nvl(src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT, 0) as COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                ,nvl(src3.INVENTTRANS1_KITIDENTIFIER, '''') as COGSFIFO_KIT_IDENTIFIER
                                ,nvl(src3.EXCHANGERATE1_FROMCURRENCYCODE, '''') as COGSFIFO_FROM_CURRENCY_CODE
                                ,nvl(src3.EXCHANGERATE1_TOCURRENCYCODE, '''') as COGSFIFO_TO_CURRENCY_CODE
                                ,nvl(src3.EXCHANGERATE1_EXCHRATE, 0) as COGSFIFO_EXCHANGE_RATE
                                ,(case when src3.SALESLINE1_SALESSTATUS <> 3 
                                    then (src3.SALESLINE1_COSTPRICE
                                        * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                then src3.EXCHANGERATE1_EXCHRATE
                                                else 1
                                                end))
                                        * nvl(src3.SALESLINE1_SALESQTY, 0)
                                    else (case when (src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) is null
                                        then (src3.SALESLINE1_COSTPRICE 
                                            * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end)
                                            ) * nvl(src3.SALESLINE1_SALESQTY, 0)
                                        else ((src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) * - 1) 
                                            * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end)
                                        end)
                                    end) as COGSFIFO_COST_OF_GOODS_SOLD
                                , fsi1.HK_SOURCE_NAME
                                , fsi1.HK_SOFT_DELETE_FLAG
                                , fsi1.HK_SOURCE_CREATED_TIMESTAMP
                                , fsi1.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(fsi1.HK_CREATED_JOB_RUN_ID,src3.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , nvl(wrk2.HK_LAST_UPDATED_JOB_RUN_ID, fsi1.HK_LAST_UPDATED_JOB_RUN_ID) AS HK_LAST_UPDATED_JOB_RUN_ID
                                , fsi1.HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , fsi1.HK_HASH_KEY AS TGT_HK_HASH_KEY         
                            FROM ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' fsi1
INNER JOIN (select distinct SOURCE_NAME FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ') wrk1 on fsi1.SOURCE_NAME = wrk1.SOURCE_NAME
INNER JOIN ' || :src_db || '.' || :src_schema || '.' || :src_tbl3 ||' src3 on
                                fsi1.LEGAL_ENTITY = src3.SALESLINE1_DATAAREAID
                                    and fsi1.INVENTORY_TRANSACTION_ID = src3.SALESLINE1_INVENTTRANSID
LEFT JOIN ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' wrk2 on fsi1.SOURCE_NAME = wrk2.SOURCE_NAME
                                AND fsi1.RECORD_ID = wrk2.RECORD_ID
                                AND fsi1.LEGAL_ENTITY = wrk2.LEGAL_ENTITY
                                AND fsi1.ITEM_ID = wrk2.ITEM_ID
                            LEFT JOIN (select ITEMNUMBER, CONFIGURATION, STANDARDCOST
		                             from ' || :src_db || '.' || :src_schema || '.' || :src_tbl4 || '
		                              qualify row_number() over (partition by ITEMNUMBER, CONFIGURATION order by EFFECTIVEDATE desc) 
                                      = 1) citcx1 on fsi1.ITEM_ID = citcx1.ITEMNUMBER
                                        and fsi1.CONFIGURATION_ID = citcx1.CONFIGURATION
	                              left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc6 on
	                              	citsc6.STANDARDCOST_SOURCE = ''iip6'' and
		                              fsi1.LEGAL_ENTITY = citsc6.DATAAREAID and
		                              fsi1.ITEM_ID = citsc6.ITEMID and
	                              	fsi1.CONFIGURATION_ID = citsc6.INVENTDIM_CONFIGID and
		                              fsi1.INVENTORY_SITE_ID = citsc6.INVENTDIM_INVENTSITEID
	                              left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc7 on
		                              citsc7.STANDARDCOST_SOURCE = ''iip7'' and
		                              fsi1.LEGAL_ENTITY = citsc7.DATAAREAID and
		                              fsi1.ITEM_ID = citsc7.ITEMID and
		                              fsi1.INVENTORY_SITE_ID = citsc7.INVENTDIM_INVENTSITEID
	                              left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc8 on
	                              	citsc8.STANDARDCOST_SOURCE = ''iip8'' and
		                              fsi1.LEGAL_ENTITY = citsc8.DATAAREAID and
		                              fsi1.ITEM_ID = citsc8.ITEMID and
	                              	fsi1.CONFIGURATION_ID = citsc8.INVENTDIM_CONFIGID
	                              left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc9 on
		                              citsc9.STANDARDCOST_SOURCE = ''iip9'' and
		                              fsi1.LEGAL_ENTITY = citsc9.DATAAREAID and
		                              fsi1.ITEM_ID = citsc9.ITEMID
	                        WHERE wrk2.RECORD_ID IS NULL
                                AND fsi1.COGSFIFO_COST_OF_GOODS_SOLD
                                != (case when src3.SALESLINE1_SALESSTATUS <> 3 
                                    then (src3.SALESLINE1_COSTPRICE
                                        * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                then src3.EXCHANGERATE1_EXCHRATE
                                                else 1
                                                end))
                                        * nvl(src3.SALESLINE1_SALESQTY, 0)
                                    else (case when (src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) is null
                                          then (src3.SALESLINE1_COSTPRICE 
                                            * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end)
                                            ) * nvl(src3.SALESLINE1_SALESQTY, 0)
                                          else (((src3.INVENTTRANS1_COSTAMOUNTPOSTED + src3.INVENTTRANS1_COSTAMOUNTADJUSTMENT) * - 1) 
                                            * (case when src3.SALESLINE1_CURRENCYCODE <> src3.LEDGER1_ACCOUNTINGCURRENCY
                                                    then src3.EXCHANGERATE1_EXCHRATE
                                                    else 1
                                                    end)
                                                )
                                          end)
                                    end)
                                   
                                    ';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1a;
  
             /*
        1.	Read data from first target/source/first working tables and write to third working table
        SOURCE:	CURATE internal table and RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01b_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_01_<YYYYMMDDHH24MISSFF3>_001b

        a.            should retrieve existing data where FROZEN_COST is going to change
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1b';
    LET create_wrk_tbl1b STRING DEFAULT '';
    
   create_wrk_tbl1b := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01b_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                fsi1.FACT_SALES_INVOICES_KEY
                                , fsi1.SOURCE_NAME
                                , fsi1.RECORD_ID
                                , fsi1.LEGAL_ENTITY
                                , fsi1.ITEM_ID
                                , fsi1.DIM_SOURCE_SYSTEM_KEY
                                , fsi1.DIM_SOURCE_SYSTEM_SNKEY
                                , fsi1.DELIVERY_DATE_DIM_DATE_KEY
                                , fsi1.DELIVERY_DATE_DIM_DATE_SNKEY
                                , fsi1.DOCUMENT_DATE_DIM_DATE_KEY
                                , fsi1.DOCUMENT_DATE_DIM_DATE_SNKEY
                                , fsi1.DUE_DATE_DIM_DATE_KEY
                                , fsi1.DUE_DATE_DIM_DATE_SNKEY
                                , fsi1.INVOICE_DATE_DIM_DATE_KEY
                                , fsi1.INVOICE_DATE_DIM_DATE_SNKEY
                                , fsi1.MANUFACTURED_DATE_DIM_DATE_KEY
                                , fsi1.MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , fsi1.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , fsi1.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , fsi1.RELATED_ORDER_DATE_DIM_DATE_KEY
                                , fsi1.RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , fsi1.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , fsi1.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , fsi1.RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , fsi1.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , fsi1.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , fsi1.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , fsi1.DIM_BUSINESS_UNIT_KEY
                                , fsi1.DIM_BUSINESS_UNIT_SNKEY
                                , fsi1.DIM_CAMPAIGN_KEY
                                , fsi1.DIM_CAMPAIGN_SNKEY
                                , fsi1.DIM_COMMISSION_GROUP_KEY
                                , fsi1.DIM_COMMISSION_GROUP_SNKEY
                                , fsi1.DIM_COST_KEY
                                , fsi1.DIM_COST_SNKEY
                                , fsi1.DIM_CURRENCY_KEY
                                , fsi1.DIM_CURRENCY_SNKEY
                                , fsi1.DIM_CUSTOMER_INVOICE_KEY
                                , fsi1.DIM_CUSTOMER_INVOICE_SNKEY
                                , fsi1.DIM_CUSTOMER_ORDER_KEY
                                , fsi1.DIM_CUSTOMER_ORDER_SNKEY
                                , fsi1.DIM_CUSTOMER_GROUP_KEY
                                , fsi1.DIM_CUSTOMER_GROUP_SNKEY
                                , fsi1.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , fsi1.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , fsi1.DIM_DEFAULT_DIMENSION_KEY
                                , fsi1.DIM_DEFAULT_DIMENSION_SNKEY
                                , fsi1.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , fsi1.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , fsi1.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , fsi1.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , fsi1.DIM_INVENTORY_KEY
                                , fsi1.DIM_INVENTORY_SNKEY
                                , fsi1.DIM_ITEM_KEY
                                , fsi1.DIM_ITEM_SNKEY
                                , fsi1.DIM_ITEM_STATUS_KEY
                                , fsi1.DIM_ITEM_STATUS_SNKEY
                                , fsi1.DIM_LEGAL_ENTITY_KEY
                                , fsi1.DIM_LEGAL_ENTITY_SNKEY
                                , fsi1.DIM_LINE_RETURN_REASON_KEY
                                , fsi1.DIM_LINE_RETURN_REASON_SNKEY
                                , fsi1.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , fsi1.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , fsi1.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , fsi1.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , fsi1.DIM_DELIVERY_MODE_KEY
                                , fsi1.DIM_DELIVERY_MODE_SNKEY
                                , fsi1.DIM_DELIVERY_TERM_KEY
                                , fsi1.DIM_DELIVERY_TERM_SNKEY
                                , fsi1.DIM_PAYMENT_TERMS_KEY
                                , fsi1.DIM_PAYMENT_TERMS_SNKEY
                                , fsi1.DIM_PROCUREMENT_CATEGORY_KEY
                                , fsi1.DIM_PROCUREMENT_CATEGORY_SNKEY
                                , fsi1.DIM_RETURN_DISPOSITION_KEY
                                , fsi1.DIM_RETURN_DISPOSITION_SNKEY
                                , fsi1.DIM_RETURN_REASON_KEY
                                , fsi1.DIM_RETURN_REASON_SNKEY
                                , fsi1.DIM_SALES_GROUP_KEY
                                , fsi1.DIM_SALES_GROUP_SNKEY
                                , fsi1.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , fsi1.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , fsi1.DIM_SALES_ORDER_KEY
                                , fsi1.DIM_SALES_ORDER_SNKEY
                                , fsi1.DIM_SALES_ORIGIN_KEY
                                , fsi1.DIM_SALES_ORIGIN_SNKEY
                                , fsi1.DIM_SALES_POOL_KEY
                                , fsi1.DIM_SALES_POOL_SNKEY
                                , fsi1.DIM_SALES_PRICE_GROUP_KEY
                                , fsi1.DIM_SALES_PRICE_GROUP_SNKEY
                                , fsi1.DIM_TAX_GROUP_KEY
                                , fsi1.DIM_TAX_GROUP_SNKEY
                                , fsi1.DIM_TAX_ITEM_GROUP_KEY
                                , fsi1.DIM_TAX_ITEM_GROUP_SNKEY
                                , fsi1.DIM_UNIT_OF_MEASURE_SALES_KEY
                                , fsi1.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , fsi1.DIM_WAREHOUSE_KEY
                                , fsi1.DIM_WAREHOUSE_SNKEY
                                , fsi1.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , fsi1.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , fsi1.DIM_WORKER_SALES_TAKER_KEY
                                , fsi1.DIM_WORKER_SALES_TAKER_SNKEY
                                , fsi1.INVOICE_KEY
                                , fsi1.BUSINESS_UNIT_ID
                                , fsi1.CAMPAIGN_ID
                                , fsi1.COMMISSION_GROUP_ID
                                , fsi1.CURRENCY_CODE
                                , fsi1.CUSTOMER_ACCOUNT_INVOICE
                                , fsi1.CUSTOMER_ACCOUNT_ORDER
                                , fsi1.CUSTOMER_GROUP_ID
                                , fsi1.CUSTOMER_MARKUP_GROUP_ID
                                , fsi1.DEFAULT_DIMENSION
                                , fsi1.CONFIGURATION_ID
                                , fsi1.INTRA_STAT_TRANSACTION_CODE
                                , fsi1.INVENTORY_DIMENSION_ID
                                , fsi1.ITEM_STATUS
                                , fsi1.LINE_RETURN_REASON_ID
                                , fsi1.LINE_RETURN_REASON_GROUP_ID
                                , fsi1.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , fsi1.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , fsi1.DELIVERY_MODE_ID
                                , fsi1.DELIVERY_TERM_ID
                                , fsi1.PAYMENT_TERMS_ID
                                , fsi1.PROCUREMENT_CATEGORY
                                , fsi1.RETURN_DISPOSITION_ID
                                , fsi1.RETURN_REASON_ID
                                , fsi1.SALES_GROUP_ID
                                , fsi1.SALES_LINE_DISCOUNT_GROUP_ID
                                , fsi1.SALES_ORDER_ID
                                , fsi1.SALES_ORIGIN_ID
                                , fsi1.SALES_POOL_ID
                                , fsi1.SALES_PRICE_GROUP_ID
                                , fsi1.TAX_GROUP_ID
                                , fsi1.TAX_ITEM_GROUP_ID
                                , fsi1.UNIT_OF_MEASURE_CODE_SALES
                                , fsi1.WAREHOUSE_ID
                                , fsi1.RECORD_ID_SALES_RESPONSIBLE
                                , fsi1.RECORD_ID_SALES_TAKER
                                , fsi1.DOCUMENT_STATUS
                                , fsi1.FLOOR_SAMPLE_TYPE
                                , fsi1.HEADER_RETURN_STATUS
                                , fsi1.HEADER_SALES_STATUS
                                , fsi1.RETURN_STATUS
                                , fsi1.SALES_STATUS
                                , fsi1.SALES_TYPE
                                , fsi1.SHIP_CARRIER_DELIVERY_TYPE
                                , fsi1.TRADE_LINE_DELIVERY_TYPE
                                , fsi1.IS_AT_AGENT_TRANSACTION
                                , fsi1.IS_BLIND_SHIPMENT
                                , fsi1.IS_EXPEDITED_SHIPMENT
                                , fsi1.IS_FLOOR_SAMPLE_DISCOUNT
                                , fsi1.IS_ITEM_TRANSACTION
                                , fsi1.IS_LINE_DELIVERY_COMPLETE
                                , fsi1.IS_ORDER_BLOCKED
                                , fsi1.IS_ORDER_LINE_BLOCKED
                                , fsi1.IS_ORDER_LOCKED
                                , fsi1.IS_RETURNED_ITEM_SCRAP
                                , fsi1.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , fsi1.IS_STOCKED_PRODUCT
                                , fsi1.DROP_SHIPMENT
                                , fsi1.DELIVERY_DATE
								, fsi1.DOCUMENT_DATE
								, fsi1.DUE_DATE
								, fsi1.INVOICE_DATE
								, fsi1.MANUFACTURED_DATE
								, fsi1.ORIGINATING_ORDER_CREATED_DATE
								, fsi1.RELATED_ORDER_DATE
								, fsi1.RETURN_ARRIVAL_DATE
								, fsi1.RETURN_CLOSED_DATE
								, fsi1.SALES_LINE_CREATED_DATE
								, fsi1.INVENTORY_TRANSACTION_ID
                                , fsi1.INVOICE_ID
                                , fsi1.LEDGER_VOUCHER
                                , fsi1.LINE_NUMBER
                                , fsi1.ORIGINAL_SALES_ORDER_ID
                                , fsi1.PRODUCTION_TIME
                                , fsi1.PURCHASE_ORDER_ID
                                , fsi1.ORIGINATING_ORDER_SALES_ID
                                , fsi1.REGISTRY_NUMBER
                                , fsi1.INVENTORY_QUANTITY
                                , fsi1.INVOICE_QUANTITY
                                , fsi1.PHYSICAL_QUANTITY
                                , fsi1.PRICE_UNIT
                                , fsi1.SALES_PRICE
                                , fsi1.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , fsi1.LINE_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.LINE_AMOUNT_COMPANY_CURRENCY
                                , fsi1.TAX_AMOUNT_TRANSACTION_CURRENCY
                                , fsi1.TAX_AMOUNT_COMPANY_CURRENCY
                                , fsi1.DISCOUNT_PERCENT
                                , fsi1.DISCOUNT_AMOUNT
                                , fsi1.LINE_DISCOUNT
                                , fsi1.LINE_DISCOUNT_PERCENT
                                , fsi1.FLOOR_LINE_DISCOUNT
                                , fsi1.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , fsi1.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , fsi1.COST_OF_GOODS_SOLD
								, fsi1.FIXED_OVERHEAD
                                , fsi1.LABOR
                                , fsi1.MATERIAL
                                , fsi1.VARIABLE_OVERHEAD
                                , fsi1.FROZEN_FIXED_OVERHEAD
                                , fsi1.FROZEN_LABOR
                                , fsi1.FROZEN_MATERIAL
                                , (case when fsi1.LEGAL_ENTITY = ''740'' then nvl(citcx1.STANDARDCOST, 0)
                                                                    else fsi1.FROZEN_STANDARD_COST
                                                                    end) as FROZEN_COST_OF_GOODS_SOLD
                                , fsi1.FROZEN_VARIABLE_OVERHEAD
                                , fsi1.STANDARD_COST
                                , (CASE WHEN fsi1.RECORD_ID < 0 THEN ROUND(coalesce(citsc6.INVENTITEMPRICE_STANDARDCOST, citsc7.INVENTITEMPRICE_STANDARDCOST, citsc8.INVENTITEMPRICE_STANDARDCOST, citsc9.INVENTITEMPRICE_STANDARDCOST, 0),2)
                                    ELSE (coalesce(citsc6.INVENTITEMPRICE_STANDARDCOST, citsc7.INVENTITEMPRICE_STANDARDCOST, citsc8.INVENTITEMPRICE_STANDARDCOST, citsc9.INVENTITEMPRICE_STANDARDCOST, 0))
                                    END) AS FROZEN_STANDARD_COST
                                , fsi1.PRICE_OVERRIDE_REASON_CODE
                                , fsi1.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , fsi1.ISLR
                                , fsi1.RECORD_ID_POS
                                , fsi1.PRICE_TYPE
                                , fsi1.ACTIVATION_DATE
                                , fsi1.CREATED_DATETIME
								, fsi1.JOURNAL_NUMBER
								, fsi1.JOURNAL_NAME
								, fsi1.INVENTORY_SITE_ID
                                , fsi1.COGSFIFO_CURRENCY_CODE
                                , fsi1.COGSFIFO_SALES_STATUS
                                , fsi1.COGSFIFO_COST_PRICE
                                , fsi1.COGSFIFO_SALES_QTY
                                , fsi1.COGSFIFO_ACCOUNTING_CURRENCY
                                , fsi1.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                , fsi1.COGSFIFO_KIT_BOM_LEVEL
                                , fsi1.COGSFIFO_COST_AMOUNT_POSTED
                                , fsi1.COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                , fsi1.COGSFIFO_KIT_IDENTIFIER
                                , fsi1.COGSFIFO_FROM_CURRENCY_CODE
                                , fsi1.COGSFIFO_TO_CURRENCY_CODE
                                , fsi1.COGSFIFO_EXCHANGE_RATE
                                , fsi1.COGSFIFO_COST_OF_GOODS_SOLD
                                , fsi1.HK_HASH_KEY
                                , fsi1.HK_SOURCE_NAME
                                , fsi1.HK_SOFT_DELETE_FLAG
                                , fsi1.HK_SOURCE_CREATED_TIMESTAMP
                                , nvl(wrk1a.HK_SOURCE_LAST_UPDATED_TIMESTAMP, fsi1.HK_SOURCE_LAST_UPDATED_TIMESTAMP) AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(wrk1a.HK_CREATED_JOB_RUN_ID, fsi1.HK_CREATED_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , nvl(wrk1a.HK_LAST_UPDATED_JOB_RUN_ID,fsi1.HK_LAST_UPDATED_JOB_RUN_ID) AS HK_LAST_UPDATED_JOB_RUN_ID
                                , fsi1.HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , fsi1.HK_HASH_KEY AS TGT_HK_HASH_KEY  
                           
                           FROM ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' fsi1
                           INNER JOIN (select distinct SOURCE_NAME FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ') wrk on fsi1.SOURCE_NAME = wrk.SOURCE_NAME
                           left join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' wrk1 on fsi1.SOURCE_NAME = wrk1.SOURCE_NAME and fsi1.RECORD_ID = wrk1.RECORD_ID and fsi1.LEGAL_ENTITY = wrk1.LEGAL_ENTITY and fsi1.ITEM_ID = wrk1.ITEM_ID
                           left join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01a_' || :CURR_FORMATTED_TIMESTAMP
     || ' wrk1a on fsi1.SOURCE_NAME = wrk1a.SOURCE_NAME and fsi1.RECORD_ID = wrk1a.RECORD_ID and fsi1.LEGAL_ENTITY = wrk1a.LEGAL_ENTITY and fsi1.ITEM_ID = wrk1a.ITEM_ID
                           left join (select ITEMNUMBER, CONFIGURATION, STANDARDCOST
                                     from ' || :src_db || '.' || :src_schema || '.' || :src_tbl4 || '
		                              qualify row_number() over (partition by ITEMNUMBER, CONFIGURATION order by EFFECTIVEDATE desc) = 1) citcx1 
                                      on fsi1.ITEM_ID = citcx1.ITEMNUMBER
                                        and fsi1.CONFIGURATION_ID = citcx1.CONFIGURATION
                           left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc6 
                                on citsc6.STANDARDCOST_SOURCE = ''iip6'' 
                                    and fsi1.LEGAL_ENTITY = citsc6.DATAAREAID 
                                    and fsi1.ITEM_ID = citsc6.ITEMID 
                                    and fsi1.CONFIGURATION_ID = citsc6.INVENTDIM_CONFIGID 
                                    and fsi1.INVENTORY_SITE_ID = citsc6.INVENTDIM_INVENTSITEID
                           left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc7 
                                on citsc7.STANDARDCOST_SOURCE = ''iip7'' 
                                    and fsi1.LEGAL_ENTITY = citsc7.DATAAREAID 
                                    and fsi1.ITEM_ID = citsc7.ITEMID 
                                    and fsi1.INVENTORY_SITE_ID = citsc7.INVENTDIM_INVENTSITEID
                           left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc8 
                                on citsc8.STANDARDCOST_SOURCE = ''iip8'' 
                                    and fsi1.LEGAL_ENTITY = citsc8.DATAAREAID 
                                    and fsi1.ITEM_ID = citsc8.ITEMID 
                                    and fsi1.CONFIGURATION_ID = citsc8.INVENTDIM_CONFIGID
                           left join ' || :src_db || '.' || :src_schema || '.' || :src_tbl2 || ' citsc9 
                                on citsc9.STANDARDCOST_SOURCE = ''iip9'' 
                                    and fsi1.LEGAL_ENTITY = citsc9.DATAAREAID 
                                    and fsi1.ITEM_ID = citsc9.ITEMID
                           where nvl(wrk1.RECORD_ID, wrk1a.RECORD_ID) is null
-- the following is added so that we ONLY pull in records from the target ""if"" the FROZEN_COST_OF_GOODS_SOLD or FROZEN_STANDARD_COST value is going to change.
                            and (fsi1.FROZEN_COST_OF_GOODS_SOLD != (case when fsi1.LEGAL_ENTITY = ''740'' then nvl(citcx1.STANDARDCOST, 0)
                                                                    else fsi1.FROZEN_STANDARD_COST
                                                                    end)
	                           
                                or fsi1.FROZEN_STANDARD_COST !=  (CASE WHEN fsi1.RECORD_ID < 0 THEN ROUND((coalesce(citsc6.INVENTITEMPRICE_STANDARDCOST, citsc7.INVENTITEMPRICE_STANDARDCOST, citsc8.INVENTITEMPRICE_STANDARDCOST, citsc9.INVENTITEMPRICE_STANDARDCOST, 0)),2)
                                    ELSE (coalesce(citsc6.INVENTITEMPRICE_STANDARDCOST, citsc7.INVENTITEMPRICE_STANDARDCOST, citsc8.INVENTITEMPRICE_STANDARDCOST, citsc9.INVENTITEMPRICE_STANDARDCOST, 0))
                                    END)
                                )
                                ';

                                
        EXECUTE IMMEDIATE :create_wrk_tbl1b;




    /*
        1.	Combiner (union all) data from all working tables and write to final working table
        SOURCE:	transient working tables (3)
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01final_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_01_<YYYYMMDDHH24MISSFF3>_001final

        a.            retrieve from working tables where standard cost, frozen cost, cost of good sold, frozen cost of goods sold is going to change
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        f.              Working Columns: TGT_HK_HASH_KEY
    */
    v_proc_step := '4.1final';
    LET create_wrk_tbl1final STRING DEFAULT '';
    

   create_wrk_tbl1final := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                utbl.FACT_SALES_INVOICES_KEY
                                , utbl.SOURCE_NAME
                                , utbl.RECORD_ID
                                , utbl.LEGAL_ENTITY
                                , utbl.ITEM_ID
                                , utbl.DIM_SOURCE_SYSTEM_KEY
                                , utbl.DIM_SOURCE_SYSTEM_SNKEY
                                , utbl.DELIVERY_DATE_DIM_DATE_KEY
                                , utbl.DELIVERY_DATE_DIM_DATE_SNKEY
                                , utbl.DOCUMENT_DATE_DIM_DATE_KEY
                                , utbl.DOCUMENT_DATE_DIM_DATE_SNKEY
                                , utbl.DUE_DATE_DIM_DATE_KEY
                                , utbl.DUE_DATE_DIM_DATE_SNKEY
                                , utbl.INVOICE_DATE_DIM_DATE_KEY
                                , utbl.INVOICE_DATE_DIM_DATE_SNKEY
                                , utbl.MANUFACTURED_DATE_DIM_DATE_KEY
                                , utbl.MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , utbl.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , utbl.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , utbl.RELATED_ORDER_DATE_DIM_DATE_KEY
                                , utbl.RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , utbl.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , utbl.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , utbl.RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , utbl.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , utbl.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , utbl.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , utbl.DIM_BUSINESS_UNIT_KEY
                                , utbl.DIM_BUSINESS_UNIT_SNKEY
                                , utbl.DIM_CAMPAIGN_KEY
                                , utbl.DIM_CAMPAIGN_SNKEY
                                , utbl.DIM_COMMISSION_GROUP_KEY
                                , utbl.DIM_COMMISSION_GROUP_SNKEY
                                , utbl.DIM_COST_KEY
                                , utbl.DIM_COST_SNKEY
                                , utbl.DIM_CURRENCY_KEY
                                , utbl.DIM_CURRENCY_SNKEY
                                , utbl.DIM_CUSTOMER_INVOICE_KEY
                                , utbl.DIM_CUSTOMER_INVOICE_SNKEY
                                , utbl.DIM_CUSTOMER_ORDER_KEY
                                , utbl.DIM_CUSTOMER_ORDER_SNKEY
                                , utbl.DIM_CUSTOMER_GROUP_KEY
                                , utbl.DIM_CUSTOMER_GROUP_SNKEY
                                , utbl.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , utbl.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , utbl.DIM_DEFAULT_DIMENSION_KEY
                                , utbl.DIM_DEFAULT_DIMENSION_SNKEY
                                , utbl.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , utbl.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , utbl.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , utbl.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , utbl.DIM_INVENTORY_KEY
                                , utbl.DIM_INVENTORY_SNKEY
                                , utbl.DIM_ITEM_KEY
                                , utbl.DIM_ITEM_SNKEY
                                , utbl.DIM_ITEM_STATUS_KEY
                                , utbl.DIM_ITEM_STATUS_SNKEY
                                , utbl.DIM_LEGAL_ENTITY_KEY
                                , utbl.DIM_LEGAL_ENTITY_SNKEY
                                , utbl.DIM_LINE_RETURN_REASON_KEY
                                , utbl.DIM_LINE_RETURN_REASON_SNKEY
                                , utbl.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , utbl.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , utbl.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , utbl.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , utbl.DIM_DELIVERY_MODE_KEY
                                , utbl.DIM_DELIVERY_MODE_SNKEY
                                , utbl.DIM_DELIVERY_TERM_KEY
                                , utbl.DIM_DELIVERY_TERM_SNKEY
                                , utbl.DIM_PAYMENT_TERMS_KEY
                                , utbl.DIM_PAYMENT_TERMS_SNKEY
                                , utbl.DIM_PROCUREMENT_CATEGORY_KEY
                                , utbl.DIM_PROCUREMENT_CATEGORY_SNKEY
                                , utbl.DIM_RETURN_DISPOSITION_KEY
                                , utbl.DIM_RETURN_DISPOSITION_SNKEY
                                , utbl.DIM_RETURN_REASON_KEY
                                , utbl.DIM_RETURN_REASON_SNKEY
                                , utbl.DIM_SALES_GROUP_KEY
                                , utbl.DIM_SALES_GROUP_SNKEY
                                , utbl.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , utbl.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , utbl.DIM_SALES_ORDER_KEY
                                , utbl.DIM_SALES_ORDER_SNKEY
                                , utbl.DIM_SALES_ORIGIN_KEY
                                , utbl.DIM_SALES_ORIGIN_SNKEY
                                , utbl.DIM_SALES_POOL_KEY
                                , utbl.DIM_SALES_POOL_SNKEY
                                , utbl.DIM_SALES_PRICE_GROUP_KEY
                                , utbl.DIM_SALES_PRICE_GROUP_SNKEY
                                , utbl.DIM_TAX_GROUP_KEY
                                , utbl.DIM_TAX_GROUP_SNKEY
                                , utbl.DIM_TAX_ITEM_GROUP_KEY
                                , utbl.DIM_TAX_ITEM_GROUP_SNKEY
                                , utbl.DIM_UNIT_OF_MEASURE_SALES_KEY
                                , utbl.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , utbl.DIM_WAREHOUSE_KEY
                                , utbl.DIM_WAREHOUSE_SNKEY
                                , utbl.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , utbl.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , utbl.DIM_WORKER_SALES_TAKER_KEY
                                , utbl.DIM_WORKER_SALES_TAKER_SNKEY
                                , utbl.INVOICE_KEY
                                , utbl.BUSINESS_UNIT_ID
                                , utbl.CAMPAIGN_ID
                                , utbl.COMMISSION_GROUP_ID
                                , utbl.CURRENCY_CODE
                                , utbl.CUSTOMER_ACCOUNT_INVOICE
                                , utbl.CUSTOMER_ACCOUNT_ORDER
                                , utbl.CUSTOMER_GROUP_ID
                                , utbl.CUSTOMER_MARKUP_GROUP_ID
                                , utbl.DEFAULT_DIMENSION
                                , utbl.CONFIGURATION_ID
                                , utbl.INTRA_STAT_TRANSACTION_CODE
                                , utbl.INVENTORY_DIMENSION_ID
                                , utbl.ITEM_STATUS
                                , utbl.LINE_RETURN_REASON_ID
                                , utbl.LINE_RETURN_REASON_GROUP_ID
                                , utbl.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , utbl.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , utbl.DELIVERY_MODE_ID
                                , utbl.DELIVERY_TERM_ID
                                , utbl.PAYMENT_TERMS_ID
                                , utbl.PROCUREMENT_CATEGORY
                                , utbl.RETURN_DISPOSITION_ID
                                , utbl.RETURN_REASON_ID
                                , utbl.SALES_GROUP_ID
                                , utbl.SALES_LINE_DISCOUNT_GROUP_ID
                                , utbl.SALES_ORDER_ID
                                , utbl.SALES_ORIGIN_ID
                                , utbl.SALES_POOL_ID
                                , utbl.SALES_PRICE_GROUP_ID
                                , utbl.TAX_GROUP_ID
                                , utbl.TAX_ITEM_GROUP_ID
                                , utbl.UNIT_OF_MEASURE_CODE_SALES
                                , utbl.WAREHOUSE_ID
                                , utbl.RECORD_ID_SALES_RESPONSIBLE
                                , utbl.RECORD_ID_SALES_TAKER
                                , utbl.DOCUMENT_STATUS
                                , utbl.FLOOR_SAMPLE_TYPE
                                , utbl.HEADER_RETURN_STATUS
                                , utbl.HEADER_SALES_STATUS
                                , utbl.RETURN_STATUS
                                , utbl.SALES_STATUS
                                , utbl.SALES_TYPE
                                , utbl.SHIP_CARRIER_DELIVERY_TYPE
                                , utbl.TRADE_LINE_DELIVERY_TYPE
                                , utbl.IS_AT_AGENT_TRANSACTION
                                , utbl.IS_BLIND_SHIPMENT
                                , utbl.IS_EXPEDITED_SHIPMENT
                                , utbl.IS_FLOOR_SAMPLE_DISCOUNT
                                , utbl.IS_ITEM_TRANSACTION
                                , utbl.IS_LINE_DELIVERY_COMPLETE
                                , utbl.IS_ORDER_BLOCKED
                                , utbl.IS_ORDER_LINE_BLOCKED
                                , utbl.IS_ORDER_LOCKED
                                , utbl.IS_RETURNED_ITEM_SCRAP
                                , utbl.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , utbl.IS_STOCKED_PRODUCT
                                , utbl.DROP_SHIPMENT
                                , utbl.DELIVERY_DATE
								, utbl.DOCUMENT_DATE
								, utbl.DUE_DATE
								, utbl.INVOICE_DATE
								, utbl.MANUFACTURED_DATE
								, utbl.ORIGINATING_ORDER_CREATED_DATE
								, utbl.RELATED_ORDER_DATE
								, utbl.RETURN_ARRIVAL_DATE
								, utbl.RETURN_CLOSED_DATE
								, utbl.SALES_LINE_CREATED_DATE
								, utbl.INVENTORY_TRANSACTION_ID
                                , utbl.INVOICE_ID
                                , utbl.LEDGER_VOUCHER
                                , utbl.LINE_NUMBER
                                , utbl.ORIGINAL_SALES_ORDER_ID
                                , utbl.PRODUCTION_TIME
                                , utbl.PURCHASE_ORDER_ID
                                , utbl.ORIGINATING_ORDER_SALES_ID
                                , utbl.REGISTRY_NUMBER
                                , utbl.INVENTORY_QUANTITY
                                , utbl.INVOICE_QUANTITY
                                , utbl.PHYSICAL_QUANTITY
                                , utbl.PRICE_UNIT
                                , utbl.SALES_PRICE
                                , utbl.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , utbl.COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , utbl.LINE_AMOUNT_TRANSACTION_CURRENCY
                                , utbl.LINE_AMOUNT_COMPANY_CURRENCY
                                , utbl.TAX_AMOUNT_TRANSACTION_CURRENCY
                                , utbl.TAX_AMOUNT_COMPANY_CURRENCY
                                , utbl.DISCOUNT_PERCENT
                                , utbl.DISCOUNT_AMOUNT
                                , utbl.LINE_DISCOUNT
                                , utbl.LINE_DISCOUNT_PERCENT
                                , utbl.FLOOR_LINE_DISCOUNT
                                , utbl.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , utbl.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , utbl.COST_OF_GOODS_SOLD
								, utbl.FIXED_OVERHEAD
                                , utbl.LABOR
                                , utbl.MATERIAL
                                , utbl.VARIABLE_OVERHEAD
                                , utbl.FROZEN_COST_OF_GOODS_SOLD
                                , utbl.FROZEN_FIXED_OVERHEAD
                                , utbl.FROZEN_LABOR
                                , utbl.FROZEN_MATERIAL
                                , utbl.FROZEN_VARIABLE_OVERHEAD
                                , utbl.STANDARD_COST
                                , utbl.FROZEN_STANDARD_COST
                                , utbl.PRICE_OVERRIDE_REASON_CODE
                                , utbl.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , utbl.ISLR
                                , utbl.RECORD_ID_POS
                                , utbl.PRICE_TYPE
                                , utbl.ACTIVATION_DATE
                                , utbl.CREATED_DATETIME
								, utbl.JOURNAL_NUMBER
								, utbl.JOURNAL_NAME
								, utbl.INVENTORY_SITE_ID
                                , utbl.COGSFIFO_CURRENCY_CODE
                                , utbl.COGSFIFO_SALES_STATUS
                                , utbl.COGSFIFO_COST_PRICE
                                , utbl.COGSFIFO_SALES_QTY
                                , utbl.COGSFIFO_ACCOUNTING_CURRENCY
                                , utbl.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                , utbl.COGSFIFO_KIT_BOM_LEVEL
                                , utbl.COGSFIFO_COST_AMOUNT_POSTED
                                , utbl.COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                , utbl.COGSFIFO_KIT_IDENTIFIER
                                , utbl.COGSFIFO_FROM_CURRENCY_CODE
                                , utbl.COGSFIFO_TO_CURRENCY_CODE
                                , utbl.COGSFIFO_EXCHANGE_RATE
                                , utbl.COGSFIFO_COST_OF_GOODS_SOLD
                                , utbl.HK_SOURCE_NAME
                                , utbl.HK_SOFT_DELETE_FLAG
                                , utbl.HK_SOURCE_CREATED_TIMESTAMP
                                , utbl.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , utbl.HK_CREATED_JOB_RUN_ID
                                , utbl.HK_LAST_UPDATED_JOB_RUN_ID
                                , utbl.HK_CREATED_TIMESTAMP
                                , utbl.HK_LAST_UPDATED_TIMESTAMP
                                , utbl.HK_WAREHOUSE_ID
                                , utbl.TGT_HK_HASH_KEY
                        FROM (
                            SELECT FACT_SALES_INVOICES_KEY
                                , SOURCE_NAME
                                , RECORD_ID
                                , LEGAL_ENTITY
                                , ITEM_ID
                                , DIM_SOURCE_SYSTEM_KEY
                                , DIM_SOURCE_SYSTEM_SNKEY
                                , DELIVERY_DATE_DIM_DATE_KEY
                                , DELIVERY_DATE_DIM_DATE_SNKEY
                                , DOCUMENT_DATE_DIM_DATE_KEY
                                , DOCUMENT_DATE_DIM_DATE_SNKEY
                                , DUE_DATE_DIM_DATE_KEY
                                , DUE_DATE_DIM_DATE_SNKEY
                                , INVOICE_DATE_DIM_DATE_KEY
                                , INVOICE_DATE_DIM_DATE_SNKEY
                                , MANUFACTURED_DATE_DIM_DATE_KEY
                                , MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , RELATED_ORDER_DATE_DIM_DATE_KEY
                                , RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , DIM_BUSINESS_UNIT_KEY
                                , DIM_BUSINESS_UNIT_SNKEY
                                , DIM_CAMPAIGN_KEY
                                , DIM_CAMPAIGN_SNKEY
                                , DIM_COMMISSION_GROUP_KEY
                                , DIM_COMMISSION_GROUP_SNKEY
                                , DIM_COST_KEY
                                , DIM_COST_SNKEY
                                , DIM_CURRENCY_KEY
                                , DIM_CURRENCY_SNKEY
                                , DIM_CUSTOMER_INVOICE_KEY
                                , DIM_CUSTOMER_INVOICE_SNKEY
                                , DIM_CUSTOMER_ORDER_KEY
                                , DIM_CUSTOMER_ORDER_SNKEY
                                , DIM_CUSTOMER_GROUP_KEY
                                , DIM_CUSTOMER_GROUP_SNKEY
                                , DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , DIM_DEFAULT_DIMENSION_KEY
                                , DIM_DEFAULT_DIMENSION_SNKEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , DIM_INVENTORY_KEY
                                , DIM_INVENTORY_SNKEY
                                , DIM_ITEM_KEY
                                , DIM_ITEM_SNKEY
                                , DIM_ITEM_STATUS_KEY
                                , DIM_ITEM_STATUS_SNKEY
                                , DIM_LEGAL_ENTITY_KEY
                                , DIM_LEGAL_ENTITY_SNKEY
                                , DIM_LINE_RETURN_REASON_KEY
                                , DIM_LINE_RETURN_REASON_SNKEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , DIM_DELIVERY_MODE_KEY
                                , DIM_DELIVERY_MODE_SNKEY
                                , DIM_DELIVERY_TERM_KEY
                                , DIM_DELIVERY_TERM_SNKEY
                                , DIM_PAYMENT_TERMS_KEY
                                , DIM_PAYMENT_TERMS_SNKEY
                                , DIM_PROCUREMENT_CATEGORY_KEY
                                , DIM_PROCUREMENT_CATEGORY_SNKEY
                                , DIM_RETURN_DISPOSITION_KEY
                                , DIM_RETURN_DISPOSITION_SNKEY
                                , DIM_RETURN_REASON_KEY
                                , DIM_RETURN_REASON_SNKEY
                                , DIM_SALES_GROUP_KEY
                                , DIM_SALES_GROUP_SNKEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , DIM_SALES_ORDER_KEY
                                , DIM_SALES_ORDER_SNKEY
                                , DIM_SALES_ORIGIN_KEY
                                , DIM_SALES_ORIGIN_SNKEY
                                , DIM_SALES_POOL_KEY
                                , DIM_SALES_POOL_SNKEY
                                , DIM_SALES_PRICE_GROUP_KEY
                                , DIM_SALES_PRICE_GROUP_SNKEY
                                , DIM_TAX_GROUP_KEY
                                , DIM_TAX_GROUP_SNKEY
                                , DIM_TAX_ITEM_GROUP_KEY
                                , DIM_TAX_ITEM_GROUP_SNKEY
                                , DIM_UNIT_OF_MEASURE_SALES_KEY
                                , DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , DIM_WAREHOUSE_KEY
                                , DIM_WAREHOUSE_SNKEY
                                , DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , DIM_WORKER_SALES_TAKER_KEY
                                , DIM_WORKER_SALES_TAKER_SNKEY
                                , INVOICE_KEY
                                , BUSINESS_UNIT_ID
                                , CAMPAIGN_ID
                                , COMMISSION_GROUP_ID
                                , CURRENCY_CODE
                                , CUSTOMER_ACCOUNT_INVOICE
                                , CUSTOMER_ACCOUNT_ORDER
                                , CUSTOMER_GROUP_ID
                                , CUSTOMER_MARKUP_GROUP_ID
                                , DEFAULT_DIMENSION
                                , CONFIGURATION_ID
                                , INTRA_STAT_TRANSACTION_CODE
                                , INVENTORY_DIMENSION_ID
                                , ITEM_STATUS
                                , LINE_RETURN_REASON_ID
                                , LINE_RETURN_REASON_GROUP_ID
                                , RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , DELIVERY_MODE_ID
                                , DELIVERY_TERM_ID
                                , PAYMENT_TERMS_ID
                                , PROCUREMENT_CATEGORY
                                , RETURN_DISPOSITION_ID
                                , RETURN_REASON_ID
                                , SALES_GROUP_ID
                                , SALES_LINE_DISCOUNT_GROUP_ID
                                , SALES_ORDER_ID
                                , SALES_ORIGIN_ID
                                , SALES_POOL_ID
                                , SALES_PRICE_GROUP_ID
                                , TAX_GROUP_ID
                                , TAX_ITEM_GROUP_ID
                                , UNIT_OF_MEASURE_CODE_SALES
                                , WAREHOUSE_ID
                                , RECORD_ID_SALES_RESPONSIBLE
                                , RECORD_ID_SALES_TAKER
                                , DOCUMENT_STATUS
                                , FLOOR_SAMPLE_TYPE
                                , HEADER_RETURN_STATUS
                                , HEADER_SALES_STATUS
                                , RETURN_STATUS
                                , SALES_STATUS
                                , SALES_TYPE
                                , SHIP_CARRIER_DELIVERY_TYPE
                                , TRADE_LINE_DELIVERY_TYPE
                                , IS_AT_AGENT_TRANSACTION
                                , IS_BLIND_SHIPMENT
                                , IS_EXPEDITED_SHIPMENT
                                , IS_FLOOR_SAMPLE_DISCOUNT
                                , IS_ITEM_TRANSACTION
                                , IS_LINE_DELIVERY_COMPLETE
                                , IS_ORDER_BLOCKED
                                , IS_ORDER_LINE_BLOCKED
                                , IS_ORDER_LOCKED
                                , IS_RETURNED_ITEM_SCRAP
                                , IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , IS_STOCKED_PRODUCT
                                , DROP_SHIPMENT
                                , DELIVERY_DATE
								, DOCUMENT_DATE
								, DUE_DATE
								, INVOICE_DATE
								, MANUFACTURED_DATE
								, ORIGINATING_ORDER_CREATED_DATE
								, RELATED_ORDER_DATE
								, RETURN_ARRIVAL_DATE
								, RETURN_CLOSED_DATE
								, SALES_LINE_CREATED_DATE
								, INVENTORY_TRANSACTION_ID
                                , INVOICE_ID
                                , LEDGER_VOUCHER
                                , LINE_NUMBER
                                , ORIGINAL_SALES_ORDER_ID
                                , PRODUCTION_TIME
                                , PURCHASE_ORDER_ID
                                , ORIGINATING_ORDER_SALES_ID
                                , REGISTRY_NUMBER
                                , INVENTORY_QUANTITY
                                , INVOICE_QUANTITY
                                , PHYSICAL_QUANTITY
                                , PRICE_UNIT
                                , SALES_PRICE
                                , COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , LINE_AMOUNT_TRANSACTION_CURRENCY
                                , LINE_AMOUNT_COMPANY_CURRENCY
                                , TAX_AMOUNT_TRANSACTION_CURRENCY
                                , TAX_AMOUNT_COMPANY_CURRENCY
                                , DISCOUNT_PERCENT
                                , DISCOUNT_AMOUNT
                                , LINE_DISCOUNT
                                , LINE_DISCOUNT_PERCENT
                                , FLOOR_LINE_DISCOUNT
                                , LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , COST_OF_GOODS_SOLD
								, FIXED_OVERHEAD
                                , LABOR
                                , MATERIAL
                                , VARIABLE_OVERHEAD
                                , FROZEN_FIXED_OVERHEAD
                                , FROZEN_LABOR
                                , FROZEN_MATERIAL
                                , FROZEN_COST_OF_GOODS_SOLD
                                , FROZEN_VARIABLE_OVERHEAD
                                , STANDARD_COST
                                , FROZEN_STANDARD_COST
                                , PRICE_OVERRIDE_REASON_CODE
                                , PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , ISLR
                                , RECORD_ID_POS
                                , PRICE_TYPE
                                , ACTIVATION_DATE
                                , CREATED_DATETIME
								, JOURNAL_NUMBER
								, JOURNAL_NAME
								, INVENTORY_SITE_ID
                                , COGSFIFO_CURRENCY_CODE
                                , COGSFIFO_SALES_STATUS
                                , COGSFIFO_COST_PRICE
                                , COGSFIFO_SALES_QTY
                                , COGSFIFO_ACCOUNTING_CURRENCY
                                , COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                , COGSFIFO_KIT_BOM_LEVEL
                                , COGSFIFO_COST_AMOUNT_POSTED
                                , COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                , COGSFIFO_KIT_IDENTIFIER
                                , COGSFIFO_FROM_CURRENCY_CODE
                                , COGSFIFO_TO_CURRENCY_CODE
                                , COGSFIFO_EXCHANGE_RATE
                                , COGSFIFO_COST_OF_GOODS_SOLD
                                , HK_SOURCE_NAME
                                , HK_SOFT_DELETE_FLAG
                                , HK_SOURCE_CREATED_TIMESTAMP
                                , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , HK_CREATED_JOB_RUN_ID
                                , HK_LAST_UPDATED_JOB_RUN_ID
                                , HK_CREATED_TIMESTAMP
                                , HK_LAST_UPDATED_TIMESTAMP
                                , HK_WAREHOUSE_ID
                                , TGT_HK_HASH_KEY  
                                FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || '
                                UNION ALL

                                SELECT FACT_SALES_INVOICES_KEY
                                , SOURCE_NAME
                                , RECORD_ID
                                , LEGAL_ENTITY
                                , ITEM_ID
                                , DIM_SOURCE_SYSTEM_KEY
                                , DIM_SOURCE_SYSTEM_SNKEY
                                , DELIVERY_DATE_DIM_DATE_KEY
                                , DELIVERY_DATE_DIM_DATE_SNKEY
                                , DOCUMENT_DATE_DIM_DATE_KEY
                                , DOCUMENT_DATE_DIM_DATE_SNKEY
                                , DUE_DATE_DIM_DATE_KEY
                                , DUE_DATE_DIM_DATE_SNKEY
                                , INVOICE_DATE_DIM_DATE_KEY
                                , INVOICE_DATE_DIM_DATE_SNKEY
                                , MANUFACTURED_DATE_DIM_DATE_KEY
                                , MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , RELATED_ORDER_DATE_DIM_DATE_KEY
                                , RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , DIM_BUSINESS_UNIT_KEY
                                , DIM_BUSINESS_UNIT_SNKEY
                                , DIM_CAMPAIGN_KEY
                                , DIM_CAMPAIGN_SNKEY
                                , DIM_COMMISSION_GROUP_KEY
                                , DIM_COMMISSION_GROUP_SNKEY
                                , DIM_COST_KEY
                                , DIM_COST_SNKEY
                                , DIM_CURRENCY_KEY
                                , DIM_CURRENCY_SNKEY
                                , DIM_CUSTOMER_INVOICE_KEY
                                , DIM_CUSTOMER_INVOICE_SNKEY
                                , DIM_CUSTOMER_ORDER_KEY
                                , DIM_CUSTOMER_ORDER_SNKEY
                                , DIM_CUSTOMER_GROUP_KEY
                                , DIM_CUSTOMER_GROUP_SNKEY
                                , DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , DIM_DEFAULT_DIMENSION_KEY
                                , DIM_DEFAULT_DIMENSION_SNKEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , DIM_INVENTORY_KEY
                                , DIM_INVENTORY_SNKEY
                                , DIM_ITEM_KEY
                                , DIM_ITEM_SNKEY
                                , DIM_ITEM_STATUS_KEY
                                , DIM_ITEM_STATUS_SNKEY
                                , DIM_LEGAL_ENTITY_KEY
                                , DIM_LEGAL_ENTITY_SNKEY
                                , DIM_LINE_RETURN_REASON_KEY
                                , DIM_LINE_RETURN_REASON_SNKEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , DIM_DELIVERY_MODE_KEY
                                , DIM_DELIVERY_MODE_SNKEY
                                , DIM_DELIVERY_TERM_KEY
                                , DIM_DELIVERY_TERM_SNKEY
                                , DIM_PAYMENT_TERMS_KEY
                                , DIM_PAYMENT_TERMS_SNKEY
                                , DIM_PROCUREMENT_CATEGORY_KEY
                                , DIM_PROCUREMENT_CATEGORY_SNKEY
                                , DIM_RETURN_DISPOSITION_KEY
                                , DIM_RETURN_DISPOSITION_SNKEY
                                , DIM_RETURN_REASON_KEY
                                , DIM_RETURN_REASON_SNKEY
                                , DIM_SALES_GROUP_KEY
                                , DIM_SALES_GROUP_SNKEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , DIM_SALES_ORDER_KEY
                                , DIM_SALES_ORDER_SNKEY
                                , DIM_SALES_ORIGIN_KEY
                                , DIM_SALES_ORIGIN_SNKEY
                                , DIM_SALES_POOL_KEY
                                , DIM_SALES_POOL_SNKEY
                                , DIM_SALES_PRICE_GROUP_KEY
                                , DIM_SALES_PRICE_GROUP_SNKEY
                                , DIM_TAX_GROUP_KEY
                                , DIM_TAX_GROUP_SNKEY
                                , DIM_TAX_ITEM_GROUP_KEY
                                , DIM_TAX_ITEM_GROUP_SNKEY
                                , DIM_UNIT_OF_MEASURE_SALES_KEY
                                , DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , DIM_WAREHOUSE_KEY
                                , DIM_WAREHOUSE_SNKEY
                                , DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , DIM_WORKER_SALES_TAKER_KEY
                                , DIM_WORKER_SALES_TAKER_SNKEY
                                , INVOICE_KEY
                                , BUSINESS_UNIT_ID
                                , CAMPAIGN_ID
                                , COMMISSION_GROUP_ID
                                , CURRENCY_CODE
                                , CUSTOMER_ACCOUNT_INVOICE
                                , CUSTOMER_ACCOUNT_ORDER
                                , CUSTOMER_GROUP_ID
                                , CUSTOMER_MARKUP_GROUP_ID
                                , DEFAULT_DIMENSION
                                , CONFIGURATION_ID
                                , INTRA_STAT_TRANSACTION_CODE
                                , INVENTORY_DIMENSION_ID
                                , ITEM_STATUS
                                , LINE_RETURN_REASON_ID
                                , LINE_RETURN_REASON_GROUP_ID
                                , RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , DELIVERY_MODE_ID
                                , DELIVERY_TERM_ID
                                , PAYMENT_TERMS_ID
                                , PROCUREMENT_CATEGORY
                                , RETURN_DISPOSITION_ID
                                , RETURN_REASON_ID
                                , SALES_GROUP_ID
                                , SALES_LINE_DISCOUNT_GROUP_ID
                                , SALES_ORDER_ID
                                , SALES_ORIGIN_ID
                                , SALES_POOL_ID
                                , SALES_PRICE_GROUP_ID
                                , TAX_GROUP_ID
                                , TAX_ITEM_GROUP_ID
                                , UNIT_OF_MEASURE_CODE_SALES
                                , WAREHOUSE_ID
                                , RECORD_ID_SALES_RESPONSIBLE
                                , RECORD_ID_SALES_TAKER
                                , DOCUMENT_STATUS
                                , FLOOR_SAMPLE_TYPE
                                , HEADER_RETURN_STATUS
                                , HEADER_SALES_STATUS
                                , RETURN_STATUS
                                , SALES_STATUS
                                , SALES_TYPE
                                , SHIP_CARRIER_DELIVERY_TYPE
                                , TRADE_LINE_DELIVERY_TYPE
                                , IS_AT_AGENT_TRANSACTION
                                , IS_BLIND_SHIPMENT
                                , IS_EXPEDITED_SHIPMENT
                                , IS_FLOOR_SAMPLE_DISCOUNT
                                , IS_ITEM_TRANSACTION
                                , IS_LINE_DELIVERY_COMPLETE
                                , IS_ORDER_BLOCKED
                                , IS_ORDER_LINE_BLOCKED
                                , IS_ORDER_LOCKED
                                , IS_RETURNED_ITEM_SCRAP
                                , IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , IS_STOCKED_PRODUCT
                                , DROP_SHIPMENT
                                , DELIVERY_DATE
								, DOCUMENT_DATE
								, DUE_DATE
								, INVOICE_DATE
								, MANUFACTURED_DATE
								, ORIGINATING_ORDER_CREATED_DATE
								, RELATED_ORDER_DATE
								, RETURN_ARRIVAL_DATE
								, RETURN_CLOSED_DATE
								, SALES_LINE_CREATED_DATE
								, INVENTORY_TRANSACTION_ID
                                , INVOICE_ID
                                , LEDGER_VOUCHER
                                , LINE_NUMBER
                                , ORIGINAL_SALES_ORDER_ID
                                , PRODUCTION_TIME
                                , PURCHASE_ORDER_ID
                                , ORIGINATING_ORDER_SALES_ID
                                , REGISTRY_NUMBER
                                , INVENTORY_QUANTITY
                                , INVOICE_QUANTITY
                                , PHYSICAL_QUANTITY
                                , PRICE_UNIT
                                , SALES_PRICE
                                , COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , LINE_AMOUNT_TRANSACTION_CURRENCY
                                , LINE_AMOUNT_COMPANY_CURRENCY
                                , TAX_AMOUNT_TRANSACTION_CURRENCY
                                , TAX_AMOUNT_COMPANY_CURRENCY
                                , DISCOUNT_PERCENT
                                , DISCOUNT_AMOUNT
                                , LINE_DISCOUNT
                                , LINE_DISCOUNT_PERCENT
                                , FLOOR_LINE_DISCOUNT
                                , LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , COST_OF_GOODS_SOLD
								, FIXED_OVERHEAD
                                , LABOR
                                , MATERIAL
                                , VARIABLE_OVERHEAD
                                , FROZEN_FIXED_OVERHEAD
                                , FROZEN_LABOR
                                , FROZEN_MATERIAL
                                , FROZEN_COST_OF_GOODS_SOLD
                                , FROZEN_VARIABLE_OVERHEAD
                                , STANDARD_COST
                                , FROZEN_STANDARD_COST
                                , PRICE_OVERRIDE_REASON_CODE
                                , PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , ISLR
                                , RECORD_ID_POS
                                , PRICE_TYPE
                                , ACTIVATION_DATE
                                , CREATED_DATETIME
								, JOURNAL_NUMBER
								, JOURNAL_NAME
								, INVENTORY_SITE_ID
                                , COGSFIFO_CURRENCY_CODE
                                , COGSFIFO_SALES_STATUS
                                , COGSFIFO_COST_PRICE
                                , COGSFIFO_SALES_QTY
                                , COGSFIFO_ACCOUNTING_CURRENCY
                                , COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                , COGSFIFO_KIT_BOM_LEVEL
                                , COGSFIFO_COST_AMOUNT_POSTED
                                , COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                , COGSFIFO_KIT_IDENTIFIER
                                , COGSFIFO_FROM_CURRENCY_CODE
                                , COGSFIFO_TO_CURRENCY_CODE
                                , COGSFIFO_EXCHANGE_RATE
                                , COGSFIFO_COST_OF_GOODS_SOLD
                                , HK_SOURCE_NAME
                                , HK_SOFT_DELETE_FLAG
                                , HK_SOURCE_CREATED_TIMESTAMP
                                , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , HK_CREATED_JOB_RUN_ID
                                , HK_LAST_UPDATED_JOB_RUN_ID
                                , HK_CREATED_TIMESTAMP
                                , HK_LAST_UPDATED_TIMESTAMP
                                , HK_WAREHOUSE_ID
                                , TGT_HK_HASH_KEY  
                                FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01A_' || :CURR_FORMATTED_TIMESTAMP
     || '
                                
                                UNION ALL

                                SELECT FACT_SALES_INVOICES_KEY
                                , SOURCE_NAME
                                , RECORD_ID
                                , LEGAL_ENTITY
                                , ITEM_ID
                                , DIM_SOURCE_SYSTEM_KEY
                                , DIM_SOURCE_SYSTEM_SNKEY
                                , DELIVERY_DATE_DIM_DATE_KEY
                                , DELIVERY_DATE_DIM_DATE_SNKEY
                                , DOCUMENT_DATE_DIM_DATE_KEY
                                , DOCUMENT_DATE_DIM_DATE_SNKEY
                                , DUE_DATE_DIM_DATE_KEY
                                , DUE_DATE_DIM_DATE_SNKEY
                                , INVOICE_DATE_DIM_DATE_KEY
                                , INVOICE_DATE_DIM_DATE_SNKEY
                                , MANUFACTURED_DATE_DIM_DATE_KEY
                                , MANUFACTURED_DATE_DIM_DATE_SNKEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                , RELATED_ORDER_DATE_DIM_DATE_KEY
                                , RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                , RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                , RETURN_CLOSED_DATE_DIM_DATE_KEY
                                , RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                , SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                , DIM_BUSINESS_UNIT_KEY
                                , DIM_BUSINESS_UNIT_SNKEY
                                , DIM_CAMPAIGN_KEY
                                , DIM_CAMPAIGN_SNKEY
                                , DIM_COMMISSION_GROUP_KEY
                                , DIM_COMMISSION_GROUP_SNKEY
                                , DIM_COST_KEY
                                , DIM_COST_SNKEY
                                , DIM_CURRENCY_KEY
                                , DIM_CURRENCY_SNKEY
                                , DIM_CUSTOMER_INVOICE_KEY
                                , DIM_CUSTOMER_INVOICE_SNKEY
                                , DIM_CUSTOMER_ORDER_KEY
                                , DIM_CUSTOMER_ORDER_SNKEY
                                , DIM_CUSTOMER_GROUP_KEY
                                , DIM_CUSTOMER_GROUP_SNKEY
                                , DIM_CUSTOMER_MARKUP_GROUP_KEY
                                , DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                , DIM_DEFAULT_DIMENSION_KEY
                                , DIM_DEFAULT_DIMENSION_SNKEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                , DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                , DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                , DIM_INVENTORY_KEY
                                , DIM_INVENTORY_SNKEY
                                , DIM_ITEM_KEY
                                , DIM_ITEM_SNKEY
                                , DIM_ITEM_STATUS_KEY
                                , DIM_ITEM_STATUS_SNKEY
                                , DIM_LEGAL_ENTITY_KEY
                                , DIM_LEGAL_ENTITY_SNKEY
                                , DIM_LINE_RETURN_REASON_KEY
                                , DIM_LINE_RETURN_REASON_SNKEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                , DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                , DIM_LOCATION_INVOICE_ADDRESS_KEY
                                , DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                , DIM_DELIVERY_MODE_KEY
                                , DIM_DELIVERY_MODE_SNKEY
                                , DIM_DELIVERY_TERM_KEY
                                , DIM_DELIVERY_TERM_SNKEY
                                , DIM_PAYMENT_TERMS_KEY
                                , DIM_PAYMENT_TERMS_SNKEY
                                , DIM_PROCUREMENT_CATEGORY_KEY
                                , DIM_PROCUREMENT_CATEGORY_SNKEY
                                , DIM_RETURN_DISPOSITION_KEY
                                , DIM_RETURN_DISPOSITION_SNKEY
                                , DIM_RETURN_REASON_KEY
                                , DIM_RETURN_REASON_SNKEY
                                , DIM_SALES_GROUP_KEY
                                , DIM_SALES_GROUP_SNKEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                , DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                , DIM_SALES_ORDER_KEY
                                , DIM_SALES_ORDER_SNKEY
                                , DIM_SALES_ORIGIN_KEY
                                , DIM_SALES_ORIGIN_SNKEY
                                , DIM_SALES_POOL_KEY
                                , DIM_SALES_POOL_SNKEY
                                , DIM_SALES_PRICE_GROUP_KEY
                                , DIM_SALES_PRICE_GROUP_SNKEY
                                , DIM_TAX_GROUP_KEY
                                , DIM_TAX_GROUP_SNKEY
                                , DIM_TAX_ITEM_GROUP_KEY
                                , DIM_TAX_ITEM_GROUP_SNKEY
                                , DIM_UNIT_OF_MEASURE_SALES_KEY
                                , DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                , DIM_WAREHOUSE_KEY
                                , DIM_WAREHOUSE_SNKEY
                                , DIM_WORKER_SALES_RESPONSIBLE_KEY
                                , DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                , DIM_WORKER_SALES_TAKER_KEY
                                , DIM_WORKER_SALES_TAKER_SNKEY
                                , INVOICE_KEY
                                , BUSINESS_UNIT_ID
                                , CAMPAIGN_ID
                                , COMMISSION_GROUP_ID
                                , CURRENCY_CODE
                                , CUSTOMER_ACCOUNT_INVOICE
                                , CUSTOMER_ACCOUNT_ORDER
                                , CUSTOMER_GROUP_ID
                                , CUSTOMER_MARKUP_GROUP_ID
                                , DEFAULT_DIMENSION
                                , CONFIGURATION_ID
                                , INTRA_STAT_TRANSACTION_CODE
                                , INVENTORY_DIMENSION_ID
                                , ITEM_STATUS
                                , LINE_RETURN_REASON_ID
                                , LINE_RETURN_REASON_GROUP_ID
                                , RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                , RECORD_ID_LOCATION_INVOICE_ADDRESS
                                , DELIVERY_MODE_ID
                                , DELIVERY_TERM_ID
                                , PAYMENT_TERMS_ID
                                , PROCUREMENT_CATEGORY
                                , RETURN_DISPOSITION_ID
                                , RETURN_REASON_ID
                                , SALES_GROUP_ID
                                , SALES_LINE_DISCOUNT_GROUP_ID
                                , SALES_ORDER_ID
                                , SALES_ORIGIN_ID
                                , SALES_POOL_ID
                                , SALES_PRICE_GROUP_ID
                                , TAX_GROUP_ID
                                , TAX_ITEM_GROUP_ID
                                , UNIT_OF_MEASURE_CODE_SALES
                                , WAREHOUSE_ID
                                , RECORD_ID_SALES_RESPONSIBLE
                                , RECORD_ID_SALES_TAKER
                                , DOCUMENT_STATUS
                                , FLOOR_SAMPLE_TYPE
                                , HEADER_RETURN_STATUS
                                , HEADER_SALES_STATUS
                                , RETURN_STATUS
                                , SALES_STATUS
                                , SALES_TYPE
                                , SHIP_CARRIER_DELIVERY_TYPE
                                , TRADE_LINE_DELIVERY_TYPE
                                , IS_AT_AGENT_TRANSACTION
                                , IS_BLIND_SHIPMENT
                                , IS_EXPEDITED_SHIPMENT
                                , IS_FLOOR_SAMPLE_DISCOUNT
                                , IS_ITEM_TRANSACTION
                                , IS_LINE_DELIVERY_COMPLETE
                                , IS_ORDER_BLOCKED
                                , IS_ORDER_LINE_BLOCKED
                                , IS_ORDER_LOCKED
                                , IS_RETURNED_ITEM_SCRAP
                                , IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                , IS_STOCKED_PRODUCT
                                , DROP_SHIPMENT
                                , DELIVERY_DATE
								, DOCUMENT_DATE
								, DUE_DATE
								, INVOICE_DATE
								, MANUFACTURED_DATE
								, ORIGINATING_ORDER_CREATED_DATE
								, RELATED_ORDER_DATE
								, RETURN_ARRIVAL_DATE
								, RETURN_CLOSED_DATE
								, SALES_LINE_CREATED_DATE
								, INVENTORY_TRANSACTION_ID
                                , INVOICE_ID
                                , LEDGER_VOUCHER
                                , LINE_NUMBER
                                , ORIGINAL_SALES_ORDER_ID
                                , PRODUCTION_TIME
                                , PURCHASE_ORDER_ID
                                , ORIGINATING_ORDER_SALES_ID
                                , REGISTRY_NUMBER
                                , INVENTORY_QUANTITY
                                , INVOICE_QUANTITY
                                , PHYSICAL_QUANTITY
                                , PRICE_UNIT
                                , SALES_PRICE
                                , COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                , COMMISSION_AMOUNT_COMPANY_CURRENCY
                                , LINE_AMOUNT_TRANSACTION_CURRENCY
                                , LINE_AMOUNT_COMPANY_CURRENCY
                                , TAX_AMOUNT_TRANSACTION_CURRENCY
                                , TAX_AMOUNT_COMPANY_CURRENCY
                                , DISCOUNT_PERCENT
                                , DISCOUNT_AMOUNT
                                , LINE_DISCOUNT
                                , LINE_DISCOUNT_PERCENT
                                , FLOOR_LINE_DISCOUNT
                                , LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                , LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                , COST_OF_GOODS_SOLD
								, FIXED_OVERHEAD
                                , LABOR
                                , MATERIAL
                                , VARIABLE_OVERHEAD
                                , FROZEN_FIXED_OVERHEAD
                                , FROZEN_LABOR
                                , FROZEN_MATERIAL
                                , FROZEN_COST_OF_GOODS_SOLD
                                , FROZEN_VARIABLE_OVERHEAD
                                , STANDARD_COST
                                , FROZEN_STANDARD_COST
                                , PRICE_OVERRIDE_REASON_CODE
                                , PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                , ISLR
                                , RECORD_ID_POS
                                , PRICE_TYPE
                                , ACTIVATION_DATE
                                , CREATED_DATETIME
								, JOURNAL_NUMBER
								, JOURNAL_NAME
								, INVENTORY_SITE_ID
                                , COGSFIFO_CURRENCY_CODE
                                , COGSFIFO_SALES_STATUS
                                , COGSFIFO_COST_PRICE
                                , COGSFIFO_SALES_QTY
                                , COGSFIFO_ACCOUNTING_CURRENCY
                                , COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                , COGSFIFO_KIT_BOM_LEVEL
                                , COGSFIFO_COST_AMOUNT_POSTED
                                , COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                , COGSFIFO_KIT_IDENTIFIER
                                , COGSFIFO_FROM_CURRENCY_CODE
                                , COGSFIFO_TO_CURRENCY_CODE
                                , COGSFIFO_EXCHANGE_RATE
                                , COGSFIFO_COST_OF_GOODS_SOLD
                                , HK_SOURCE_NAME
                                , HK_SOFT_DELETE_FLAG
                                , HK_SOURCE_CREATED_TIMESTAMP
                                , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , HK_CREATED_JOB_RUN_ID
                                , HK_LAST_UPDATED_JOB_RUN_ID
                                , HK_CREATED_TIMESTAMP
                                , HK_LAST_UPDATED_TIMESTAMP
                                , HK_WAREHOUSE_ID
                                , TGT_HK_HASH_KEY  
                                FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01B_' || :CURR_FORMATTED_TIMESTAMP
     || '
                        
                        ) as utbl
                        ';
                            
        EXECUTE IMMEDIATE :create_wrk_tbl1final;
       
        
        
        
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1 
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.LEGAL_ENTITY, ''~'', src.ITEM_ID) AS FACT_SALES_INVOICES_KEY
, src.SOURCE_NAME
, src.RECORD_ID
, src.LEGAL_ENTITY
, src.ITEM_ID
, case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
, src.DIM_SOURCE_SYSTEM_SNKEY
, case when src.DELIVERY_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS DELIVERY_DATE_DIM_DATE_KEY
, src.DELIVERY_DATE_DIM_DATE_SNKEY
, case when src.DOCUMENT_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS DOCUMENT_DATE_DIM_DATE_KEY
, src.DOCUMENT_DATE_DIM_DATE_SNKEY
, case when src.DUE_DATE = ''1950-01-01'' then -2 else nvl(d4.DIM_DATE_KEY, -1) END AS DUE_DATE_DIM_DATE_KEY
, src.DUE_DATE_DIM_DATE_SNKEY
, case when src.INVOICE_DATE = ''1950-01-01'' then -2 else nvl(d5.DIM_DATE_KEY, -1) END AS INVOICE_DATE_DIM_DATE_KEY
, src.INVOICE_DATE_DIM_DATE_SNKEY
, case when src.MANUFACTURED_DATE = ''1950-01-01'' then -2 else nvl(d6.DIM_DATE_KEY, -1) END AS MANUFACTURED_DATE_DIM_DATE_KEY
, src.MANUFACTURED_DATE_DIM_DATE_SNKEY
, case when src.ORIGINATING_ORDER_CREATED_DATE = ''1950-01-01'' then -2 else nvl(d7.DIM_DATE_KEY, -1) END AS ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
, src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
, case when src.RELATED_ORDER_DATE = ''1950-01-01'' then -2 else nvl(d8.DIM_DATE_KEY, -1) END AS RELATED_ORDER_DATE_DIM_DATE_KEY
, src.RELATED_ORDER_DATE_DIM_DATE_SNKEY
, case when src.RETURN_ARRIVAL_DATE = ''1950-01-01'' then -2 else nvl(d9.DIM_DATE_KEY, -1) END AS RETURN_ARRIVAL_DATE_DIM_DATE_KEY
, src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
, case when src.RETURN_CLOSED_DATE = ''1950-01-01'' then -2 else nvl(d10.DIM_DATE_KEY, -1) END AS RETURN_CLOSED_DATE_DIM_DATE_KEY
, src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
, case when src.SALES_LINE_CREATED_DATE = ''1950-01-01'' then -2 else nvl(d11.DIM_DATE_KEY, -1) END AS SALES_LINE_CREATED_DATE_DIM_DATE_KEY
, src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
, case when src.DIM_BUSINESS_UNIT_SNKEY = -2 then -2 else nvl(d12.DIM_BUSINESS_UNIT_KEY, -1) END AS DIM_BUSINESS_UNIT_KEY
, src.DIM_BUSINESS_UNIT_SNKEY
, case when src.DIM_CAMPAIGN_SNKEY = -2 then -2 else nvl(d13.DIM_CAMPAIGN_KEY, -1) END AS DIM_CAMPAIGN_KEY
, src.DIM_CAMPAIGN_SNKEY
, case when src.DIM_COMMISSION_GROUP_SNKEY = -2 then -2 else nvl(d14.DIM_COMMISSION_GROUP_KEY, -1) END AS DIM_COMMISSION_GROUP_KEY
, src.DIM_COMMISSION_GROUP_SNKEY
, case when src.DIM_COST_SNKEY = -2 then -2 else nvl(d15.DIM_COST_KEY, -1) END AS DIM_COST_KEY
, src.DIM_COST_SNKEY
, case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d16.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
, src.DIM_CURRENCY_SNKEY
, case when src.DIM_CUSTOMER_INVOICE_SNKEY = -2 then -2 else nvl(d17.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_INVOICE_KEY
, src.DIM_CUSTOMER_INVOICE_SNKEY
, case when src.DIM_CUSTOMER_ORDER_SNKEY = -2 then -2 else nvl(d18.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_ORDER_KEY
, src.DIM_CUSTOMER_ORDER_SNKEY
, case when src.DIM_CUSTOMER_GROUP_SNKEY = -2 then -2 else nvl(d19.DIM_CUSTOMER_GROUP_KEY, -1) END AS DIM_CUSTOMER_GROUP_KEY
, src.DIM_CUSTOMER_GROUP_SNKEY
, case when src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = -2 then -2 else nvl(d20.DIM_CUSTOMER_MARKUP_GROUP_KEY, -1) END AS DIM_CUSTOMER_MARKUP_GROUP_KEY
, src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
, case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2 else nvl(d21.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
, src.DIM_DEFAULT_DIMENSION_SNKEY
, case when src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = -2 then -2 else nvl(d22.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY, -1) END AS DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
, src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
, case when src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = -2 then -2 else nvl(d23.DIM_INTRA_STAT_TRANSACTION_CODE_KEY, -1) END AS DIM_INTRA_STAT_TRANSACTION_CODE_KEY
, src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
, case when src.DIM_INVENTORY_SNKEY = -2 then -2 else nvl(d24.DIM_INVENTORY_KEY, -1) END AS DIM_INVENTORY_KEY
, src.DIM_INVENTORY_SNKEY
, case when src.DIM_ITEM_SNKEY = -2 then -2 else nvl(d25.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
, src.DIM_ITEM_SNKEY
, -1 AS DIM_ITEM_STATUS_KEY
, src.DIM_ITEM_STATUS_SNKEY
, case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d27.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
, src.DIM_LEGAL_ENTITY_SNKEY
, case when src.DIM_LINE_RETURN_REASON_SNKEY = -2 then -2 else nvl(d28.DIM_LINE_RETURN_REASON_KEY, -1) END AS DIM_LINE_RETURN_REASON_KEY
, src.DIM_LINE_RETURN_REASON_SNKEY
, case when src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = -2 then -2 else nvl(d29.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_DELIVERY_ADDRESS_KEY
, src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
, case when src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = -2 then -2 else nvl(d30.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_INVOICE_ADDRESS_KEY
, src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
, case when src.DIM_DELIVERY_MODE_SNKEY = -2 then -2 else nvl(d31.DIM_DELIVERY_MODE_KEY, -1) END AS DIM_DELIVERY_MODE_KEY
, src.DIM_DELIVERY_MODE_SNKEY
, case when src.DIM_DELIVERY_TERM_SNKEY = -2 then -2 else nvl(d32.DIM_DELIVERY_TERM_KEY, -1) END AS DIM_DELIVERY_TERM_KEY
, src.DIM_DELIVERY_TERM_SNKEY
, case when src.DIM_PAYMENT_TERMS_SNKEY = -2 then -2 else nvl(d33.DIM_PAYMENT_TERMS_KEY, -1) END AS DIM_PAYMENT_TERMS_KEY
, src.DIM_PAYMENT_TERMS_SNKEY
, case when src.DIM_PAYMENT_TERMS_SNKEY = -2 then -2 else nvl(d34.DIM_SALES_PROCUREMENT_CATEGORY_KEY, -1) END AS DIM_PROCUREMENT_CATEGORY_KEY
, src.DIM_PROCUREMENT_CATEGORY_SNKEY
, case when src.DIM_RETURN_DISPOSITION_SNKEY = -2 then -2 else nvl(d35.DIM_RETURN_DISPOSITION_KEY, -1) END AS DIM_RETURN_DISPOSITION_KEY
, src.DIM_RETURN_DISPOSITION_SNKEY
, case when src.DIM_RETURN_REASON_SNKEY = -2 then -2 else nvl(d36.DIM_RETURN_REASON_KEY, -1) END AS DIM_RETURN_REASON_KEY
, src.DIM_RETURN_REASON_SNKEY
, case when src.DIM_SALES_GROUP_SNKEY = -2 then -2 else nvl(d37.DIM_SALES_GROUP_KEY, -1) END AS DIM_SALES_GROUP_KEY
, src.DIM_SALES_GROUP_SNKEY
, case when src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = -2 then -2 else nvl(d38.DIM_SALES_LINE_DISCOUNT_GROUP_KEY, -1) END AS DIM_SALES_LINE_DISCOUNT_GROUP_KEY
, src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
, case when src.DIM_SALES_ORDER_SNKEY = -2 then -2 else nvl(d39.DIM_SALES_ORDER_KEY, -1) END AS DIM_SALES_ORDER_KEY
, src.DIM_SALES_ORDER_SNKEY
, case when src.DIM_SALES_ORIGIN_SNKEY = -2 then -2 else nvl(d40.DIM_SALES_ORIGIN_KEY, -1) END AS DIM_SALES_ORIGIN_KEY
, src.DIM_SALES_ORIGIN_SNKEY
, case when src.DIM_SALES_POOL_SNKEY = -2 then -2 else nvl(d41.DIM_SALES_POOL_KEY, -1) END AS DIM_SALES_POOL_KEY
, src.DIM_SALES_POOL_SNKEY
, case when src.DIM_SALES_PRICE_GROUP_SNKEY = -2 then -2 else nvl(d42.DIM_SALES_PRICE_GROUP_KEY, -1) END AS DIM_SALES_PRICE_GROUP_KEY
, src.DIM_SALES_PRICE_GROUP_SNKEY
, case when src.DIM_TAX_GROUP_SNKEY = -2 then -2 else nvl(d43.DIM_TAX_GROUP_KEY, -1) END AS DIM_TAX_GROUP_KEY
, src.DIM_TAX_GROUP_SNKEY
, case when src.DIM_TAX_ITEM_GROUP_SNKEY = -2 then -2 else nvl(d44.DIM_TAX_ITEM_GROUP_KEY, -1) END AS DIM_TAX_ITEM_GROUP_KEY
, src.DIM_TAX_ITEM_GROUP_SNKEY
, case when src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = -2 then -2 else nvl(d45.DIM_UNIT_OF_MEASURE_KEY, -1) END AS DIM_UNIT_OF_MEASURE_SALES_KEY
, src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
, case when src.DIM_WAREHOUSE_SNKEY = -2 then -2 else nvl(d46.DIM_WAREHOUSE_KEY, -1) END AS DIM_WAREHOUSE_KEY
, src.DIM_WAREHOUSE_SNKEY
, case when src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = -2 then -2 else nvl(d47.DIM_WORKER_KEY, -1) END AS DIM_WORKER_SALES_RESPONSIBLE_KEY
, src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
, case when src.DIM_WORKER_SALES_TAKER_SNKEY = -2 then -2 else nvl(d48.DIM_WORKER_KEY, -1) END AS DIM_WORKER_SALES_TAKER_KEY
, src.DIM_WORKER_SALES_TAKER_SNKEY
, hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID_POS), ''~'', src.ITEM_ID) AS INVOICE_KEY
, src.BUSINESS_UNIT_ID
, src.CAMPAIGN_ID
, src.COMMISSION_GROUP_ID
, src.CURRENCY_CODE
, src.CUSTOMER_ACCOUNT_INVOICE
, src.CUSTOMER_ACCOUNT_ORDER
, src.CUSTOMER_GROUP_ID
, src.CUSTOMER_MARKUP_GROUP_ID
, src.DEFAULT_DIMENSION
, src.CONFIGURATION_ID
, src.INTRA_STAT_TRANSACTION_CODE
, src.INVENTORY_DIMENSION_ID
, src.ITEM_STATUS
, src.LINE_RETURN_REASON_ID
, src.LINE_RETURN_REASON_GROUP_ID
, src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
, src.RECORD_ID_LOCATION_INVOICE_ADDRESS
, src.DELIVERY_MODE_ID
, src.DELIVERY_TERM_ID
, src.PAYMENT_TERMS_ID
, src.PROCUREMENT_CATEGORY
, src.RETURN_DISPOSITION_ID
, src.RETURN_REASON_ID
, src.SALES_GROUP_ID
, src.SALES_LINE_DISCOUNT_GROUP_ID
, src.SALES_ORDER_ID
, src.SALES_ORIGIN_ID
, src.SALES_POOL_ID
, src.SALES_PRICE_GROUP_ID
, src.TAX_GROUP_ID
, src.TAX_ITEM_GROUP_ID
, src.UNIT_OF_MEASURE_CODE_SALES
, src.WAREHOUSE_ID
, src.RECORD_ID_SALES_RESPONSIBLE
, src.RECORD_ID_SALES_TAKER
, src.DOCUMENT_STATUS
, src.FLOOR_SAMPLE_TYPE
, src.HEADER_RETURN_STATUS
, src.HEADER_SALES_STATUS
, src.RETURN_STATUS
, src.SALES_STATUS
, src.SALES_TYPE
, src.SHIP_CARRIER_DELIVERY_TYPE
, src.TRADE_LINE_DELIVERY_TYPE
, src.IS_AT_AGENT_TRANSACTION
, src.IS_BLIND_SHIPMENT
, src.IS_EXPEDITED_SHIPMENT
, src.IS_FLOOR_SAMPLE_DISCOUNT
, src.IS_ITEM_TRANSACTION
, src.IS_LINE_DELIVERY_COMPLETE
, src.IS_ORDER_BLOCKED
, src.IS_ORDER_LINE_BLOCKED
, src.IS_ORDER_LOCKED
, src.IS_RETURNED_ITEM_SCRAP
, src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
, src.IS_STOCKED_PRODUCT
, src.DROP_SHIPMENT
, src.DELIVERY_DATE
, src.DOCUMENT_DATE
, src.DUE_DATE
, src.INVOICE_DATE
, src.MANUFACTURED_DATE
, src.ORIGINATING_ORDER_CREATED_DATE
, src.RELATED_ORDER_DATE
, src.RETURN_ARRIVAL_DATE
, src.RETURN_CLOSED_DATE
, src.SALES_LINE_CREATED_DATE
, src.INVENTORY_TRANSACTION_ID
, src.INVOICE_ID
, src.LEDGER_VOUCHER
, src.LINE_NUMBER
, src.ORIGINAL_SALES_ORDER_ID
, src.PRODUCTION_TIME
, src.PURCHASE_ORDER_ID
, src.ORIGINATING_ORDER_SALES_ID
, src.REGISTRY_NUMBER
, src.INVENTORY_QUANTITY
, src.INVOICE_QUANTITY
, src.PHYSICAL_QUANTITY
, src.PRICE_UNIT
, src.SALES_PRICE
, src.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
, src.COMMISSION_AMOUNT_COMPANY_CURRENCY
, src.LINE_AMOUNT_TRANSACTION_CURRENCY
, src.LINE_AMOUNT_COMPANY_CURRENCY
, src.TAX_AMOUNT_TRANSACTION_CURRENCY
, src.TAX_AMOUNT_COMPANY_CURRENCY
, src.DISCOUNT_PERCENT
, src.DISCOUNT_AMOUNT
, src.LINE_DISCOUNT
, src.LINE_DISCOUNT_PERCENT
, src.FLOOR_LINE_DISCOUNT
, src.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
, src.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
, src.COST_OF_GOODS_SOLD
, src.FIXED_OVERHEAD
, src.LABOR
, src.MATERIAL
, src.VARIABLE_OVERHEAD
, src.FROZEN_COST_OF_GOODS_SOLD
, src.FROZEN_FIXED_OVERHEAD
, src.FROZEN_LABOR
, src.FROZEN_MATERIAL
, src.FROZEN_VARIABLE_OVERHEAD
, src.STANDARD_COST
, src.FROZEN_STANDARD_COST
, src.PRICE_OVERRIDE_REASON_CODE
, src.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
, src.ISLR
, src.RECORD_ID_POS
, src.PRICE_TYPE
, src.ACTIVATION_DATE
, src.CREATED_DATETIME
, src.JOURNAL_NUMBER
, src.JOURNAL_NAME
, src.INVENTORY_SITE_ID
, src.COGSFIFO_CURRENCY_CODE
, src.COGSFIFO_SALES_STATUS
, src.COGSFIFO_COST_PRICE
, src.COGSFIFO_SALES_QTY
, src.COGSFIFO_ACCOUNTING_CURRENCY
, src.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
, src.COGSFIFO_KIT_BOM_LEVEL
, src.COGSFIFO_COST_AMOUNT_POSTED
, src.COGSFIFO_COST_AMOUNT_ADJUSTMENT
, src.COGSFIFO_KIT_IDENTIFIER
, src.COGSFIFO_FROM_CURRENCY_CODE
, src.COGSFIFO_TO_CURRENCY_CODE
, src.COGSFIFO_EXCHANGE_RATE
, src.COGSFIFO_COST_OF_GOODS_SOLD
, hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.LEGAL_ENTITY, ''~'', src.ITEM_ID, ''~'', src.BUSINESS_UNIT_ID, ''~'', src.CAMPAIGN_ID, ''~'', src.COMMISSION_GROUP_ID, ''~'', src.CURRENCY_CODE, ''~'', src.CUSTOMER_ACCOUNT_INVOICE, ''~'', src.CUSTOMER_ACCOUNT_ORDER, ''~'', src.CUSTOMER_GROUP_ID, ''~'', src.CUSTOMER_MARKUP_GROUP_ID, ''~'', src.DEFAULT_DIMENSION, ''~'', src.CONFIGURATION_ID, ''~'', src.INTRA_STAT_TRANSACTION_CODE, ''~'', src.INVENTORY_DIMENSION_ID, ''~'', src.ITEM_STATUS, ''~'', src.LINE_RETURN_REASON_ID, ''~'', src.LINE_RETURN_REASON_GROUP_ID, ''~'', to_char(src.RECORD_ID_LOCATION_DELIVERY_ADDRESS), ''~'', to_char(src.RECORD_ID_LOCATION_INVOICE_ADDRESS), ''~'', src.DELIVERY_MODE_ID, ''~'', src.DELIVERY_TERM_ID, ''~'', src.PAYMENT_TERMS_ID, ''~'', to_char(src.PROCUREMENT_CATEGORY), ''~'', src.RETURN_DISPOSITION_ID, ''~'', src.RETURN_REASON_ID, ''~'', src.SALES_GROUP_ID, ''~'', src.SALES_LINE_DISCOUNT_GROUP_ID, ''~'', src.SALES_ORDER_ID, ''~'', src.SALES_ORIGIN_ID, ''~'', src.SALES_POOL_ID, ''~'', src.SALES_PRICE_GROUP_ID, ''~'', src.TAX_GROUP_ID, ''~'', src.TAX_ITEM_GROUP_ID, ''~'', src.UNIT_OF_MEASURE_CODE_SALES, ''~'', src.WAREHOUSE_ID, ''~'', to_char(src.RECORD_ID_SALES_RESPONSIBLE), ''~'', to_char(src.RECORD_ID_SALES_TAKER), ''~'', src.DOCUMENT_STATUS, ''~'', src.FLOOR_SAMPLE_TYPE, ''~'', src.HEADER_RETURN_STATUS, ''~'', src.HEADER_SALES_STATUS, ''~'', src.RETURN_STATUS, ''~'', src.SALES_STATUS, ''~'', src.SALES_TYPE, ''~'', src.SHIP_CARRIER_DELIVERY_TYPE, ''~'', src.TRADE_LINE_DELIVERY_TYPE, ''~'', src.IS_AT_AGENT_TRANSACTION, ''~'', src.IS_BLIND_SHIPMENT, ''~'', src.IS_EXPEDITED_SHIPMENT, ''~'', src.IS_FLOOR_SAMPLE_DISCOUNT, ''~'', src.IS_ITEM_TRANSACTION, ''~'', src.IS_LINE_DELIVERY_COMPLETE, ''~'', src.IS_ORDER_BLOCKED, ''~'', src.IS_ORDER_LINE_BLOCKED, ''~'', src.IS_ORDER_LOCKED, ''~'', src.IS_RETURNED_ITEM_SCRAP, ''~'', src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE, ''~'', src.IS_STOCKED_PRODUCT, ''~'', src.DROP_SHIPMENT, ''~'', to_char(src.DELIVERY_DATE, ''yyyymmdd''), ''~'', to_char(src.DOCUMENT_DATE, ''yyyymmdd''), ''~'', to_char(src.DUE_DATE, ''yyyymmdd''), ''~'', to_char(src.INVOICE_DATE, ''yyyymmdd''), ''~'', to_char(src.MANUFACTURED_DATE, ''yyyymmdd''), ''~'', to_char(src.ORIGINATING_ORDER_CREATED_DATE, ''yyyymmdd''), ''~'', to_char(src.RELATED_ORDER_DATE, ''yyyymmdd''), ''~'', to_char(src.RETURN_ARRIVAL_DATE, ''yyyymmdd''), ''~'', to_char(src.RETURN_CLOSED_DATE, ''yyyymmdd''), ''~'', to_char(src.SALES_LINE_CREATED_DATE, ''yyyymmdd''), ''~'', src.INVENTORY_TRANSACTION_ID, ''~'', src.INVOICE_ID, ''~'', src.LEDGER_VOUCHER, ''~'', to_char(src.LINE_NUMBER), ''~'', src.ORIGINAL_SALES_ORDER_ID, ''~'', to_char(src.PRODUCTION_TIME, ''yyyymmddHH24MISSFF3''), ''~'', src.PURCHASE_ORDER_ID, ''~'', src.ORIGINATING_ORDER_SALES_ID, ''~'', src.REGISTRY_NUMBER, ''~'', to_char(src.INVENTORY_QUANTITY), ''~'', to_char(src.INVOICE_QUANTITY), ''~'', to_char(src.PHYSICAL_QUANTITY), ''~'', to_char(src.PRICE_UNIT), ''~'', to_char(src.SALES_PRICE), ''~'', to_char(src.COMMISSION_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.COMMISSION_AMOUNT_COMPANY_CURRENCY), ''~'', to_char(src.LINE_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.LINE_AMOUNT_COMPANY_CURRENCY), ''~'', to_char(src.TAX_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.TAX_AMOUNT_COMPANY_CURRENCY), ''~'', to_char(src.DISCOUNT_PERCENT), ''~'', to_char(src.DISCOUNT_AMOUNT), ''~'', to_char(src.LINE_DISCOUNT), ''~'', to_char(src.LINE_DISCOUNT_PERCENT), ''~'', to_char(src.FLOOR_LINE_DISCOUNT), ''~'', to_char(src.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY), ''~'', to_char(src.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY), ''~'', to_char(src.COST_OF_GOODS_SOLD), ''~'', to_char(src.FIXED_OVERHEAD), ''~'', to_char(src.LABOR), ''~'', to_char(src.MATERIAL), ''~'', to_char(src.VARIABLE_OVERHEAD), ''~'', to_char(src.FROZEN_COST_OF_GOODS_SOLD), ''~'', to_char(src.FROZEN_FIXED_OVERHEAD), ''~'', to_char(src.FROZEN_LABOR), ''~'', to_char(src.FROZEN_MATERIAL), ''~'', to_char(src.FROZEN_VARIABLE_OVERHEAD), ''~'', to_char(src.STANDARD_COST), ''~'', to_char(src.FROZEN_STANDARD_COST), ''~'', src.PRICE_OVERRIDE_REASON_CODE, ''~'', src.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION, ''~'', to_char(src.ISLR), ''~'', to_char(src.RECORD_ID_POS), ''~'', src.PRICE_TYPE, ''~'', to_char(src.ACTIVATION_DATE, ''yyyymmdd''), ''~'', to_char(src.CREATED_DATETIME, ''yyyymmddhh24missff3''), ''~'', src.JOURNAL_NUMBER, ''~'', src.JOURNAL_NAME, ''~'', src.INVENTORY_SITE_ID, ''~'', src.COGSFIFO_CURRENCY_CODE, ''~'', src.COGSFIFO_SALES_STATUS, ''~'', src.COGSFIFO_COST_PRICE, ''~'', src.COGSFIFO_SALES_QTY, ''~'', src.COGSFIFO_ACCOUNTING_CURRENCY, ''~'', src.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID, ''~'', src.COGSFIFO_KIT_BOM_LEVEL, ''~'', src.COGSFIFO_COST_AMOUNT_POSTED, ''~'', src.COGSFIFO_COST_AMOUNT_ADJUSTMENT, ''~'', src.COGSFIFO_KIT_IDENTIFIER, ''~'', src.COGSFIFO_FROM_CURRENCY_CODE, ''~'', src.COGSFIFO_TO_CURRENCY_CODE, ''~'', src.COGSFIFO_EXCHANGE_RATE, ''~'', src.COGSFIFO_COST_OF_GOODS_SOLD) AS SRC_HK_HASH_KEY
, src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID, src.LEGAL_ENTITY, src.ITEM_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                           
FROM (SELECT 
    prep01.FACT_SALES_INVOICES_KEY
    , prep01.SOURCE_NAME
    , prep01.RECORD_ID
    , prep01.LEGAL_ENTITY
    , prep01.ITEM_ID
    , prep01.DIM_SOURCE_SYSTEM_KEY
    , case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
    , prep01.DELIVERY_DATE_DIM_DATE_KEY
    , case when prep01.DELIVERY_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DELIVERY_DATE, ''yyyymmdd'')) END AS DELIVERY_DATE_DIM_DATE_SNKEY
    , prep01.DOCUMENT_DATE_DIM_DATE_KEY
    , case when prep01.DOCUMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
    , prep01.DUE_DATE_DIM_DATE_KEY
    , case when prep01.DUE_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DUE_DATE, ''yyyymmdd'')) END AS DUE_DATE_DIM_DATE_SNKEY
    , prep01.INVOICE_DATE_DIM_DATE_KEY
    , case when prep01.INVOICE_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.INVOICE_DATE, ''yyyymmdd'')) END AS INVOICE_DATE_DIM_DATE_SNKEY
    , prep01.MANUFACTURED_DATE_DIM_DATE_KEY
    , case when prep01.MANUFACTURED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.MANUFACTURED_DATE, ''yyyymmdd'')) END AS    MANUFACTURED_DATE_DIM_DATE_SNKEY
    , prep01.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
    , case when prep01.ORIGINATING_ORDER_CREATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.ORIGINATING_ORDER_CREATED_DATE, ''yyyymmdd'')) END AS ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
    , prep01.RELATED_ORDER_DATE_DIM_DATE_KEY
    , case when prep01.RELATED_ORDER_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.RELATED_ORDER_DATE, ''yyyymmdd'')) END AS RELATED_ORDER_DATE_DIM_DATE_SNKEY
    , prep01.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
, case when prep01.RETURN_ARRIVAL_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.RETURN_ARRIVAL_DATE, ''yyyymmdd'')) END AS RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
, prep01.RETURN_CLOSED_DATE_DIM_DATE_KEY
, case when prep01.RETURN_CLOSED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.RETURN_CLOSED_DATE, ''yyyymmdd'')) END AS RETURN_CLOSED_DATE_DIM_DATE_SNKEY
, prep01.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
, case when prep01.SALES_LINE_CREATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.SALES_LINE_CREATED_DATE, ''yyyymmdd'')) END AS SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
, prep01.DIM_BUSINESS_UNIT_KEY
, case when nvl(prep01.BUSINESS_UNIT_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.BUSINESS_UNIT_ID) END AS DIM_BUSINESS_UNIT_SNKEY
, prep01.DIM_CAMPAIGN_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CAMPAIGN_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CAMPAIGN_ID) END AS DIM_CAMPAIGN_SNKEY
, prep01.DIM_COMMISSION_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.COMMISSION_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.COMMISSION_GROUP_ID) END AS DIM_COMMISSION_GROUP_SNKEY
, prep01.DIM_COST_KEY
, case when nvl(prep01.ITEM_ID, '''') = '''' then -2
	else coalesce(dcst1.dim_cost_snkey, dcst2.dim_cost_snkey, dcst3.dim_cost_snkey, dcst4.dim_cost_snkey, -1)
	end AS DIM_COST_SNKEY
, prep01.DIM_CURRENCY_KEY
, case when nvl(prep01.CURRENCY_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
, prep01.DIM_CUSTOMER_INVOICE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
		when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
	else DIM_CUSTOMER_INVOICE_SNKEY_RAW
	end as DIM_CUSTOMER_INVOICE_SNKEY
, prep01.DIM_CUSTOMER_ORDER_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
		when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
	else DIM_CUSTOMER_ORDER_SNKEY_RAW
	end as DIM_CUSTOMER_ORDER_SNKEY
, prep01.DIM_CUSTOMER_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_GROUP_ID) END AS DIM_CUSTOMER_GROUP_SNKEY
, prep01.DIM_CUSTOMER_MARKUP_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_MARKUP_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_MARKUP_GROUP_ID) END AS DIM_CUSTOMER_MARKUP_GROUP_SNKEY
, prep01.DIM_DEFAULT_DIMENSION_KEY
, case when nvl(prep01.DEFAULT_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
, prep01.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CONFIGURATION_ID, '''') = '''' or nvl(prep01.ITEM_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CONFIGURATION_ID, ''~'', prep01.ITEM_ID) END AS DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
, prep01.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.INTRA_STAT_TRANSACTION_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INTRA_STAT_TRANSACTION_CODE) END AS DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
, prep01.DIM_INVENTORY_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.INVENTORY_DIMENSION_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.INVENTORY_DIMENSION_ID) END AS DIM_INVENTORY_SNKEY
, prep01.DIM_ITEM_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.ITEM_ID, '''') = '''' then -2 else hash('''', ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.ITEM_ID) END AS DIM_ITEM_SNKEY
, prep01.DIM_ITEM_STATUS_KEY
, -1 AS DIM_ITEM_STATUS_SNKEY
, prep01.DIM_LEGAL_ENTITY_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
, prep01.DIM_LINE_RETURN_REASON_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.LINE_RETURN_REASON_ID, '''') = '''' or nvl(prep01.LINE_RETURN_REASON_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.LINE_RETURN_REASON_ID, ''~'', prep01.LINE_RETURN_REASON_GROUP_ID) END AS DIM_LINE_RETURN_REASON_SNKEY
, prep01.DIM_LOCATION_DELIVERY_ADDRESS_KEY
, case when nvl(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS)) END AS DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
, prep01.DIM_LOCATION_INVOICE_ADDRESS_KEY
, case when nvl(prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS)) END AS DIM_LOCATION_INVOICE_ADDRESS_SNKEY
, prep01.DIM_DELIVERY_MODE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_MODE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_MODE_ID) END AS DIM_DELIVERY_MODE_SNKEY
, prep01.DIM_DELIVERY_TERM_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_TERM_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_TERM_ID) END AS DIM_DELIVERY_TERM_SNKEY
, prep01.DIM_PAYMENT_TERMS_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.PAYMENT_TERMS_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.PAYMENT_TERMS_ID) END AS DIM_PAYMENT_TERMS_SNKEY
, prep01.DIM_PROCUREMENT_CATEGORY_KEY
, case when nvl(prep01.PROCUREMENT_CATEGORY, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.PROCUREMENT_CATEGORY)) END AS DIM_PROCUREMENT_CATEGORY_SNKEY
, prep01.DIM_RETURN_DISPOSITION_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.RETURN_DISPOSITION_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.RETURN_DISPOSITION_ID) END AS DIM_RETURN_DISPOSITION_SNKEY
, prep01.DIM_RETURN_REASON_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.RETURN_REASON_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.RETURN_REASON_ID) END AS DIM_RETURN_REASON_SNKEY
, prep01.DIM_SALES_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_GROUP_ID) END AS DIM_SALES_GROUP_SNKEY
, prep01.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_LINE_DISCOUNT_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_LINE_DISCOUNT_GROUP_ID) END AS DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
, prep01.DIM_SALES_ORDER_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_ORDER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_ORDER_ID) END AS DIM_SALES_ORDER_SNKEY
, prep01.DIM_SALES_ORIGIN_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_ORIGIN_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_ORIGIN_ID) END AS DIM_SALES_ORIGIN_SNKEY
, prep01.DIM_SALES_POOL_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_POOL_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_POOL_ID) END AS DIM_SALES_POOL_SNKEY
, prep01.DIM_SALES_PRICE_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.SALES_PRICE_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.SALES_PRICE_GROUP_ID) END AS DIM_SALES_PRICE_GROUP_SNKEY
, prep01.DIM_TAX_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.TAX_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.TAX_GROUP_ID) END AS DIM_TAX_GROUP_SNKEY
, prep01.DIM_TAX_ITEM_GROUP_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.TAX_ITEM_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.TAX_ITEM_GROUP_ID) END AS DIM_TAX_ITEM_GROUP_SNKEY
, prep01.DIM_UNIT_OF_MEASURE_SALES_KEY
, case when nvl(prep01.UNIT_OF_MEASURE_CODE_SALES, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.UNIT_OF_MEASURE_CODE_SALES) END AS DIM_UNIT_OF_MEASURE_SALES_SNKEY
, prep01.DIM_WAREHOUSE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.WAREHOUSE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.WAREHOUSE_ID) END AS DIM_WAREHOUSE_SNKEY
, prep01.DIM_WORKER_SALES_RESPONSIBLE_KEY
, case when nvl(prep01.RECORD_ID_SALES_RESPONSIBLE, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_SALES_RESPONSIBLE)) END AS DIM_WORKER_SALES_RESPONSIBLE_SNKEY
, prep01.DIM_WORKER_SALES_TAKER_KEY
, case when nvl(prep01.RECORD_ID_SALES_TAKER, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_SALES_TAKER)) END AS DIM_WORKER_SALES_TAKER_SNKEY
, prep01.INVOICE_KEY
, prep01.BUSINESS_UNIT_ID
, prep01.CAMPAIGN_ID
, prep01.COMMISSION_GROUP_ID
, prep01.CURRENCY_CODE
, prep01.CUSTOMER_ACCOUNT_INVOICE
, prep01.CUSTOMER_ACCOUNT_ORDER
, prep01.CUSTOMER_GROUP_ID
, prep01.CUSTOMER_MARKUP_GROUP_ID
, prep01.DEFAULT_DIMENSION
, prep01.CONFIGURATION_ID
, prep01.INTRA_STAT_TRANSACTION_CODE
, prep01.INVENTORY_DIMENSION_ID
, prep01.ITEM_STATUS
, prep01.LINE_RETURN_REASON_ID
, prep01.LINE_RETURN_REASON_GROUP_ID
, prep01.RECORD_ID_LOCATION_DELIVERY_ADDRESS
, prep01.RECORD_ID_LOCATION_INVOICE_ADDRESS
, prep01.DELIVERY_MODE_ID
, prep01.DELIVERY_TERM_ID
, prep01.PAYMENT_TERMS_ID
, prep01.PROCUREMENT_CATEGORY
, prep01.RETURN_DISPOSITION_ID
, prep01.RETURN_REASON_ID
, prep01.SALES_GROUP_ID
, prep01.SALES_LINE_DISCOUNT_GROUP_ID
, prep01.SALES_ORDER_ID
, prep01.SALES_ORIGIN_ID
, prep01.SALES_POOL_ID
, prep01.SALES_PRICE_GROUP_ID
, prep01.TAX_GROUP_ID
, prep01.TAX_ITEM_GROUP_ID
, prep01.UNIT_OF_MEASURE_CODE_SALES
, prep01.WAREHOUSE_ID
, prep01.RECORD_ID_SALES_RESPONSIBLE
, prep01.RECORD_ID_SALES_TAKER
, prep01.DOCUMENT_STATUS
, prep01.FLOOR_SAMPLE_TYPE
, prep01.HEADER_RETURN_STATUS
, prep01.HEADER_SALES_STATUS
, prep01.RETURN_STATUS
, prep01.SALES_STATUS
, prep01.SALES_TYPE
, prep01.SHIP_CARRIER_DELIVERY_TYPE
, prep01.TRADE_LINE_DELIVERY_TYPE
, prep01.IS_AT_AGENT_TRANSACTION
, prep01.IS_BLIND_SHIPMENT
, prep01.IS_EXPEDITED_SHIPMENT
, prep01.IS_FLOOR_SAMPLE_DISCOUNT
, prep01.IS_ITEM_TRANSACTION
, prep01.IS_LINE_DELIVERY_COMPLETE
, prep01.IS_ORDER_BLOCKED
, prep01.IS_ORDER_LINE_BLOCKED
, prep01.IS_ORDER_LOCKED
, prep01.IS_RETURNED_ITEM_SCRAP
, prep01.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
, prep01.IS_STOCKED_PRODUCT
, prep01.DROP_SHIPMENT
, prep01.DELIVERY_DATE
, prep01.DOCUMENT_DATE
, prep01.DUE_DATE
, prep01.INVOICE_DATE
, prep01.MANUFACTURED_DATE
, prep01.ORIGINATING_ORDER_CREATED_DATE
, prep01.RELATED_ORDER_DATE
, prep01.RETURN_ARRIVAL_DATE
, prep01.RETURN_CLOSED_DATE
, prep01.SALES_LINE_CREATED_DATE
, prep01.INVENTORY_TRANSACTION_ID
, prep01.INVOICE_ID
, prep01.LEDGER_VOUCHER
, prep01.LINE_NUMBER
, prep01.ORIGINAL_SALES_ORDER_ID
, prep01.PRODUCTION_TIME
, prep01.PURCHASE_ORDER_ID
, prep01.ORIGINATING_ORDER_SALES_ID
, prep01.REGISTRY_NUMBER
, prep01.INVENTORY_QUANTITY
, prep01.INVOICE_QUANTITY
, prep01.PHYSICAL_QUANTITY
, prep01.PRICE_UNIT
, prep01.SALES_PRICE
, prep01.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
, prep01.COMMISSION_AMOUNT_COMPANY_CURRENCY
, prep01.LINE_AMOUNT_TRANSACTION_CURRENCY
, prep01.LINE_AMOUNT_COMPANY_CURRENCY
, prep01.TAX_AMOUNT_TRANSACTION_CURRENCY
, prep01.TAX_AMOUNT_COMPANY_CURRENCY
, prep01.DISCOUNT_PERCENT
, prep01.DISCOUNT_AMOUNT
, prep01.LINE_DISCOUNT
, prep01.LINE_DISCOUNT_PERCENT
, prep01.FLOOR_LINE_DISCOUNT
, prep01.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
, prep01.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
, prep01.COST_OF_GOODS_SOLD
, prep01.FIXED_OVERHEAD
, prep01.LABOR
, prep01.MATERIAL
, prep01.VARIABLE_OVERHEAD
, prep01.FROZEN_COST_OF_GOODS_SOLD
, prep01.FROZEN_FIXED_OVERHEAD
, prep01.FROZEN_LABOR
, prep01.FROZEN_MATERIAL
, prep01.FROZEN_VARIABLE_OVERHEAD
, prep01.STANDARD_COST
, prep01.FROZEN_STANDARD_COST
, prep01.PRICE_OVERRIDE_REASON_CODE
, prep01.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
, prep01.ISLR
, prep01.RECORD_ID_POS
, prep01.PRICE_TYPE
, prep01.ACTIVATION_DATE
, prep01.CREATED_DATETIME
, prep01.JOURNAL_NUMBER
, prep01.JOURNAL_NAME
, prep01.INVENTORY_SITE_ID
, prep01.COGSFIFO_CURRENCY_CODE
, prep01.COGSFIFO_SALES_STATUS
, prep01.COGSFIFO_COST_PRICE
, prep01.COGSFIFO_SALES_QTY
, prep01.COGSFIFO_ACCOUNTING_CURRENCY
, prep01.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
, prep01.COGSFIFO_KIT_BOM_LEVEL
, prep01.COGSFIFO_COST_AMOUNT_POSTED
, prep01.COGSFIFO_COST_AMOUNT_ADJUSTMENT
, prep01.COGSFIFO_KIT_IDENTIFIER
, prep01.COGSFIFO_FROM_CURRENCY_CODE
, prep01.COGSFIFO_TO_CURRENCY_CODE
, prep01.COGSFIFO_EXCHANGE_RATE
, prep01.COGSFIFO_COST_OF_GOODS_SOLD
, prep01.HK_SOURCE_NAME
, prep01.HK_SOFT_DELETE_FLAG
, prep01.HK_SOURCE_CREATED_TIMESTAMP
, prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
, prep01.HK_CREATED_JOB_RUN_ID
, prep01.HK_LAST_UPDATED_JOB_RUN_ID
, prep01.HK_CREATED_TIMESTAMP
, prep01.HK_LAST_UPDATED_TIMESTAMP
, prep01.HK_WAREHOUSE_ID
, prep01.TGT_HK_HASH_KEY
FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
								DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
								DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
							
							left join (select f10.record_id, f10.legal_entity, f10.item_id, dcst10.dim_cost_snkey
									from ' || :tgt_db || '.global.DIM_COST dcst10
                                    inner join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' f10 on
										f10.legal_entity = dcst10.legal_entity and
										f10.item_id = dcst10.item_id and
										f10.configuration_id = dcst10.configuration_id and
										f10.inventory_site_id = dcst10.inventory_site_id
									where dcst10.price_type_id = 0
									qualify row_number() over (partition by f10.record_id, f10.legal_entity, f10.item_id order by dcst10.activation_date desc, dcst10.hk_last_updated_timestamp desc) = 1) dcst1 on
								prep01.record_id = dcst1.record_id and
								prep01.legal_entity = dcst1.legal_entity and
								prep01.item_id = dcst1.item_id
							left join (select f20.record_id, f20.legal_entity, f20.item_id, dcst20.dim_cost_snkey
									from ' || :tgt_db || '.global.DIM_COST dcst20
									inner join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' f20 on
										f20.legal_entity = dcst20.legal_entity and
										f20.item_id = dcst20.item_id and
										f20.inventory_site_id = dcst20.inventory_site_id and
										f20.invoice_date >= dcst20.activation_date
									where dcst20.price_type_id = 0
									qualify row_number() over (partition by f20.record_id, f20.legal_entity, f20.item_id order by dcst20.activation_date desc, dcst20.hk_last_updated_timestamp desc) = 1) dcst2 on
								prep01.record_id = dcst2.record_id and
								prep01.legal_entity = dcst2.legal_entity and
								prep01.item_id = dcst2.item_id
							left join (select f30.record_id, f30.legal_entity, f30.item_id, dcst30.dim_cost_snkey
									from ' || :tgt_db || '.global.DIM_COST dcst30
									inner join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' f30 on
										f30.legal_entity = dcst30.legal_entity and
										f30.item_id = dcst30.item_id and
										f30.configuration_id = dcst30.configuration_id and
										f30.invoice_date >= dcst30.activation_date
									where dcst30.price_type_id = 0
									qualify row_number() over (partition by f30.record_id, f30.legal_entity, f30.item_id order by dcst30.activation_date desc, dcst30.hk_last_updated_timestamp desc) = 1) dcst3 on
								prep01.record_id = dcst3.record_id and
								prep01.legal_entity = dcst3.legal_entity and
								prep01.item_id = dcst3.item_id
							left join (select f40.record_id, f40.legal_entity, f40.item_id, dcst40.dim_cost_snkey
									from ' || :tgt_db || '.global.DIM_COST dcst40
									inner join ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01final_' || :CURR_FORMATTED_TIMESTAMP
     || ' f40 on
										f40.legal_entity = dcst40.legal_entity and
										f40.item_id = dcst40.item_id and
										f40.invoice_date >= dcst40.activation_date
									where dcst40.price_type_id = 0
									qualify row_number() over (partition by f40.record_id, f40.legal_entity, f40.item_id order by dcst40.activation_date desc, dcst40.hk_last_updated_timestamp desc) = 1) dcst4 on
								prep01.record_id = dcst4.record_id and
								prep01.legal_entity = dcst4.legal_entity and
								prep01.item_id = dcst4.item_id
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DELIVERY_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.DUE_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.INVOICE_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                                src.MANUFACTURED_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                                src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d8 ON
                                src.RELATED_ORDER_DATE_DIM_DATE_SNKEY = d8.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d9 ON
                                src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY = d9.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d10 ON
                                src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY = d10.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d11 ON
                                src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY = d11.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_BUSINESS_UNIT d12 ON
                                src.DIM_BUSINESS_UNIT_SNKEY = d12.DIM_BUSINESS_UNIT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CAMPAIGN d13 ON
                               src.DIM_CAMPAIGN_SNKEY = d13.DIM_CAMPAIGN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_COMMISSION_GROUP d14 ON
                                src.DIM_COMMISSION_GROUP_SNKEY = d14.DIM_COMMISSION_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_COST d15 ON
                               src.DIM_COST_SNKEY = d15.DIM_COST_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d16 ON
                                src.DIM_CURRENCY_SNKEY = d16.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d17 ON
                                src.DIM_CUSTOMER_INVOICE_SNKEY = d17.DIM_CUSTOMER_SNKEY
                                AND src.INVOICE_DATE >= d17.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.INVOICE_DATE < d17.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY
                                AND src.INVOICE_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.INVOICE_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_GROUP d19 ON
                               src.DIM_CUSTOMER_GROUP_SNKEY = d19.DIM_CUSTOMER_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_MARKUP_GROUP d20 ON
                               src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = d20.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d21 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d21.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_GLOBAL_TRADE_ITEM_NUMBER d22 ON
                               src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = d22.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INTRA_STAT_TRANSACTION_CODE d23 ON
                               src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = d23.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d24 ON
                                src.DIM_INVENTORY_SNKEY = d24.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d25 ON
                                src.DIM_ITEM_SNKEY = d25.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d27 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d27.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LINE_RETURN_REASON d28 ON
                                src.DIM_LINE_RETURN_REASON_SNKEY = d28.DIM_LINE_RETURN_REASON_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d29 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d29.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d30 ON
                                src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = d30.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d31 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d31.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d32 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d32.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_PAYMENT_TERMS d33 ON
                                src.DIM_PAYMENT_TERMS_SNKEY = d33.DIM_PAYMENT_TERMS_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PROCUREMENT_CATEGORY d34 ON
                                src.DIM_PROCUREMENT_CATEGORY_SNKEY = d34.DIM_SALES_PROCUREMENT_CATEGORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_RETURN_DISPOSITION d35 ON
                               src.DIM_RETURN_DISPOSITION_SNKEY = d35.DIM_RETURN_DISPOSITION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_RETURN_REASON d36 ON
                                src.DIM_RETURN_REASON_SNKEY = d36.DIM_RETURN_REASON_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_GROUP d37 ON
                               src.DIM_SALES_GROUP_SNKEY = d37.DIM_SALES_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_LINE_DISCOUNT_GROUP d38 ON
                               src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = d38.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d39 ON
                                src.DIM_SALES_ORDER_SNKEY = d39.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORIGIN d40 ON
                                src.DIM_SALES_ORIGIN_SNKEY = d40.DIM_SALES_ORIGIN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_POOL d41 ON
                               src.DIM_SALES_POOL_SNKEY = d41.DIM_SALES_POOL_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PRICE_GROUP d42 ON
                               src.DIM_SALES_PRICE_GROUP_SNKEY = d42.DIM_SALES_PRICE_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d43 ON
                               src.DIM_TAX_GROUP_SNKEY = d43.DIM_TAX_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_ITEM_GROUP d44 ON
                               src.DIM_TAX_ITEM_GROUP_SNKEY = d44.DIM_TAX_ITEM_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_UNIT_OF_MEASURE d45 ON
                               src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = d45.DIM_UNIT_OF_MEASURE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d46 ON
                                src.DIM_WAREHOUSE_SNKEY = d46.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d47 ON
                                src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = d47.DIM_WORKER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d48 ON
                                src.DIM_WORKER_SALES_TAKER_SNKEY = d48.DIM_WORKER_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_SALES_INVOICES_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_SALES_INVOICES

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_SALES_INVOICES_KEY = tgt.FACT_SALES_INVOICES_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
     || ' src on src.FACT_SALES_INVOICES_KEY = tgt.FACT_SALES_INVOICES_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_KEY = src.DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_SNKEY = src.DELIVERY_DATE_DIM_DATE_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.DUE_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_SNKEY = src.DUE_DATE_DIM_DATE_SNKEY
                                    , tgt.INVOICE_DATE_DIM_DATE_KEY = src.INVOICE_DATE_DIM_DATE_KEY
                                    , tgt.INVOICE_DATE_DIM_DATE_SNKEY = src.INVOICE_DATE_DIM_DATE_SNKEY
                                    , tgt.MANUFACTURED_DATE_DIM_DATE_KEY = src.MANUFACTURED_DATE_DIM_DATE_KEY
                                    , tgt.MANUFACTURED_DATE_DIM_DATE_SNKEY = src.MANUFACTURED_DATE_DIM_DATE_SNKEY
                                    , tgt.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY = src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY = src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                    , tgt.RELATED_ORDER_DATE_DIM_DATE_KEY = src.RELATED_ORDER_DATE_DIM_DATE_KEY
                                    , tgt.RELATED_ORDER_DATE_DIM_DATE_SNKEY = src.RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                    , tgt.RETURN_ARRIVAL_DATE_DIM_DATE_KEY = src.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                    , tgt.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY = src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                    , tgt.RETURN_CLOSED_DATE_DIM_DATE_KEY = src.RETURN_CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.RETURN_CLOSED_DATE_DIM_DATE_SNKEY = src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                    , tgt.SALES_LINE_CREATED_DATE_DIM_DATE_KEY = src.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY = src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_BUSINESS_UNIT_KEY = src.DIM_BUSINESS_UNIT_KEY
                                    , tgt.DIM_BUSINESS_UNIT_SNKEY = src.DIM_BUSINESS_UNIT_SNKEY
                                    , tgt.DIM_CAMPAIGN_KEY = src.DIM_CAMPAIGN_KEY
                                    , tgt.DIM_CAMPAIGN_SNKEY = src.DIM_CAMPAIGN_SNKEY
                                    , tgt.DIM_COMMISSION_GROUP_KEY = src.DIM_COMMISSION_GROUP_KEY
                                    , tgt.DIM_COMMISSION_GROUP_SNKEY = src.DIM_COMMISSION_GROUP_SNKEY
                                    , tgt.DIM_COST_KEY = src.DIM_COST_KEY
                                    , tgt.DIM_COST_SNKEY = src.DIM_COST_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.DIM_CUSTOMER_INVOICE_SNKEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_SNKEY = src.DIM_CUSTOMER_ORDER_SNKEY
                                    , tgt.DIM_CUSTOMER_GROUP_KEY = src.DIM_CUSTOMER_GROUP_KEY
                                    , tgt.DIM_CUSTOMER_GROUP_SNKEY = src.DIM_CUSTOMER_GROUP_SNKEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_KEY = src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                    , tgt.DIM_INVENTORY_KEY = src.DIM_INVENTORY_KEY
                                    , tgt.DIM_INVENTORY_SNKEY = src.DIM_INVENTORY_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_ITEM_STATUS_KEY = src.DIM_ITEM_STATUS_KEY
                                    , tgt.DIM_ITEM_STATUS_SNKEY = src.DIM_ITEM_STATUS_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_LINE_RETURN_REASON_KEY = src.DIM_LINE_RETURN_REASON_KEY
                                    , tgt.DIM_LINE_RETURN_REASON_SNKEY = src.DIM_LINE_RETURN_REASON_SNKEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_KEY = src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_MODE_SNKEY = src.DIM_DELIVERY_MODE_SNKEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_DELIVERY_TERM_SNKEY = src.DIM_DELIVERY_TERM_SNKEY
                                    , tgt.DIM_PAYMENT_TERMS_KEY = src.DIM_PAYMENT_TERMS_KEY
                                    , tgt.DIM_PAYMENT_TERMS_SNKEY = src.DIM_PAYMENT_TERMS_SNKEY
                                    , tgt.DIM_PROCUREMENT_CATEGORY_KEY = src.DIM_PROCUREMENT_CATEGORY_KEY
                                    , tgt.DIM_PROCUREMENT_CATEGORY_SNKEY = src.DIM_PROCUREMENT_CATEGORY_SNKEY
                                    , tgt.DIM_RETURN_DISPOSITION_KEY = src.DIM_RETURN_DISPOSITION_KEY
                                    , tgt.DIM_RETURN_DISPOSITION_SNKEY = src.DIM_RETURN_DISPOSITION_SNKEY
                                    , tgt.DIM_RETURN_REASON_KEY = src.DIM_RETURN_REASON_KEY
                                    , tgt.DIM_RETURN_REASON_SNKEY = src.DIM_RETURN_REASON_SNKEY
                                    , tgt.DIM_SALES_GROUP_KEY = src.DIM_SALES_GROUP_KEY
                                    , tgt.DIM_SALES_GROUP_SNKEY = src.DIM_SALES_GROUP_SNKEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_ORDER_SNKEY = src.DIM_SALES_ORDER_SNKEY
                                    , tgt.DIM_SALES_ORIGIN_KEY = src.DIM_SALES_ORIGIN_KEY
                                    , tgt.DIM_SALES_ORIGIN_SNKEY = src.DIM_SALES_ORIGIN_SNKEY
                                    , tgt.DIM_SALES_POOL_KEY = src.DIM_SALES_POOL_KEY
                                    , tgt.DIM_SALES_POOL_SNKEY = src.DIM_SALES_POOL_SNKEY
                                    , tgt.DIM_SALES_PRICE_GROUP_KEY = src.DIM_SALES_PRICE_GROUP_KEY
                                    , tgt.DIM_SALES_PRICE_GROUP_SNKEY = src.DIM_SALES_PRICE_GROUP_SNKEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.DIM_TAX_GROUP_KEY
                                    , tgt.DIM_TAX_GROUP_SNKEY = src.DIM_TAX_GROUP_SNKEY
                                    , tgt.DIM_TAX_ITEM_GROUP_KEY = src.DIM_TAX_ITEM_GROUP_KEY
                                    , tgt.DIM_TAX_ITEM_GROUP_SNKEY = src.DIM_TAX_ITEM_GROUP_SNKEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_KEY = src.DIM_UNIT_OF_MEASURE_SALES_KEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_SNKEY = src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WAREHOUSE_SNKEY = src.DIM_WAREHOUSE_SNKEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_KEY = src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                    , tgt.DIM_WORKER_SALES_TAKER_KEY = src.DIM_WORKER_SALES_TAKER_KEY
                                    , tgt.DIM_WORKER_SALES_TAKER_SNKEY = src.DIM_WORKER_SALES_TAKER_SNKEY
                                    , tgt.INVOICE_KEY = src.INVOICE_KEY
                                    , tgt.BUSINESS_UNIT_ID = src.BUSINESS_UNIT_ID
                                    , tgt.CAMPAIGN_ID = src.CAMPAIGN_ID
                                    , tgt.COMMISSION_GROUP_ID = src.COMMISSION_GROUP_ID
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.CUSTOMER_ACCOUNT_INVOICE = src.CUSTOMER_ACCOUNT_INVOICE
                                    , tgt.CUSTOMER_ACCOUNT_ORDER = src.CUSTOMER_ACCOUNT_ORDER
                                    , tgt.CUSTOMER_GROUP_ID = src.CUSTOMER_GROUP_ID
                                    , tgt.CUSTOMER_MARKUP_GROUP_ID = src.CUSTOMER_MARKUP_GROUP_ID
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.CONFIGURATION_ID = src.CONFIGURATION_ID
                                    , tgt.INTRA_STAT_TRANSACTION_CODE = src.INTRA_STAT_TRANSACTION_CODE
                                    , tgt.INVENTORY_DIMENSION_ID = src.INVENTORY_DIMENSION_ID
                                    , tgt.ITEM_STATUS = src.ITEM_STATUS
                                    , tgt.LINE_RETURN_REASON_ID = src.LINE_RETURN_REASON_ID
                                    , tgt.LINE_RETURN_REASON_GROUP_ID = src.LINE_RETURN_REASON_GROUP_ID
                                    , tgt.RECORD_ID_LOCATION_DELIVERY_ADDRESS = src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                    , tgt.RECORD_ID_LOCATION_INVOICE_ADDRESS = src.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                    , tgt.DELIVERY_MODE_ID = src.DELIVERY_MODE_ID
                                    , tgt.DELIVERY_TERM_ID = src.DELIVERY_TERM_ID
                                    , tgt.PAYMENT_TERMS_ID = src.PAYMENT_TERMS_ID
                                    , tgt.PROCUREMENT_CATEGORY = src.PROCUREMENT_CATEGORY
                                    , tgt.RETURN_DISPOSITION_ID = src.RETURN_DISPOSITION_ID
                                    , tgt.RETURN_REASON_ID = src.RETURN_REASON_ID
                                    , tgt.SALES_GROUP_ID = src.SALES_GROUP_ID
                                    , tgt.SALES_LINE_DISCOUNT_GROUP_ID = src.SALES_LINE_DISCOUNT_GROUP_ID
                                    , tgt.SALES_ORDER_ID = src.SALES_ORDER_ID
                                    , tgt.SALES_ORIGIN_ID = src.SALES_ORIGIN_ID
                                    , tgt.SALES_POOL_ID = src.SALES_POOL_ID
                                    , tgt.SALES_PRICE_GROUP_ID = src.SALES_PRICE_GROUP_ID
                                    , tgt.TAX_GROUP_ID = src.TAX_GROUP_ID
                                    , tgt.TAX_ITEM_GROUP_ID = src.TAX_ITEM_GROUP_ID
                                    , tgt.UNIT_OF_MEASURE_CODE_SALES = src.UNIT_OF_MEASURE_CODE_SALES
                                    , tgt.WAREHOUSE_ID = src.WAREHOUSE_ID
                                    , tgt.RECORD_ID_SALES_RESPONSIBLE = src.RECORD_ID_SALES_RESPONSIBLE
                                    , tgt.RECORD_ID_SALES_TAKER = src.RECORD_ID_SALES_TAKER
                                    , tgt.DOCUMENT_STATUS = src.DOCUMENT_STATUS
                                    , tgt.FLOOR_SAMPLE_TYPE = src.FLOOR_SAMPLE_TYPE
                                    , tgt.HEADER_RETURN_STATUS = src.HEADER_RETURN_STATUS
                                    , tgt.HEADER_SALES_STATUS = src.HEADER_SALES_STATUS
                                    , tgt.RETURN_STATUS = src.RETURN_STATUS
                                    , tgt.SALES_STATUS = src.SALES_STATUS
                                    , tgt.SALES_TYPE = src.SALES_TYPE
                                    , tgt.SHIP_CARRIER_DELIVERY_TYPE = src.SHIP_CARRIER_DELIVERY_TYPE
                                    , tgt.TRADE_LINE_DELIVERY_TYPE = src.TRADE_LINE_DELIVERY_TYPE
                                    , tgt.IS_AT_AGENT_TRANSACTION = src.IS_AT_AGENT_TRANSACTION
                                    , tgt.IS_BLIND_SHIPMENT = src.IS_BLIND_SHIPMENT
                                    , tgt.IS_EXPEDITED_SHIPMENT = src.IS_EXPEDITED_SHIPMENT
                                    , tgt.IS_FLOOR_SAMPLE_DISCOUNT = src.IS_FLOOR_SAMPLE_DISCOUNT
                                    , tgt.IS_ITEM_TRANSACTION = src.IS_ITEM_TRANSACTION
                                    , tgt.IS_LINE_DELIVERY_COMPLETE = src.IS_LINE_DELIVERY_COMPLETE
                                    , tgt.IS_ORDER_BLOCKED = src.IS_ORDER_BLOCKED
                                    , tgt.IS_ORDER_LINE_BLOCKED = src.IS_ORDER_LINE_BLOCKED
                                    , tgt.IS_ORDER_LOCKED = src.IS_ORDER_LOCKED
                                    , tgt.IS_RETURNED_ITEM_SCRAP = src.IS_RETURNED_ITEM_SCRAP
                                    , tgt.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE = src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                    , tgt.IS_STOCKED_PRODUCT = src.IS_STOCKED_PRODUCT
                                    , tgt.DROP_SHIPMENT = src.DROP_SHIPMENT
                                    , tgt.DELIVERY_DATE = src.DELIVERY_DATE
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.DUE_DATE = src.DUE_DATE
                                    , tgt.INVOICE_DATE = src.INVOICE_DATE
                                    , tgt.MANUFACTURED_DATE = src.MANUFACTURED_DATE
                                    , tgt.ORIGINATING_ORDER_CREATED_DATE = src.ORIGINATING_ORDER_CREATED_DATE
                                    , tgt.RELATED_ORDER_DATE = src.RELATED_ORDER_DATE
                                    , tgt.RETURN_ARRIVAL_DATE = src.RETURN_ARRIVAL_DATE
                                    , tgt.RETURN_CLOSED_DATE = src.RETURN_CLOSED_DATE
                                    , tgt.SALES_LINE_CREATED_DATE = src.SALES_LINE_CREATED_DATE
                                    , tgt.INVENTORY_TRANSACTION_ID = src.INVENTORY_TRANSACTION_ID
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.LEDGER_VOUCHER = src.LEDGER_VOUCHER
                                    , tgt.LINE_NUMBER = src.LINE_NUMBER
                                    , tgt.PRODUCTION_TIME = src.PRODUCTION_TIME
                                    , tgt.PURCHASE_ORDER_ID = src.PURCHASE_ORDER_ID
                                    , tgt.ORIGINATING_ORDER_SALES_ID = src.ORIGINATING_ORDER_SALES_ID
                                    , tgt.REGISTRY_NUMBER = src.REGISTRY_NUMBER
                                    , tgt.INVENTORY_QUANTITY = src.INVENTORY_QUANTITY
                                    , tgt.INVOICE_QUANTITY = src.INVOICE_QUANTITY
                                    , tgt.PHYSICAL_QUANTITY = src.PHYSICAL_QUANTITY
                                    , tgt.PRICE_UNIT = src.PRICE_UNIT
                                    , tgt.SALES_PRICE = src.SALES_PRICE
                                    , tgt.COMMISSION_AMOUNT_TRANSACTION_CURRENCY = src.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.COMMISSION_AMOUNT_COMPANY_CURRENCY = src.COMMISSION_AMOUNT_COMPANY_CURRENCY
                                    , tgt.LINE_AMOUNT_TRANSACTION_CURRENCY = src.LINE_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.LINE_AMOUNT_COMPANY_CURRENCY = src.LINE_AMOUNT_COMPANY_CURRENCY
                                    , tgt.TAX_AMOUNT_TRANSACTION_CURRENCY = src.TAX_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.TAX_AMOUNT_COMPANY_CURRENCY = src.TAX_AMOUNT_COMPANY_CURRENCY
                                    , tgt.DISCOUNT_PERCENT = src.DISCOUNT_PERCENT
                                    , tgt.DISCOUNT_AMOUNT = src.DISCOUNT_AMOUNT
                                    , tgt.LINE_DISCOUNT = src.LINE_DISCOUNT
                                    , tgt.LINE_DISCOUNT_PERCENT = src.LINE_DISCOUNT_PERCENT
                                    , tgt.FLOOR_LINE_DISCOUNT = src.FLOOR_LINE_DISCOUNT
                                    , tgt.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY = src.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                    , tgt.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY = src.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                    , tgt.COST_OF_GOODS_SOLD = src.COST_OF_GOODS_SOLD
                                    , tgt.FIXED_OVERHEAD = src.FIXED_OVERHEAD
                                    , tgt.LABOR = src.LABOR
                                    , tgt.MATERIAL = src.MATERIAL
                                    , tgt.VARIABLE_OVERHEAD = src.VARIABLE_OVERHEAD
                                    , tgt.FROZEN_COST_OF_GOODS_SOLD = src.FROZEN_COST_OF_GOODS_SOLD
                                    , tgt.FROZEN_FIXED_OVERHEAD = src.FROZEN_FIXED_OVERHEAD
                                    , tgt.FROZEN_LABOR = src.FROZEN_LABOR
                                    , tgt.FROZEN_MATERIAL = src.FROZEN_MATERIAL
                                    , tgt.FROZEN_VARIABLE_OVERHEAD = src.FROZEN_VARIABLE_OVERHEAD
                                    , tgt.STANDARD_COST = src.STANDARD_COST
                                    , tgt.FROZEN_STANDARD_COST = src.FROZEN_STANDARD_COST
                                    , tgt.PRICE_OVERRIDE_REASON_CODE = src.PRICE_OVERRIDE_REASON_CODE
                                    , tgt.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION = src.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                    , tgt.ISLR = src.ISLR
                                    , tgt.RECORD_ID_POS = src.RECORD_ID_POS
                                    , tgt.PRICE_TYPE = src.PRICE_TYPE
                                    , tgt.ACTIVATION_DATE = src.ACTIVATION_DATE
                                    , tgt.CREATED_DATETIME = src.CREATED_DATETIME
									, tgt.JOURNAL_NUMBER = src.JOURNAL_NUMBER
									, tgt.JOURNAL_NAME = src.JOURNAL_NAME
									, tgt.INVENTORY_SITE_ID = src.INVENTORY_SITE_ID
                                    , tgt.COGSFIFO_CURRENCY_CODE = src.COGSFIFO_CURRENCY_CODE
                                    , tgt.COGSFIFO_SALES_STATUS = src.COGSFIFO_SALES_STATUS
                                    , tgt.COGSFIFO_COST_PRICE = src.COGSFIFO_COST_PRICE
                                    , tgt.COGSFIFO_SALES_QTY = src.COGSFIFO_SALES_QTY
                                    , tgt.COGSFIFO_ACCOUNTING_CURRENCY = src.COGSFIFO_ACCOUNTING_CURRENCY
                                    , tgt.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID = src.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                    , tgt.COGSFIFO_KIT_BOM_LEVEL = src.COGSFIFO_KIT_BOM_LEVEL
                                    , tgt.COGSFIFO_COST_AMOUNT_POSTED = src.COGSFIFO_COST_AMOUNT_POSTED
                                    , tgt.COGSFIFO_COST_AMOUNT_ADJUSTMENT = src.COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                    , tgt.COGSFIFO_KIT_IDENTIFIER = src.COGSFIFO_KIT_IDENTIFIER
                                    , tgt.COGSFIFO_FROM_CURRENCY_CODE = src.COGSFIFO_FROM_CURRENCY_CODE
                                    , tgt.COGSFIFO_TO_CURRENCY_CODE = src.COGSFIFO_TO_CURRENCY_CODE
                                    , tgt.COGSFIFO_EXCHANGE_RATE = src.COGSFIFO_EXCHANGE_RATE
                                    , tgt.COGSFIFO_COST_OF_GOODS_SOLD = src.COGSFIFO_COST_OF_GOODS_SOLD
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                    (
                                        FACT_SALES_INVOICES_KEY
                                        , SOURCE_NAME
                                        , RECORD_ID
                                        , LEGAL_ENTITY
                                        , ITEM_ID
                                        , DIM_SOURCE_SYSTEM_KEY
                                        , DIM_SOURCE_SYSTEM_SNKEY
                                        , DELIVERY_DATE_DIM_DATE_KEY
                                        , DELIVERY_DATE_DIM_DATE_SNKEY
                                        , DOCUMENT_DATE_DIM_DATE_KEY
                                        , DOCUMENT_DATE_DIM_DATE_SNKEY
                                        , DUE_DATE_DIM_DATE_KEY
                                        , DUE_DATE_DIM_DATE_SNKEY
                                        , INVOICE_DATE_DIM_DATE_KEY
                                        , INVOICE_DATE_DIM_DATE_SNKEY
                                        , MANUFACTURED_DATE_DIM_DATE_KEY
                                        , MANUFACTURED_DATE_DIM_DATE_SNKEY
                                        , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                        , ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                        , RELATED_ORDER_DATE_DIM_DATE_KEY
                                        , RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                        , RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                        , RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                        , RETURN_CLOSED_DATE_DIM_DATE_KEY
                                        , RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                        , SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                        , SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                        , DIM_BUSINESS_UNIT_KEY
                                        , DIM_BUSINESS_UNIT_SNKEY
                                        , DIM_CAMPAIGN_KEY
                                        , DIM_CAMPAIGN_SNKEY
                                        , DIM_COMMISSION_GROUP_KEY
                                        , DIM_COMMISSION_GROUP_SNKEY
                                        , DIM_COST_KEY
                                        , DIM_COST_SNKEY
                                        , DIM_CURRENCY_KEY
                                        , DIM_CURRENCY_SNKEY
                                        , DIM_CUSTOMER_INVOICE_KEY
                                        , DIM_CUSTOMER_INVOICE_SNKEY
                                        , DIM_CUSTOMER_ORDER_KEY
                                        , DIM_CUSTOMER_ORDER_SNKEY
                                        , DIM_CUSTOMER_GROUP_KEY
                                        , DIM_CUSTOMER_GROUP_SNKEY
                                        , DIM_CUSTOMER_MARKUP_GROUP_KEY
                                        , DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                        , DIM_DEFAULT_DIMENSION_KEY
                                        , DIM_DEFAULT_DIMENSION_SNKEY
                                        , DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                        , DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                        , DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                        , DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                        , DIM_INVENTORY_KEY
                                        , DIM_INVENTORY_SNKEY
                                        , DIM_ITEM_KEY
                                        , DIM_ITEM_SNKEY
                                        , DIM_ITEM_STATUS_KEY
                                        , DIM_ITEM_STATUS_SNKEY
                                        , DIM_LEGAL_ENTITY_KEY
                                        , DIM_LEGAL_ENTITY_SNKEY
                                        , DIM_LINE_RETURN_REASON_KEY
                                        , DIM_LINE_RETURN_REASON_SNKEY
                                        , DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                        , DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                        , DIM_LOCATION_INVOICE_ADDRESS_KEY
                                        , DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                        , DIM_DELIVERY_MODE_KEY
                                        , DIM_DELIVERY_MODE_SNKEY
                                        , DIM_DELIVERY_TERM_KEY
                                        , DIM_DELIVERY_TERM_SNKEY
                                        , DIM_PAYMENT_TERMS_KEY
                                        , DIM_PAYMENT_TERMS_SNKEY
                                        , DIM_PROCUREMENT_CATEGORY_KEY
                                        , DIM_PROCUREMENT_CATEGORY_SNKEY
                                        , DIM_RETURN_DISPOSITION_KEY
                                        , DIM_RETURN_DISPOSITION_SNKEY
                                        , DIM_RETURN_REASON_KEY
                                        , DIM_RETURN_REASON_SNKEY
                                        , DIM_SALES_GROUP_KEY
                                        , DIM_SALES_GROUP_SNKEY
                                        , DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                        , DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                        , DIM_SALES_ORDER_KEY
                                        , DIM_SALES_ORDER_SNKEY
                                        , DIM_SALES_ORIGIN_KEY
                                        , DIM_SALES_ORIGIN_SNKEY
                                        , DIM_SALES_POOL_KEY
                                        , DIM_SALES_POOL_SNKEY
                                        , DIM_SALES_PRICE_GROUP_KEY
                                        , DIM_SALES_PRICE_GROUP_SNKEY
                                        , DIM_TAX_GROUP_KEY
                                        , DIM_TAX_GROUP_SNKEY
                                        , DIM_TAX_ITEM_GROUP_KEY
                                        , DIM_TAX_ITEM_GROUP_SNKEY
                                        , DIM_UNIT_OF_MEASURE_SALES_KEY
                                        , DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                        , DIM_WAREHOUSE_KEY
                                        , DIM_WAREHOUSE_SNKEY
                                        , DIM_WORKER_SALES_RESPONSIBLE_KEY
                                        , DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                        , DIM_WORKER_SALES_TAKER_KEY
                                        , DIM_WORKER_SALES_TAKER_SNKEY
                                        , INVOICE_KEY
                                        , BUSINESS_UNIT_ID
                                        , CAMPAIGN_ID
                                        , COMMISSION_GROUP_ID
                                        , CURRENCY_CODE
                                        , CUSTOMER_ACCOUNT_INVOICE
                                        , CUSTOMER_ACCOUNT_ORDER
                                        , CUSTOMER_GROUP_ID
                                        , CUSTOMER_MARKUP_GROUP_ID
                                        , DEFAULT_DIMENSION
                                        , CONFIGURATION_ID
                                        , INTRA_STAT_TRANSACTION_CODE
                                        , INVENTORY_DIMENSION_ID
                                        , ITEM_STATUS
                                        , LINE_RETURN_REASON_ID
                                        , LINE_RETURN_REASON_GROUP_ID
                                        , RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                        , RECORD_ID_LOCATION_INVOICE_ADDRESS
                                        , DELIVERY_MODE_ID
                                        , DELIVERY_TERM_ID
                                        , PAYMENT_TERMS_ID
                                        , PROCUREMENT_CATEGORY
                                        , RETURN_DISPOSITION_ID
                                        , RETURN_REASON_ID
                                        , SALES_GROUP_ID
                                        , SALES_LINE_DISCOUNT_GROUP_ID
                                        , SALES_ORDER_ID
                                        , SALES_ORIGIN_ID
                                        , SALES_POOL_ID
                                        , SALES_PRICE_GROUP_ID
                                        , TAX_GROUP_ID
                                        , TAX_ITEM_GROUP_ID
                                        , UNIT_OF_MEASURE_CODE_SALES
                                        , WAREHOUSE_ID
                                        , RECORD_ID_SALES_RESPONSIBLE
                                        , RECORD_ID_SALES_TAKER
                                        , DOCUMENT_STATUS
                                        , FLOOR_SAMPLE_TYPE
                                        , HEADER_RETURN_STATUS
                                        , HEADER_SALES_STATUS
                                        , RETURN_STATUS
                                        , SALES_STATUS
                                        , SALES_TYPE
                                        , SHIP_CARRIER_DELIVERY_TYPE
                                        , TRADE_LINE_DELIVERY_TYPE
                                        , IS_AT_AGENT_TRANSACTION
                                        , IS_BLIND_SHIPMENT
                                        , IS_EXPEDITED_SHIPMENT
                                        , IS_FLOOR_SAMPLE_DISCOUNT
                                        , IS_ITEM_TRANSACTION
                                        , IS_LINE_DELIVERY_COMPLETE
                                        , IS_ORDER_BLOCKED
                                        , IS_ORDER_LINE_BLOCKED
                                        , IS_ORDER_LOCKED
                                        , IS_RETURNED_ITEM_SCRAP
                                        , IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                        , IS_STOCKED_PRODUCT
                                        , DROP_SHIPMENT
                                        , DELIVERY_DATE
                                        , DOCUMENT_DATE
                                        , DUE_DATE
                                        , INVOICE_DATE
                                        , MANUFACTURED_DATE
                                        , ORIGINATING_ORDER_CREATED_DATE
                                        , RELATED_ORDER_DATE
                                        , RETURN_ARRIVAL_DATE
                                        , RETURN_CLOSED_DATE
                                        , SALES_LINE_CREATED_DATE
                                        , INVENTORY_TRANSACTION_ID
                                        , INVOICE_ID
                                        , LEDGER_VOUCHER
                                        , LINE_NUMBER
                                        , ORIGINAL_SALES_ORDER_ID
                                        , PRODUCTION_TIME
                                        , PURCHASE_ORDER_ID
                                        , ORIGINATING_ORDER_SALES_ID
                                        , REGISTRY_NUMBER
                                        , INVENTORY_QUANTITY
                                        , INVOICE_QUANTITY
                                        , PHYSICAL_QUANTITY
                                        , PRICE_UNIT
                                        , SALES_PRICE
                                        , COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                        , COMMISSION_AMOUNT_COMPANY_CURRENCY
                                        , LINE_AMOUNT_TRANSACTION_CURRENCY
                                        , LINE_AMOUNT_COMPANY_CURRENCY
                                        , TAX_AMOUNT_TRANSACTION_CURRENCY
                                        , TAX_AMOUNT_COMPANY_CURRENCY
                                        , DISCOUNT_PERCENT
                                        , DISCOUNT_AMOUNT
                                        , LINE_DISCOUNT
                                        , LINE_DISCOUNT_PERCENT
                                        , FLOOR_LINE_DISCOUNT
                                        , LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                        , LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                        , COST_OF_GOODS_SOLD
                                        , FIXED_OVERHEAD
                                        , LABOR
                                        , MATERIAL
                                        , VARIABLE_OVERHEAD
                                        , FROZEN_COST_OF_GOODS_SOLD
                                        , FROZEN_FIXED_OVERHEAD
                                        , FROZEN_LABOR
                                        , FROZEN_MATERIAL
                                        , FROZEN_VARIABLE_OVERHEAD
                                        , STANDARD_COST
                                        , FROZEN_STANDARD_COST
                                        , PRICE_OVERRIDE_REASON_CODE
                                        , PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                        , ISLR
                                        , RECORD_ID_POS
                                        , PRICE_TYPE
                                        , ACTIVATION_DATE
                                        , CREATED_DATETIME
										, JOURNAL_NUMBER
										, JOURNAL_NAME
										, INVENTORY_SITE_ID
                                        , COGSFIFO_CURRENCY_CODE
                                        , COGSFIFO_SALES_STATUS
                                        , COGSFIFO_COST_PRICE
                                        , COGSFIFO_SALES_QTY
                                        , COGSFIFO_ACCOUNTING_CURRENCY
                                        , COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                        , COGSFIFO_KIT_BOM_LEVEL
                                        , COGSFIFO_COST_AMOUNT_POSTED
                                        , COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                        , COGSFIFO_KIT_IDENTIFIER
                                        , COGSFIFO_FROM_CURRENCY_CODE
                                        , COGSFIFO_TO_CURRENCY_CODE
                                        , COGSFIFO_EXCHANGE_RATE
                                        , COGSFIFO_COST_OF_GOODS_SOLD
                                        , HK_HASH_KEY
                                        , HK_SOURCE_NAME
                                        , HK_SOFT_DELETE_FLAG
                                        , HK_SOURCE_CREATED_TIMESTAMP
                                        , HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                        , HK_CREATED_JOB_RUN_ID
                                        , HK_LAST_UPDATED_JOB_RUN_ID
                                        , HK_CREATED_TIMESTAMP
                                        , HK_LAST_UPDATED_TIMESTAMP
                                        , HK_WAREHOUSE_ID
                                    )
                                VALUES
                                    (
                                        src.FACT_SALES_INVOICES_KEY
                                        , src.SOURCE_NAME
                                        , src.RECORD_ID
                                        , src.LEGAL_ENTITY
                                        , src.ITEM_ID
                                        , src.DIM_SOURCE_SYSTEM_KEY
                                        , src.DIM_SOURCE_SYSTEM_SNKEY
                                        , src.DELIVERY_DATE_DIM_DATE_KEY
                                        , src.DELIVERY_DATE_DIM_DATE_SNKEY
                                        , src.DOCUMENT_DATE_DIM_DATE_KEY
                                        , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                        , src.DUE_DATE_DIM_DATE_KEY
                                        , src.DUE_DATE_DIM_DATE_SNKEY
                                        , src.INVOICE_DATE_DIM_DATE_KEY
                                        , src.INVOICE_DATE_DIM_DATE_SNKEY
                                        , src.MANUFACTURED_DATE_DIM_DATE_KEY
                                        , src.MANUFACTURED_DATE_DIM_DATE_SNKEY
                                        , src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                        , src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY
                                        , src.RELATED_ORDER_DATE_DIM_DATE_KEY
                                        , src.RELATED_ORDER_DATE_DIM_DATE_SNKEY
                                        , src.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                        , src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY
                                        , src.RETURN_CLOSED_DATE_DIM_DATE_KEY
                                        , src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY
                                        , src.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                        , src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY
                                        , src.DIM_BUSINESS_UNIT_KEY
                                        , src.DIM_BUSINESS_UNIT_SNKEY
                                        , src.DIM_CAMPAIGN_KEY
                                        , src.DIM_CAMPAIGN_SNKEY
                                        , src.DIM_COMMISSION_GROUP_KEY
                                        , src.DIM_COMMISSION_GROUP_SNKEY
                                        , src.DIM_COST_KEY
                                        , src.DIM_COST_SNKEY
                                        , src.DIM_CURRENCY_KEY
                                        , src.DIM_CURRENCY_SNKEY
                                        , src.DIM_CUSTOMER_INVOICE_KEY
                                        , src.DIM_CUSTOMER_INVOICE_SNKEY
                                        , src.DIM_CUSTOMER_ORDER_KEY
                                        , src.DIM_CUSTOMER_ORDER_SNKEY
                                        , src.DIM_CUSTOMER_GROUP_KEY
                                        , src.DIM_CUSTOMER_GROUP_SNKEY
                                        , src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                                        , src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                                        , src.DIM_DEFAULT_DIMENSION_KEY
                                        , src.DIM_DEFAULT_DIMENSION_SNKEY
                                        , src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                        , src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                                        , src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                        , src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                                        , src.DIM_INVENTORY_KEY
                                        , src.DIM_INVENTORY_SNKEY
                                        , src.DIM_ITEM_KEY
                                        , src.DIM_ITEM_SNKEY
                                        , src.DIM_ITEM_STATUS_KEY
                                        , src.DIM_ITEM_STATUS_SNKEY
                                        , src.DIM_LEGAL_ENTITY_KEY
                                        , src.DIM_LEGAL_ENTITY_SNKEY
                                        , src.DIM_LINE_RETURN_REASON_KEY
                                        , src.DIM_LINE_RETURN_REASON_SNKEY
                                        , src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                        , src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY
                                        , src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                                        , src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY
                                        , src.DIM_DELIVERY_MODE_KEY
                                        , src.DIM_DELIVERY_MODE_SNKEY
                                        , src.DIM_DELIVERY_TERM_KEY
                                        , src.DIM_DELIVERY_TERM_SNKEY
                                        , src.DIM_PAYMENT_TERMS_KEY
                                        , src.DIM_PAYMENT_TERMS_SNKEY
                                        , src.DIM_PROCUREMENT_CATEGORY_KEY
                                        , src.DIM_PROCUREMENT_CATEGORY_SNKEY
                                        , src.DIM_RETURN_DISPOSITION_KEY
                                        , src.DIM_RETURN_DISPOSITION_SNKEY
                                        , src.DIM_RETURN_REASON_KEY
                                        , src.DIM_RETURN_REASON_SNKEY
                                        , src.DIM_SALES_GROUP_KEY
                                        , src.DIM_SALES_GROUP_SNKEY
                                        , src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                        , src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                                        , src.DIM_SALES_ORDER_KEY
                                        , src.DIM_SALES_ORDER_SNKEY
                                        , src.DIM_SALES_ORIGIN_KEY
                                        , src.DIM_SALES_ORIGIN_SNKEY
                                        , src.DIM_SALES_POOL_KEY
                                        , src.DIM_SALES_POOL_SNKEY
                                        , src.DIM_SALES_PRICE_GROUP_KEY
                                        , src.DIM_SALES_PRICE_GROUP_SNKEY
                                        , src.DIM_TAX_GROUP_KEY
                                        , src.DIM_TAX_GROUP_SNKEY
                                        , src.DIM_TAX_ITEM_GROUP_KEY
                                        , src.DIM_TAX_ITEM_GROUP_SNKEY
                                        , src.DIM_UNIT_OF_MEASURE_SALES_KEY
                                        , src.DIM_UNIT_OF_MEASURE_SALES_SNKEY
                                        , src.DIM_WAREHOUSE_KEY
                                        , src.DIM_WAREHOUSE_SNKEY
                                        , src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                                        , src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY
                                        , src.DIM_WORKER_SALES_TAKER_KEY
                                        , src.DIM_WORKER_SALES_TAKER_SNKEY
                                        , src.INVOICE_KEY
                                        , src.BUSINESS_UNIT_ID
                                        , src.CAMPAIGN_ID
                                        , src.COMMISSION_GROUP_ID
                                        , src.CURRENCY_CODE
                                        , src.CUSTOMER_ACCOUNT_INVOICE
                                        , src.CUSTOMER_ACCOUNT_ORDER
                                        , src.CUSTOMER_GROUP_ID
                                        , src.CUSTOMER_MARKUP_GROUP_ID
                                        , src.DEFAULT_DIMENSION
                                        , src.CONFIGURATION_ID
                                        , src.INTRA_STAT_TRANSACTION_CODE
                                        , src.INVENTORY_DIMENSION_ID
                                        , src.ITEM_STATUS
                                        , src.LINE_RETURN_REASON_ID
                                        , src.LINE_RETURN_REASON_GROUP_ID
                                        , src.RECORD_ID_LOCATION_DELIVERY_ADDRESS
                                        , src.RECORD_ID_LOCATION_INVOICE_ADDRESS
                                        , src.DELIVERY_MODE_ID
                                        , src.DELIVERY_TERM_ID
                                        , src.PAYMENT_TERMS_ID
                                        , src.PROCUREMENT_CATEGORY
                                        , src.RETURN_DISPOSITION_ID
                                        , src.RETURN_REASON_ID
                                        , src.SALES_GROUP_ID
                                        , src.SALES_LINE_DISCOUNT_GROUP_ID
                                        , src.SALES_ORDER_ID
                                        , src.SALES_ORIGIN_ID
                                        , src.SALES_POOL_ID
                                        , src.SALES_PRICE_GROUP_ID
                                        , src.TAX_GROUP_ID
                                        , src.TAX_ITEM_GROUP_ID
                                        , src.UNIT_OF_MEASURE_CODE_SALES
                                        , src.WAREHOUSE_ID
                                        , src.RECORD_ID_SALES_RESPONSIBLE
                                        , src.RECORD_ID_SALES_TAKER
                                        , src.DOCUMENT_STATUS
                                        , src.FLOOR_SAMPLE_TYPE
                                        , src.HEADER_RETURN_STATUS
                                        , src.HEADER_SALES_STATUS
                                        , src.RETURN_STATUS
                                        , src.SALES_STATUS
                                        , src.SALES_TYPE
                                        , src.SHIP_CARRIER_DELIVERY_TYPE
                                        , src.TRADE_LINE_DELIVERY_TYPE
                                        , src.IS_AT_AGENT_TRANSACTION
                                        , src.IS_BLIND_SHIPMENT
                                        , src.IS_EXPEDITED_SHIPMENT
                                        , src.IS_FLOOR_SAMPLE_DISCOUNT
                                        , src.IS_ITEM_TRANSACTION
                                        , src.IS_LINE_DELIVERY_COMPLETE
                                        , src.IS_ORDER_BLOCKED
                                        , src.IS_ORDER_LINE_BLOCKED
                                        , src.IS_ORDER_LOCKED
                                        , src.IS_RETURNED_ITEM_SCRAP
                                        , src.IS_SHIP_CARRIER_USING_FUEL_SURCHARGE
                                        , src.IS_STOCKED_PRODUCT
                                        , src.DROP_SHIPMENT
                                        , src.DELIVERY_DATE
                                        , src.DOCUMENT_DATE
                                        , src.DUE_DATE
                                        , src.INVOICE_DATE
                                        , src.MANUFACTURED_DATE
                                        , src.ORIGINATING_ORDER_CREATED_DATE
                                        , src.RELATED_ORDER_DATE
                                        , src.RETURN_ARRIVAL_DATE
                                        , src.RETURN_CLOSED_DATE
                                        , src.SALES_LINE_CREATED_DATE
                                        , src.INVENTORY_TRANSACTION_ID
                                        , src.INVOICE_ID
                                        , src.LEDGER_VOUCHER
                                        , src.LINE_NUMBER
                                        , src.ORIGINAL_SALES_ORDER_ID
                                        , src.PRODUCTION_TIME
                                        , src.PURCHASE_ORDER_ID
                                        , src.ORIGINATING_ORDER_SALES_ID
                                        , src.REGISTRY_NUMBER
                                        , src.INVENTORY_QUANTITY
                                        , src.INVOICE_QUANTITY
                                        , src.PHYSICAL_QUANTITY
                                        , src.PRICE_UNIT
                                        , src.SALES_PRICE
                                        , src.COMMISSION_AMOUNT_TRANSACTION_CURRENCY
                                        , src.COMMISSION_AMOUNT_COMPANY_CURRENCY
                                        , src.LINE_AMOUNT_TRANSACTION_CURRENCY
                                        , src.LINE_AMOUNT_COMPANY_CURRENCY
                                        , src.TAX_AMOUNT_TRANSACTION_CURRENCY
                                        , src.TAX_AMOUNT_COMPANY_CURRENCY
                                        , src.DISCOUNT_PERCENT
                                        , src.DISCOUNT_AMOUNT
                                        , src.LINE_DISCOUNT
                                        , src.LINE_DISCOUNT_PERCENT
                                        , src.FLOOR_LINE_DISCOUNT
                                        , src.LINE_DISCOUNT_TOTAL_TRANSACTION_CURRENCY
                                        , src.LINE_DISCOUNT_TOTAL_COMPANY_CURRENCY
                                        , src.COST_OF_GOODS_SOLD
                                        , src.FIXED_OVERHEAD
                                        , src.LABOR
                                        , src.MATERIAL
                                        , src.VARIABLE_OVERHEAD
                                        , src.FROZEN_COST_OF_GOODS_SOLD
                                        , src.FROZEN_FIXED_OVERHEAD
                                        , src.FROZEN_LABOR
                                        , src.FROZEN_MATERIAL
                                        , src.FROZEN_VARIABLE_OVERHEAD
                                        , src.STANDARD_COST
                                        , src.FROZEN_STANDARD_COST
                                        , src.PRICE_OVERRIDE_REASON_CODE
                                        , src.PRICE_OVERRIDE_REASON_CODE_DESCRIPTION
                                        , src.ISLR
                                        , src.RECORD_ID_POS
                                        , src.PRICE_TYPE
                                        , src.ACTIVATION_DATE
                                        , src.CREATED_DATETIME
										, src.JOURNAL_NUMBER
										, src.JOURNAL_NAME
										, src.INVENTORY_SITE_ID
                                        , src.COGSFIFO_CURRENCY_CODE
                                        , src.COGSFIFO_SALES_STATUS
                                        , src.COGSFIFO_COST_PRICE
                                        , src.COGSFIFO_SALES_QTY
                                        , src.COGSFIFO_ACCOUNTING_CURRENCY
                                        , src.COGSFIFO_KIT_PARENT_INVENTORY_TRANSACTION_ID
                                        , src.COGSFIFO_KIT_BOM_LEVEL
                                        , src.COGSFIFO_COST_AMOUNT_POSTED
                                        , src.COGSFIFO_COST_AMOUNT_ADJUSTMENT
                                        , src.COGSFIFO_KIT_IDENTIFIER
                                        , src.COGSFIFO_FROM_CURRENCY_CODE
                                        , src.COGSFIFO_TO_CURRENCY_CODE
                                        , src.COGSFIFO_EXCHANGE_RATE
                                        , src.COGSFIFO_COST_OF_GOODS_SOLD
                                        , src.SRC_HK_HASH_KEY
                                        , src.HK_SOURCE_NAME
                                        , src.HK_SOFT_DELETE_FLAG
                                        , src.HK_SOURCE_CREATED_TIMESTAMP
                                        , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                        , src.HK_CREATED_JOB_RUN_ID
                                        , src.HK_LAST_UPDATED_JOB_RUN_ID
                                        , src.HK_CREATED_TIMESTAMP
                                        , src.HK_LAST_UPDATED_TIMESTAMP
                                        , src.HK_WAREHOUSE_ID
                                    )';

         res := (EXECUTE IMMEDIATE :merge_statement);
        
         LET cur3 CURSOR FOR res;

          FOR row_variable IN cur3 DO
          i_count := row_variable."number of rows inserted";
          u_count := row_variable."number of rows updated";
          END FOR;
     
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
            a.FACT_SALES_INVOICES_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_DELIVERY_DATE_DIM_DATE_KEY
            , a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
            , a.NEW_DUE_DATE_DIM_DATE_KEY
            , a.NEW_INVOICE_DATE_DIM_DATE_KEY
            , a.NEW_MANUFACTURED_DATE_DIM_DATE_KEY
            , a.NEW_ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
            , a.NEW_RELATED_ORDER_DATE_DIM_DATE_KEY
            , a.NEW_RETURN_ARRIVAL_DATE_DIM_DATE_KEY
            , a.NEW_RETURN_CLOSED_DATE_DIM_DATE_KEY
            , a.NEW_SALES_LINE_CREATED_DATE_DIM_DATE_KEY
            , a.NEW_DIM_BUSINESS_UNIT_KEY
            , a.NEW_DIM_CAMPAIGN_KEY
            , a.NEW_DIM_COMMISSION_GROUP_KEY
            , a.NEW_DIM_COST_KEY
            , a.NEW_DIM_CURRENCY_KEY
            , a.NEW_DIM_CUSTOMER_INVOICE_KEY
            , a.NEW_DIM_CUSTOMER_ORDER_KEY
            , a.NEW_DIM_CUSTOMER_GROUP_KEY
            , a.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
            , a.NEW_DIM_DEFAULT_DIMENSION_KEY
            , a.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
            , a.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
            , a.NEW_DIM_INVENTORY_KEY
            , a.NEW_DIM_ITEM_KEY
            --, a.NEW_DIM_ITEM_STATUS_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_LINE_RETURN_REASON_KEY
            , a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
            , a.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
            , a.NEW_DIM_DELIVERY_MODE_KEY
            , a.NEW_DIM_DELIVERY_TERM_KEY
            , a.NEW_DIM_PAYMENT_TERMS_KEY
            , a.NEW_DIM_PROCUREMENT_CATEGORY_KEY
            , a.NEW_DIM_RETURN_DISPOSITION_KEY
            , a.NEW_DIM_RETURN_REASON_KEY
            , a.NEW_DIM_SALES_GROUP_KEY
            , a.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
            , a.NEW_DIM_SALES_ORDER_KEY
            , a.NEW_DIM_SALES_ORIGIN_KEY
            , a.NEW_DIM_SALES_POOL_KEY
            , a.NEW_DIM_SALES_PRICE_GROUP_KEY
            , a.NEW_DIM_TAX_GROUP_KEY
            , a.NEW_DIM_TAX_ITEM_GROUP_KEY
            , a.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
            , a.NEW_DIM_WAREHOUSE_KEY
            , a.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
            , a.NEW_DIM_WORKER_SALES_TAKER_KEY
                from (
                select 
                src.FACT_SALES_INVOICES_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.DELIVERY_DATE_DIM_DATE_KEY
                , src.DOCUMENT_DATE_DIM_DATE_KEY
                , src.DUE_DATE_DIM_DATE_KEY
                , src.INVOICE_DATE_DIM_DATE_KEY
                , src.MANUFACTURED_DATE_DIM_DATE_KEY
                , src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                , src.RELATED_ORDER_DATE_DIM_DATE_KEY
                , src.RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                , src.RETURN_CLOSED_DATE_DIM_DATE_KEY
                , src.SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                , src.DIM_BUSINESS_UNIT_KEY
                , src.DIM_CAMPAIGN_KEY
                , src.DIM_COMMISSION_GROUP_KEY
                , src.DIM_COST_KEY
                , src.DIM_CURRENCY_KEY
                , src.DIM_CUSTOMER_INVOICE_KEY
                , src.DIM_CUSTOMER_ORDER_KEY
                , src.DIM_CUSTOMER_GROUP_KEY
                , src.DIM_CUSTOMER_MARKUP_GROUP_KEY
                , src.DIM_DEFAULT_DIMENSION_KEY
                , src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                , src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                , src.DIM_INVENTORY_KEY
                , src.DIM_ITEM_KEY
                --, src.DIM_ITEM_STATUS_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_LINE_RETURN_REASON_KEY
                , src.DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , src.DIM_LOCATION_INVOICE_ADDRESS_KEY
                , src.DIM_DELIVERY_MODE_KEY
                , src.DIM_DELIVERY_TERM_KEY
                , src.DIM_PAYMENT_TERMS_KEY
                , src.DIM_PROCUREMENT_CATEGORY_KEY
                , src.DIM_RETURN_DISPOSITION_KEY
                , src.DIM_RETURN_REASON_KEY
                , src.DIM_SALES_GROUP_KEY
                , src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                , src.DIM_SALES_ORDER_KEY
                , src.DIM_SALES_ORIGIN_KEY
                , src.DIM_SALES_POOL_KEY
                , src.DIM_SALES_PRICE_GROUP_KEY
                , src.DIM_TAX_GROUP_KEY
                , src.DIM_TAX_ITEM_GROUP_KEY
                , src.DIM_UNIT_OF_MEASURE_SALES_KEY
                , src.DIM_WAREHOUSE_KEY
                , src.DIM_WORKER_SALES_RESPONSIBLE_KEY
                , src.DIM_WORKER_SALES_TAKER_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_DELIVERY_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_DATE_KEY, -1) AS NEW_DUE_DATE_DIM_DATE_KEY
                , nvl(d5.DIM_DATE_KEY, -1) AS NEW_INVOICE_DATE_DIM_DATE_KEY
                , nvl(d6.DIM_DATE_KEY, -1) AS NEW_MANUFACTURED_DATE_DIM_DATE_KEY
                , nvl(d7.DIM_DATE_KEY, -1) AS NEW_ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                , nvl(d8.DIM_DATE_KEY, -1) AS NEW_RELATED_ORDER_DATE_DIM_DATE_KEY
                , nvl(d9.DIM_DATE_KEY, -1) AS NEW_RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                , nvl(d10.DIM_DATE_KEY, -1) AS NEW_RETURN_CLOSED_DATE_DIM_DATE_KEY
                , nvl(d11.DIM_DATE_KEY, -1) AS NEW_SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                , nvl(d12.DIM_BUSINESS_UNIT_KEY, -1) AS NEW_DIM_BUSINESS_UNIT_KEY
                , nvl(d13.DIM_CAMPAIGN_KEY, -1) AS NEW_DIM_CAMPAIGN_KEY
                , nvl(d14.DIM_COMMISSION_GROUP_KEY, -1) AS NEW_DIM_COMMISSION_GROUP_KEY
                , nvl(d15.DIM_COST_KEY, -1) AS NEW_DIM_COST_KEY
                , nvl(d16.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
                , nvl(d17.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
                , nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
                , nvl(d19.DIM_CUSTOMER_GROUP_KEY, -1) AS NEW_DIM_CUSTOMER_GROUP_KEY
                , nvl(d20.DIM_CUSTOMER_MARKUP_GROUP_KEY, -1) AS NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
                , nvl(d21.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
                , nvl(d22.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY, -1) AS NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                , nvl(d23.DIM_INTRA_STAT_TRANSACTION_CODE_KEY, -1) AS NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                , nvl(d24.DIM_INVENTORY_KEY, -1) AS NEW_DIM_INVENTORY_KEY
                , nvl(d25.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                -- , nvl(d26.DIM_ITEM_STATUS_KEY, -1) AS NEW_DIM_ITEM_STATUS_KEY
                , nvl(d27.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d28.DIM_LINE_RETURN_REASON_KEY, -1) AS NEW_DIM_LINE_RETURN_REASON_KEY
                , nvl(d29.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                , nvl(d30.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
                , nvl(d31.DIM_DELIVERY_MODE_KEY, -1) AS NEW_DIM_DELIVERY_MODE_KEY
                , nvl(d32.DIM_DELIVERY_TERM_KEY, -1) AS NEW_DIM_DELIVERY_TERM_KEY
                , nvl(d33.DIM_PAYMENT_TERMS_KEY, -1) AS NEW_DIM_PAYMENT_TERMS_KEY
                , nvl(d34.DIM_SALES_PROCUREMENT_CATEGORY_KEY, -1) AS NEW_DIM_PROCUREMENT_CATEGORY_KEY
                , nvl(d35.DIM_RETURN_DISPOSITION_KEY, -1) AS NEW_DIM_RETURN_DISPOSITION_KEY
                , nvl(d36.DIM_RETURN_REASON_KEY, -1) AS NEW_DIM_RETURN_REASON_KEY
                , nvl(d37.DIM_SALES_GROUP_KEY, -1) AS NEW_DIM_SALES_GROUP_KEY
                , nvl(d38.DIM_SALES_LINE_DISCOUNT_GROUP_KEY, -1) AS NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                , nvl(d39.DIM_SALES_ORDER_KEY, -1) AS NEW_DIM_SALES_ORDER_KEY
                , nvl(d40.DIM_SALES_ORIGIN_KEY, -1) AS NEW_DIM_SALES_ORIGIN_KEY
                , nvl(d41.DIM_SALES_POOL_KEY, -1) AS NEW_DIM_SALES_POOL_KEY
                , nvl(d42.DIM_SALES_PRICE_GROUP_KEY, -1) AS NEW_DIM_SALES_PRICE_GROUP_KEY
                , nvl(d43.DIM_TAX_GROUP_KEY, -1) AS NEW_DIM_TAX_GROUP_KEY
                , nvl(d44.DIM_TAX_ITEM_GROUP_KEY, -1) AS NEW_DIM_TAX_ITEM_GROUP_KEY
                , nvl(d45.DIM_UNIT_OF_MEASURE_KEY, -1) AS NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
                , nvl(d46.DIM_WAREHOUSE_KEY, -1) AS NEW_DIM_WAREHOUSE_KEY
                , nvl(d47.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
                , nvl(d48.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_SALES_TAKER_KEY
                    from ' || :tgt_db || '.global.FACT_SALES_INVOICES src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DELIVERY_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.DUE_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.INVOICE_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
                                src.MANUFACTURED_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d7 ON
                                src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY = d7.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d8 ON
                                src.RELATED_ORDER_DATE_DIM_DATE_SNKEY = d8.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d9 ON
                                src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY = d9.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d10 ON
                                src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY = d10.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d11 ON
                                src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY = d11.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_BUSINESS_UNIT d12 ON
                                src.DIM_BUSINESS_UNIT_SNKEY = d12.DIM_BUSINESS_UNIT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CAMPAIGN d13 ON
                               src.DIM_CAMPAIGN_SNKEY = d13.DIM_CAMPAIGN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_COMMISSION_GROUP d14 ON
                                src.DIM_COMMISSION_GROUP_SNKEY = d14.DIM_COMMISSION_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_COST d15 ON
                               src.DIM_COST_SNKEY = d15.DIM_COST_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d16 ON
                                src.DIM_CURRENCY_SNKEY = d16.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d17 ON
                                src.DIM_CUSTOMER_INVOICE_SNKEY = d17.DIM_CUSTOMER_SNKEY
                                AND src.INVOICE_DATE >= d17.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.INVOICE_DATE < d17.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
                                src.DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY
                                AND src.INVOICE_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.INVOICE_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_GROUP d19 ON
                               src.DIM_CUSTOMER_GROUP_SNKEY = d19.DIM_CUSTOMER_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_MARKUP_GROUP d20 ON
                               src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY = d20.DIM_CUSTOMER_MARKUP_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d21 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d21.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_GLOBAL_TRADE_ITEM_NUMBER d22 ON
                               src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY = d22.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INTRA_STAT_TRANSACTION_CODE d23 ON
                               src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY = d23.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_INVENTORY d24 ON
                                src.DIM_INVENTORY_SNKEY = d24.DIM_INVENTORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d25 ON
                                src.DIM_ITEM_SNKEY = d25.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d27 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d27.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LINE_RETURN_REASON d28 ON
                                src.DIM_LINE_RETURN_REASON_SNKEY = d28.DIM_LINE_RETURN_REASON_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d29 ON
                                src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY = d29.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d30 ON
                                src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY = d30.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d31 ON
                                src.DIM_DELIVERY_MODE_SNKEY = d31.DIM_DELIVERY_MODE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_TERM d32 ON
                                src.DIM_DELIVERY_TERM_SNKEY = d32.DIM_DELIVERY_TERM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_PAYMENT_TERMS d33 ON
                                src.DIM_PAYMENT_TERMS_SNKEY = d33.DIM_PAYMENT_TERMS_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PROCUREMENT_CATEGORY d34 ON
                                src.DIM_PROCUREMENT_CATEGORY_SNKEY = d34.DIM_SALES_PROCUREMENT_CATEGORY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_RETURN_DISPOSITION d35 ON
                               src.DIM_RETURN_DISPOSITION_SNKEY = d35.DIM_RETURN_DISPOSITION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_RETURN_REASON d36 ON
                                src.DIM_RETURN_REASON_SNKEY = d36.DIM_RETURN_REASON_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_GROUP d37 ON
                               src.DIM_SALES_GROUP_SNKEY = d37.DIM_SALES_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_LINE_DISCOUNT_GROUP d38 ON
                               src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY = d38.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d39 ON
                                src.DIM_SALES_ORDER_SNKEY = d39.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORIGIN d40 ON
                                src.DIM_SALES_ORIGIN_SNKEY = d40.DIM_SALES_ORIGIN_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_POOL d41 ON
                               src.DIM_SALES_POOL_SNKEY = d41.DIM_SALES_POOL_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_PRICE_GROUP d42 ON
                               src.DIM_SALES_PRICE_GROUP_SNKEY = d42.DIM_SALES_PRICE_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d43 ON
                               src.DIM_TAX_GROUP_SNKEY = d43.DIM_TAX_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_ITEM_GROUP d44 ON
                               src.DIM_TAX_ITEM_GROUP_SNKEY = d44.DIM_TAX_ITEM_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_UNIT_OF_MEASURE d45 ON
                               src.DIM_UNIT_OF_MEASURE_SALES_SNKEY = d45.DIM_UNIT_OF_MEASURE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WAREHOUSE d46 ON
                                src.DIM_WAREHOUSE_SNKEY = d46.DIM_WAREHOUSE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d47 ON
                                src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY = d47.DIM_WORKER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d48 ON
                                src.DIM_WORKER_SALES_TAKER_SNKEY = d48.DIM_WORKER_SNKEY
    where 1=1
    and (
        (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
or (src.DELIVERY_DATE_DIM_DATE_KEY = -1 and src.DELIVERY_DATE_DIM_DATE_SNKEY != -1)
or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
or (src.DUE_DATE_DIM_DATE_KEY = -1 and src.DUE_DATE_DIM_DATE_SNKEY != -1)
or (src.INVOICE_DATE_DIM_DATE_KEY = -1 and src.INVOICE_DATE_DIM_DATE_SNKEY != -1)
or (src.MANUFACTURED_DATE_DIM_DATE_KEY = -1 and src.MANUFACTURED_DATE_DIM_DATE_SNKEY != -1)
or (src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY = -1 and src.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_SNKEY != -1)
or (src.RELATED_ORDER_DATE_DIM_DATE_KEY = -1 and src.RELATED_ORDER_DATE_DIM_DATE_SNKEY != -1)
or (src.RETURN_ARRIVAL_DATE_DIM_DATE_KEY = -1 and src.RETURN_ARRIVAL_DATE_DIM_DATE_SNKEY != -1)
or (src.RETURN_CLOSED_DATE_DIM_DATE_KEY = -1 and src.RETURN_CLOSED_DATE_DIM_DATE_SNKEY != -1)
or (src.SALES_LINE_CREATED_DATE_DIM_DATE_KEY = -1 and src.SALES_LINE_CREATED_DATE_DIM_DATE_SNKEY != -1)
or (src.DIM_BUSINESS_UNIT_KEY = -1 and src.DIM_BUSINESS_UNIT_SNKEY != -1)
or (src.DIM_CAMPAIGN_KEY = -1 and src.DIM_CAMPAIGN_SNKEY != -1)
or (src.DIM_COMMISSION_GROUP_KEY = -1 and src.DIM_COMMISSION_GROUP_SNKEY != -1)
or (src.DIM_COST_KEY = -1 and src.DIM_COST_SNKEY != -1)
or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
or (src.DIM_CUSTOMER_INVOICE_KEY = -1 and src.DIM_CUSTOMER_INVOICE_SNKEY != -1)
or (src.DIM_CUSTOMER_ORDER_KEY = -1 and src.DIM_CUSTOMER_ORDER_SNKEY != -1)
or (src.DIM_CUSTOMER_GROUP_KEY = -1 and src.DIM_CUSTOMER_GROUP_SNKEY != -1)
or (src.DIM_CUSTOMER_MARKUP_GROUP_KEY = -1 and src.DIM_CUSTOMER_MARKUP_GROUP_SNKEY != -1)
or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
or (src.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = -1 and src.DIM_GLOBAL_TRADE_ITEM_NUMBER_SNKEY != -1)
or (src.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = -1 and src.DIM_INTRA_STAT_TRANSACTION_CODE_SNKEY != -1)
or (src.DIM_INVENTORY_KEY = -1 and src.DIM_INVENTORY_SNKEY != -1)
or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
-- or (src.DIM_ITEM_STATUS_KEY = -1 and src.DIM_ITEM_STATUS_SNKEY != -1)
or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
or (src.DIM_LINE_RETURN_REASON_KEY = -1 and src.DIM_LINE_RETURN_REASON_SNKEY != -1)
or (src.DIM_LOCATION_DELIVERY_ADDRESS_KEY = -1 and src.DIM_LOCATION_DELIVERY_ADDRESS_SNKEY != -1)
or (src.DIM_LOCATION_INVOICE_ADDRESS_KEY = -1 and src.DIM_LOCATION_INVOICE_ADDRESS_SNKEY != -1)
or (src.DIM_DELIVERY_MODE_KEY = -1 and src.DIM_DELIVERY_MODE_SNKEY != -1)
or (src.DIM_DELIVERY_TERM_KEY = -1 and src.DIM_DELIVERY_TERM_SNKEY != -1)
or (src.DIM_PAYMENT_TERMS_KEY = -1 and src.DIM_PAYMENT_TERMS_SNKEY != -1)
or (src.DIM_PROCUREMENT_CATEGORY_KEY = -1 and src.DIM_PROCUREMENT_CATEGORY_SNKEY != -1)
or (src.DIM_RETURN_DISPOSITION_KEY = -1 and src.DIM_RETURN_DISPOSITION_SNKEY != -1)
or (src.DIM_RETURN_REASON_KEY = -1 and src.DIM_RETURN_REASON_SNKEY != -1)
or (src.DIM_SALES_GROUP_KEY = -1 and src.DIM_SALES_GROUP_SNKEY != -1)
or (src.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = -1 and src.DIM_SALES_LINE_DISCOUNT_GROUP_SNKEY != -1)
or (src.DIM_SALES_ORDER_KEY = -1 and src.DIM_SALES_ORDER_SNKEY != -1)
or (src.DIM_SALES_ORIGIN_KEY = -1 and src.DIM_SALES_ORIGIN_SNKEY != -1)
or (src.DIM_SALES_POOL_KEY = -1 and src.DIM_SALES_POOL_SNKEY != -1)
or (src.DIM_SALES_PRICE_GROUP_KEY = -1 and src.DIM_SALES_PRICE_GROUP_SNKEY != -1)
or (src.DIM_TAX_GROUP_KEY = -1 and src.DIM_TAX_GROUP_SNKEY != -1)
or (src.DIM_TAX_ITEM_GROUP_KEY = -1 and src.DIM_TAX_ITEM_GROUP_SNKEY != -1)
or (src.DIM_UNIT_OF_MEASURE_SALES_KEY = -1 and src.DIM_UNIT_OF_MEASURE_SALES_SNKEY != -1)
or (src.DIM_WAREHOUSE_KEY = -1 and src.DIM_WAREHOUSE_SNKEY != -1)
or (src.DIM_WORKER_SALES_RESPONSIBLE_KEY = -1 and src.DIM_WORKER_SALES_RESPONSIBLE_SNKEY != -1)
or (src.DIM_WORKER_SALES_TAKER_KEY = -1 and src.DIM_WORKER_SALES_TAKER_SNKEY != -1)
        )
    ) a
where 1=1
and ((a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
or (a.DELIVERY_DATE_DIM_DATE_KEY != a.NEW_DELIVERY_DATE_DIM_DATE_KEY)
or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
or (a.DUE_DATE_DIM_DATE_KEY != a.NEW_DUE_DATE_DIM_DATE_KEY)
or (a.INVOICE_DATE_DIM_DATE_KEY != a.NEW_INVOICE_DATE_DIM_DATE_KEY)
or (a.MANUFACTURED_DATE_DIM_DATE_KEY != a.NEW_MANUFACTURED_DATE_DIM_DATE_KEY)
or (a.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY != a.NEW_ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY)
or (a.RELATED_ORDER_DATE_DIM_DATE_KEY != a.NEW_RELATED_ORDER_DATE_DIM_DATE_KEY)
or (a.RETURN_ARRIVAL_DATE_DIM_DATE_KEY != a.NEW_RETURN_ARRIVAL_DATE_DIM_DATE_KEY)
or (a.RETURN_CLOSED_DATE_DIM_DATE_KEY != a.NEW_RETURN_CLOSED_DATE_DIM_DATE_KEY)
or (a.SALES_LINE_CREATED_DATE_DIM_DATE_KEY != a.NEW_SALES_LINE_CREATED_DATE_DIM_DATE_KEY)
or (a.DIM_BUSINESS_UNIT_KEY != a.NEW_DIM_BUSINESS_UNIT_KEY)
or (a.DIM_CAMPAIGN_KEY != a.NEW_DIM_CAMPAIGN_KEY)
or (a.DIM_COMMISSION_GROUP_KEY != a.NEW_DIM_COMMISSION_GROUP_KEY)
or (a.DIM_COST_KEY != a.NEW_DIM_COST_KEY)
or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
or (a.DIM_CUSTOMER_INVOICE_KEY != a.NEW_DIM_CUSTOMER_INVOICE_KEY)
or (a.DIM_CUSTOMER_ORDER_KEY != a.NEW_DIM_CUSTOMER_ORDER_KEY)
or (a.DIM_CUSTOMER_GROUP_KEY != a.NEW_DIM_CUSTOMER_GROUP_KEY)
or (a.DIM_CUSTOMER_MARKUP_GROUP_KEY != a.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY)
or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
or (a.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY != a.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY)
or (a.DIM_INTRA_STAT_TRANSACTION_CODE_KEY != a.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY)
or (a.DIM_INVENTORY_KEY != a.NEW_DIM_INVENTORY_KEY)
or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
-- or (a.DIM_ITEM_STATUS_KEY != a.NEW_DIM_ITEM_STATUS_KEY)
or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
or (a.DIM_LINE_RETURN_REASON_KEY != a.NEW_DIM_LINE_RETURN_REASON_KEY)
or (a.DIM_LOCATION_DELIVERY_ADDRESS_KEY != a.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY)
or (a.DIM_LOCATION_INVOICE_ADDRESS_KEY != a.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY)
or (a.DIM_DELIVERY_MODE_KEY != a.NEW_DIM_DELIVERY_MODE_KEY)
or (a.DIM_DELIVERY_TERM_KEY != a.NEW_DIM_DELIVERY_TERM_KEY)
or (a.DIM_PAYMENT_TERMS_KEY != a.NEW_DIM_PAYMENT_TERMS_KEY)
or (a.DIM_PROCUREMENT_CATEGORY_KEY != a.NEW_DIM_PROCUREMENT_CATEGORY_KEY)
or (a.DIM_RETURN_DISPOSITION_KEY != a.NEW_DIM_RETURN_DISPOSITION_KEY)
or (a.DIM_RETURN_REASON_KEY != a.NEW_DIM_RETURN_REASON_KEY)
or (a.DIM_SALES_GROUP_KEY != a.NEW_DIM_SALES_GROUP_KEY)
or (a.DIM_SALES_LINE_DISCOUNT_GROUP_KEY != a.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY)
or (a.DIM_SALES_ORDER_KEY != a.NEW_DIM_SALES_ORDER_KEY)
or (a.DIM_SALES_ORIGIN_KEY != a.NEW_DIM_SALES_ORIGIN_KEY)
or (a.DIM_SALES_POOL_KEY != a.NEW_DIM_SALES_POOL_KEY)
or (a.DIM_SALES_PRICE_GROUP_KEY != a.NEW_DIM_SALES_PRICE_GROUP_KEY)
or (a.DIM_TAX_GROUP_KEY != a.NEW_DIM_TAX_GROUP_KEY)
or (a.DIM_TAX_ITEM_GROUP_KEY != a.NEW_DIM_TAX_ITEM_GROUP_KEY)
or (a.DIM_UNIT_OF_MEASURE_SALES_KEY != a.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY)
or (a.DIM_WAREHOUSE_KEY != a.NEW_DIM_WAREHOUSE_KEY)
or (a.DIM_WORKER_SALES_RESPONSIBLE_KEY != a.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY)
or (a.DIM_WORKER_SALES_TAKER_KEY != a.NEW_DIM_WORKER_SALES_TAKER_KEY)
    )
;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_SALES_INVOICES_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_SNKEY
				, a.NEW_DIM_CUSTOMER_INVOICE_KEY
				, a.NEW_DIM_CUSTOMER_INVOICE_SNKEY
			from (select src.FACT_SALES_INVOICES_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
						else DIM_CUSTOMER_ORDER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_ORDER_SNKEY
					, src.DIM_CUSTOMER_ORDER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
					
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
					, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
							when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
						else DIM_CUSTOMER_INVOICE_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_INVOICE_SNKEY
					, src.DIM_CUSTOMER_INVOICE_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
				from ' || :tgt_db || '.global.FACT_SALES_INVOICES src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.INVOICE_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.INVOICE_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
				
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
					DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
					DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d17 ON
					NEW_DIM_CUSTOMER_INVOICE_SNKEY = d17.DIM_CUSTOMER_SNKEY and
					src.INVOICE_DATE >= d17.HK_EFFECTIVE_START_TIMESTAMP and
					src.INVOICE_DATE < d17.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_ORDER_SNKEY != NEW_DIM_CUSTOMER_ORDER_SNKEY
				or src.DIM_CUSTOMER_ORDER_KEY != NEW_DIM_CUSTOMER_ORDER_KEY
				or src.DIM_CUSTOMER_INVOICE_SNKEY != NEW_DIM_CUSTOMER_INVOICE_SNKEY
				or src.DIM_CUSTOMER_INVOICE_KEY != NEW_DIM_CUSTOMER_INVOICE_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;


        
        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
     || ' src on src.FACT_SALES_INVOICES_KEY = tgt.FACT_SALES_INVOICES_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DELIVERY_DATE_DIM_DATE_KEY = src.NEW_DELIVERY_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.NEW_DUE_DATE_DIM_DATE_KEY
                                    , tgt.INVOICE_DATE_DIM_DATE_KEY = src.NEW_INVOICE_DATE_DIM_DATE_KEY
                                    , tgt.MANUFACTURED_DATE_DIM_DATE_KEY = src.NEW_MANUFACTURED_DATE_DIM_DATE_KEY
                                    , tgt.ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY = src.NEW_ORIGINATING_ORDER_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.RELATED_ORDER_DATE_DIM_DATE_KEY = src.NEW_RELATED_ORDER_DATE_DIM_DATE_KEY
                                    , tgt.RETURN_ARRIVAL_DATE_DIM_DATE_KEY = src.NEW_RETURN_ARRIVAL_DATE_DIM_DATE_KEY
                                    , tgt.RETURN_CLOSED_DATE_DIM_DATE_KEY = src.NEW_RETURN_CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.SALES_LINE_CREATED_DATE_DIM_DATE_KEY = src.NEW_SALES_LINE_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.DIM_BUSINESS_UNIT_KEY = src.NEW_DIM_BUSINESS_UNIT_KEY
                                    , tgt.DIM_CAMPAIGN_KEY = src.NEW_DIM_CAMPAIGN_KEY
                                    , tgt.DIM_COMMISSION_GROUP_KEY = src.NEW_DIM_COMMISSION_GROUP_KEY
                                    , tgt.DIM_COST_KEY = src.NEW_DIM_COST_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_GROUP_KEY = src.NEW_DIM_CUSTOMER_GROUP_KEY
                                    , tgt.DIM_CUSTOMER_MARKUP_GROUP_KEY = src.NEW_DIM_CUSTOMER_MARKUP_GROUP_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY = src.NEW_DIM_GLOBAL_TRADE_ITEM_NUMBER_KEY
                                    , tgt.DIM_INTRA_STAT_TRANSACTION_CODE_KEY = src.NEW_DIM_INTRA_STAT_TRANSACTION_CODE_KEY
                                    , tgt.DIM_INVENTORY_KEY = src.NEW_DIM_INVENTORY_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    --, tgt.DIM_ITEM_STATUS_KEY = src.NEW_DIM_ITEM_STATUS_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LINE_RETURN_REASON_KEY = src.NEW_DIM_LINE_RETURN_REASON_KEY
                                    , tgt.DIM_LOCATION_DELIVERY_ADDRESS_KEY = src.NEW_DIM_LOCATION_DELIVERY_ADDRESS_KEY
                                    , tgt.DIM_LOCATION_INVOICE_ADDRESS_KEY = src.NEW_DIM_LOCATION_INVOICE_ADDRESS_KEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.NEW_DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_TERM_KEY = src.NEW_DIM_DELIVERY_TERM_KEY
                                    , tgt.DIM_PAYMENT_TERMS_KEY = src.NEW_DIM_PAYMENT_TERMS_KEY
                                    , tgt.DIM_PROCUREMENT_CATEGORY_KEY = src.NEW_DIM_PROCUREMENT_CATEGORY_KEY
                                    , tgt.DIM_RETURN_DISPOSITION_KEY = src.NEW_DIM_RETURN_DISPOSITION_KEY
                                    , tgt.DIM_RETURN_REASON_KEY = src.NEW_DIM_RETURN_REASON_KEY
                                    , tgt.DIM_SALES_GROUP_KEY = src.NEW_DIM_SALES_GROUP_KEY
                                    , tgt.DIM_SALES_LINE_DISCOUNT_GROUP_KEY = src.NEW_DIM_SALES_LINE_DISCOUNT_GROUP_KEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.NEW_DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_ORIGIN_KEY = src.NEW_DIM_SALES_ORIGIN_KEY
                                    , tgt.DIM_SALES_POOL_KEY = src.NEW_DIM_SALES_POOL_KEY
                                    , tgt.DIM_SALES_PRICE_GROUP_KEY = src.NEW_DIM_SALES_PRICE_GROUP_KEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.NEW_DIM_TAX_GROUP_KEY
                                    , tgt.DIM_TAX_ITEM_GROUP_KEY = src.NEW_DIM_TAX_ITEM_GROUP_KEY
                                    , tgt.DIM_UNIT_OF_MEASURE_SALES_KEY = src.NEW_DIM_UNIT_OF_MEASURE_SALES_KEY
                                    , tgt.DIM_WAREHOUSE_KEY = src.NEW_DIM_WAREHOUSE_KEY
                                    , tgt.DIM_WORKER_SALES_RESPONSIBLE_KEY = src.NEW_DIM_WORKER_SALES_RESPONSIBLE_KEY
                                    , tgt.DIM_WORKER_SALES_TAKER_KEY = src.NEW_DIM_WORKER_SALES_TAKER_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

         res := (EXECUTE IMMEDIATE :merge_statement);

         LET c4 CURSOR FOR res;

         LET key_fix_count INTEGER DEFAULT 0;
         FOR row_variable IN c4 DO
             key_fix_count := row_variable."number of rows updated";
         END FOR;


--merge late arriving dim back into fact table for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
     || ' src
                        
						on src.FACT_SALES_INVOICES_KEY = tgt.FACT_SALES_INVOICES_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_ORDER_SNKEY = src.NEW_DIM_CUSTOMER_ORDER_SNKEY
									, tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
									, tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.NEW_DIM_CUSTOMER_INVOICE_SNKEY
									, tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
         res := (EXECUTE IMMEDIATE :update_statement_customer);

		  LET c5 CURSOR FOR res;

          LET key_fix_count_customer INTEGER DEFAULT 0;
          FOR row_variable IN c5 DO
		  	key_fix_count_customer := row_variable."number of rows updated";
          END FOR;
	
	
        -- --Logging insert row count
         v_proc_step := '8';

         call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        -- --Logging update row count
         v_proc_step := '8';

         call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        -- --Logging late arriving dimension count
         v_proc_step := '9';

         call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        -- --Logging late arriving dimension count
         v_proc_step := '10';

         call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        -- --Logging stored procedure completed
         v_proc_step := '11';

         call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        -- --Update the TASK_INSTANCE table
         v_proc_step := '12';
         call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

     EXCEPTION
         WHEN STATEMENT_ERROR THEN
             CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
             RETURN FALSE;
         WHEN EXPRESSION_ERROR THEN
             CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
             RETURN FALSE;
         WHEN OTHER THEN
             CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
             RETURN FALSE;
END;