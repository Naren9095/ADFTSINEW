/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_TRANSPORTATION_LOAD
    CREATED BY     : Joshua Mills
    CREATED ON     : 07/11/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_TRANSPORTATION_LOAD(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_TRANSPORTATION_LOAD
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_TRANSPORTATION_LOAD';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'WHSLOADLINE';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_TRANSPORTATION_LOAD';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TRANSPORTATION_LOAD_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_TRANSPORTATION_LOAD_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.DATAAREAID AS DATA_AREA_ID
                                , src.LOADID AS LOAD_ID
                                , src.ORDERNUM AS SALES_ORDER_ID
                                , src.ITEMID AS ITEM_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS PLANNED_SHIP_DATE_DIM_DATE_KEY
                                , 0 AS PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                                , 0 AS ACTUAL_SHIP_DATE_DIM_DATE_KEY
                                , 0 AS ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CUSTOMER_KEY
                                , 0 AS DIM_CUSTOMER_SNKEY
                                , 0 AS DIM_ITEM_KEY
                                , 0 AS DIM_ITEM_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_LOCATION_KEY
                                , 0 AS DIM_LOCATION_SNKEY
                                , 0 AS DIM_SALES_ORDER_KEY
                                , 0 AS DIM_SALES_ORDER_SNKEY
                                , 0 AS DIM_SHIPPING_CARRIER_KEY
                                , 0 AS DIM_SHIPPING_CARRIER_SNKEY
                                , 0 AS DIM_SITE_KEY
                                , 0 AS DIM_SITE_SNKEY
                                , 0 AS DIM_TRAILERS_KEY
                                , 0 AS DIM_TRAILERS_SNKEY
                                , nvl(src.SALESTABLE_CUSTACCOUNT, '''') AS CUSTOMER_ACCOUNT
                                , nvl(src.SALESTABLE_DELIVERYPOSTALADDRESS, 0) AS RECORD_ID_LOCATION
                                , nvl(src.WHSLOADTABLE_INVENTSITEID, '''') AS INVENT_SITE_ID
                                , nvl(src.WHSLOADTABLE_EBCCARRIERID, '''') AS EBC_CARRIER_ID
                                , nvl(src.WHSLOADTABLE_EBCTRAILERID, '''') AS EBC_TRAILER_ID
                                , nvl(src.MCSRNAROUTESTOP_STOPCOUNT, 0) AS PLANNED_STOP_COUNT
                                , nvl(src.QTY, 0) AS SCHEDULED_PIECES
                                , nvl(src.MCSRNAROUTESTOP_MILEAGE, 0) AS SCHEDULED_MILEAGE
                                , nvl(src.MCSRNAEVENTHEADER_ACTUALMILES, 0) AS ACTUAL_MILES
                                , nvl(src.MCSRNAEVENTHEADER_ACTUALSTOPCOUNT, 0) AS ACTUAL_STOP_COUNT
                                , nvl(src.MCSRNAEVENTLINE_ACTUALPIECES, 0) AS ACTUAL_PIECES
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_SALESTYPE, '''') AS TRANSACTION_TYPE
                                , nvl(src.MCSTRAILERS_CUBICVOLUME, 0) AS TRAILER_CUBIC_VOLUME_CAPACITY
                                , case when UPPER(src.ITEMID) like ''%MERGE%'' then nvl((src.MCSRNAEVENTLINE_ACTUALPIECES * src.MCSRNAEVENTLINE_UNITVOLUME), 0) else nvl((src.MCSRNAEVENTLINE_ACTUALPIECES * src.INVENTTABLE_UNITVOLUME), 0) END AS ACTUAL_CUBES
                                , case when UPPER(src.ITEMID) like ''%MERGE%'' then nvl((src.QTY * src.MCSRNAEVENTLINE_UNITVOLUME), 0) else nvl((src.QTY * src.INVENTTABLE_UNITVOLUME), 0) END AS PLANNED_CUBES
                                , case when nvl(src.WHSLOADTABLE_LOADSCHEDSHIPUTCDATETIME, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.WHSLOADTABLE_LOADSCHEDSHIPUTCDATETIME < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.WHSLOADTABLE_LOADSCHEDSHIPUTCDATETIME > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.WHSLOADTABLE_LOADSCHEDSHIPUTCDATETIME END AS PLANNED_SHIP_DATE
                                , case when nvl(src.SALESTABLE_SHIPPINGDATECONFIRMED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.SALESTABLE_SHIPPINGDATECONFIRMED < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.SALESTABLE_SHIPPINGDATECONFIRMED > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.SALESTABLE_SHIPPINGDATECONFIRMED END AS ACTUAL_SHIP_DATE
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_LOADSTATUS, '''') AS LOAD_STATUS_DESCRIPTION
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                    on src.HK_SOURCE_NAME = tgt.SOURCE_NAME 
    and 
        src.DATAAREAID = tgt.DATA_AREA_ID 
    and 
        src.LOADID = tgt.LOAD_ID 
    and 
        src.ORDERNUM = tgt.SALES_ORDER_ID
    and 
        src.ITEMID = tgt.ITEM_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TRANSPORTATION_LOAD_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TRANSPORTATION_LOAD_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                            hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', src.LOAD_ID, ''~'', src.SALES_ORDER_ID, ''~'', src.ITEM_ID) AS FACT_TRANSPORTATION_LOAD_KEY
                            , src.SOURCE_NAME
                            , src.DATA_AREA_ID
                            , src.LOAD_ID
                            , src.SALES_ORDER_ID
                            , src.ITEM_ID
                            , case when src.SOURCE_NAME = ''''  then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.PLANNED_SHIP_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS PLANNED_SHIP_DATE_DIM_DATE_KEY
                            , src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                            , case when src.ACTUAL_SHIP_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS ACTUAL_SHIP_DATE_DIM_DATE_KEY
                            , src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_CUSTOMER_SNKEY = -2 then -2 else nvl(d4.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_KEY
                            , src.DIM_CUSTOMER_SNKEY
                            , case when src.DIM_ITEM_SNKEY = -2 then -2 else nvl(d5.DIM_ITEM_KEY, -1) END AS DIM_ITEM_KEY
                            , src.DIM_ITEM_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d6.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_LOCATION_SNKEY = -2 then -2 else nvl(d7.DIM_LOCATION_KEY, -1) END AS DIM_LOCATION_KEY
                            , src.DIM_LOCATION_SNKEY
                            , case when src.DIM_SALES_ORDER_SNKEY = -2 then -2 else nvl(d8.DIM_SALES_ORDER_KEY, -1) END AS DIM_SALES_ORDER_KEY
                            , src.DIM_SALES_ORDER_SNKEY
                            , case when src.DIM_SHIPPING_CARRIER_SNKEY = -2 then -2 else nvl(d9.DIM_SHIPPING_CARRIER_KEY, -1) END AS DIM_SHIPPING_CARRIER_KEY
                            , src.DIM_SHIPPING_CARRIER_SNKEY
                            , case when src.DIM_SITE_SNKEY = -2 then -2 else nvl(d10.DIM_SITE_KEY, -1) END AS DIM_SITE_KEY
                            , src.DIM_SITE_SNKEY
                            , case when src.DIM_TRAILERS_SNKEY = -2 then -2 else nvl(d11.DIM_TRAILERS_KEY, -1) END AS DIM_TRAILERS_KEY
                            , src.DIM_TRAILERS_SNKEY
                            , src.CUSTOMER_ACCOUNT
                            , src.RECORD_ID_LOCATION
                            , src.INVENT_SITE_ID
                            , src.EBC_CARRIER_ID
                            , src.EBC_TRAILER_ID
                            , src.PLANNED_STOP_COUNT
                            , src.SCHEDULED_PIECES
                            , src.SCHEDULED_MILEAGE
                            , src.ACTUAL_MILES
                            , src.ACTUAL_STOP_COUNT
                            , src.ACTUAL_PIECES
                            , src.TRANSACTION_TYPE
                            , src.TRAILER_CUBIC_VOLUME_CAPACITY
                            , src.ACTUAL_CUBES
                            , src.PLANNED_CUBES
                            , src.PLANNED_SHIP_DATE
                            , src.ACTUAL_SHIP_DATE
                            , src.LOAD_STATUS_DESCRIPTION
                            , hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', src.LOAD_ID, ''~'', src.SALES_ORDER_ID, ''~'', src.ITEM_ID, ''~'', src.CUSTOMER_ACCOUNT, ''~'', to_char(src.RECORD_ID_LOCATION), ''~'', src.INVENT_SITE_ID, ''~'', src.EBC_CARRIER_ID, ''~'', src.EBC_TRAILER_ID, ''~'', to_char(src.PLANNED_STOP_COUNT), ''~'', to_char(src.SCHEDULED_PIECES), ''~'', to_char(src.SCHEDULED_MILEAGE), ''~'', to_char(src.ACTUAL_MILES), ''~'', to_char(src.ACTUAL_STOP_COUNT), ''~'', to_char(src.ACTUAL_PIECES), ''~'', src.TRANSACTION_TYPE, ''~'', to_char(src.TRAILER_CUBIC_VOLUME_CAPACITY), ''~'', to_char(src.ACTUAL_CUBES), ''~'', to_char(src.PLANNED_CUBES), ''~'', to_char(src.PLANNED_SHIP_DATE, ''yyyymmdd''), ''~'', to_char(src.ACTUAL_SHIP_DATE, ''yyyymmdd''), ''~'', src.LOAD_STATUS_DESCRIPTION) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.DATA_AREA_ID, src.LOAD_ID, src.SALES_ORDER_ID, src.ITEM_ID  order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            prep01.FACT_TRANSPORTATION_LOAD_KEY
                            , prep01.SOURCE_NAME
                            , prep01.DATA_AREA_ID
                            , prep01.LOAD_ID
                            , prep01.SALES_ORDER_ID
                            , prep01.ITEM_ID
                            , prep01.DIM_SOURCE_SYSTEM_KEY
                            , case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , prep01.PLANNED_SHIP_DATE_DIM_DATE_KEY
                            , case when prep01.PLANNED_SHIP_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.PLANNED_SHIP_DATE, ''yyyymmdd'')) END AS PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                            , prep01.ACTUAL_SHIP_DATE_DIM_DATE_KEY
                            , case when prep01.ACTUAL_SHIP_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.ACTUAL_SHIP_DATE, ''yyyymmdd'')) END AS ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                            , prep01.DIM_CUSTOMER_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', prep01.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
							, case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', upper(prep01.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
                            , case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
									when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
								else DIM_CUSTOMER_SNKEY_RAW
								end as DIM_CUSTOMER_SNKEY
                            , prep01.DIM_ITEM_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.ITEM_ID, '''') = '''' then -2 else hash('''', ''~'', prep01.DATA_AREA_ID, ''~'', prep01.ITEM_ID) END AS DIM_ITEM_SNKEY
                            , prep01.DIM_LEGAL_ENTITY_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID) END AS DIM_LEGAL_ENTITY_SNKEY
                            , prep01.DIM_LOCATION_KEY
                            , case when nvl(prep01.RECORD_ID_LOCATION, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_LOCATION)) END AS DIM_LOCATION_SNKEY
                            , prep01.DIM_SALES_ORDER_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.SALES_ORDER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', prep01.SALES_ORDER_ID) END AS DIM_SALES_ORDER_SNKEY
                            , prep01.DIM_SHIPPING_CARRIER_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.EBC_CARRIER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', prep01.EBC_CARRIER_ID) END AS DIM_SHIPPING_CARRIER_SNKEY
                            , prep01.DIM_SITE_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.INVENT_SITE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', prep01.INVENT_SITE_ID) END AS DIM_SITE_SNKEY
                            , prep01.DIM_TRAILERS_KEY
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.EBC_TRAILER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', prep01.EBC_TRAILER_ID) END AS DIM_TRAILERS_SNKEY_RAW
                            , case when nvl(prep01.DATA_AREA_ID, '''') = '''' or nvl(prep01.EBC_TRAILER_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DATA_AREA_ID, ''~'', upper(prep01.EBC_TRAILER_ID)) END AS DIM_TRAILERS_SNKEY_UPPER
                            , case when dt1.DIM_TRAILERS_SNKEY is not null then DIM_TRAILERS_SNKEY_RAW
									when dt2.DIM_TRAILERS_SNKEY is not null then DIM_TRAILERS_SNKEY_UPPER
								else DIM_TRAILERS_SNKEY_RAW
								end as DIM_TRAILERS_SNKEY
                            , prep01.CUSTOMER_ACCOUNT
                            , prep01.RECORD_ID_LOCATION
                            , prep01.INVENT_SITE_ID
                            , prep01.EBC_CARRIER_ID
                            , prep01.EBC_TRAILER_ID
                            , prep01.PLANNED_STOP_COUNT
                            , prep01.SCHEDULED_PIECES
                            , prep01.SCHEDULED_MILEAGE
                            , prep01.ACTUAL_MILES
                            , prep01.ACTUAL_STOP_COUNT
                            , prep01.ACTUAL_PIECES
                            , prep01.TRANSACTION_TYPE
                            , prep01.TRAILER_CUBIC_VOLUME_CAPACITY
                            , prep01.ACTUAL_CUBES
                            , prep01.PLANNED_CUBES
                            , prep01.PLANNED_SHIP_DATE
                            , prep01.ACTUAL_SHIP_DATE
                            , prep01.LOAD_STATUS_DESCRIPTION
                            , prep01.HK_HASH_KEY
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_TRAILERS_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_TRAILERS) dt1 ON
								DIM_TRAILERS_SNKEY_RAW = dt1.DIM_TRAILERS_SNKEY
							LEFT JOIN (select distinct DIM_TRAILERS_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_TRAILERS) dt2 ON
								DIM_TRAILERS_SNKEY_UPPER = dt2.DIM_TRAILERS_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d4 ON
                                src.DIM_CUSTOMER_SNKEY = d4.DIM_CUSTOMER_SNKEY
                                and src.PLANNED_SHIP_DATE >= d4.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.PLANNED_SHIP_DATE < d4.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d5 ON
                                src.DIM_ITEM_SNKEY = d5.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d6 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d6.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d7 ON
                                src.DIM_LOCATION_SNKEY = d7.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d8 ON
                                src.DIM_SALES_ORDER_SNKEY = d8.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d9 ON
                                src.DIM_SHIPPING_CARRIER_SNKEY = d9.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SITE d10 ON
                                src.DIM_SITE_SNKEY = d10.DIM_SITE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TRAILERS d11 ON
                                src.DIM_TRAILERS_SNKEY = d11.DIM_TRAILERS_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_TRANSPORTATION_LOAD_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_TRANSPORTATION_LOAD

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_TRANSPORTATION_LOAD_KEY = tgt.FACT_TRANSPORTATION_LOAD_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_TRANSPORTATION_LOAD_KEY = tgt.FACT_TRANSPORTATION_LOAD_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.DATA_AREA_ID = src.DATA_AREA_ID
                                    , tgt.LOAD_ID = src.LOAD_ID
                                    , tgt.SALES_ORDER_ID = src.SALES_ORDER_ID
                                    , tgt.ITEM_ID = src.ITEM_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.PLANNED_SHIP_DATE_DIM_DATE_KEY = src.PLANNED_SHIP_DATE_DIM_DATE_KEY
                                    , tgt.PLANNED_SHIP_DATE_DIM_DATE_SNKEY = src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                                    , tgt.ACTUAL_SHIP_DATE_DIM_DATE_KEY = src.ACTUAL_SHIP_DATE_DIM_DATE_KEY
                                    , tgt.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY = src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CUSTOMER_KEY = src.DIM_CUSTOMER_KEY
                                    , tgt.DIM_CUSTOMER_SNKEY = src.DIM_CUSTOMER_SNKEY
                                    , tgt.DIM_ITEM_KEY = src.DIM_ITEM_KEY
                                    , tgt.DIM_ITEM_SNKEY = src.DIM_ITEM_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_LOCATION_KEY = src.DIM_LOCATION_KEY
                                    , tgt.DIM_LOCATION_SNKEY = src.DIM_LOCATION_SNKEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SALES_ORDER_SNKEY = src.DIM_SALES_ORDER_SNKEY
                                    , tgt.DIM_SHIPPING_CARRIER_KEY = src.DIM_SHIPPING_CARRIER_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_SNKEY = src.DIM_SHIPPING_CARRIER_SNKEY
                                    , tgt.DIM_SITE_KEY = src.DIM_SITE_KEY
                                    , tgt.DIM_SITE_SNKEY = src.DIM_SITE_SNKEY
                                    , tgt.DIM_TRAILERS_KEY = src.DIM_TRAILERS_KEY
                                    , tgt.DIM_TRAILERS_SNKEY = src.DIM_TRAILERS_SNKEY
                                    , tgt.CUSTOMER_ACCOUNT = src.CUSTOMER_ACCOUNT
                                    , tgt.RECORD_ID_LOCATION = src.RECORD_ID_LOCATION
                                    , tgt.INVENT_SITE_ID = src.INVENT_SITE_ID
                                    , tgt.EBC_CARRIER_ID = src.EBC_CARRIER_ID
                                    , tgt.EBC_TRAILER_ID = src.EBC_TRAILER_ID
                                    , tgt.PLANNED_STOP_COUNT = src.PLANNED_STOP_COUNT
                                    , tgt.SCHEDULED_PIECES = src.SCHEDULED_PIECES
                                    , tgt.SCHEDULED_MILEAGE = src.SCHEDULED_MILEAGE
                                    , tgt.ACTUAL_MILES = src.ACTUAL_MILES
                                    , tgt.ACTUAL_STOP_COUNT = src.ACTUAL_STOP_COUNT
                                    , tgt.ACTUAL_PIECES = src.ACTUAL_PIECES
                                    , tgt.TRANSACTION_TYPE = src.TRANSACTION_TYPE
                                    , tgt.TRAILER_CUBIC_VOLUME_CAPACITY = src.TRAILER_CUBIC_VOLUME_CAPACITY
                                    , tgt.ACTUAL_CUBES = src.ACTUAL_CUBES
                                    , tgt.PLANNED_CUBES = src.PLANNED_CUBES
                                    , tgt.PLANNED_SHIP_DATE = src.PLANNED_SHIP_DATE
                                    , tgt.ACTUAL_SHIP_DATE = src.ACTUAL_SHIP_DATE
                                    , tgt.LOAD_STATUS_DESCRIPTION = src.LOAD_STATUS_DESCRIPTION
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                	FACT_TRANSPORTATION_LOAD_KEY
                                	, SOURCE_NAME
                                	, DATA_AREA_ID
                                	, LOAD_ID
                                	, SALES_ORDER_ID
                                	, ITEM_ID
                                	, DIM_SOURCE_SYSTEM_KEY
                                	, DIM_SOURCE_SYSTEM_SNKEY
                                	, PLANNED_SHIP_DATE_DIM_DATE_KEY
                                	, PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                                	, ACTUAL_SHIP_DATE_DIM_DATE_KEY
                                	, ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                                	, DIM_CUSTOMER_KEY
                                	, DIM_CUSTOMER_SNKEY
                                	, DIM_ITEM_KEY
                                	, DIM_ITEM_SNKEY
                                	, DIM_LEGAL_ENTITY_KEY
                                	, DIM_LEGAL_ENTITY_SNKEY
                                	, DIM_LOCATION_KEY
                                	, DIM_LOCATION_SNKEY
                                	, DIM_SALES_ORDER_KEY
                                	, DIM_SALES_ORDER_SNKEY
                                	, DIM_SHIPPING_CARRIER_KEY
                                	, DIM_SHIPPING_CARRIER_SNKEY
                                	, DIM_SITE_KEY
                                	, DIM_SITE_SNKEY
                                	, DIM_TRAILERS_KEY
                                	, DIM_TRAILERS_SNKEY
                                	, CUSTOMER_ACCOUNT
                                	, RECORD_ID_LOCATION
                                	, INVENT_SITE_ID
                                	, EBC_CARRIER_ID
                                	, EBC_TRAILER_ID
                                	, PLANNED_STOP_COUNT
                                	, SCHEDULED_PIECES
                                	, SCHEDULED_MILEAGE
                                	, ACTUAL_MILES
                                	, ACTUAL_STOP_COUNT
                                	, ACTUAL_PIECES
                                	, TRANSACTION_TYPE
                                	, TRAILER_CUBIC_VOLUME_CAPACITY
                                	, ACTUAL_CUBES
                                	, PLANNED_CUBES
                                	, PLANNED_SHIP_DATE
                                	, ACTUAL_SHIP_DATE
                                	, LOAD_STATUS_DESCRIPTION
                                	, HK_HASH_KEY
                                	, HK_SOURCE_NAME
                                	, HK_SOFT_DELETE_FLAG
                                	, HK_SOURCE_CREATED_TIMESTAMP
                                	, HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, HK_CREATED_JOB_RUN_ID
                                	, HK_LAST_UPDATED_JOB_RUN_ID
                                	, HK_CREATED_TIMESTAMP
                                	, HK_LAST_UPDATED_TIMESTAMP
                                	, HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                	src.FACT_TRANSPORTATION_LOAD_KEY
                                	, src.SOURCE_NAME
                                	, src.DATA_AREA_ID
                                	, src.LOAD_ID
                                	, src.SALES_ORDER_ID
                                	, src.ITEM_ID
                                	, src.DIM_SOURCE_SYSTEM_KEY
                                	, src.DIM_SOURCE_SYSTEM_SNKEY
                                	, src.PLANNED_SHIP_DATE_DIM_DATE_KEY
                                	, src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY
                                	, src.ACTUAL_SHIP_DATE_DIM_DATE_KEY
                                	, src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY
                                	, src.DIM_CUSTOMER_KEY
                                	, src.DIM_CUSTOMER_SNKEY
                                	, src.DIM_ITEM_KEY
                                	, src.DIM_ITEM_SNKEY
                                	, src.DIM_LEGAL_ENTITY_KEY
                                	, src.DIM_LEGAL_ENTITY_SNKEY
                                	, src.DIM_LOCATION_KEY
                                	, src.DIM_LOCATION_SNKEY
                                	, src.DIM_SALES_ORDER_KEY
                                	, src.DIM_SALES_ORDER_SNKEY
                                	, src.DIM_SHIPPING_CARRIER_KEY
                                	, src.DIM_SHIPPING_CARRIER_SNKEY
                                	, src.DIM_SITE_KEY
                                	, src.DIM_SITE_SNKEY
                                	, src.DIM_TRAILERS_KEY
                                	, src.DIM_TRAILERS_SNKEY
                                	, src.CUSTOMER_ACCOUNT
                                	, src.RECORD_ID_LOCATION
                                	, src.INVENT_SITE_ID
                                	, src.EBC_CARRIER_ID
                                	, src.EBC_TRAILER_ID
                                	, src.PLANNED_STOP_COUNT
                                	, src.SCHEDULED_PIECES
                                	, src.SCHEDULED_MILEAGE
                                	, src.ACTUAL_MILES
                                	, src.ACTUAL_STOP_COUNT
                                	, src.ACTUAL_PIECES
                                	, src.TRANSACTION_TYPE
                                	, src.TRAILER_CUBIC_VOLUME_CAPACITY
                                	, src.ACTUAL_CUBES
                                	, src.PLANNED_CUBES
                                	, src.PLANNED_SHIP_DATE
                                	, src.ACTUAL_SHIP_DATE
                                	, src.LOAD_STATUS_DESCRIPTION
                                	, src.SRC_HK_HASH_KEY
                                	, src.HK_SOURCE_NAME
                                	, src.HK_SOFT_DELETE_FLAG
                                	, src.HK_SOURCE_CREATED_TIMESTAMP
                                	, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, src.HK_CREATED_JOB_RUN_ID
                                	, src.HK_LAST_UPDATED_JOB_RUN_ID
                                	, src.HK_CREATED_TIMESTAMP
                                	, src.HK_LAST_UPDATED_TIMESTAMP
                                	, src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
              a.FACT_TRANSPORTATION_LOAD_key
            , a.NEW_DIM_SOURCE_SYSTEM_KEY
            , a.NEW_PLANNED_SHIP_DATE_DIM_DATE_KEY
            , a.NEW_ACTUAL_SHIP_DATE_DIM_DATE_KEY
            , a.NEW_DIM_CUSTOMER_KEY
            , a.NEW_DIM_ITEM_KEY
            , a.NEW_DIM_LEGAL_ENTITY_KEY
            , a.NEW_DIM_LOCATION_KEY
            , a.NEW_DIM_SALES_ORDER_KEY
            , a.NEW_DIM_SHIPPING_CARRIER_KEY
            , a.NEW_DIM_SITE_KEY
            , a.NEW_DIM_TRAILERS_KEY
        from (
            select 
                src.FACT_TRANSPORTATION_LOAD_KEY
                , src.DIM_SOURCE_SYSTEM_KEY
                , src.PLANNED_SHIP_DATE_DIM_DATE_KEY
                , src.ACTUAL_SHIP_DATE_DIM_DATE_KEY
                , src.DIM_CUSTOMER_KEY
                , src.DIM_ITEM_KEY
                , src.DIM_LEGAL_ENTITY_KEY
                , src.DIM_LOCATION_KEY
                , src.DIM_SALES_ORDER_KEY
                , src.DIM_SHIPPING_CARRIER_KEY
                , src.DIM_SITE_KEY
                , src.DIM_TRAILERS_KEY
                , nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
                , nvl(d2.DIM_DATE_KEY, -1) AS NEW_PLANNED_SHIP_DATE_DIM_DATE_KEY
                , nvl(d3.DIM_DATE_KEY, -1) AS NEW_ACTUAL_SHIP_DATE_DIM_DATE_KEY
                , nvl(d4.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
                , nvl(d5.DIM_ITEM_KEY, -1) AS NEW_DIM_ITEM_KEY
                , nvl(d6.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
                , nvl(d7.DIM_LOCATION_KEY, -1) AS NEW_DIM_LOCATION_KEY
                , nvl(d8.DIM_SALES_ORDER_KEY, -1) AS NEW_DIM_SALES_ORDER_KEY
                , nvl(d9.DIM_SHIPPING_CARRIER_KEY, -1) AS NEW_DIM_SHIPPING_CARRIER_KEY
                , nvl(d10.DIM_SITE_KEY, -1) AS NEW_DIM_SITE_KEY
                , nvl(d11.DIM_TRAILERS_KEY, -1) AS NEW_DIM_TRAILERS_KEY
            from ' || :tgt_db || '.global.FACT_TRANSPORTATION_LOAD src
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d4 ON
                                src.DIM_CUSTOMER_SNKEY = d4.DIM_CUSTOMER_SNKEY
                                and src.PLANNED_SHIP_DATE >= d4.HK_EFFECTIVE_START_TIMESTAMP 
                                and src.PLANNED_SHIP_DATE < d4.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_ITEM d5 ON
                                src.DIM_ITEM_SNKEY = d5.DIM_ITEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d6 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d6.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LOCATION d7 ON
                                src.DIM_LOCATION_SNKEY = d7.DIM_LOCATION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SALES_ORDER d8 ON
                                src.DIM_SALES_ORDER_SNKEY = d8.DIM_SALES_ORDER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SHIPPING_CARRIER d9 ON
                                src.DIM_SHIPPING_CARRIER_SNKEY = d9.DIM_SHIPPING_CARRIER_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SITE d10 ON
                                src.DIM_SITE_SNKEY = d10.DIM_SITE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TRAILERS d11 ON
                                src.DIM_TRAILERS_SNKEY = d11.DIM_TRAILERS_SNKEY
            where 1=1
            and (
                (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
                or (src.PLANNED_SHIP_DATE_DIM_DATE_KEY = -1 and src.PLANNED_SHIP_DATE_DIM_DATE_SNKEY != -1)
                or (src.ACTUAL_SHIP_DATE_DIM_DATE_KEY = -1 and src.ACTUAL_SHIP_DATE_DIM_DATE_SNKEY != -1)
                or (src.DIM_CUSTOMER_KEY = -1 and src.DIM_CUSTOMER_SNKEY != -1)
                or (src.DIM_ITEM_KEY = -1 and src.DIM_ITEM_SNKEY != -1)
                or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
                or (src.DIM_LOCATION_KEY = -1 and src.DIM_LOCATION_SNKEY != -1)
                or (src.DIM_SALES_ORDER_KEY = -1 and src.DIM_SALES_ORDER_SNKEY != -1)
                or (src.DIM_SHIPPING_CARRIER_KEY = -1 and src.DIM_SHIPPING_CARRIER_SNKEY != -1)
                or (src.DIM_SITE_KEY = -1 and src.DIM_SITE_SNKEY != -1)
                or (src.DIM_TRAILERS_KEY = -1 and src.DIM_TRAILERS_SNKEY != -1)
                )
            ) a
        where 1=1
        and (
        (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
        or (a.PLANNED_SHIP_DATE_DIM_DATE_KEY != a.NEW_PLANNED_SHIP_DATE_DIM_DATE_KEY)
        or (a.ACTUAL_SHIP_DATE_DIM_DATE_KEY != a.NEW_ACTUAL_SHIP_DATE_DIM_DATE_KEY)
        or (a.DIM_CUSTOMER_KEY != a.NEW_DIM_CUSTOMER_KEY)
        or (a.DIM_ITEM_KEY != a.NEW_DIM_ITEM_KEY)
        or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
        or (a.DIM_LOCATION_KEY != a.NEW_DIM_LOCATION_KEY)
        or (a.DIM_SALES_ORDER_KEY != a.NEW_DIM_SALES_ORDER_KEY)
        or (a.DIM_SHIPPING_CARRIER_KEY != a.NEW_DIM_SHIPPING_CARRIER_KEY)
        or (a.DIM_SITE_KEY != a.NEW_DIM_SITE_KEY)
        or (a.DIM_TRAILERS_KEY != a.NEW_DIM_TRAILERS_KEY)
            )
        ;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER / TRAILERS
        v_proc_step := '6.1';

        LET late_dim_select_2 VARCHAR DEFAULT '';

        late_dim_select_2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_TRANSPORTATION_LOAD_KEY
				, a.NEW_DIM_CUSTOMER_KEY
				, a.NEW_DIM_CUSTOMER_SNKEY
				, a.NEW_DIM_TRAILERS_KEY
				, a.NEW_DIM_TRAILERS_SNKEY
			from (select src.FACT_TRANSPORTATION_LOAD_KEY
					, case when nvl(src.DATA_AREA_ID, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', src.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
					, case when nvl(src.DATA_AREA_ID, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', upper(src.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
						else DIM_CUSTOMER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_SNKEY
					, src.DIM_CUSTOMER_KEY
					, nvl(d4.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
					
					, case when nvl(src.DATA_AREA_ID, '''') = '''' or nvl(src.EBC_TRAILER_ID, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', src.EBC_TRAILER_ID) END AS DIM_TRAILERS_SNKEY_RAW
					, case when nvl(src.DATA_AREA_ID, '''') = '''' or nvl(src.EBC_TRAILER_ID, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.DATA_AREA_ID, ''~'', upper(src.EBC_TRAILER_ID)) END AS DIM_TRAILERS_SNKEY_UPPER
					, case when dt1.DIM_TRAILERS_SNKEY is not null then DIM_TRAILERS_SNKEY_RAW
							when dt2.DIM_TRAILERS_SNKEY is not null then DIM_TRAILERS_SNKEY_UPPER
						else DIM_TRAILERS_SNKEY_RAW
						end as NEW_DIM_TRAILERS_SNKEY
					, src.DIM_TRAILERS_KEY
					, nvl(d11.DIM_TRAILERS_KEY, -1) AS NEW_DIM_TRAILERS_KEY
				from ' || :tgt_db || '.global.FACT_TRANSPORTATION_LOAD src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d4 ON
					NEW_DIM_CUSTOMER_SNKEY = d4.DIM_CUSTOMER_SNKEY and
					src.PLANNED_SHIP_DATE >= d4.HK_EFFECTIVE_START_TIMESTAMP and
					src.PLANNED_SHIP_DATE < d4.HK_EFFECTIVE_END_TIMESTAMP
				
				LEFT JOIN (select distinct DIM_TRAILERS_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_TRAILERS) dt1 ON
					DIM_TRAILERS_SNKEY_RAW = dt1.DIM_TRAILERS_SNKEY
				LEFT JOIN (select distinct DIM_TRAILERS_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_TRAILERS) dt2 ON
					DIM_TRAILERS_SNKEY_UPPER = dt2.DIM_TRAILERS_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TRAILERS d11 ON
					NEW_DIM_TRAILERS_SNKEY = d11.DIM_TRAILERS_SNKEY
			where 1=1
			and (src.DIM_CUSTOMER_SNKEY != NEW_DIM_CUSTOMER_SNKEY
				or src.DIM_CUSTOMER_KEY != NEW_DIM_CUSTOMER_KEY
				or src.DIM_TRAILERS_SNKEY != NEW_DIM_TRAILERS_SNKEY
				or src.DIM_TRAILERS_KEY != NEW_DIM_TRAILERS_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_2;


        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_TRANSPORTATION_LOAD_KEY = tgt.FACT_TRANSPORTATION_LOAD_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.PLANNED_SHIP_DATE_DIM_DATE_KEY = src.NEW_PLANNED_SHIP_DATE_DIM_DATE_KEY
                                    , tgt.ACTUAL_SHIP_DATE_DIM_DATE_KEY = src.NEW_ACTUAL_SHIP_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
                                    , tgt.DIM_ITEM_KEY = src.NEW_DIM_ITEM_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LOCATION_KEY = src.NEW_DIM_LOCATION_KEY
                                    , tgt.DIM_SALES_ORDER_KEY = src.NEW_DIM_SALES_ORDER_KEY
                                    , tgt.DIM_SHIPPING_CARRIER_KEY = src.NEW_DIM_SHIPPING_CARRIER_KEY
                                    , tgt.DIM_SITE_KEY = src.NEW_DIM_SITE_KEY
                                    , tgt.DIM_TRAILERS_KEY = src.NEW_DIM_TRAILERS_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER / TRAILERS
        v_proc_step := '7.1';
		
		LET update_statement_2 STRING DEFAULT '';

		update_statement_2 := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_TRANSPORTATION_LOAD_KEY = tgt.FACT_TRANSPORTATION_LOAD_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_SNKEY = src.NEW_DIM_CUSTOMER_SNKEY
									, tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
									, tgt.DIM_TRAILERS_SNKEY = src.NEW_DIM_TRAILERS_SNKEY
									, tgt.DIM_TRAILERS_KEY = src.NEW_DIM_TRAILERS_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_2);

		LET c5 CURSOR FOR res;

        LET key_fix_count_2 INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_2 := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count 2', :key_fix_count_2);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;