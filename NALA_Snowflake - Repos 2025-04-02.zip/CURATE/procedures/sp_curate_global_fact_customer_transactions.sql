
/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_CUSTOMER_TRANSACTIONS
    CREATED BY     : Joshua Mills
    CREATED ON     : 02/01/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_CUSTOMER_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_CUSTOMER_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_CUSTOMER_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'CUSTTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_CUSTOMER_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;



    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_CUSTOMER_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                            0 AS FACT_CUSTOMER_TRANSACTIONS_KEY
                            , src.HK_SOURCE_NAME AS SOURCE_NAME
                            , src.RECID AS RECORD_ID
                            , 0 AS DIM_SOURCE_SYSTEM_KEY
                            , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                            , 0 AS CLOSED_DATE_DIM_DATE_KEY
                            , 0 AS CLOSED_DATE_DIM_DATE_SNKEY
                            , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                            , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                            , 0 AS DUE_DATE_DIM_DATE_KEY
                            , 0 AS DUE_DATE_DIM_DATE_SNKEY
                            , 0 AS LAST_SETTLE_DATE_DIM_DATE_KEY
                            , 0 AS LAST_SETTLE_DATE_DIM_DATE_SNKEY
                            , 0 AS TRANSACTION_DATE_DIM_DATE_KEY
                            , 0 AS TRANSACTION_DATE_DIM_DATE_SNKEY
                            , 0 AS DIM_CASH_DISCOUNT_KEY
                            , 0 AS DIM_CASH_DISCOUNT_SNKEY
                            , 0 AS DIM_CURRENCY_KEY
                            , 0 AS DIM_CURRENCY_SNKEY
                            , 0 AS DIM_CUSTOMER_INVOICE_KEY
                            , 0 AS DIM_CUSTOMER_INVOICE_SNKEY
                            , 0 AS DIM_CUSTOMER_ORDER_KEY
                            , 0 AS DIM_CUSTOMER_ORDER_SNKEY
                            , 0 AS DIM_CUSTOMER_POSTING_PROFILE_KEY
                            , 0 AS DIM_CUSTOMER_POSTING_PROFILE_SNKEY
                            , 0 AS DIM_DEFAULT_DIMENSION_KEY
                            , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                            , 0 AS DIM_DELIVERY_MODE_KEY
                            , 0 AS DIM_DELIVERY_MODE_SNKEY
                            , 0 AS DIM_LEGAL_ENTITY_KEY
                            , 0 AS DIM_LEGAL_ENTITY_SNKEY
                            , 0 AS DIM_PAYMENT_MODE_KEY
                            , 0 AS DIM_PAYMENT_MODE_SNKEY
                            , 0 AS DIM_REASON_KEY
                            , 0 AS DIM_REASON_SNKEY
                            , 0 AS DIM_WORKER_APPROVER_KEY
                            , 0 AS DIM_WORKER_APPROVER_SNKEY
                            , 0 AS FACT_CUSTOMER_SETTLEMENTS_KEY
                            , nvl(src.CASHDISCCODE, '''') AS CASH_DISCOUNT_ID
                            , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                            , nvl(src.ACCOUNTNUM, '''') AS CUSTOMER_ACCOUNT_INVOICE
                            , nvl(src.ORDERACCOUNT, '''') AS CUSTOMER_ACCOUNT_ORDER
                            , nvl(src.POSTINGPROFILE, '''') AS POSTING_PROFILE_ID
                            , case when nvl(to_char(src.DEFAULTDIMENSION), '''') in ('''', ''0'') then ''''
								else nvl(to_char(src.DEFAULTDIMENSION), '''')
								end AS DEFAULT_DIMENSION
                            , nvl(src.DELIVERYMODE, '''') AS DELIVERY_MODE_ID
                            , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                            , nvl(src.PAYMMODE, '''') AS PAYMENT_MODE_ID
                            , nvl(src.REASONREFRECID, 0) AS REASON_ID
                            , nvl(src.APPROVER, 0) AS RECORD_ID_APPROVER
                            , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_NETCURRENT, '''') AS PAYMENT_METHOD
                            , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_DXCMBINTEGRATIONTRANSTYPE, '''') AS MANBASE_TRANSACTION_TYPE
                            , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_LEDGERTRANSTYPE, '''') AS TRANSACTION_TYPE
                            , case when nvl(src.APPROVED, 0) = 1 then ''Yes'' else ''No'' END AS IS_APPROVED
                            , case when nvl(src.CANCELLEDPAYMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_CANCELLED
                            , case when nvl(src.PREPAYMENT, 0) = 1 then ''Yes'' else ''No'' END AS IS_PREPAYMENT
                            , case when nvl(src.CORRECT, 0) = 1 then ''Yes'' else ''No'' END AS IS_REVERSAL
                            , nvl(src.INVOICE, '''') AS INVOICE_ID
                            , nvl(src.CUSTINVOICEJOUR_SALESID, '''') AS SALES_ORDER_ID
                            , case when nvl(src.CLOSED, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
									when src.CLOSED < dd1.MIN_DATE_VALUE then ''1951-12-31''
									when src.CLOSED > dd1.MAX_DATE_VALUE then ''9951-12-31''
								else src.CLOSED
								end as CLOSED_DATE
                            , case when nvl(src.DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
									when src.DOCUMENTDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
									when src.DOCUMENTDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
								else src.DOCUMENTDATE
								end as DOCUMENT_DATE
                            , case when nvl(src.DUEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
									when src.DUEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
									when src.DUEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
								else src.DUEDATE
								end as DUE_DATE
                            , case when nvl(src.LASTSETTLEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
									when src.LASTSETTLEDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
									when src.LASTSETTLEDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
								else src.LASTSETTLEDATE
								end as LAST_SETTLE_DATE
                            , case when nvl(src.TRANSDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''
									when src.TRANSDATE < dd1.MIN_DATE_VALUE then ''1951-12-31''
									when src.TRANSDATE > dd1.MAX_DATE_VALUE then ''9951-12-31''
								else src.TRANSDATE
								end as TRANSACTION_DATE
                            , nvl(src.DOCUMENTNUM, '''') AS DOCUMENT_NUMBER
                            , nvl(src.LEDGERJOURNALTRANS_JOURNALNUM, '''') AS JOURNAL_BATCH_NUMBER
                            , nvl(src.LASTSETTLEVOUCHER, '''') AS LAST_SETTLE_VOUCHER
                            , nvl(src.PAYMREFERENCE, '''') AS PAYMENT_REFERENCE
                            , nvl(src.EBCPURCHORDERFORMNUM, '''') AS PURCHASE_ORDER_NUMBER
                            , nvl(src.TXT, '''') AS TRANSACTION_COMMENT
                            , nvl(src.VOUCHER, '''') AS VOUCHER
                            , nvl(src.AMOUNTCUR, 0) AS AMOUNT_TRANSACTION_CURRENCY
                            , nvl(src.AMOUNTMST, 0) AS AMOUNT_COMPANY_CURRENCY
                            , nvl(src.SETTLEAMOUNTCUR, 0) AS SETTLED_AMOUNT_TRANSACTION_CURRENCY
                            , nvl(src.SETTLEAMOUNTMST, 0) AS SETTLED_AMOUNT_COMPANY_CURRENCY
                            , case when (src.INVOICE like ''415I%'' or src.INVOICE like ''I0000%'') then ''Sales Invoice''   when (src.INVOICE like ''415C%'' or src.INVOICE like ''C0000%'') then ''Sales Credit''   when (src.INVOICE like ''TC415%'' or src.INVOICE like ''TC0000%'') then ''Customer Credit''   when src.INVOICE like ''415FC%'' then ''Free Text Credit''   when src.INVOICE like ''415FI%'' then ''Free Text Invoice'' else ''Type Unassigned'' END AS INVOICE_TRANSACTION_TYPE
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src
							left join ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt on
								src.HK_SOURCE_NAME = tgt.SOURCE_NAME and
								src.RECID = tgt.RECORD_ID
							inner join (select min(date_value) as MIN_DATE_VALUE
											, max(date_value) as MAX_DATE_VALUE
										from ' || :tgt_db || '.' || :tgt_schema || '.DIM_DATE 
										where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31'')) dd1 on
								1=1
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';

        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_CUSTOMER_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_CUSTOMER_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_CUSTOMER_TRANSACTIONS_KEY
, src.SOURCE_NAME
, src.RECORD_ID
, case when src.SOURCE_NAME = ''''   then -2   when d1.DIM_SOURCE_SYSTEM_KEY is null then -1 else d1.DIM_SOURCE_SYSTEM_KEY END AS DIM_SOURCE_SYSTEM_KEY
, src.DIM_SOURCE_SYSTEM_SNKEY
, case when src.CLOSED_DATE = ''1950-01-01'' then -2   when d2.DIM_DATE_KEY is null then -1 else d2.DIM_DATE_KEY END AS CLOSED_DATE_DIM_DATE_KEY
, src.CLOSED_DATE_DIM_DATE_SNKEY
, case when src.DOCUMENT_DATE = ''1950-01-01'' then -2   when d3.DIM_DATE_KEY is null then -1 else d3.DIM_DATE_KEY END AS DOCUMENT_DATE_DIM_DATE_KEY
, src.DOCUMENT_DATE_DIM_DATE_SNKEY
, case when src.DUE_DATE = ''1950-01-01'' then -2   when d4.DIM_DATE_KEY is null then -1 else d4.DIM_DATE_KEY END AS DUE_DATE_DIM_DATE_KEY
, src.DUE_DATE_DIM_DATE_SNKEY
, case when src.LAST_SETTLE_DATE = ''1950-01-01'' then -2   when d5.DIM_DATE_KEY is null then -1 else d5.DIM_DATE_KEY END AS LAST_SETTLE_DATE_DIM_DATE_KEY
, src.LAST_SETTLE_DATE_DIM_DATE_SNKEY
, case when src.TRANSACTION_DATE = ''1950-01-01'' then -2   when d6.DIM_DATE_KEY is null then -1 else d6.DIM_DATE_KEY END AS TRANSACTION_DATE_DIM_DATE_KEY
, src.TRANSACTION_DATE_DIM_DATE_SNKEY
, case when src.DIM_CASH_DISCOUNT_SNKEY = -2 then -2 else nvl(d7.DIM_CASH_DISCOUNT_KEY, -1) END AS DIM_CASH_DISCOUNT_KEY
, src.DIM_CASH_DISCOUNT_SNKEY
, case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d8.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
, src.DIM_CURRENCY_SNKEY
, case when src.DIM_CUSTOMER_INVOICE_SNKEY = -2 then -2 else nvl(d9.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_INVOICE_KEY
, src.DIM_CUSTOMER_INVOICE_SNKEY
, case when src.DIM_CUSTOMER_ORDER_SNKEY = -2 then -2 else nvl(d10.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_ORDER_KEY
, src.DIM_CUSTOMER_ORDER_SNKEY
, case when src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY = -2 then -2 else nvl(d11.DIM_CUSTOMER_POSTING_PROFILE_KEY, -1) END AS DIM_CUSTOMER_POSTING_PROFILE_KEY
, src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY
, case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2 else nvl(d12.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
, src.DIM_DEFAULT_DIMENSION_SNKEY
, case when src.DIM_DELIVERY_MODE_SNKEY = -2 then -2 else nvl(d13.DIM_DELIVERY_MODE_KEY, -1) END AS DIM_DELIVERY_MODE_KEY
, src.DIM_DELIVERY_MODE_SNKEY
, case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d14.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
, src.DIM_LEGAL_ENTITY_SNKEY
, case when src.DIM_PAYMENT_MODE_SNKEY = -2 then -2 else nvl(d15.DIM_PAYMENT_MODE_KEY, -1) END AS DIM_PAYMENT_MODE_KEY
, src.DIM_PAYMENT_MODE_SNKEY
, case when src.DIM_REASON_SNKEY = -2 then -2 else nvl(d16.DIM_REASON_KEY, -1) END AS DIM_REASON_KEY
, src.DIM_REASON_SNKEY
, case when src.DIM_WORKER_APPROVER_SNKEY = -2 then -2 else nvl(d17.DIM_WORKER_KEY, -1) END AS DIM_WORKER_APPROVER_KEY
, -1 AS FACT_CUSTOMER_SETTLEMENTS_KEY
, src.DIM_WORKER_APPROVER_SNKEY
, src.CASH_DISCOUNT_ID
, src.CURRENCY_CODE
, src.CUSTOMER_ACCOUNT_INVOICE
, src.CUSTOMER_ACCOUNT_ORDER
, src.POSTING_PROFILE_ID
, src.DEFAULT_DIMENSION
, src.DELIVERY_MODE_ID
, src.LEGAL_ENTITY
, src.PAYMENT_MODE_ID
, src.REASON_ID
, src.RECORD_ID_APPROVER
, src.PAYMENT_METHOD
, src.MANBASE_TRANSACTION_TYPE
, src.TRANSACTION_TYPE
, src.IS_APPROVED
, src.IS_CANCELLED
, src.IS_PREPAYMENT
, src.IS_REVERSAL
, src.INVOICE_ID
, src.SALES_ORDER_ID
, src.CLOSED_DATE
, src.DOCUMENT_DATE
, src.DUE_DATE
, src.LAST_SETTLE_DATE
, src.TRANSACTION_DATE
, src.DOCUMENT_NUMBER
, src.JOURNAL_BATCH_NUMBER
, src.LAST_SETTLE_VOUCHER
, src.PAYMENT_REFERENCE
, src.PURCHASE_ORDER_NUMBER
, src.TRANSACTION_COMMENT
, src.VOUCHER
, src.AMOUNT_TRANSACTION_CURRENCY
, src.AMOUNT_COMPANY_CURRENCY
, src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
, src.SETTLED_AMOUNT_COMPANY_CURRENCY
, src.INVOICE_TRANSACTION_TYPE
,  hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.CASH_DISCOUNT_ID, ''~'', src.CURRENCY_CODE, ''~'', src.CUSTOMER_ACCOUNT_INVOICE, ''~'', src.CUSTOMER_ACCOUNT_ORDER, ''~'', src.POSTING_PROFILE_ID, ''~'', src.DEFAULT_DIMENSION, ''~'', src.DELIVERY_MODE_ID, ''~'', src.LEGAL_ENTITY, ''~'', src.PAYMENT_MODE_ID, ''~'', to_char(src.REASON_ID), ''~'', to_char(src.RECORD_ID_APPROVER), ''~'', src.PAYMENT_METHOD, ''~'', src.MANBASE_TRANSACTION_TYPE, ''~'', src.TRANSACTION_TYPE, ''~'', src.IS_APPROVED, ''~'', src.IS_CANCELLED, ''~'', src.IS_PREPAYMENT, ''~'', src.IS_REVERSAL, ''~'', src.INVOICE_ID, ''~'', src.SALES_ORDER_ID, ''~'', to_char(src.CLOSED_DATE, ''yyyymmdd''), ''~'', to_char(src.DOCUMENT_DATE, ''yyyymmdd''), ''~'', to_char(src.DUE_DATE, ''yyyymmdd''), ''~'', to_char(src.LAST_SETTLE_DATE, ''yyyymmdd''), ''~'', to_char(src.TRANSACTION_DATE, ''yyyymmdd''), ''~'', src.DOCUMENT_NUMBER, ''~'', src.JOURNAL_BATCH_NUMBER, ''~'', src.LAST_SETTLE_VOUCHER, ''~'', src.PAYMENT_REFERENCE, ''~'', src.PURCHASE_ORDER_NUMBER, ''~'', src.TRANSACTION_COMMENT, ''~'', src.VOUCHER, ''~'', to_char(src.AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.AMOUNT_COMPANY_CURRENCY), ''~'', to_char(src.SETTLED_AMOUNT_TRANSACTION_CURRENCY), ''~'', to_char(src.SETTLED_AMOUNT_COMPANY_CURRENCY), ''~'', src.INVOICE_TRANSACTION_TYPE) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
prep01.FACT_CUSTOMER_TRANSACTIONS_KEY
, prep01.SOURCE_NAME
, prep01.RECORD_ID
, prep01.DIM_SOURCE_SYSTEM_KEY
, case when prep01.SOURCE_NAME = '''' then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
, prep01.CLOSED_DATE_DIM_DATE_KEY
, case when prep01.CLOSED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.CLOSED_DATE, ''yyyymmdd'')) END AS CLOSED_DATE_DIM_DATE_SNKEY
, prep01.DOCUMENT_DATE_DIM_DATE_KEY
, case when prep01.DOCUMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
, prep01.DUE_DATE_DIM_DATE_KEY
, case when prep01.DUE_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DUE_DATE, ''yyyymmdd'')) END AS DUE_DATE_DIM_DATE_SNKEY
, prep01.LAST_SETTLE_DATE_DIM_DATE_KEY
, case when prep01.LAST_SETTLE_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.LAST_SETTLE_DATE, ''yyyymmdd'')) END AS LAST_SETTLE_DATE_DIM_DATE_SNKEY
, prep01.TRANSACTION_DATE_DIM_DATE_KEY
, case when prep01.TRANSACTION_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.TRANSACTION_DATE, ''yyyymmdd'')) END AS TRANSACTION_DATE_DIM_DATE_SNKEY
, prep01.DIM_CASH_DISCOUNT_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CASH_DISCOUNT_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CASH_DISCOUNT_ID) end AS DIM_CASH_DISCOUNT_SNKEY
, prep01.DIM_CURRENCY_KEY
, case when nvl(prep01.CURRENCY_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
, prep01.DIM_CUSTOMER_INVOICE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
		when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
	else DIM_CUSTOMER_INVOICE_SNKEY_RAW
	end as DIM_CUSTOMER_INVOICE_SNKEY
, prep01.DIM_CUSTOMER_ORDER_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
		when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
	else DIM_CUSTOMER_ORDER_SNKEY_RAW
	end as DIM_CUSTOMER_ORDER_SNKEY
, prep01.DIM_CUSTOMER_POSTING_PROFILE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.POSTING_PROFILE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.POSTING_PROFILE_ID) end AS DIM_CUSTOMER_POSTING_PROFILE_SNKEY
, prep01.DIM_DEFAULT_DIMENSION_KEY
, case when nvl(prep01.DEFAULT_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
, prep01.DIM_DELIVERY_MODE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.DELIVERY_MODE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.DELIVERY_MODE_ID) END AS DIM_DELIVERY_MODE_SNKEY
, prep01.DIM_LEGAL_ENTITY_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
, prep01.DIM_PAYMENT_MODE_KEY
, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.PAYMENT_MODE_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.PAYMENT_MODE_ID) END AS DIM_PAYMENT_MODE_SNKEY
, prep01.DIM_REASON_KEY
, case when nvl(prep01.REASON_ID, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.REASON_ID)) end AS DIM_REASON_SNKEY
, prep01.DIM_WORKER_APPROVER_KEY
, prep01.FACT_CUSTOMER_SETTLEMENTS_KEY
, case when nvl(prep01.RECORD_ID_APPROVER, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_APPROVER)) END AS DIM_WORKER_APPROVER_SNKEY
, prep01.CASH_DISCOUNT_ID
, prep01.CURRENCY_CODE
, prep01.CUSTOMER_ACCOUNT_INVOICE
, prep01.CUSTOMER_ACCOUNT_ORDER
, prep01.POSTING_PROFILE_ID
, prep01.DEFAULT_DIMENSION
, prep01.DELIVERY_MODE_ID
, prep01.LEGAL_ENTITY
, prep01.PAYMENT_MODE_ID
, prep01.REASON_ID
, prep01.RECORD_ID_APPROVER
, prep01.PAYMENT_METHOD
, prep01.MANBASE_TRANSACTION_TYPE
, prep01.TRANSACTION_TYPE
, prep01.IS_APPROVED
, prep01.IS_CANCELLED
, prep01.IS_PREPAYMENT
, prep01.IS_REVERSAL
, prep01.INVOICE_ID
, prep01.SALES_ORDER_ID
, prep01.CLOSED_DATE
, prep01.DOCUMENT_DATE
, prep01.DUE_DATE
, prep01.LAST_SETTLE_DATE
, prep01.TRANSACTION_DATE
, prep01.DOCUMENT_NUMBER
, prep01.JOURNAL_BATCH_NUMBER
, prep01.LAST_SETTLE_VOUCHER
, prep01.PAYMENT_REFERENCE
, prep01.PURCHASE_ORDER_NUMBER
, prep01.TRANSACTION_COMMENT
, prep01.VOUCHER
, prep01.AMOUNT_TRANSACTION_CURRENCY
, prep01.AMOUNT_COMPANY_CURRENCY
, prep01.SETTLED_AMOUNT_TRANSACTION_CURRENCY
, prep01.SETTLED_AMOUNT_COMPANY_CURRENCY
, prep01.INVOICE_TRANSACTION_TYPE
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
								DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
								DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
    src.CLOSED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
    src.DOCUMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
    src.DUE_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
    src.LAST_SETTLE_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
    src.TRANSACTION_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
 LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CASH_DISCOUNT d7 ON
     src.DIM_CASH_DISCOUNT_SNKEY = d7.DIM_CASH_DISCOUNT_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d8 ON
    src.DIM_CURRENCY_SNKEY = d8.DIM_CURRENCY_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d9 ON
    src.DIM_CUSTOMER_INVOICE_SNKEY = d9.DIM_CUSTOMER_SNKEY
    AND src.TRANSACTION_DATE >= d9.HK_EFFECTIVE_START_TIMESTAMP
    AND src.TRANSACTION_DATE < d9.HK_EFFECTIVE_END_TIMESTAMP
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d10 ON
    src.DIM_CUSTOMER_ORDER_SNKEY = d10.DIM_CUSTOMER_SNKEY
    AND src.TRANSACTION_DATE >= d10.HK_EFFECTIVE_START_TIMESTAMP
    AND src.TRANSACTION_DATE < d10.HK_EFFECTIVE_END_TIMESTAMP
 LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_POSTING_PROFILE d11 ON
     src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY = d11.DIM_CUSTOMER_POSTING_PROFILE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d12 ON
    src.DIM_DEFAULT_DIMENSION_SNKEY = d12.DIM_DEFAULT_DIMENSION_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d13 ON
    src.DIM_DELIVERY_MODE_SNKEY = d13.DIM_DELIVERY_MODE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d14 ON
    src.DIM_LEGAL_ENTITY_SNKEY = d14.DIM_LEGAL_ENTITY_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_PAYMENT_MODE d15 ON
    src.DIM_PAYMENT_MODE_SNKEY = d15.DIM_PAYMENT_MODE_SNKEY
 LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REASON d16 ON
     src.DIM_REASON_SNKEY = d16.DIM_REASON_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
    src.DIM_WORKER_APPROVER_SNKEY = d17.DIM_WORKER_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_CUSTOMER_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_CUSTOMER_TRANSACTIONS

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_CUSTOMER_TRANSACTIONS_KEY = tgt.FACT_CUSTOMER_TRANSACTIONS_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_CUSTOMER_TRANSACTIONS_KEY = tgt.FACT_CUSTOMER_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.CLOSED_DATE_DIM_DATE_KEY = src.CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.CLOSED_DATE_DIM_DATE_SNKEY = src.CLOSED_DATE_DIM_DATE_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.DUE_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_SNKEY = src.DUE_DATE_DIM_DATE_SNKEY
                                    , tgt.LAST_SETTLE_DATE_DIM_DATE_KEY = src.LAST_SETTLE_DATE_DIM_DATE_KEY
                                    , tgt.LAST_SETTLE_DATE_DIM_DATE_SNKEY = src.LAST_SETTLE_DATE_DIM_DATE_SNKEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_SNKEY = src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CASH_DISCOUNT_KEY = src.DIM_CASH_DISCOUNT_KEY
                                    , tgt.DIM_CASH_DISCOUNT_SNKEY = src.DIM_CASH_DISCOUNT_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.DIM_CUSTOMER_INVOICE_SNKEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_SNKEY = src.DIM_CUSTOMER_ORDER_SNKEY
                                    , tgt.DIM_CUSTOMER_POSTING_PROFILE_KEY = src.DIM_CUSTOMER_POSTING_PROFILE_KEY
                                    , tgt.DIM_CUSTOMER_POSTING_PROFILE_SNKEY = src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_DELIVERY_MODE_SNKEY = src.DIM_DELIVERY_MODE_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_PAYMENT_MODE_KEY = src.DIM_PAYMENT_MODE_KEY
                                    , tgt.DIM_PAYMENT_MODE_SNKEY = src.DIM_PAYMENT_MODE_SNKEY
                                    , tgt.DIM_REASON_KEY = src.DIM_REASON_KEY
                                    , tgt.DIM_REASON_SNKEY = src.DIM_REASON_SNKEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.DIM_WORKER_APPROVER_KEY
                                    , tgt.DIM_WORKER_APPROVER_SNKEY = src.DIM_WORKER_APPROVER_SNKEY
                                    , tgt.FACT_CUSTOMER_SETTLEMENTS_KEY = src.FACT_CUSTOMER_SETTLEMENTS_KEY
                                    , tgt.CASH_DISCOUNT_ID = src.CASH_DISCOUNT_ID
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.CUSTOMER_ACCOUNT_INVOICE = src.CUSTOMER_ACCOUNT_INVOICE
                                    , tgt.CUSTOMER_ACCOUNT_ORDER = src.CUSTOMER_ACCOUNT_ORDER
                                    , tgt.POSTING_PROFILE_ID = src.POSTING_PROFILE_ID
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.DELIVERY_MODE_ID = src.DELIVERY_MODE_ID
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.PAYMENT_MODE_ID = src.PAYMENT_MODE_ID
                                    , tgt.REASON_ID = src.REASON_ID
                                    , tgt.RECORD_ID_APPROVER = src.RECORD_ID_APPROVER
                                    , tgt.PAYMENT_METHOD = src.PAYMENT_METHOD
                                    , tgt.MANBASE_TRANSACTION_TYPE = src.MANBASE_TRANSACTION_TYPE
                                    , tgt.TRANSACTION_TYPE = src.TRANSACTION_TYPE
                                    , tgt.IS_APPROVED = src.IS_APPROVED
                                    , tgt.IS_CANCELLED = src.IS_CANCELLED
                                    , tgt.IS_PREPAYMENT = src.IS_PREPAYMENT
                                    , tgt.IS_REVERSAL = src.IS_REVERSAL
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.SALES_ORDER_ID = src.SALES_ORDER_ID
                                    , tgt.CLOSED_DATE = src.CLOSED_DATE
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.DUE_DATE = src.DUE_DATE
                                    , tgt.LAST_SETTLE_DATE = src.LAST_SETTLE_DATE
                                    , tgt.TRANSACTION_DATE = src.TRANSACTION_DATE
                                    , tgt.DOCUMENT_NUMBER = src.DOCUMENT_NUMBER
                                    , tgt.JOURNAL_BATCH_NUMBER = src.JOURNAL_BATCH_NUMBER
                                    , tgt.LAST_SETTLE_VOUCHER = src.LAST_SETTLE_VOUCHER
                                    , tgt.PAYMENT_REFERENCE = src.PAYMENT_REFERENCE
                                    , tgt.PURCHASE_ORDER_NUMBER = src.PURCHASE_ORDER_NUMBER
                                    , tgt.TRANSACTION_COMMENT = src.TRANSACTION_COMMENT
                                    , tgt.VOUCHER = src.VOUCHER
                                    , tgt.AMOUNT_TRANSACTION_CURRENCY = src.AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.AMOUNT_COMPANY_CURRENCY = src.AMOUNT_COMPANY_CURRENCY
                                    , tgt.SETTLED_AMOUNT_TRANSACTION_CURRENCY = src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
                                    , tgt.SETTLED_AMOUNT_COMPANY_CURRENCY = src.SETTLED_AMOUNT_COMPANY_CURRENCY
                                    , tgt.INVOICE_TRANSACTION_TYPE = src.INVOICE_TRANSACTION_TYPE
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
(
FACT_CUSTOMER_TRANSACTIONS_KEY
, SOURCE_NAME
, RECORD_ID
, DIM_SOURCE_SYSTEM_KEY
, DIM_SOURCE_SYSTEM_SNKEY
, CLOSED_DATE_DIM_DATE_KEY
, CLOSED_DATE_DIM_DATE_SNKEY
, DOCUMENT_DATE_DIM_DATE_KEY
, DOCUMENT_DATE_DIM_DATE_SNKEY
, DUE_DATE_DIM_DATE_KEY
, DUE_DATE_DIM_DATE_SNKEY
, LAST_SETTLE_DATE_DIM_DATE_KEY
, LAST_SETTLE_DATE_DIM_DATE_SNKEY
, TRANSACTION_DATE_DIM_DATE_KEY
, TRANSACTION_DATE_DIM_DATE_SNKEY
, DIM_CASH_DISCOUNT_KEY
, DIM_CASH_DISCOUNT_SNKEY
, DIM_CURRENCY_KEY
, DIM_CURRENCY_SNKEY
, DIM_CUSTOMER_INVOICE_KEY
, DIM_CUSTOMER_INVOICE_SNKEY
, DIM_CUSTOMER_ORDER_KEY
, DIM_CUSTOMER_ORDER_SNKEY
, DIM_CUSTOMER_POSTING_PROFILE_KEY
, DIM_CUSTOMER_POSTING_PROFILE_SNKEY
, DIM_DEFAULT_DIMENSION_KEY
, DIM_DEFAULT_DIMENSION_SNKEY
, DIM_DELIVERY_MODE_KEY
, DIM_DELIVERY_MODE_SNKEY
, DIM_LEGAL_ENTITY_KEY
, DIM_LEGAL_ENTITY_SNKEY
, DIM_PAYMENT_MODE_KEY
, DIM_PAYMENT_MODE_SNKEY
, DIM_REASON_KEY
, DIM_REASON_SNKEY
, DIM_WORKER_APPROVER_KEY
, DIM_WORKER_APPROVER_SNKEY
, FACT_CUSTOMER_SETTLEMENTS_KEY
, CASH_DISCOUNT_ID
, CURRENCY_CODE
, CUSTOMER_ACCOUNT_INVOICE
, CUSTOMER_ACCOUNT_ORDER
, POSTING_PROFILE_ID
, DEFAULT_DIMENSION
, DELIVERY_MODE_ID
, LEGAL_ENTITY
, PAYMENT_MODE_ID
, REASON_ID
, RECORD_ID_APPROVER
, PAYMENT_METHOD
, MANBASE_TRANSACTION_TYPE
, TRANSACTION_TYPE
, IS_APPROVED
, IS_CANCELLED
, IS_PREPAYMENT
, IS_REVERSAL
, INVOICE_ID
, SALES_ORDER_ID
, CLOSED_DATE
, DOCUMENT_DATE
, DUE_DATE
, LAST_SETTLE_DATE
, TRANSACTION_DATE
, DOCUMENT_NUMBER
, JOURNAL_BATCH_NUMBER
, LAST_SETTLE_VOUCHER
, PAYMENT_REFERENCE
, PURCHASE_ORDER_NUMBER
, TRANSACTION_COMMENT
, VOUCHER
, AMOUNT_TRANSACTION_CURRENCY
, AMOUNT_COMPANY_CURRENCY
, SETTLED_AMOUNT_TRANSACTION_CURRENCY
, SETTLED_AMOUNT_COMPANY_CURRENCY
, INVOICE_TRANSACTION_TYPE
, HK_HASH_KEY
, HK_SOURCE_NAME
, HK_SOFT_DELETE_FLAG
, HK_SOURCE_CREATED_TIMESTAMP
, HK_SOURCE_LAST_UPDATED_TIMESTAMP
, HK_CREATED_JOB_RUN_ID
, HK_LAST_UPDATED_JOB_RUN_ID
, HK_CREATED_TIMESTAMP
, HK_LAST_UPDATED_TIMESTAMP
, HK_WAREHOUSE_ID
)
 VALUES
(
 src.FACT_CUSTOMER_TRANSACTIONS_KEY
, src.SOURCE_NAME
, src.RECORD_ID
, src.DIM_SOURCE_SYSTEM_KEY
, src.DIM_SOURCE_SYSTEM_SNKEY
, src.CLOSED_DATE_DIM_DATE_KEY
, src.CLOSED_DATE_DIM_DATE_SNKEY
, src.DOCUMENT_DATE_DIM_DATE_KEY
, src.DOCUMENT_DATE_DIM_DATE_SNKEY
, src.DUE_DATE_DIM_DATE_KEY
, src.DUE_DATE_DIM_DATE_SNKEY
, src.LAST_SETTLE_DATE_DIM_DATE_KEY
, src.LAST_SETTLE_DATE_DIM_DATE_SNKEY
, src.TRANSACTION_DATE_DIM_DATE_KEY
, src.TRANSACTION_DATE_DIM_DATE_SNKEY
, src.DIM_CASH_DISCOUNT_KEY
, src.DIM_CASH_DISCOUNT_SNKEY
, src.DIM_CURRENCY_KEY
, src.DIM_CURRENCY_SNKEY
, src.DIM_CUSTOMER_INVOICE_KEY
, src.DIM_CUSTOMER_INVOICE_SNKEY
, src.DIM_CUSTOMER_ORDER_KEY
, src.DIM_CUSTOMER_ORDER_SNKEY
, src.DIM_CUSTOMER_POSTING_PROFILE_KEY
, src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY
, src.DIM_DEFAULT_DIMENSION_KEY
, src.DIM_DEFAULT_DIMENSION_SNKEY
, src.DIM_DELIVERY_MODE_KEY
, src.DIM_DELIVERY_MODE_SNKEY
, src.DIM_LEGAL_ENTITY_KEY
, src.DIM_LEGAL_ENTITY_SNKEY
, src.DIM_PAYMENT_MODE_KEY
, src.DIM_PAYMENT_MODE_SNKEY
, src.DIM_REASON_KEY
, src.DIM_REASON_SNKEY
, src.DIM_WORKER_APPROVER_KEY
, src.DIM_WORKER_APPROVER_SNKEY
, src.FACT_CUSTOMER_SETTLEMENTS_KEY
, src.CASH_DISCOUNT_ID
, src.CURRENCY_CODE
, src.CUSTOMER_ACCOUNT_INVOICE
, src.CUSTOMER_ACCOUNT_ORDER
, src.POSTING_PROFILE_ID
, src.DEFAULT_DIMENSION
, src.DELIVERY_MODE_ID
, src.LEGAL_ENTITY
, src.PAYMENT_MODE_ID
, src.REASON_ID
, src.RECORD_ID_APPROVER
, src.PAYMENT_METHOD
, src.MANBASE_TRANSACTION_TYPE
, src.TRANSACTION_TYPE
, src.IS_APPROVED
, src.IS_CANCELLED
, src.IS_PREPAYMENT
, src.IS_REVERSAL
, src.INVOICE_ID
, src.SALES_ORDER_ID
, src.CLOSED_DATE
, src.DOCUMENT_DATE
, src.DUE_DATE
, src.LAST_SETTLE_DATE
, src.TRANSACTION_DATE
, src.DOCUMENT_NUMBER
, src.JOURNAL_BATCH_NUMBER
, src.LAST_SETTLE_VOUCHER
, src.PAYMENT_REFERENCE
, src.PURCHASE_ORDER_NUMBER
, src.TRANSACTION_COMMENT
, src.VOUCHER
, src.AMOUNT_TRANSACTION_CURRENCY
, src.AMOUNT_COMPANY_CURRENCY
, src.SETTLED_AMOUNT_TRANSACTION_CURRENCY
, src.SETTLED_AMOUNT_COMPANY_CURRENCY
, src.INVOICE_TRANSACTION_TYPE
, src.SRC_HK_HASH_KEY
, src.HK_SOURCE_NAME
, src.HK_SOFT_DELETE_FLAG
, src.HK_SOURCE_CREATED_TIMESTAMP
, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
, src.HK_CREATED_JOB_RUN_ID
, src.HK_LAST_UPDATED_JOB_RUN_ID
, src.HK_CREATED_TIMESTAMP
, src.HK_LAST_UPDATED_TIMESTAMP
, src.HK_WAREHOUSE_ID
);';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_CUSTOMER_TRANSACTIONS_key
      , a.NEW_DIM_SOURCE_SYSTEM_KEY
, a.NEW_CLOSED_DATE_DIM_DATE_KEY
, a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
, a.NEW_DUE_DATE_DIM_DATE_KEY
, a.NEW_LAST_SETTLE_DATE_DIM_DATE_KEY
, a.NEW_TRANSACTION_DATE_DIM_DATE_KEY
, a.NEW_DIM_CASH_DISCOUNT_KEY
, a.NEW_DIM_CURRENCY_KEY
, a.NEW_DIM_CUSTOMER_INVOICE_KEY
, a.NEW_DIM_CUSTOMER_ORDER_KEY
, a.NEW_DIM_CUSTOMER_POSTING_PROFILE_KEY
, a.NEW_DIM_DEFAULT_DIMENSION_KEY
, a.NEW_DIM_DELIVERY_MODE_KEY
, a.NEW_DIM_LEGAL_ENTITY_KEY
, a.NEW_DIM_PAYMENT_MODE_KEY
, a.NEW_DIM_REASON_KEY
, a.NEW_DIM_WORKER_APPROVER_KEY
from (
select src.FACT_CUSTOMER_TRANSACTIONS_key
, src.DIM_SOURCE_SYSTEM_KEY
, src.CLOSED_DATE_DIM_DATE_KEY
, src.DOCUMENT_DATE_DIM_DATE_KEY
, src.DUE_DATE_DIM_DATE_KEY
, src.LAST_SETTLE_DATE_DIM_DATE_KEY
, src.TRANSACTION_DATE_DIM_DATE_KEY
, src.DIM_CASH_DISCOUNT_KEY
, src.DIM_CURRENCY_KEY
, src.DIM_CUSTOMER_INVOICE_KEY
, src.DIM_CUSTOMER_ORDER_KEY
, src.DIM_CUSTOMER_POSTING_PROFILE_KEY
, src.DIM_DEFAULT_DIMENSION_KEY
, src.DIM_DELIVERY_MODE_KEY
, src.DIM_LEGAL_ENTITY_KEY
, src.DIM_PAYMENT_MODE_KEY
, src.DIM_REASON_KEY
, src.DIM_WORKER_APPROVER_KEY
, nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
, nvl(d2.DIM_DATE_KEY, -1) AS NEW_CLOSED_DATE_DIM_DATE_KEY
, nvl(d3.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
, nvl(d4.DIM_DATE_KEY, -1) AS NEW_DUE_DATE_DIM_DATE_KEY
, nvl(d5.DIM_DATE_KEY, -1) AS NEW_LAST_SETTLE_DATE_DIM_DATE_KEY
, nvl(d6.DIM_DATE_KEY, -1) AS NEW_TRANSACTION_DATE_DIM_DATE_KEY
, nvl(d7.DIM_CASH_DISCOUNT_KEY, -1) AS NEW_DIM_CASH_DISCOUNT_KEY
, nvl(d8.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
, nvl(d9.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
, nvl(d10.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
, nvl(d11.DIM_CUSTOMER_POSTING_PROFILE_KEY, -1) AS NEW_DIM_CUSTOMER_POSTING_PROFILE_KEY
, nvl(d12.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
, nvl(d13.DIM_DELIVERY_MODE_KEY, -1) AS NEW_DIM_DELIVERY_MODE_KEY
, nvl(d14.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
, nvl(d15.DIM_PAYMENT_MODE_KEY, -1) AS NEW_DIM_PAYMENT_MODE_KEY
, nvl(d16.DIM_REASON_KEY, -1) AS NEW_DIM_REASON_KEY
, nvl(d17.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_APPROVER_KEY
    from ' || :tgt_db || '.global.FACT_CUSTOMER_TRANSACTIONS src
    LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
    src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
    src.CLOSED_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
    src.DOCUMENT_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
    src.DUE_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
    src.LAST_SETTLE_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d6 ON
    src.TRANSACTION_DATE_DIM_DATE_SNKEY = d6.DIM_DATE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CASH_DISCOUNT d7 ON
    src.DIM_CASH_DISCOUNT_SNKEY = d7.DIM_CASH_DISCOUNT_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d8 ON
    src.DIM_CURRENCY_SNKEY = d8.DIM_CURRENCY_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d9 ON
    src.DIM_CUSTOMER_INVOICE_SNKEY = d9.DIM_CUSTOMER_SNKEY
    AND src.TRANSACTION_DATE >= d9.HK_EFFECTIVE_START_TIMESTAMP
    AND src.TRANSACTION_DATE < d9.HK_EFFECTIVE_END_TIMESTAMP
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d10 ON
    src.DIM_CUSTOMER_ORDER_SNKEY = d10.DIM_CUSTOMER_SNKEY
    AND src.TRANSACTION_DATE >= d10.HK_EFFECTIVE_START_TIMESTAMP
    AND src.TRANSACTION_DATE < d10.HK_EFFECTIVE_END_TIMESTAMP
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER_POSTING_PROFILE d11 ON
    src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY = d11.DIM_CUSTOMER_POSTING_PROFILE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d12 ON
    src.DIM_DEFAULT_DIMENSION_SNKEY = d12.DIM_DEFAULT_DIMENSION_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DELIVERY_MODE d13 ON
    src.DIM_DELIVERY_MODE_SNKEY = d13.DIM_DELIVERY_MODE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d14 ON
    src.DIM_LEGAL_ENTITY_SNKEY = d14.DIM_LEGAL_ENTITY_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_PAYMENT_MODE d15 ON
    src.DIM_PAYMENT_MODE_SNKEY = d15.DIM_PAYMENT_MODE_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_REASON d16 ON
    src.DIM_REASON_SNKEY = d16.DIM_REASON_SNKEY
LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
    src.DIM_WORKER_APPROVER_SNKEY = d17.DIM_WORKER_SNKEY
    where 1=1
    and (
        (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
or (src.CLOSED_DATE_DIM_DATE_KEY = -1 and src.CLOSED_DATE_DIM_DATE_SNKEY != -1)
or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
or (src.DUE_DATE_DIM_DATE_KEY = -1 and src.DUE_DATE_DIM_DATE_SNKEY != -1)
or (src.LAST_SETTLE_DATE_DIM_DATE_KEY = -1 and src.LAST_SETTLE_DATE_DIM_DATE_SNKEY != -1)
or (src.TRANSACTION_DATE_DIM_DATE_KEY = -1 and src.TRANSACTION_DATE_DIM_DATE_SNKEY != -1)
or (src.DIM_CASH_DISCOUNT_KEY = -1 and src.DIM_CASH_DISCOUNT_SNKEY != -1)
or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
or (src.DIM_CUSTOMER_INVOICE_KEY = -1 and src.DIM_CUSTOMER_INVOICE_SNKEY != -1)
or (src.DIM_CUSTOMER_ORDER_KEY = -1 and src.DIM_CUSTOMER_ORDER_SNKEY != -1)
or (src.DIM_CUSTOMER_POSTING_PROFILE_KEY = -1 and src.DIM_CUSTOMER_POSTING_PROFILE_SNKEY != -1)
or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
or (src.DIM_DELIVERY_MODE_KEY = -1 and src.DIM_DELIVERY_MODE_SNKEY != -1)
or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
or (src.DIM_PAYMENT_MODE_KEY = -1 and src.DIM_PAYMENT_MODE_SNKEY != -1)
or (src.DIM_REASON_KEY = -1 and src.DIM_REASON_SNKEY != -1)
or (src.DIM_WORKER_APPROVER_KEY = -1 and src.DIM_WORKER_APPROVER_SNKEY != -1)
    )
    )a
where 1=1
and (
(a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
or (a.CLOSED_DATE_DIM_DATE_KEY != a.NEW_CLOSED_DATE_DIM_DATE_KEY)
or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
or (a.DUE_DATE_DIM_DATE_KEY != a.NEW_DUE_DATE_DIM_DATE_KEY)
or (a.LAST_SETTLE_DATE_DIM_DATE_KEY != a.NEW_LAST_SETTLE_DATE_DIM_DATE_KEY)
or (a.TRANSACTION_DATE_DIM_DATE_KEY != a.NEW_TRANSACTION_DATE_DIM_DATE_KEY)
or (a.DIM_CASH_DISCOUNT_KEY != a.NEW_DIM_CASH_DISCOUNT_KEY)
or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
or (a.DIM_CUSTOMER_INVOICE_KEY != a.NEW_DIM_CUSTOMER_INVOICE_KEY)
or (a.DIM_CUSTOMER_ORDER_KEY != a.NEW_DIM_CUSTOMER_ORDER_KEY)
or (a.DIM_CUSTOMER_POSTING_PROFILE_KEY != a.NEW_DIM_CUSTOMER_POSTING_PROFILE_KEY)
or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
or (a.DIM_DELIVERY_MODE_KEY != a.NEW_DIM_DELIVERY_MODE_KEY)
or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
or (a.DIM_PAYMENT_MODE_KEY != a.NEW_DIM_PAYMENT_MODE_KEY)
or (a.DIM_REASON_KEY != a.NEW_DIM_REASON_KEY)
or (a.DIM_WORKER_APPROVER_KEY != a.NEW_DIM_WORKER_APPROVER_KEY)
    )
;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_CUSTOMER_TRANSACTIONS_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_KEY
				, a.NEW_DIM_CUSTOMER_ORDER_SNKEY
				, a.NEW_DIM_CUSTOMER_INVOICE_KEY
				, a.NEW_DIM_CUSTOMER_INVOICE_SNKEY
			from (select src.FACT_CUSTOMER_TRANSACTIONS_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_ORDER) END AS DIM_CUSTOMER_ORDER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_ORDER, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_ORDER)) END AS DIM_CUSTOMER_ORDER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_ORDER_SNKEY_UPPER
						else DIM_CUSTOMER_ORDER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_ORDER_SNKEY
					, src.DIM_CUSTOMER_ORDER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_ORDER_KEY
					
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT_INVOICE) END AS DIM_CUSTOMER_INVOICE_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT_INVOICE, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT_INVOICE)) END AS DIM_CUSTOMER_INVOICE_SNKEY_UPPER
					, case when dc3.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_RAW
							when dc4.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_INVOICE_SNKEY_UPPER
						else DIM_CUSTOMER_INVOICE_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_INVOICE_SNKEY
					, src.DIM_CUSTOMER_INVOICE_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_INVOICE_KEY
				from ' || :tgt_db || '.global.FACT_CUSTOMER_TRANSACTIONS src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_ORDER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_ORDER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_ORDER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.TRANSACTION_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.TRANSACTION_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
				
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc3 ON
					DIM_CUSTOMER_INVOICE_SNKEY_RAW = dc3.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc4 ON
					DIM_CUSTOMER_INVOICE_SNKEY_UPPER = dc4.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d17 ON
					NEW_DIM_CUSTOMER_INVOICE_SNKEY = d17.DIM_CUSTOMER_SNKEY and
					src.TRANSACTION_DATE >= d17.HK_EFFECTIVE_START_TIMESTAMP and
					src.TRANSACTION_DATE < d17.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_ORDER_SNKEY != NEW_DIM_CUSTOMER_ORDER_SNKEY
				or src.DIM_CUSTOMER_ORDER_KEY != NEW_DIM_CUSTOMER_ORDER_KEY
				or src.DIM_CUSTOMER_INVOICE_SNKEY != NEW_DIM_CUSTOMER_INVOICE_SNKEY
				or src.DIM_CUSTOMER_INVOICE_KEY != NEW_DIM_CUSTOMER_INVOICE_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;
	

        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_CUSTOMER_TRANSACTIONS_KEY = tgt.FACT_CUSTOMER_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.CLOSED_DATE_DIM_DATE_KEY = src.NEW_CLOSED_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DUE_DATE_DIM_DATE_KEY = src.NEW_DUE_DATE_DIM_DATE_KEY
                                    , tgt.LAST_SETTLE_DATE_DIM_DATE_KEY = src.NEW_LAST_SETTLE_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.NEW_TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CASH_DISCOUNT_KEY = src.NEW_DIM_CASH_DISCOUNT_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
                                    , tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
                                    , tgt.DIM_CUSTOMER_POSTING_PROFILE_KEY = src.NEW_DIM_CUSTOMER_POSTING_PROFILE_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DELIVERY_MODE_KEY = src.NEW_DIM_DELIVERY_MODE_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_PAYMENT_MODE_KEY = src.NEW_DIM_PAYMENT_MODE_KEY
                                    , tgt.DIM_REASON_KEY = src.NEW_DIM_REASON_KEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.NEW_DIM_WORKER_APPROVER_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER (ORDER/INVOICE)
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_CUSTOMER_TRANSACTIONS_KEY = tgt.FACT_CUSTOMER_TRANSACTIONS_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_ORDER_SNKEY = src.NEW_DIM_CUSTOMER_ORDER_SNKEY
									, tgt.DIM_CUSTOMER_ORDER_KEY = src.NEW_DIM_CUSTOMER_ORDER_KEY
									, tgt.DIM_CUSTOMER_INVOICE_SNKEY = src.NEW_DIM_CUSTOMER_INVOICE_SNKEY
									, tgt.DIM_CUSTOMER_INVOICE_KEY = src.NEW_DIM_CUSTOMER_INVOICE_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_customer);

		LET c5 CURSOR FOR res;

        LET key_fix_count_customer INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_customer := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;