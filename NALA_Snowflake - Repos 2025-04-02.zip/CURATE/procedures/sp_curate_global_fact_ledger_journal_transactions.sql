/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_FACT_LEDGER_JOURNAL_TRANSACTIONS
    CREATED BY     : Joshua Mills
    CREATED ON     : 02/01/2024
    PURPOSE        : Stored procedure for loading dimension tables
    INPUT PARAMS   : TASK_KEY, TASK_STEP_NUMBER, TASK_INSTANCE_KEY, JOB_ID, ENVIRONMENT
    OUT PARAMS     : BOOLEAN
    EXEC Statement : call GLOBAL.SP_FACT_LEDGER_JOURNAL_TRANSACTIONS(<TASK_KEY>, <TASK_STEP_NUMBER>, <TASK_INSTANCE_KEY>, <JOB_ID>, <ENVIRONMENT>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE GLOBAL.SP_FACT_LEDGER_JOURNAL_TRANSACTIONS
(
TASK_KEY NUMBER,
TASK_STEP_NUMBER NUMBER,
TASK_INSTANCE_KEY NUMBER,
JOB_ID VARCHAR,
ENVIRONMENT VARCHAR
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS CALLER
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name VARCHAR DEFAULT 'SP_FACT_LEDGER_JOURNAL_TRANSACTIONS';
i_count INTEGER DEFAULT 0;
u_count INTEGER DEFAULT 0;
res RESULTSET;
err_msg STRING;
MIN_DATE DATE DEFAULT '1950-01-01';
MAX_DATE DATE DEFAULT '9000-01-01';
BEGIN
    --set up parameters
    v_proc_step := '1';
    LET src_db STRING := :ENVIRONMENT || '_RAW';
    LET src_schema STRING := 'AX_NALA';
    LET src_tbl STRING := 'LEDGERJOURNALTRANS';
    LET wrk_db STRING := :ENVIRONMENT || '_WORK';
    LET wrk_schema STRING := 'GLOBAL';
    LET tgt_db STRING := :ENVIRONMENT || '_CURATE';
    LET tgt_schema STRING := 'GLOBAL';
    LET tgt_tbl STRING := 'FACT_LEDGER_JOURNAL_TRANSACTIONS';

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    --Logging Stored Procedure Started
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'started');


    --Get current timestamp as well as a formatted current timestamp
    --CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
    --CURR_TIMESTAMP is for inserting/updating timestamps in the target table
    v_proc_step := '3.1';

    res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

    LET CURR_TIMESTAMP STRING DEFAULT '';
    LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
    LET cur1 CURSOR FOR res;
    FOR row_variable IN cur1 DO
        CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
        CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
    END FOR;

    --Get minimum and maximum date values from GLOBAL.DIM_DATE
    v_proc_step := '3.2';

    LET date_query STRING DEFAULT '';
    
    date_query := '(select min(date_value) as MIN_DATE_VALUE
    , max(date_value) as MAX_DATE_VALUE
  from ' || :tgt_db || '.global.DIM_DATE
  where date_value not in (''1950-01-01'', ''1951-12-31'', ''9000-01-01'', ''9951-12-31''))';
  
    res := (EXECUTE IMMEDIATE :date_query);
    
    LET MIN_DATE_VALUE DATE DEFAULT '1950-01-01';
    LET MAX_DATE_VALUE DATE DEFAULT '9000-01-01';
    LET cur10 CURSOR FOR res;
    FOR row_variable IN cur10 DO
        MIN_DATE_VALUE := row_variable."MIN_DATE_VALUE";
        MAX_DATE_VALUE := row_variable."MAX_DATE_VALUE";
    END FOR;


    /*
        1.	Read data from source table and write to first working table
        SOURCE:	RAW external table
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_LEDGER_JOURNAL_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>_001

        a.            should only grab the latest data since the last run
        b.            the WORK table should mimic the "exact" same structure as the TARGET table; with additional "working" columns as needed
        c.             all TARGET table columns in the WORK table should be NOT null; additional "working" columns may contain null values as needed
        d.            all KEY/SNKEY values are set to 0 in this step (will be defined later)
        e.            all TARGET table transformations are performed in this step (except KEY/SNKEY columns)
        f.              Working Columns: TGT_HK_HASH_KEY

    */
    v_proc_step := '4.1';
    LET create_wrk_tbl1 STRING DEFAULT '';
    

    create_wrk_tbl1 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
     || ' as
                            select
                                0 AS FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                                , src.HK_SOURCE_NAME AS SOURCE_NAME
                                , src.RECID AS RECORD_ID
                                , 0 AS DIM_SOURCE_SYSTEM_KEY
                                , 0 AS DIM_SOURCE_SYSTEM_SNKEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_KEY
                                , 0 AS DOCUMENT_DATE_DIM_DATE_SNKEY
                                , 0 AS JOURNAL_CREATED_DATE_DIM_DATE_KEY
                                , 0 AS JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_KEY
                                , 0 AS TRANSACTION_DATE_DIM_DATE_SNKEY
                                , 0 AS REVERSAL_DATE_DIM_DATE_KEY
                                , 0 AS REVERSAL_DATE_DIM_DATE_SNKEY
                                , 0 AS DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                                , 0 AS DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                                , 0 AS DIM_CURRENCY_KEY
                                , 0 AS DIM_CURRENCY_SNKEY
                                , 0 AS DIM_CUSTOMER_KEY
                                , 0 AS DIM_CUSTOMER_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_SNKEY
                                , 0 AS DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                , 0 AS DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                , 0 AS DIM_LEDGER_DIMENSION_KEY
                                , 0 AS DIM_LEDGER_DIMENSION_SNKEY
                                , 0 AS DIM_LEDGER_DIMENSION_OFFSET_KEY
                                , 0 AS DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                , 0 AS DIM_LEGAL_ENTITY_KEY
                                , 0 AS DIM_LEGAL_ENTITY_SNKEY
                                , 0 AS DIM_MAIN_ACCOUNT_KEY
                                , 0 AS DIM_MAIN_ACCOUNT_SNKEY
                                , 0 AS DIM_TAX_KEY
                                , 0 AS DIM_TAX_SNKEY
                                , 0 AS DIM_TAX_GROUP_KEY
                                , 0 AS DIM_TAX_GROUP_SNKEY
                                , 0 AS DIM_WORKER_APPROVER_KEY
                                , 0 AS DIM_WORKER_APPROVER_SNKEY
                                , nvl(to_char(src.DEFAULTDIMENSION_MAIN_ACCOUNT), '''') AS MAIN_ACCOUNT
                                , nvl(src.CURRENCYCODE, '''') AS CURRENCY_CODE
                                , nvl(src.DEFAULTDIMENSION_I_CUSTOMER, '''') AS CUSTOMER_ACCOUNT
                                , case when nvl(to_char(src.DEFAULTDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.DEFAULTDIMENSION), '''') end AS DEFAULT_DIMENSION
                                , case when nvl(to_char(src.OFFSETDEFAULTDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.OFFSETDEFAULTDIMENSION), '''') end AS DEFAULT_DIMENSION_OFFSET
                                , case when nvl(to_char(src.LEDGERDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.LEDGERDIMENSION), '''') end AS LEDGER_DIMENSION
                                , case when nvl(to_char(src.OFFSETLEDGERDIMENSION), '''') = ''0'' then ''''
                                    else nvl(to_char(src.OFFSETLEDGERDIMENSION), '''') end AS LEDGER_DIMENSION_OFFSET
                                , nvl(src.DIMENSIONATTRIBUTEVALUECOMBINATION_MAINACCOUNT, 0) AS RECORD_ID_MAIN_ACCOUNT
                                , nvl(src.TAXCODE, '''') AS TAX_ID
                                , nvl(src.TAXGROUP, '''') AS TAX_GROUP_ID
                                , nvl(src.APPROVER, 0) AS RECORD_ID_APPROVER
                                , nvl(src.TIMEXTENDERENUMTABLE1_ENUMVALUELABEL_ACCOUNTTYPE, '''') AS ACCOUNT_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE2_ENUMVALUELABEL_DXCMBINTEGRATIONTRANSTYPE, '''') AS MANBASE_TRANSACTION_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE3_ENUMVALUELABEL_OFFSETACCOUNTTYPE, '''') AS OFFSET_ACCOUNT_TYPE
                                , nvl(src.TIMEXTENDERENUMTABLE4_ENUMVALUELABEL_TRANSACTIONTYPE, '''') AS TRANSACTION_TYPE
                                , case when nvl(src.APPROVED, 0) = 1 then ''Yes'' else ''No'' END AS IS_APPROVED
                                , case when nvl(src.LEDGERJOURNALTABLE_POSTED, 0) = 1 then ''Yes'' else ''No'' END AS IS_POSTED
                                , case when nvl(src.REVERSEENTRY, 0) = 1 then ''Yes'' else ''No'' END AS IS_REVERSAL
                                , case when nvl(src.DOCUMENTDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.DOCUMENTDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.DOCUMENTDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.DOCUMENTDATE END AS DOCUMENT_DATE
                                , case when nvl(src.LEDGERJOURNALTABLE_CREATEDDATETIME, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.LEDGERJOURNALTABLE_CREATEDDATETIME < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.LEDGERJOURNALTABLE_CREATEDDATETIME > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.LEDGERJOURNALTABLE_CREATEDDATETIME END AS JOURNAL_CREATED_DATE
                                , case when nvl(src.TRANSDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.TRANSDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.TRANSDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.TRANSDATE END AS TRANSACTION_DATE
                                , case when nvl(src.LEDGERJOURNALTABLE_REVERSEDATE, ''1900-01-01'') in (''1900-01-01'') then ''1950-01-01''   when src.LEDGERJOURNALTABLE_REVERSEDATE < ''' || :MIN_DATE_VALUE || ''' then ''1951-12-31''   when src.LEDGERJOURNALTABLE_REVERSEDATE > ''' || :MAX_DATE_VALUE || ''' then ''9951-12-31'' else src.LEDGERJOURNALTABLE_REVERSEDATE END AS REVERSAL_DATE
                                , nvl(src.DOCUMENTNUM, '''') AS DOCUMENT_NUMBER
                                , nvl(src.INVOICE, '''') AS INVOICE_ID
                                , nvl(src.LEDGERJOURNALTABLE_CREATEDBY, '''') AS JOURNAL_CREATED_BY
                                , nvl(src.LEDGERJOURNALTABLE_NAME, '''') AS JOURNAL_DESCRIPTION
                                , nvl(src.LEDGERJOURNALTABLE_JOURNALNAME, '''') AS JOURNAL_NAME
                                , nvl(src.JOURNALNUM, '''') AS JOURNAL_NUMBER
                                , nvl(src.TXT, '''') AS JOURNAL_TEXT
                                , nvl(src.VOUCHER, '''') AS JOURNAL_VOUCHER
                                , nvl(src.DATAAREAID, '''') AS LEGAL_ENTITY
                                , nvl(src.LINENUM, 0) AS LINE_NUMBER
                                , nvl(src.QTY, 0) AS QUANTITY
                                , nvl(src.AMOUNTCURCREDIT, 0) AS AMOUNT_CREDIT
                                , nvl(src.AMOUNTCURDEBIT, 0) AS AMOUNT_DEBIT
                                , nvl(src.LEDGERJOURNALTABLE_POSTED, 0) AS POSTED
                                , 0 AS HK_HASH_KEY
                                , src.HK_SOURCE_NAME AS HK_SOURCE_NAME
                                , FALSE AS HK_SOFT_DELETE_FLAG
                                , nvl(tgt.HK_SOURCE_CREATED_TIMESTAMP, src.LATEST_MODIFIEDDATETIME) AS HK_SOURCE_CREATED_TIMESTAMP
                                , src.LATEST_MODIFIEDDATETIME AS HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                , nvl(tgt.HK_CREATED_JOB_RUN_ID, src.HK_JOB_RUN_ID) AS HK_CREATED_JOB_RUN_ID
                                , src.HK_JOB_RUN_ID AS HK_LAST_UPDATED_JOB_RUN_ID
                                , nvl(tgt.HK_CREATED_TIMESTAMP, ''' || :CURR_TIMESTAMP || ''') AS HK_CREATED_TIMESTAMP
                                , ''' || :CURR_TIMESTAMP || ''' AS HK_LAST_UPDATED_TIMESTAMP
                                , uuid_string() AS HK_WAREHOUSE_ID
                                , tgt.HK_HASH_KEY AS TGT_HK_HASH_KEY
                            from 
                                ' || :src_db || '.' || :src_schema || '.' || :src_tbl || ' src LEFT JOIN ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                                on src.HK_SOURCE_NAME = tgt.SOURCE_NAME and src.RECID = tgt.RECORD_ID
                            where
                                src.HK_CREATED_TIMESTAMP > ( 
                                    select NVL(dateadd(day, -1, max(TASK_INSTANCE_START_TIMESTAMP::DATE)), ''' || :MIN_DATE || '''::timestamp_tz) as LAST_TASK_RUN_DATE 
                                            from CONTROL.TASK_INSTANCE 
                                            where TASK_KEY  = (select TASK_KEY from CONTROL.TASK_INSTANCE where TASK_INSTANCE_KEY = ' || :TASK_INSTANCE_KEY || ') and TASK_INSTANCE_START_TIMESTAMP IS NOT NULL and TASK_INSTANCE_STATUS=''completed''       
                                     )';
        
        EXECUTE IMMEDIATE :create_wrk_tbl1;
        
        /*
        2.	Read data from first working table and write to second working table
        SOURCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_01_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_LEDGER_JOURNAL_TRANSACTIONS_01_<YYYYMMDDHH24MISSFF3>
        WORK:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_LEDGER_JOURNAL_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>

        a. Create source HK_HASH_KEY; to be used later for determining insert/updates/no changes
        b. Assign DML indicator for merge
        c. Set PK, SNKEY values
        d. Select only rows with PK_ROW_NUMBER = 1
    */
        v_proc_step := '4.2';
        LET create_wrk_tbl2 STRING DEFAULT '';                   
        create_wrk_tbl2 := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP
      || ' as 
                            SELECT
                             hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID)) AS FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                            , src.SOURCE_NAME
                            , src.RECORD_ID
                            , case when src.SOURCE_NAME = '''' then -2 else nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) END AS DIM_SOURCE_SYSTEM_KEY
                            , src.DIM_SOURCE_SYSTEM_SNKEY
                            , case when src.DOCUMENT_DATE = ''1950-01-01'' then -2 else nvl(d2.DIM_DATE_KEY, -1) END AS DOCUMENT_DATE_DIM_DATE_KEY
                            , src.DOCUMENT_DATE_DIM_DATE_SNKEY
                            , case when src.JOURNAL_CREATED_DATE = ''1950-01-01'' then -2 else nvl(d3.DIM_DATE_KEY, -1) END AS JOURNAL_CREATED_DATE_DIM_DATE_KEY
                            , src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                            , case when src.TRANSACTION_DATE = ''1950-01-01'' then -2 else nvl(d4.DIM_DATE_KEY, -1) END AS TRANSACTION_DATE_DIM_DATE_KEY
                            , src.TRANSACTION_DATE_DIM_DATE_SNKEY
                            , case when src.REVERSAL_DATE = ''1950-01-01'' then -2 else nvl(d5.DIM_DATE_KEY, -1) END AS REVERSAL_DATE_DIM_DATE_KEY
                            , src.REVERSAL_DATE_DIM_DATE_SNKEY
                            , case when src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY = -2 then -2 else nvl(d6.DIM_CORPORATE_ALLOCATION_MAPPING_KEY, -1) END AS DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                            , src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                            , case when src.DIM_CURRENCY_SNKEY = -2 then -2 else nvl(d7.DIM_CURRENCY_KEY, -1) END AS DIM_CURRENCY_KEY
                            , src.DIM_CURRENCY_SNKEY
                            , case when src.DIM_CUSTOMER_SNKEY = -2 then -2 else nvl(d8.DIM_CUSTOMER_KEY, -1) END AS DIM_CUSTOMER_KEY
                            , src.DIM_CUSTOMER_SNKEY
                            , case when src.DIM_DEFAULT_DIMENSION_SNKEY = -2 then -2 else nvl(d9.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_KEY
                            , src.DIM_DEFAULT_DIMENSION_SNKEY
                            , case when src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = -2 then -2 else nvl(d10.DIM_DEFAULT_DIMENSION_KEY, -1) END AS DIM_DEFAULT_DIMENSION_OFFSET_KEY
                            , src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                            , case when src.DIM_LEDGER_DIMENSION_SNKEY = -2 then -2 else nvl(d11.DIM_LEDGER_DIMENSION_KEY, -1) END AS DIM_LEDGER_DIMENSION_KEY
                            , src.DIM_LEDGER_DIMENSION_SNKEY
                            , case when src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = -2 then -2 else nvl(d12.DIM_LEDGER_DIMENSION_KEY, -1) END AS DIM_LEDGER_DIMENSION_OFFSET_KEY
                            , src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                            , case when src.DIM_LEGAL_ENTITY_SNKEY = -2 then -2 else nvl(d13.DIM_LEGAL_ENTITY_KEY, -1) END AS DIM_LEGAL_ENTITY_KEY
                            , src.DIM_LEGAL_ENTITY_SNKEY
                            , case when src.DIM_MAIN_ACCOUNT_SNKEY = -2 then -2 else nvl(d14.DIM_MAIN_ACCOUNT_KEY, -1) END AS DIM_MAIN_ACCOUNT_KEY
                            , src.DIM_MAIN_ACCOUNT_SNKEY
                            , case when src.DIM_TAX_SNKEY = -2 then -2 else nvl(d15.DIM_TAX_KEY, -1) END AS DIM_TAX_KEY
                            , src.DIM_TAX_SNKEY
                            , case when src.DIM_TAX_GROUP_SNKEY = -2 then -2 else nvl(d16.DIM_TAX_GROUP_KEY, -1) END AS DIM_TAX_GROUP_KEY
                            , src.DIM_TAX_GROUP_SNKEY
                            , case when src.DIM_WORKER_APPROVER_SNKEY = -2 then -2 else nvl(d17.DIM_WORKER_KEY, -1) END AS DIM_WORKER_APPROVER_KEY
                            , src.DIM_WORKER_APPROVER_SNKEY
                            , src.MAIN_ACCOUNT
                            , src.CURRENCY_CODE
                            , src.CUSTOMER_ACCOUNT
                            , src.DEFAULT_DIMENSION
                            , src.DEFAULT_DIMENSION_OFFSET
                            , src.LEDGER_DIMENSION
                            , src.LEDGER_DIMENSION_OFFSET
                            , src.RECORD_ID_MAIN_ACCOUNT
                            , src.TAX_ID
                            , src.TAX_GROUP_ID
                            , src.RECORD_ID_APPROVER
                            , src.ACCOUNT_TYPE
                            , src.MANBASE_TRANSACTION_TYPE
                            , src.OFFSET_ACCOUNT_TYPE
                            , src.TRANSACTION_TYPE
                            , src.IS_APPROVED
                            , src.IS_POSTED
                            , src.IS_REVERSAL
                            , src.DOCUMENT_DATE
                            , src.JOURNAL_CREATED_DATE
                            , src.TRANSACTION_DATE
                            , src.REVERSAL_DATE
                            , src.DOCUMENT_NUMBER
                            , src.INVOICE_ID
                            , src.JOURNAL_CREATED_BY
                            , src.JOURNAL_DESCRIPTION
                            , src.JOURNAL_NAME
                            , src.JOURNAL_NUMBER
                            , src.JOURNAL_TEXT
                            , src.JOURNAL_VOUCHER
                            , src.LEGAL_ENTITY
                            , src.LINE_NUMBER
                            , src.QUANTITY
                            , src.AMOUNT_CREDIT
                            , src.AMOUNT_DEBIT
                            , src.POSTED
                            , hash(src.SOURCE_NAME, ''~'', to_char(src.RECORD_ID), ''~'', src.MAIN_ACCOUNT, ''~'', src.CURRENCY_CODE, ''~'', src.CUSTOMER_ACCOUNT, ''~'', to_char(src.DEFAULT_DIMENSION), ''~'', to_char(src.DEFAULT_DIMENSION_OFFSET), ''~'', to_char(src.LEDGER_DIMENSION), ''~'', to_char(src.LEDGER_DIMENSION_OFFSET), ''~'', to_char(src.RECORD_ID_MAIN_ACCOUNT), ''~'', src.TAX_ID, ''~'', src.TAX_GROUP_ID, ''~'', to_char(src.RECORD_ID_APPROVER), ''~'', src.ACCOUNT_TYPE, ''~'', src.MANBASE_TRANSACTION_TYPE, ''~'', src.OFFSET_ACCOUNT_TYPE, ''~'', src.TRANSACTION_TYPE, ''~'', src.IS_APPROVED, ''~'', src.IS_POSTED, ''~'', src.IS_REVERSAL, ''~'', to_char(src.DOCUMENT_DATE, ''yyyymmdd''), ''~'', to_char(src.JOURNAL_CREATED_DATE, ''yyyymmdd''), ''~'', to_char(src.TRANSACTION_DATE, ''yyyymmdd''), ''~'', to_char(src.REVERSAL_DATE, ''yyyymmdd''), ''~'', src.DOCUMENT_NUMBER, ''~'', src.INVOICE_ID, ''~'', src.JOURNAL_CREATED_BY, ''~'', src.JOURNAL_DESCRIPTION, ''~'', src.JOURNAL_NAME, ''~'', src.JOURNAL_NUMBER, ''~'', src.JOURNAL_TEXT, ''~'', src.JOURNAL_VOUCHER, ''~'', src.LEGAL_ENTITY, ''~'', to_char(src.LINE_NUMBER), ''~'', to_char(src.QUANTITY), ''~'', to_char(src.AMOUNT_CREDIT), ''~'', to_char(src.AMOUNT_DEBIT), ''~'', to_char(src.POSTED)) AS SRC_HK_HASH_KEY
                            , src.HK_SOURCE_NAME
                            , src.HK_SOFT_DELETE_FLAG
                            , src.HK_SOURCE_CREATED_TIMESTAMP
                            , src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , src.HK_CREATED_JOB_RUN_ID
                            , src.HK_LAST_UPDATED_JOB_RUN_ID
                            , src.HK_CREATED_TIMESTAMP
                            , src.HK_LAST_UPDATED_TIMESTAMP
                            , src.HK_WAREHOUSE_ID
                            , CASE 
                                WHEN src.TGT_HK_HASH_KEY IS NULL THEN ''I''
                                WHEN src.TGT_HK_HASH_KEY != SRC_HK_HASH_KEY THEN ''U''
                                ELSE ''DROP''
                            END AS DML_IND
                            , row_number() over (partition by src.SOURCE_NAME, src.RECORD_ID order by src.HK_SOURCE_LAST_UPDATED_TIMESTAMP DESC) as PK_ROW_NUMBER
                            FROM (SELECT 
                            prep01.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                            , prep01.SOURCE_NAME
                            , prep01.RECORD_ID
                            , prep01.DIM_SOURCE_SYSTEM_KEY
                            , case when prep01.SOURCE_NAME = ''''  then -2 else hash(prep01.SOURCE_NAME) END AS DIM_SOURCE_SYSTEM_SNKEY
                            , prep01.DOCUMENT_DATE_DIM_DATE_KEY
                            , case when prep01.DOCUMENT_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.DOCUMENT_DATE, ''yyyymmdd'')) END AS DOCUMENT_DATE_DIM_DATE_SNKEY
                            , prep01.JOURNAL_CREATED_DATE_DIM_DATE_KEY
                            , case when prep01.JOURNAL_CREATED_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.JOURNAL_CREATED_DATE, ''yyyymmdd'')) END AS JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                            , prep01.TRANSACTION_DATE_DIM_DATE_KEY
                            , case when prep01.TRANSACTION_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.TRANSACTION_DATE, ''yyyymmdd'')) END AS TRANSACTION_DATE_DIM_DATE_SNKEY
                            , prep01.REVERSAL_DATE_DIM_DATE_KEY
                            , case when prep01.REVERSAL_DATE = ''1950-01-01'' then -2 else hash('''', ''~'', to_char(prep01.REVERSAL_DATE, ''yyyymmdd'')) END AS REVERSAL_DATE_DIM_DATE_SNKEY
                            , prep01.DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.MAIN_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.MAIN_ACCOUNT) END AS DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                            , prep01.DIM_CURRENCY_KEY
                            , case when nvl(prep01.CURRENCY_CODE, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.CURRENCY_CODE) END AS DIM_CURRENCY_SNKEY
                            , prep01.DIM_CUSTOMER_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
							, case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', upper(prep01.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
							, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
									when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
								else DIM_CUSTOMER_SNKEY_RAW
								end as DIM_CUSTOMER_SNKEY
                            , prep01.DIM_DEFAULT_DIMENSION_KEY
                            , case when nvl(prep01.DEFAULT_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION) END AS DIM_DEFAULT_DIMENSION_SNKEY
                            , prep01.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                            , case when nvl(prep01.DEFAULT_DIMENSION_OFFSET, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.DEFAULT_DIMENSION_OFFSET) END AS DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                            , prep01.DIM_LEDGER_DIMENSION_KEY
                            , case when nvl(prep01.LEDGER_DIMENSION, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEDGER_DIMENSION) END AS DIM_LEDGER_DIMENSION_SNKEY
                            , prep01.DIM_LEDGER_DIMENSION_OFFSET_KEY
                            , case when nvl(prep01.LEDGER_DIMENSION_OFFSET, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEDGER_DIMENSION_OFFSET) END AS DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                            , prep01.DIM_LEGAL_ENTITY_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY) END AS DIM_LEGAL_ENTITY_SNKEY
                            , prep01.DIM_MAIN_ACCOUNT_KEY
                            , case when nvl(prep01.RECORD_ID_MAIN_ACCOUNT, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_MAIN_ACCOUNT)) END AS DIM_MAIN_ACCOUNT_SNKEY
                            , prep01.DIM_TAX_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.TAX_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.TAX_ID) END AS DIM_TAX_SNKEY
                            , prep01.DIM_TAX_GROUP_KEY
                            , case when nvl(prep01.LEGAL_ENTITY, '''') = '''' or nvl(prep01.TAX_GROUP_ID, '''') = '''' then -2 else hash(prep01.SOURCE_NAME, ''~'', prep01.LEGAL_ENTITY, ''~'', prep01.TAX_GROUP_ID) END AS DIM_TAX_GROUP_SNKEY
                            , prep01.DIM_WORKER_APPROVER_KEY
                            , case when nvl(prep01.RECORD_ID_APPROVER, 0) = 0 then -2 else hash(prep01.SOURCE_NAME, ''~'', to_char(prep01.RECORD_ID_APPROVER)) END AS DIM_WORKER_APPROVER_SNKEY
                            , prep01.MAIN_ACCOUNT
                            , prep01.CURRENCY_CODE
                            , prep01.CUSTOMER_ACCOUNT
                            , prep01.DEFAULT_DIMENSION
                            , prep01.DEFAULT_DIMENSION_OFFSET
                            , prep01.LEDGER_DIMENSION
                            , prep01.LEDGER_DIMENSION_OFFSET
                            , prep01.RECORD_ID_MAIN_ACCOUNT
                            , prep01.TAX_ID
                            , prep01.TAX_GROUP_ID
                            , prep01.RECORD_ID_APPROVER
                            , prep01.ACCOUNT_TYPE
                            , prep01.MANBASE_TRANSACTION_TYPE
                            , prep01.OFFSET_ACCOUNT_TYPE
                            , prep01.TRANSACTION_TYPE
                            , prep01.IS_APPROVED
                            , prep01.IS_POSTED
                            , prep01.IS_REVERSAL
                            , prep01.DOCUMENT_DATE
                            , prep01.JOURNAL_CREATED_DATE
                            , prep01.TRANSACTION_DATE
                            , prep01.REVERSAL_DATE
                            , prep01.DOCUMENT_NUMBER
                            , prep01.INVOICE_ID
                            , prep01.JOURNAL_CREATED_BY
                            , prep01.JOURNAL_DESCRIPTION
                            , prep01.JOURNAL_NAME
                            , prep01.JOURNAL_NUMBER
                            , prep01.JOURNAL_TEXT
                            , prep01.JOURNAL_VOUCHER
                            , prep01.LEGAL_ENTITY
                            , prep01.LINE_NUMBER
                            , prep01.QUANTITY
                            , prep01.AMOUNT_CREDIT
                            , prep01.AMOUNT_DEBIT
                            , prep01.POSTED
                            , prep01.HK_HASH_KEY
                            , prep01.HK_SOURCE_NAME
                            , prep01.HK_SOFT_DELETE_FLAG
                            , prep01.HK_SOURCE_CREATED_TIMESTAMP
                            , prep01.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_CREATED_JOB_RUN_ID
                            , prep01.HK_LAST_UPDATED_JOB_RUN_ID
                            , prep01.HK_CREATED_TIMESTAMP
                            , prep01.HK_LAST_UPDATED_TIMESTAMP
                            , prep01.HK_WAREHOUSE_ID
                            , prep01.TGT_HK_HASH_KEY
                            FROM ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_01_' || :CURR_FORMATTED_TIMESTAMP
                            || ' prep01
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
								DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
							LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
								DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
							) src 
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.TRANSACTION_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.REVERSAL_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CORPORATE_ALLOCATION_MAPPING d6 ON
                                src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY = d6.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d7 ON
                                src.DIM_CURRENCY_SNKEY = d7.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d8 ON
                                src.DIM_CUSTOMER_SNKEY = d8.DIM_CUSTOMER_SNKEY
                                AND src.DOCUMENT_DATE >= d8.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.DOCUMENT_DATE < d8.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d9 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d9.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d10 ON
                                src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = d10.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d11 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d11.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d12 ON
                                src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = d12.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d13 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d13.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MAIN_ACCOUNT d14 ON
                                src.DIM_MAIN_ACCOUNT_SNKEY = d14.DIM_MAIN_ACCOUNT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX d15 ON
                                src.DIM_TAX_SNKEY = d15.DIM_TAX_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d16 ON
                                src.DIM_TAX_GROUP_SNKEY = d16.DIM_TAX_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
                                src.DIM_WORKER_APPROVER_SNKEY = d17.DIM_WORKER_SNKEY
                            QUALIFY PK_ROW_NUMBER = 1 ';
     
    EXECUTE IMMEDIATE :create_wrk_tbl2;
    

     /*
        4.	Read data from second working table and merge into target table
        SROUCE:	WORK transient table named:		<ENV>_WORK.GLOBAL.WRK_<target_table_name>_<source_schema_name>_PREP_02_<CURRENT_FORMATTED_TIMESTAMP>
                                        ex:		dev_work.global.WRK_FACT_LEDGER_JOURNAL_TRANSACTIONS_PREP_02_<YYYYMMDDHH24MISSFF3>
        TARGET:	TARGET table named:				<ENV>_CURATE.GLOBAL.<target_table_name>_<source_schema_name>
                                        ex:		DEV_CURATE.GLOBAL.FACT_LEDGER_JOURNAL_TRANSACTION

        a.	read all SOURCE table data updating the following based on WORK data:
            i.		DML_IND = 'U'
            ii.		src.FACT_LEDGER_JOURNAL_TRANSACTION_KEY = tgt.FACT_LEDGER_JOURNAL_TRANSACTION_KEY
        b.	read all SOURCE table data inserting the following based on WORK data:
            i.		DML_IND = 'I'
    */
    v_proc_step := '5';

    LET merge_statement STRING DEFAULT '';

    merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_PREP_02_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY = tgt.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY and DML_IND = ''U''
                        when matched then
                            update
                                set
                                    tgt.SOURCE_NAME = src.SOURCE_NAME
                                    , tgt.RECORD_ID = src.RECORD_ID
                                    , tgt.DIM_SOURCE_SYSTEM_KEY = src.DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DIM_SOURCE_SYSTEM_SNKEY = src.DIM_SOURCE_SYSTEM_SNKEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_SNKEY = src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                    , tgt.JOURNAL_CREATED_DATE_DIM_DATE_KEY = src.JOURNAL_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY = src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_SNKEY = src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                    , tgt.REVERSAL_DATE_DIM_DATE_KEY = src.REVERSAL_DATE_DIM_DATE_KEY
                                    , tgt.REVERSAL_DATE_DIM_DATE_SNKEY = src.REVERSAL_DATE_DIM_DATE_SNKEY
                                    , tgt.DIM_CORPORATE_ALLOCATION_MAPPING_KEY = src.DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                                    , tgt.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY = src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                                    , tgt.DIM_CURRENCY_KEY = src.DIM_CURRENCY_KEY
                                    , tgt.DIM_CURRENCY_SNKEY = src.DIM_CURRENCY_SNKEY
                                    , tgt.DIM_CUSTOMER_KEY = src.DIM_CUSTOMER_KEY
                                    , tgt.DIM_CUSTOMER_SNKEY = src.DIM_CUSTOMER_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_SNKEY = src.DIM_DEFAULT_DIMENSION_SNKEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_KEY = src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_SNKEY = src.DIM_LEDGER_DIMENSION_SNKEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_KEY = src.DIM_LEDGER_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_LEGAL_ENTITY_SNKEY = src.DIM_LEGAL_ENTITY_SNKEY
                                    , tgt.DIM_MAIN_ACCOUNT_KEY = src.DIM_MAIN_ACCOUNT_KEY
                                    , tgt.DIM_MAIN_ACCOUNT_SNKEY = src.DIM_MAIN_ACCOUNT_SNKEY
                                    , tgt.DIM_TAX_KEY = src.DIM_TAX_KEY
                                    , tgt.DIM_TAX_SNKEY = src.DIM_TAX_SNKEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.DIM_TAX_GROUP_KEY
                                    , tgt.DIM_TAX_GROUP_SNKEY = src.DIM_TAX_GROUP_SNKEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.DIM_WORKER_APPROVER_KEY
                                    , tgt.DIM_WORKER_APPROVER_SNKEY = src.DIM_WORKER_APPROVER_SNKEY
                                    , tgt.MAIN_ACCOUNT = src.MAIN_ACCOUNT
                                    , tgt.CURRENCY_CODE = src.CURRENCY_CODE
                                    , tgt.CUSTOMER_ACCOUNT = src.CUSTOMER_ACCOUNT
                                    , tgt.DEFAULT_DIMENSION = src.DEFAULT_DIMENSION
                                    , tgt.DEFAULT_DIMENSION_OFFSET = src.DEFAULT_DIMENSION_OFFSET
                                    , tgt.LEDGER_DIMENSION = src.LEDGER_DIMENSION
                                    , tgt.LEDGER_DIMENSION_OFFSET = src.LEDGER_DIMENSION_OFFSET
                                    , tgt.RECORD_ID_MAIN_ACCOUNT = src.RECORD_ID_MAIN_ACCOUNT
                                    , tgt.TAX_ID = src.TAX_ID
                                    , tgt.TAX_GROUP_ID = src.TAX_GROUP_ID
                                    , tgt.RECORD_ID_APPROVER = src.RECORD_ID_APPROVER
                                    , tgt.ACCOUNT_TYPE = src.ACCOUNT_TYPE
                                    , tgt.MANBASE_TRANSACTION_TYPE = src.MANBASE_TRANSACTION_TYPE
                                    , tgt.OFFSET_ACCOUNT_TYPE = src.OFFSET_ACCOUNT_TYPE
                                    , tgt.TRANSACTION_TYPE = src.TRANSACTION_TYPE
                                    , tgt.IS_APPROVED = src.IS_APPROVED
                                    , tgt.IS_POSTED = src.IS_POSTED
                                    , tgt.IS_REVERSAL = src.IS_REVERSAL
                                    , tgt.DOCUMENT_DATE = src.DOCUMENT_DATE
                                    , tgt.JOURNAL_CREATED_DATE = src.JOURNAL_CREATED_DATE
                                    , tgt.TRANSACTION_DATE = src.TRANSACTION_DATE
                                    , tgt.REVERSAL_DATE = src.REVERSAL_DATE
                                    , tgt.DOCUMENT_NUMBER = src.DOCUMENT_NUMBER
                                    , tgt.INVOICE_ID = src.INVOICE_ID
                                    , tgt.JOURNAL_CREATED_BY = src.JOURNAL_CREATED_BY
                                    , tgt.JOURNAL_DESCRIPTION = src.JOURNAL_DESCRIPTION
                                    , tgt.JOURNAL_NAME = src.JOURNAL_NAME
                                    , tgt.JOURNAL_NUMBER = src.JOURNAL_NUMBER
                                    , tgt.JOURNAL_TEXT = src.JOURNAL_TEXT
                                    , tgt.JOURNAL_VOUCHER = src.JOURNAL_VOUCHER
                                    , tgt.LEGAL_ENTITY = src.LEGAL_ENTITY
                                    , tgt.LINE_NUMBER = src.LINE_NUMBER
                                    , tgt.QUANTITY = src.QUANTITY
                                    , tgt.AMOUNT_CREDIT = src.AMOUNT_CREDIT
                                    , tgt.AMOUNT_DEBIT = src.AMOUNT_DEBIT
                                    , tgt.POSTED = src.POSTED
                                    , tgt.HK_HASH_KEY = src.SRC_HK_HASH_KEY
                                    , tgt.HK_SOURCE_LAST_UPDATED_TIMESTAMP = src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                    , tgt.HK_LAST_UPDATED_JOB_RUN_ID = src.HK_LAST_UPDATED_JOB_RUN_ID
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = src.HK_LAST_UPDATED_TIMESTAMP
                        when not matched AND DML_IND = ''I'' then
                                INSERT
                                (
                                	FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                                	, SOURCE_NAME
                                	, RECORD_ID
                                	, DIM_SOURCE_SYSTEM_KEY
                                	, DIM_SOURCE_SYSTEM_SNKEY
                                	, DOCUMENT_DATE_DIM_DATE_KEY
                                	, DOCUMENT_DATE_DIM_DATE_SNKEY
                                	, JOURNAL_CREATED_DATE_DIM_DATE_KEY
                                	, JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                                	, TRANSACTION_DATE_DIM_DATE_KEY
                                	, TRANSACTION_DATE_DIM_DATE_SNKEY
                                	, REVERSAL_DATE_DIM_DATE_KEY
                                	, REVERSAL_DATE_DIM_DATE_SNKEY
                                	, DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                                	, DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                                	, DIM_CURRENCY_KEY
                                	, DIM_CURRENCY_SNKEY
                                	, DIM_CUSTOMER_KEY
                                	, DIM_CUSTOMER_SNKEY
                                	, DIM_DEFAULT_DIMENSION_KEY
                                	, DIM_DEFAULT_DIMENSION_SNKEY
                                	, DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                	, DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                	, DIM_LEDGER_DIMENSION_KEY
                                	, DIM_LEDGER_DIMENSION_SNKEY
                                	, DIM_LEDGER_DIMENSION_OFFSET_KEY
                                	, DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                	, DIM_LEGAL_ENTITY_KEY
                                	, DIM_LEGAL_ENTITY_SNKEY
                                	, DIM_MAIN_ACCOUNT_KEY
                                	, DIM_MAIN_ACCOUNT_SNKEY
                                	, DIM_TAX_KEY
                                	, DIM_TAX_SNKEY
                                	, DIM_TAX_GROUP_KEY
                                	, DIM_TAX_GROUP_SNKEY
                                	, DIM_WORKER_APPROVER_KEY
                                	, DIM_WORKER_APPROVER_SNKEY
                                	, MAIN_ACCOUNT
                                	, CURRENCY_CODE
                                	, CUSTOMER_ACCOUNT
                                	, DEFAULT_DIMENSION
                                	, DEFAULT_DIMENSION_OFFSET
                                	, LEDGER_DIMENSION
                                	, LEDGER_DIMENSION_OFFSET
                                	, RECORD_ID_MAIN_ACCOUNT
                                	, TAX_ID
                                	, TAX_GROUP_ID
                                	, RECORD_ID_APPROVER
                                	, ACCOUNT_TYPE
                                	, MANBASE_TRANSACTION_TYPE
                                	, OFFSET_ACCOUNT_TYPE
                                	, TRANSACTION_TYPE
                                	, IS_APPROVED
                                	, IS_POSTED
                                	, IS_REVERSAL
                                	, DOCUMENT_DATE
                                	, JOURNAL_CREATED_DATE
                                	, TRANSACTION_DATE
                                	, REVERSAL_DATE
                                	, DOCUMENT_NUMBER
                                	, INVOICE_ID
                                	, JOURNAL_CREATED_BY
                                	, JOURNAL_DESCRIPTION
                                	, JOURNAL_NAME
                                	, JOURNAL_NUMBER
                                	, JOURNAL_TEXT
                                	, JOURNAL_VOUCHER
                                	, LEGAL_ENTITY
                                	, LINE_NUMBER
                                	, QUANTITY
                                	, AMOUNT_CREDIT
                                	, AMOUNT_DEBIT
                                	, POSTED
                                	, HK_HASH_KEY
                                	, HK_SOURCE_NAME
                                	, HK_SOFT_DELETE_FLAG
                                	, HK_SOURCE_CREATED_TIMESTAMP
                                	, HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, HK_CREATED_JOB_RUN_ID
                                	, HK_LAST_UPDATED_JOB_RUN_ID
                                	, HK_CREATED_TIMESTAMP
                                	, HK_LAST_UPDATED_TIMESTAMP
                                	, HK_WAREHOUSE_ID
                                )
                                 VALUES
                                (
                                	src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                                	, src.SOURCE_NAME
                                	, src.RECORD_ID
                                	, src.DIM_SOURCE_SYSTEM_KEY
                                	, src.DIM_SOURCE_SYSTEM_SNKEY
                                	, src.DOCUMENT_DATE_DIM_DATE_KEY
                                	, src.DOCUMENT_DATE_DIM_DATE_SNKEY
                                	, src.JOURNAL_CREATED_DATE_DIM_DATE_KEY
                                	, src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY
                                	, src.TRANSACTION_DATE_DIM_DATE_KEY
                                	, src.TRANSACTION_DATE_DIM_DATE_SNKEY
                                	, src.REVERSAL_DATE_DIM_DATE_KEY
                                	, src.REVERSAL_DATE_DIM_DATE_SNKEY
                                	, src.DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                                	, src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                                	, src.DIM_CURRENCY_KEY
                                	, src.DIM_CURRENCY_SNKEY
                                	, src.DIM_CUSTOMER_KEY
                                	, src.DIM_CUSTOMER_SNKEY
                                	, src.DIM_DEFAULT_DIMENSION_KEY
                                	, src.DIM_DEFAULT_DIMENSION_SNKEY
                                	, src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                	, src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY
                                	, src.DIM_LEDGER_DIMENSION_KEY
                                	, src.DIM_LEDGER_DIMENSION_SNKEY
                                	, src.DIM_LEDGER_DIMENSION_OFFSET_KEY
                                	, src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY
                                	, src.DIM_LEGAL_ENTITY_KEY
                                	, src.DIM_LEGAL_ENTITY_SNKEY
                                	, src.DIM_MAIN_ACCOUNT_KEY
                                	, src.DIM_MAIN_ACCOUNT_SNKEY
                                	, src.DIM_TAX_KEY
                                	, src.DIM_TAX_SNKEY
                                	, src.DIM_TAX_GROUP_KEY
                                	, src.DIM_TAX_GROUP_SNKEY
                                	, src.DIM_WORKER_APPROVER_KEY
                                	, src.DIM_WORKER_APPROVER_SNKEY
                                	, src.MAIN_ACCOUNT
                                	, src.CURRENCY_CODE
                                	, src.CUSTOMER_ACCOUNT
                                	, src.DEFAULT_DIMENSION
                                	, src.DEFAULT_DIMENSION_OFFSET
                                	, src.LEDGER_DIMENSION
                                	, src.LEDGER_DIMENSION_OFFSET
                                	, src.RECORD_ID_MAIN_ACCOUNT
                                	, src.TAX_ID
                                	, src.TAX_GROUP_ID
                                	, src.RECORD_ID_APPROVER
                                	, src.ACCOUNT_TYPE
                                	, src.MANBASE_TRANSACTION_TYPE
                                	, src.OFFSET_ACCOUNT_TYPE
                                	, src.TRANSACTION_TYPE
                                	, src.IS_APPROVED
                                	, src.IS_POSTED
                                	, src.IS_REVERSAL
                                	, src.DOCUMENT_DATE
                                	, src.JOURNAL_CREATED_DATE
                                	, src.TRANSACTION_DATE
                                	, src.REVERSAL_DATE
                                	, src.DOCUMENT_NUMBER
                                	, src.INVOICE_ID
                                	, src.JOURNAL_CREATED_BY
                                	, src.JOURNAL_DESCRIPTION
                                	, src.JOURNAL_NAME
                                	, src.JOURNAL_NUMBER
                                	, src.JOURNAL_TEXT
                                	, src.JOURNAL_VOUCHER
                                	, src.LEGAL_ENTITY
                                	, src.LINE_NUMBER
                                	, src.QUANTITY
                                	, src.AMOUNT_CREDIT
                                	, src.AMOUNT_DEBIT
                                	, src.POSTED
                                	, src.SRC_HK_HASH_KEY
                                	, src.HK_SOURCE_NAME
                                	, src.HK_SOFT_DELETE_FLAG
                                	, src.HK_SOURCE_CREATED_TIMESTAMP
                                	, src.HK_SOURCE_LAST_UPDATED_TIMESTAMP
                                	, src.HK_CREATED_JOB_RUN_ID
                                	, src.HK_LAST_UPDATED_JOB_RUN_ID
                                	, src.HK_CREATED_TIMESTAMP
                                	, src.HK_LAST_UPDATED_TIMESTAMP
                                	, src.HK_WAREHOUSE_ID
                                );';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET cur3 CURSOR FOR res;

        FOR row_variable IN cur3 DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
        END FOR;

        
        --store values from late arriving dimensions
        v_proc_step := '6';

        LET late_dim_select VARCHAR DEFAULT '';

        late_dim_select := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select 
      a.FACT_LEDGER_JOURNAL_TRANSACTIONS_key
    , a.NEW_DIM_SOURCE_SYSTEM_KEY
    , a.NEW_DOCUMENT_DATE_DIM_DATE_KEY
    , a.NEW_JOURNAL_CREATED_DATE_DIM_DATE_KEY
    , a.NEW_TRANSACTION_DATE_DIM_DATE_KEY
    , a.NEW_REVERSAL_DATE_DIM_DATE_KEY
    , a.NEW_DIM_CORPORATE_ALLOCATION_MAPPING_KEY
    , a.NEW_DIM_CURRENCY_KEY
    , a.NEW_DIM_CUSTOMER_KEY
    , a.NEW_DIM_DEFAULT_DIMENSION_KEY
    , a.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
    , a.NEW_DIM_LEDGER_DIMENSION_KEY
    , a.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
    , a.NEW_DIM_LEGAL_ENTITY_KEY
    , a.NEW_DIM_MAIN_ACCOUNT_KEY
    , a.NEW_DIM_TAX_KEY
    , a.NEW_DIM_TAX_GROUP_KEY
    , a.NEW_DIM_WORKER_APPROVER_KEY
from (
select 
src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
, src.DIM_SOURCE_SYSTEM_KEY
, src.DOCUMENT_DATE_DIM_DATE_KEY
, src.JOURNAL_CREATED_DATE_DIM_DATE_KEY
, src.TRANSACTION_DATE_DIM_DATE_KEY
, src.REVERSAL_DATE_DIM_DATE_KEY
, src.DIM_CORPORATE_ALLOCATION_MAPPING_KEY
, src.DIM_CURRENCY_KEY
, src.DIM_CUSTOMER_KEY
, src.DIM_DEFAULT_DIMENSION_KEY
, src.DIM_DEFAULT_DIMENSION_OFFSET_KEY
, src.DIM_LEDGER_DIMENSION_KEY
, src.DIM_LEDGER_DIMENSION_OFFSET_KEY
, src.DIM_LEGAL_ENTITY_KEY
, src.DIM_MAIN_ACCOUNT_KEY
, src.DIM_TAX_KEY
, src.DIM_TAX_GROUP_KEY
, src.DIM_WORKER_APPROVER_KEY
, nvl(d1.DIM_SOURCE_SYSTEM_KEY, -1) AS NEW_DIM_SOURCE_SYSTEM_KEY
, nvl(d2.DIM_DATE_KEY, -1) AS NEW_DOCUMENT_DATE_DIM_DATE_KEY
, nvl(d3.DIM_DATE_KEY, -1) AS NEW_JOURNAL_CREATED_DATE_DIM_DATE_KEY
, nvl(d4.DIM_DATE_KEY, -1) AS NEW_TRANSACTION_DATE_DIM_DATE_KEY
, nvl(d5.DIM_DATE_KEY, -1) AS NEW_REVERSAL_DATE_DIM_DATE_KEY
, nvl(d6.DIM_CORPORATE_ALLOCATION_MAPPING_KEY, -1) AS NEW_DIM_CORPORATE_ALLOCATION_MAPPING_KEY
, nvl(d7.DIM_CURRENCY_KEY, -1) AS NEW_DIM_CURRENCY_KEY
, nvl(d8.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
, nvl(d9.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_KEY
, nvl(d10.DIM_DEFAULT_DIMENSION_KEY, -1) AS NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
, nvl(d11.DIM_LEDGER_DIMENSION_KEY, -1) AS NEW_DIM_LEDGER_DIMENSION_KEY
, nvl(d12.DIM_LEDGER_DIMENSION_KEY, -1) AS NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
, nvl(d13.DIM_LEGAL_ENTITY_KEY, -1) AS NEW_DIM_LEGAL_ENTITY_KEY
, nvl(d14.DIM_MAIN_ACCOUNT_KEY, -1) AS NEW_DIM_MAIN_ACCOUNT_KEY
, nvl(d15.DIM_TAX_KEY, -1) AS NEW_DIM_TAX_KEY
, nvl(d16.DIM_TAX_GROUP_KEY, -1) AS NEW_DIM_TAX_GROUP_KEY
, nvl(d17.DIM_WORKER_KEY, -1) AS NEW_DIM_WORKER_APPROVER_KEY
    from ' || :tgt_db || '.global.FACT_LEDGER_JOURNAL_TRANSACTIONS src
    LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_SOURCE_SYSTEM d1 ON
                                src.DIM_SOURCE_SYSTEM_SNKEY = d1.DIM_SOURCE_SYSTEM_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d2 ON
                                src.DOCUMENT_DATE_DIM_DATE_SNKEY = d2.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d3 ON
                                src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY = d3.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d4 ON
                                src.TRANSACTION_DATE_DIM_DATE_SNKEY = d4.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DATE d5 ON
                                src.REVERSAL_DATE_DIM_DATE_SNKEY = d5.DIM_DATE_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CORPORATE_ALLOCATION_MAPPING d6 ON
                                src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY = d6.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CURRENCY d7 ON
                                src.DIM_CURRENCY_SNKEY = d7.DIM_CURRENCY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d8 ON
                                src.DIM_CUSTOMER_SNKEY = d8.DIM_CUSTOMER_SNKEY
                                AND src.DOCUMENT_DATE >= d8.HK_EFFECTIVE_START_TIMESTAMP
                                AND src.DOCUMENT_DATE < d8.HK_EFFECTIVE_END_TIMESTAMP
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d9 ON
                                src.DIM_DEFAULT_DIMENSION_SNKEY = d9.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_DEFAULT_DIMENSION d10 ON
                                src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY = d10.DIM_DEFAULT_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d11 ON
                                src.DIM_LEDGER_DIMENSION_SNKEY = d11.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEDGER_DIMENSION d12 ON
                                src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY = d12.DIM_LEDGER_DIMENSION_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_LEGAL_ENTITY d13 ON
                                src.DIM_LEGAL_ENTITY_SNKEY = d13.DIM_LEGAL_ENTITY_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_MAIN_ACCOUNT d14 ON
                                src.DIM_MAIN_ACCOUNT_SNKEY = d14.DIM_MAIN_ACCOUNT_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX d15 ON
                                src.DIM_TAX_SNKEY = d15.DIM_TAX_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_TAX_GROUP d16 ON
                                src.DIM_TAX_GROUP_SNKEY = d16.DIM_TAX_GROUP_SNKEY
                            LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_WORKER d17 ON
                                src.DIM_WORKER_APPROVER_SNKEY = d17.DIM_WORKER_SNKEY
    where 1=1
    and (
        (src.DIM_SOURCE_SYSTEM_KEY = -1 and src.DIM_SOURCE_SYSTEM_SNKEY != -1)
        or (src.DOCUMENT_DATE_DIM_DATE_KEY = -1 and src.DOCUMENT_DATE_DIM_DATE_SNKEY != -1)
        or (src.JOURNAL_CREATED_DATE_DIM_DATE_KEY = -1 and src.JOURNAL_CREATED_DATE_DIM_DATE_SNKEY != -1)
        or (src.TRANSACTION_DATE_DIM_DATE_KEY = -1 and src.TRANSACTION_DATE_DIM_DATE_SNKEY != -1)
        or (src.REVERSAL_DATE_DIM_DATE_KEY = -1 and src.REVERSAL_DATE_DIM_DATE_SNKEY != -1)
        or (src.DIM_CORPORATE_ALLOCATION_MAPPING_KEY = -1 and src.DIM_CORPORATE_ALLOCATION_MAPPING_SNKEY != -1)
        or (src.DIM_CURRENCY_KEY = -1 and src.DIM_CURRENCY_SNKEY != -1)
        or (src.DIM_CUSTOMER_KEY = -1 and src.DIM_CUSTOMER_SNKEY != -1)
        or (src.DIM_DEFAULT_DIMENSION_KEY = -1 and src.DIM_DEFAULT_DIMENSION_SNKEY != -1)
        or (src.DIM_DEFAULT_DIMENSION_OFFSET_KEY = -1 and src.DIM_DEFAULT_DIMENSION_OFFSET_SNKEY != -1)
        or (src.DIM_LEDGER_DIMENSION_KEY = -1 and src.DIM_LEDGER_DIMENSION_SNKEY != -1)
        or (src.DIM_LEDGER_DIMENSION_OFFSET_KEY = -1 and src.DIM_LEDGER_DIMENSION_OFFSET_SNKEY != -1)
        or (src.DIM_LEGAL_ENTITY_KEY = -1 and src.DIM_LEGAL_ENTITY_SNKEY != -1)
        or (src.DIM_MAIN_ACCOUNT_KEY = -1 and src.DIM_MAIN_ACCOUNT_SNKEY != -1)
        or (src.DIM_TAX_KEY = -1 and src.DIM_TAX_SNKEY != -1)
        or (src.DIM_TAX_GROUP_KEY = -1 and src.DIM_TAX_GROUP_SNKEY != -1)
        or (src.DIM_WORKER_APPROVER_KEY = -1 and src.DIM_WORKER_APPROVER_SNKEY != -1)
        )
    ) a
where 1=1
and (
    (a.DIM_SOURCE_SYSTEM_KEY != a.NEW_DIM_SOURCE_SYSTEM_KEY)
    or (a.DOCUMENT_DATE_DIM_DATE_KEY != a.NEW_DOCUMENT_DATE_DIM_DATE_KEY)
    or (a.JOURNAL_CREATED_DATE_DIM_DATE_KEY != a.NEW_JOURNAL_CREATED_DATE_DIM_DATE_KEY)
    or (a.TRANSACTION_DATE_DIM_DATE_KEY != a.NEW_TRANSACTION_DATE_DIM_DATE_KEY)
    or (a.REVERSAL_DATE_DIM_DATE_KEY != a.NEW_REVERSAL_DATE_DIM_DATE_KEY)
    or (a.DIM_CORPORATE_ALLOCATION_MAPPING_KEY != a.NEW_DIM_CORPORATE_ALLOCATION_MAPPING_KEY)
    or (a.DIM_CURRENCY_KEY != a.NEW_DIM_CURRENCY_KEY)
    or (a.DIM_CUSTOMER_KEY != a.NEW_DIM_CUSTOMER_KEY)
    or (a.DIM_DEFAULT_DIMENSION_KEY != a.NEW_DIM_DEFAULT_DIMENSION_KEY)
    or (a.DIM_DEFAULT_DIMENSION_OFFSET_KEY != a.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY)
    or (a.DIM_LEDGER_DIMENSION_KEY != a.NEW_DIM_LEDGER_DIMENSION_KEY)
    or (a.DIM_LEDGER_DIMENSION_OFFSET_KEY != a.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY)
    or (a.DIM_LEGAL_ENTITY_KEY != a.NEW_DIM_LEGAL_ENTITY_KEY)
    or (a.DIM_MAIN_ACCOUNT_KEY != a.NEW_DIM_MAIN_ACCOUNT_KEY)
    or (a.DIM_TAX_KEY != a.NEW_DIM_TAX_KEY)
    or (a.DIM_TAX_GROUP_KEY != a.NEW_DIM_TAX_GROUP_KEY)
    or (a.DIM_WORKER_APPROVER_KEY != a.NEW_DIM_WORKER_APPROVER_KEY)
    )
;';
            EXECUTE IMMEDIATE :late_dim_select;


--store values from late arriving dimensions for CUSTOMER
        v_proc_step := '6.1';

        LET late_dim_select_customer VARCHAR DEFAULT '';

        late_dim_select_customer := 'create or replace transient table ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP
      || ' as select a.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
				, a.NEW_DIM_CUSTOMER_KEY
				, a.NEW_DIM_CUSTOMER_SNKEY
			from (select src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', src.CUSTOMER_ACCOUNT) END AS DIM_CUSTOMER_SNKEY_RAW
					, case when nvl(src.LEGAL_ENTITY, '''') = '''' or nvl(src.CUSTOMER_ACCOUNT, '''') = '''' then -2 else hash(src.SOURCE_NAME, ''~'', src.LEGAL_ENTITY, ''~'', upper(src.CUSTOMER_ACCOUNT)) END AS DIM_CUSTOMER_SNKEY_UPPER
					, case when dc1.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_RAW
							when dc2.DIM_CUSTOMER_SNKEY is not null then DIM_CUSTOMER_SNKEY_UPPER
						else DIM_CUSTOMER_SNKEY_RAW
						end as NEW_DIM_CUSTOMER_SNKEY
					, src.DIM_CUSTOMER_KEY
					, nvl(d18.DIM_CUSTOMER_KEY, -1) AS NEW_DIM_CUSTOMER_KEY
				from ' || :tgt_db || '.global.FACT_LEDGER_JOURNAL_TRANSACTIONS src
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc1 ON
					DIM_CUSTOMER_SNKEY_RAW = dc1.DIM_CUSTOMER_SNKEY
				LEFT JOIN (select distinct DIM_CUSTOMER_SNKEY from ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER) dc2 ON
					DIM_CUSTOMER_SNKEY_UPPER = dc2.DIM_CUSTOMER_SNKEY
				LEFT JOIN ' || :tgt_db || '.GLOBAL.DIM_CUSTOMER d18 ON
					NEW_DIM_CUSTOMER_SNKEY = d18.DIM_CUSTOMER_SNKEY and
					src.DOCUMENT_DATE >= d18.HK_EFFECTIVE_START_TIMESTAMP and
					src.DOCUMENT_DATE < d18.HK_EFFECTIVE_END_TIMESTAMP
			where 1=1
			and (src.DIM_CUSTOMER_SNKEY != NEW_DIM_CUSTOMER_SNKEY
				or src.DIM_CUSTOMER_KEY != NEW_DIM_CUSTOMER_KEY)
			) a
		where 1=1
		;';
		
		EXECUTE IMMEDIATE :late_dim_select_customer;


        --merge late arriving dim back into fact table
        v_proc_step := '7';

        merge_statement := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
                        using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_' || :CURR_FORMATTED_TIMESTAMP || ' src
                        on src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY = tgt.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
                        when matched then
                            update
                                set
                                    tgt.DIM_SOURCE_SYSTEM_KEY = src.NEW_DIM_SOURCE_SYSTEM_KEY
                                    , tgt.DOCUMENT_DATE_DIM_DATE_KEY = src.NEW_DOCUMENT_DATE_DIM_DATE_KEY
                                    , tgt.JOURNAL_CREATED_DATE_DIM_DATE_KEY = src.NEW_JOURNAL_CREATED_DATE_DIM_DATE_KEY
                                    , tgt.TRANSACTION_DATE_DIM_DATE_KEY = src.NEW_TRANSACTION_DATE_DIM_DATE_KEY
                                    , tgt.REVERSAL_DATE_DIM_DATE_KEY = src.NEW_REVERSAL_DATE_DIM_DATE_KEY
                                    , tgt.DIM_CORPORATE_ALLOCATION_MAPPING_KEY = src.NEW_DIM_CORPORATE_ALLOCATION_MAPPING_KEY
                                    , tgt.DIM_CURRENCY_KEY = src.NEW_DIM_CURRENCY_KEY
                                    , tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_KEY = src.NEW_DIM_DEFAULT_DIMENSION_KEY
                                    , tgt.DIM_DEFAULT_DIMENSION_OFFSET_KEY = src.NEW_DIM_DEFAULT_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_KEY = src.NEW_DIM_LEDGER_DIMENSION_KEY
                                    , tgt.DIM_LEDGER_DIMENSION_OFFSET_KEY = src.NEW_DIM_LEDGER_DIMENSION_OFFSET_KEY
                                    , tgt.DIM_LEGAL_ENTITY_KEY = src.NEW_DIM_LEGAL_ENTITY_KEY
                                    , tgt.DIM_MAIN_ACCOUNT_KEY = src.NEW_DIM_MAIN_ACCOUNT_KEY
                                    , tgt.DIM_TAX_KEY = src.NEW_DIM_TAX_KEY
                                    , tgt.DIM_TAX_GROUP_KEY = src.NEW_DIM_TAX_GROUP_KEY
                                    , tgt.DIM_WORKER_APPROVER_KEY = src.NEW_DIM_WORKER_APPROVER_KEY
                                    , tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';

        res := (EXECUTE IMMEDIATE :merge_statement);

        LET c4 CURSOR FOR res;

        LET key_fix_count INTEGER DEFAULT 0;
        FOR row_variable IN c4 DO
            key_fix_count := row_variable."number of rows updated";
        END FOR;


--merge late arriving dim back into fact table for CUSTOMER
        v_proc_step := '7.1';
		
		LET update_statement_customer STRING DEFAULT '';

		update_statement_customer := 'merge into ' || :tgt_db || '.' || :tgt_schema || '.' || :tgt_tbl || ' tgt
						using ' || :wrk_db || '.' || :wrk_schema || '.WRK_' || :tgt_tbl || '_' || :src_schema || '_KEY_FIX_CUSTOMER_' || :CURR_FORMATTED_TIMESTAMP || ' src
						on src.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY = tgt.FACT_LEDGER_JOURNAL_TRANSACTIONS_KEY
						when matched then
							update
								set
									tgt.DIM_CUSTOMER_SNKEY = src.NEW_DIM_CUSTOMER_SNKEY
									, tgt.DIM_CUSTOMER_KEY = src.NEW_DIM_CUSTOMER_KEY
									, tgt.HK_LAST_UPDATED_TIMESTAMP = ''' || :CURR_TIMESTAMP || '''';
		
        res := (EXECUTE IMMEDIATE :update_statement_customer);

		LET c5 CURSOR FOR res;

        LET key_fix_count_customer INTEGER DEFAULT 0;
        FOR row_variable IN c5 DO
			key_fix_count_customer := row_variable."number of rows updated";
        END FOR;

        --Logging insert row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);

        --Logging update row count
        v_proc_step := '8';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);

        --Logging late arriving dimension count
        v_proc_step := '9';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Count', :key_fix_count);

        --Logging late arriving dimension count
        v_proc_step := '10';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Key Fix Customer Count', :key_fix_count_customer);
    
        --Logging stored procedure completed
        v_proc_step := '11';

        call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');

        --Update the TASK_INSTANCE table
        v_proc_step := '12';
        call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
        
        RETURN TRUE;

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
            RETURN FALSE;
END;