delete from control.TASK where task_name = 'DIM_CASH_DISCOUNT';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CASH_DISCOUNT', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CASH_DISCOUNT'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_VENDOR_PAYMENT_MODE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_VENDOR_PAYMENT_MODE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_VENDOR_PAYMENT_MODE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_VENDOR_PAYMENT_SPECIFICATION';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_VENDOR_PAYMENT_SPECIFICATION', '~', to_char(1))::number as TASK_KEY
		, 'DIM_VENDOR_PAYMENT_SPECIFICATION'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;