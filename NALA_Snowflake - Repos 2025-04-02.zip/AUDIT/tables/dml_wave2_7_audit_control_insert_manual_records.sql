----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'FACT_LEDGER_JOURNAL_TRANSACTIONS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_LEDGER_JOURNAL_TRANSACTIONS', '~', to_char(1))::number as TASK_KEY
		, 'FACT_LEDGER_JOURNAL_TRANSACTIONS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_LEDGER_JOURNAL_TRANSACTIONS', '~', to_char(3))::number as TASK_KEY
		, 'FACT_LEDGER_JOURNAL_TRANSACTIONS'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'FACT_MONTHLY_FORECAST';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_MONTHLY_FORECAST', '~', to_char(1))::number as TASK_KEY
		, 'FACT_MONTHLY_FORECAST'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_MONTHLY_FORECAST', '~', to_char(3))::number as TASK_KEY
		, 'FACT_MONTHLY_FORECAST'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;