delete from control.TASK where task_name = 'FACT_INVENTORY_JOURNAL';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_INVENTORY_JOURNAL', '~', to_char(1))::number as TASK_KEY
		, 'FACT_INVENTORY_JOURNAL'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;