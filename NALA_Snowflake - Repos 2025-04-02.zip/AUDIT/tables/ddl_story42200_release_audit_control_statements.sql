--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 42200:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	TASK
    -- new:				<add new "_DATASET_REFRESH" records for each table>
    -- updated:			n/a
    -- removed:			n/a

delete from control.TASK where task_step_number = 98;
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag, hk_created_by_user, hk_last_updated_by_user, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select hash(a.snowflake_table_name || '_DATASET_REFRESH', '~', to_char(98)) as TASK_KEY
		, a.snowflake_table_name || '_DATASET_REFRESH' as TASK_NAME
		, 98 as TASK_STEP_NUMBER
		, TRUE as TASK_IS_ENABLED_FLAG
		, current_user() as HK_CREATED_BY_USER
		, current_user() as HK_LAST_UPDATED_BY_USER
		, current_timestamp() as HK_CREATED_TIMESTAMP
		, current_timestamp() as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string() as HK_WAREHOUSE_ID
	from (select distinct case when left(snowflake_table_name, 2) = 'V_' then substr(snowflake_table_name, 3) else snowflake_table_name end as SNOWFLAKE_TABLE_NAME
		from control.PBI_SNOWFLAKE_BRIDGE) a
;


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	PBI_SNOWFLAKE_PARTITION_DETAILS
    -- new:				PBI_DB_NAME
    -- updated:			n/a
    -- removed:			n/a

create or replace TABLE control.PBI_SNOWFLAKE_PARTITION_DETAILS_NEW (
	SNOWFLAKE_TABLE_NAME VARCHAR(16777216) NOT NULL,
	PBI_DB_NAME varchar not null,
	PARTITION VARCHAR(16777216) NOT NULL,
	PARTITION_COUNT NUMBER(38,0) NOT NULL,
	PARTITION_SUM NUMBER(38,0) NOT NULL,
	PARTITION_REFRESH_FLAG BOOLEAN NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL
);

insert into control.PBI_SNOWFLAKE_PARTITION_DETAILS_NEW (snowflake_table_name, pbi_db_name, partition, partition_count, partition_sum, partition_refresh_flag, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select pspd1.SNOWFLAKE_TABLE_NAME
		, psb1.PBI_DB_NAME
		, pspd1.PARTITION
		, pspd1.PARTITION_COUNT
		, pspd1.PARTITION_SUM
		, pspd1.PARTITION_REFRESH_FLAG
		, pspd1.HK_CREATED_TIMESTAMP
		, pspd1.HK_LAST_UPDATED_TIMESTAMP
		, pspd1.HK_WAREHOUSE_ID
	from control.PBI_SNOWFLAKE_PARTITION_DETAILS pspd1
	inner join (select distinct case when left(snowflake_table_name, 2) = 'V_' then substr(snowflake_table_name, 3) else snowflake_table_name end as SNOWFLAKE_TABLE_NAME
					, pbi_db_name
				from control.PBI_SNOWFLAKE_BRIDGE) psb1 on
		psb1.pbi_db_name is not null and
		pspd1.SNOWFLAKE_TABLE_NAME = psb1.SNOWFLAKE_TABLE_NAME
;

drop table control.PBI_SNOWFLAKE_PARTITION_DETAILS;
alter table control.PBI_SNOWFLAKE_PARTITION_DETAILS_NEW rename to control.PBI_SNOWFLAKE_PARTITION_DETAILS;