----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_SALES_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SALES_LINE_DISCOUNT_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_LINE_DISCOUNT_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_LINE_DISCOUNT_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_LINE_DISCOUNT_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_LINE_DISCOUNT_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SALES_POOL';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_POOL', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_POOL'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_POOL', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_POOL'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SALES_PRICE_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_PRICE_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_PRICE_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_PRICE_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_PRICE_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SALES_PROCUREMENT_CATEGORY';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_PROCUREMENT_CATEGORY', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_PROCUREMENT_CATEGORY'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_PROCUREMENT_CATEGORY', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_PROCUREMENT_CATEGORY'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SHIPPING_CARRIER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SHIPPING_CARRIER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SHIPPING_CARRIER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SHIPPING_CARRIER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SHIPPING_CARRIER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;