----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_INVENTORY' and task_step_number = 4;
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_INVENTORY', '~', to_char(4))::number as TASK_KEY
		, 'DIM_INVENTORY'::varchar as TASK_NAME
		, 4::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_TAX_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_TAX_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_TAX_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_TAX_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_TAX_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_TAX_ITEM_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_TAX_ITEM_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_TAX_ITEM_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_TAX_ITEM_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_TAX_ITEM_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_TRADE_PROMOTION';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_TRADE_PROMOTION', '~', to_char(1))::number as TASK_KEY
		, 'DIM_TRADE_PROMOTION'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_TRADE_PROMOTION', '~', to_char(3))::number as TASK_KEY
		, 'DIM_TRADE_PROMOTION'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_TRAILERS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_TRAILERS', '~', to_char(1))::number as TASK_KEY
		, 'DIM_TRAILERS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_TRAILERS', '~', to_char(3))::number as TASK_KEY
		, 'DIM_TRAILERS'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_UNIT_OF_MEASURE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_UNIT_OF_MEASURE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_UNIT_OF_MEASURE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_UNIT_OF_MEASURE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_UNIT_OF_MEASURE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_USER_INFO';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_USER_INFO', '~', to_char(1))::number as TASK_KEY
		, 'DIM_USER_INFO'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_USER_INFO', '~', to_char(3))::number as TASK_KEY
		, 'DIM_USER_INFO'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;