--Insert statements for PBI - SNOWFLAKE  BRIDGE 
-- TST_AUDIT specific DML statements.

insert into control.pbi_snowflake_bridge(pbi_group_id,pbi_dataset_id,snowflake_table_name,pbi_db_name,pbi_table_name,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select '762f5b45-7019-46ea-90e0-96f89b2693e5', '9d172997-f165-4807-b06c-9145d25f7082','V_FACT_SALES_INVOICES','Snowflake - Sales and Marketing Gold Dataset','Sales Invoices',current_timestamp() , current_timestamp(),uuid_string() ;
insert into control.pbi_snowflake_bridge(pbi_group_id,pbi_dataset_id,snowflake_table_name,pbi_db_name,pbi_table_name,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select '762f5b45-7019-46ea-90e0-96f89b2693e5', '9d172997-f165-4807-b06c-9145d25f7082','V_FACT_SALES_ORDERS','Snowflake - Sales and Marketing Gold Dataset','Sales Order Lines',current_timestamp() , current_timestamp(),uuid_string() ;
 
