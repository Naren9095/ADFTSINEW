----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PBI_SNOWFLAKE_PARTITION
create or replace TABLE CONTROL.PBI_SNOWFLAKE_PARTITION (
	SNOWFLAKE_TABLE_NAME VARCHAR(16777216) NOT NULL,
	PARTITION_BY_COLUMN VARCHAR(16777216) NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL
);

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PBI_SNOWFLAKE_PARTITION_DETAILS
create or replace TABLE CONTROL.PBI_SNOWFLAKE_PARTITION_DETAILS (
	SNOWFLAKE_TABLE_NAME VARCHAR(16777216) NOT NULL,
	PARTITION VARCHAR(16777216) NOT NULL,
	PARTITION_COUNT NUMBER(38,0) NOT NULL,
	PARTITION_SUM NUMBER(38,0) NOT NULL,
	PARTITION_REFRESH_FLAG BOOLEAN NOT NULL,
	HK_CREATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_LAST_UPDATED_TIMESTAMP TIMESTAMP_TZ(9) NOT NULL,
	HK_WAREHOUSE_ID VARCHAR(16777216) NOT NULL
);
