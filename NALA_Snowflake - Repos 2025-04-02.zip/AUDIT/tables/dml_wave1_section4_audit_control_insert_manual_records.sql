--------------------------------------------------------------------
-- Add insert(s) for AX Retail (2) and D365 (3) tasks:

delete from control.TASK where task_name = 'FACT_PRODUCTION_JOURNAL' and task_step_number in (2, 3);
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_PRODUCTION_JOURNAL', '~', to_char(2))::number as TASK_KEY
		, 'FACT_PRODUCTION_JOURNAL'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_PRODUCTION_JOURNAL', '~', to_char(3))::number as TASK_KEY
		, 'FACT_PRODUCTION_JOURNAL'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;


--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'FACT_SALES_INVOICES';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_SALES_INVOICES', '~', to_char(1))::number as TASK_KEY
		, 'FACT_SALES_INVOICES'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_SALES_INVOICES', '~', to_char(2))::number as TASK_KEY
		, 'FACT_SALES_INVOICES'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_SALES_INVOICES', '~', to_char(3))::number as TASK_KEY
		, 'FACT_SALES_INVOICES'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'FACT_SALES_ORDERS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_SALES_ORDERS', '~', to_char(1))::number as TASK_KEY
		, 'FACT_SALES_ORDERS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_SALES_ORDERS', '~', to_char(2))::number as TASK_KEY
		, 'FACT_SALES_ORDERS'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_SALES_ORDERS', '~', to_char(3))::number as TASK_KEY
		, 'FACT_SALES_ORDERS'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;