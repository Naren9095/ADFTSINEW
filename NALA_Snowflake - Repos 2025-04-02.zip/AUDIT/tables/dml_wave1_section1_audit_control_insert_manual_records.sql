--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_BUSINESS_UNIT';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_BUSINESS_UNIT', '~', to_char(1))::number as TASK_KEY
		, 'DIM_BUSINESS_UNIT'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_BUSINESS_UNIT', '~', to_char(2))::number as TASK_KEY
		, 'DIM_BUSINESS_UNIT'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_BUSINESS_UNIT', '~', to_char(3))::number as TASK_KEY
		, 'DIM_BUSINESS_UNIT'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_COMMISSION_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_COMMISSION_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_COMMISSION_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_COMMISSION_GROUP', '~', to_char(2))::number as TASK_KEY
		, 'DIM_COMMISSION_GROUP'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_COMMISSION_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_COMMISSION_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CURRENCY';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CURRENCY', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CURRENCY'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CURRENCY', '~', to_char(2))::number as TASK_KEY
		, 'DIM_CURRENCY'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CURRENCY', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CURRENCY'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CUSTOMER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CUSTOMER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CUSTOMER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as IS_ENABLED_FLAG
	union
	select hash('DIM_CUSTOMER', '~', to_char(2))::number as TASK_KEY
		, 'DIM_CUSTOMER'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as IS_ENABLED_FLAG
	union
	select hash('DIM_CUSTOMER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CUSTOMER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_DEFAULT_DIMENSION';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_DEFAULT_DIMENSION', '~', to_char(1))::number as TASK_KEY
		, 'DIM_DEFAULT_DIMENSION'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DEFAULT_DIMENSION', '~', to_char(2))::number as TASK_KEY
		, 'DIM_DEFAULT_DIMENSION'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DEFAULT_DIMENSION', '~', to_char(3))::number as TASK_KEY
		, 'DIM_DEFAULT_DIMENSION'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_DELIVERY_MODE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_DELIVERY_MODE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_DELIVERY_MODE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DELIVERY_MODE', '~', to_char(2))::number as TASK_KEY
		, 'DIM_DELIVERY_MODE'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DELIVERY_MODE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_DELIVERY_MODE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_DELIVERY_TERM';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_DELIVERY_TERM', '~', to_char(1))::number as TASK_KEY
		, 'DIM_DELIVERY_TERM'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DELIVERY_TERM', '~', to_char(2))::number as TASK_KEY
		, 'DIM_DELIVERY_TERM'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_DELIVERY_TERM', '~', to_char(3))::number as TASK_KEY
		, 'DIM_DELIVERY_TERM'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;