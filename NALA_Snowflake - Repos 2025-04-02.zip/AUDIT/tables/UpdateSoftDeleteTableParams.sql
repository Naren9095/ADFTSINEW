INSERT INTO CONTROL.SOFT_HARD_DELETES_CONTROL (
    TASK_NAME
    ,SOURCE_NAME
    ,PK_SRC_COLS
    ,PK_TGT_COLS
    ,PK_CURATE_COLS
    ,MAPPING
    ,SOURCE_TABLE
    ,TARGET_TABLE
    ,RAW_TABLE
    ,SCHEDULE_FREQUENCY
    ,SCHEDULE_WEEKDAYS
    ,SCHEDULE_DAY_OF_MONTH
    ,IS_ACTIVE
    )
VALUES(
    'FACT_INVENTORY_TRANSACTIONS_SOFT_DELETE'
    ,'AXNALA'
    ,'recid'
    ,'RECID'
    ,'RECORD_ID'
    ,'{
        "type": "TabularTranslator",
        "mappings": 
        [
            {
                "source": {
                    "name": "HK_SOURCE_NAME",
                    "type": "STRING"
                },
                "sink": {
                    "name": "HK_SOURCE_NAME",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "HK_JOB_RUN_ID",
                    "type": "STRING"
                },
                "sink": {
                    "name": "HK_JOB_RUN_ID",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "RAW_TABLE",
                    "type": "STRING"
                },
                "sink": {
                    "name": "RAW_TABLE",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "TARGET_TABLE",
                    "type": "STRING"
                },
                "sink": {
                    "name": "TARGET_TABLE",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "PK_TGT_COLS",
                    "type": "STRING"
                },
                "sink": {
                    "name": "PK_TGT_COLS",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "PK_CURATE_COLS",
                    "type": "STRING"
                },
                "sink": {
                    "name": "PK_CURATE_COLS",
                    "type": "VARCHAR"
                }
            },
            {
                "source": {
                    "name": "recid",
                    "type": "STRING"
                },
                "sink": {
                    "name": "RECID",
                    "type": "VARCHAR"
                }
			}
       ]
    }'
    ,'inventtrans'
    ,'FACT_INVENTORY_TRANSACTIONS'
    ,'INVENTTRANS_DEL'
    ,'d'
    ,'Sun,Mon,Tue,Wed,Thu,Fri,Sat'
    ,NULL
    ,TRUE
);

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_INVENTORY_TRANSACTIONS', '~', to_char(99))::number as TASK_KEY
		, 'FACT_INVENTORY_TRANSACTIONS'::varchar as TASK_NAME
		, 99::number as TASK_STEP_NUMBER  --1 = AX_NALA, 2 = AX_RETAIL, 3 = D365, 99=DELETE SOURCE STAGING and task_name must be the target table name for deletions
		, true::number as TASK_IS_ENABLED_FLAG
    where not exists (select 1 from control.TASK where task_name = 'FACT_INVENTORY_TRANSACTIONS' and TASK_STEP_NUMBER = 99)
;