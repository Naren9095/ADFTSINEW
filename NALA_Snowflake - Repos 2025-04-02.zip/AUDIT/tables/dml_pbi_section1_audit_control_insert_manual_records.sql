--Insert statements for PBI - SNOWFLAKE  PARTITION COLUMN LOOKUP 

insert into control.pbi_snowflake_partition(snowflake_table_name, partition_by_column,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select 'FACT_SALES_INVOICES','INVOICE_DATE',current_timestamp() , current_timestamp(),uuid_string() ;
insert into control.pbi_snowflake_partition(snowflake_table_name, partition_by_column,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select 'FACT_SALES_ORDERS','SALES_LINE_CREATED_DATE',current_timestamp() , current_timestamp(),uuid_string() ;