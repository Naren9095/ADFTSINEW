----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'FACT_TAX_TRANSACTIONS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_TAX_TRANSACTIONS', '~', to_char(1))::number as TASK_KEY
		, 'FACT_TAX_TRANSACTIONS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;