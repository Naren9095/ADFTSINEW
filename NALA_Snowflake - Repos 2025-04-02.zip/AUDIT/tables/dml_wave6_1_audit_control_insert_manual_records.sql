delete from control.TASK where task_name = 'DIM_AR_BUCKETS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_AR_BUCKETS', '~', to_char(1))::number as TASK_KEY
		, 'DIM_AR_BUCKETS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CUSTOMER_POSTING_PROFILE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CUSTOMER_POSTING_PROFILE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CUSTOMER_POSTING_PROFILE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_FINANCIAL_CALENDAR_PERIOD';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_FINANCIAL_CALENDAR_PERIOD', '~', to_char(1))::number as TASK_KEY
		, 'DIM_FINANCIAL_CALENDAR_PERIOD'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_REASON';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_REASON', '~', to_char(1))::number as TASK_KEY
		, 'DIM_REASON'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'FACT_CUSTOMER_SETTLEMENTS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_CUSTOMER_SETTLEMENTS', '~', to_char(1))::number as TASK_KEY
		, 'FACT_CUSTOMER_SETTLEMENTS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;