insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_SALES_ORDERS', '~', to_char(99))::number as TASK_KEY
		, 'FACT_SALES_ORDERS'::varchar as TASK_NAME
		, 99::number as TASK_STEP_NUMBER  --1 = AX_NALA, 2 = AX_RETAIL, 3 = D365, 99=DELETE SOURCE STAGING and task_name must be the target table name for deletions
		, true::number as TASK_IS_ENABLED_FLAG
    where not exists (select 1 from control.TASK where task_name = 'FACT_SALES_ORDERS' and TASK_STEP_NUMBER = 99)
;