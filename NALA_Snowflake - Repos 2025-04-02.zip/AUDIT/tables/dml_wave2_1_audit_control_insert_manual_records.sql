----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_ARKIEVA_CUSTOMER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_ARKIEVA_CUSTOMER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_ARKIEVA_CUSTOMER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_ARKIEVA_CUSTOMER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_ARKIEVA_CUSTOMER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_ARKIEVA_SUB_CHANNEL';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_ARKIEVA_SUB_CHANNEL', '~', to_char(1))::number as TASK_KEY
		, 'DIM_ARKIEVA_SUB_CHANNEL'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_ARKIEVA_SUB_CHANNEL', '~', to_char(3))::number as TASK_KEY
		, 'DIM_ARKIEVA_SUB_CHANNEL'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CAMPAIGN';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CAMPAIGN', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CAMPAIGN'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CAMPAIGN', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CAMPAIGN'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CORPORATE_ALLOCATION_MAPPING';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CORPORATE_ALLOCATION_MAPPING', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CORPORATE_ALLOCATION_MAPPING'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CORPORATE_ALLOCATION_MAPPING', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CORPORATE_ALLOCATION_MAPPING'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;