--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_SALES_ORDER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_ORDER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_ORDER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_ORDER', '~', to_char(2))::number as TASK_KEY
		, 'DIM_SALES_ORDER'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_ORDER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_ORDER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SALES_ORIGIN';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SALES_ORIGIN', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SALES_ORIGIN'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_ORIGIN', '~', to_char(2))::number as TASK_KEY
		, 'DIM_SALES_ORIGIN'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SALES_ORIGIN', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SALES_ORIGIN'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_SITE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_SITE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_SITE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SITE', '~', to_char(2))::number as TASK_KEY
		, 'DIM_SITE'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_SITE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_SITE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_WAREHOUSE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_WAREHOUSE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_WAREHOUSE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_WAREHOUSE', '~', to_char(2))::number as TASK_KEY
		, 'DIM_WAREHOUSE'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_WAREHOUSE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_WAREHOUSE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_WORKER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_WORKER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_WORKER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_WORKER', '~', to_char(2))::number as TASK_KEY
		, 'DIM_WORKER'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_WORKER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_WORKER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'FACT_CUSTOMER_TRANSACTIONS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_CUSTOMER_TRANSACTIONS', '~', to_char(1))::number as TASK_KEY
		, 'FACT_CUSTOMER_TRANSACTIONS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_CUSTOMER_TRANSACTIONS', '~', to_char(2))::number as TASK_KEY
		, 'FACT_CUSTOMER_TRANSACTIONS'::varchar as TASK_NAME
		, 2::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('FACT_CUSTOMER_TRANSACTIONS', '~', to_char(3))::number as TASK_KEY
		, 'FACT_CUSTOMER_TRANSACTIONS'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;