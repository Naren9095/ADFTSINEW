--------------------------------------------------------------------
-- DDL for control tables:
create or replace table control.TASK (
	TASK_KEY							NUMBER NOT NULL PRIMARY KEY,						-- PK
	TASK_NAME							VARCHAR NOT NULL,									-- AK1.1
	TASK_STEP_NUMBER					NUMBER NOT NULL,									-- AK1.2
	TASK_IS_ENABLED_FLAG				BOOLEAN NOT NULL,
	HK_CREATED_BY_USER					VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_LAST_UPDATED_BY_USER				VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_LAST_UPDATED_TIMESTAMP			TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING()
);

create or replace table control.TASK_INSTANCE (
	TASK_INSTANCE_KEY					NUMBER NOT NULL PRIMARY KEY,						-- PK
	TASK_KEY							NUMBER NOT NULL,									-- AK1.1
	JOB_ID								VARCHAR NOT NULL,									-- AK1.2
	TASK_INSTANCE_STATUS				VARCHAR NOT NULL,
	TASK_INSTANCE_START_TIMESTAMP		TIMESTAMP_TZ NOT NULL,
	TASK_INSTANCE_END_TIMESTAMP			TIMESTAMP_TZ NOT NULL,
	HK_CREATED_BY_USER					VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_LAST_UPDATED_BY_USER				VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_LAST_UPDATED_TIMESTAMP			TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING()
);

create or replace table control.TASK_INSTANCE_LOG (
	TASK_INSTANCE_LOG_KEY				NUMBER NOT NULL AUTOINCREMENT PRIMARY KEY,			-- PK
	TASK_INSTANCE_KEY					NUMBER NOT NULL,
	TASK_INSTANCE_PROPERTY				VARCHAR NOT NULL,
	TASK_INSTANCE_VALUE					VARCHAR NOT NULL,
	HK_CREATED_BY_USER					VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_LAST_UPDATED_BY_USER				VARCHAR NOT NULL DEFAULT CURRENT_USER,
	HK_CREATED_TIMESTAMP				TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_LAST_UPDATED_TIMESTAMP			TIMESTAMP_TZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
	HK_WAREHOUSE_ID						VARCHAR NOT NULL DEFAULT UUID_STRING()
);


--------------------------------------------------------------------
-- Initial insert(s) for tasks:

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_DATE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_DATE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_INVENTORY', '~', to_char(1))::number as TASK_KEY
		, 'DIM_INVENTORY'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_ITEM', '~', to_char(1))::number as TASK_KEY
		, 'DIM_ITEM'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_LEGAL_ENTITY', '~', to_char(1))::number as TASK_KEY
		, 'DIM_LEGAL_ENTITY'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as IS_ENABLED_FLAG
;

insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('FACT_PRODUCTION_JOURNAL', '~', to_char(1))::number as TASK_KEY
		, 'FACT_PRODUCTION_JOURNAL'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

