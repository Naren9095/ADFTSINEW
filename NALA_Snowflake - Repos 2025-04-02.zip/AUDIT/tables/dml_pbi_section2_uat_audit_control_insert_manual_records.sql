--Insert statements for PBI - SNOWFLAKE  BRIDGE *
--UAT_AUDIT Specific DML statements

insert into control.pbi_snowflake_bridge(pbi_group_id,pbi_dataset_id,snowflake_table_name,pbi_db_name,pbi_table_name,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select '90072820-800e-49a4-95cd-7ebc700f835d', '0d1af79a-a61b-4b50-b8c9-c3cabac46cde','V_FACT_SALES_INVOICES','Snowflake - Sales and Marketing Gold Dataset','Sales Invoices',current_timestamp() , current_timestamp(),uuid_string() ;
insert into control.pbi_snowflake_bridge(pbi_group_id,pbi_dataset_id,snowflake_table_name,pbi_db_name,pbi_table_name,hk_created_timestamp,hk_last_updated_timestamp,hk_warehouse_id) select '90072820-800e-49a4-95cd-7ebc700f835d', '0d1af79a-a61b-4b50-b8c9-c3cabac46cde','V_FACT_SALES_ORDERS','Snowflake - Sales and Marketing Gold Dataset','Sales Order Lines',current_timestamp() , current_timestamp(),uuid_string() ;
