delete from control.TASK where task_name = 'DIM_LEDGER_DIMENSION';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_LEDGER_DIMENSION', '~', to_char(1))::number as TASK_KEY
		, 'DIM_LEDGER_DIMENSION'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;