----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_INTRA_STAT_TRANSACTION_CODE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_INTRA_STAT_TRANSACTION_CODE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_INTRA_STAT_TRANSACTION_CODE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_INTRA_STAT_TRANSACTION_CODE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_INTRA_STAT_TRANSACTION_CODE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_MERCHANDISING_EVENT';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_MERCHANDISING_EVENT', '~', to_char(1))::number as TASK_KEY
		, 'DIM_MERCHANDISING_EVENT'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_MERCHANDISING_EVENT', '~', to_char(3))::number as TASK_KEY
		, 'DIM_MERCHANDISING_EVENT'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_PAYMENT_MODE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_PAYMENT_MODE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_PAYMENT_MODE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_PAYMENT_MODE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_PAYMENT_MODE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_PAYMENT_TERMS';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_PAYMENT_TERMS', '~', to_char(1))::number as TASK_KEY
		, 'DIM_PAYMENT_TERMS'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_PAYMENT_TERMS', '~', to_char(3))::number as TASK_KEY
		, 'DIM_PAYMENT_TERMS'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_REBATE';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_REBATE', '~', to_char(1))::number as TASK_KEY
		, 'DIM_REBATE'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_REBATE', '~', to_char(3))::number as TASK_KEY
		, 'DIM_REBATE'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_RETURN_DISPOSITION';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_RETURN_DISPOSITION', '~', to_char(1))::number as TASK_KEY
		, 'DIM_RETURN_DISPOSITION'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_RETURN_DISPOSITION', '~', to_char(3))::number as TASK_KEY
		, 'DIM_RETURN_DISPOSITION'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;