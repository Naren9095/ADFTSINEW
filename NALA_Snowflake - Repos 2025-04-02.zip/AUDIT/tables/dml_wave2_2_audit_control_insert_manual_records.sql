----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------
-- Initial insert(s) for tasks; 1=NALA, 2=RETAIL, 3=D365:

delete from control.TASK where task_name = 'DIM_COST';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_COST', '~', to_char(1))::number as TASK_KEY
		, 'DIM_COST'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_COST', '~', to_char(3))::number as TASK_KEY
		, 'DIM_COST'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CUSTOMER_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CUSTOMER_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CUSTOMER_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CUSTOMER_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CUSTOMER_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_CUSTOMER_MARKUP_GROUP';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_CUSTOMER_MARKUP_GROUP', '~', to_char(1))::number as TASK_KEY
		, 'DIM_CUSTOMER_MARKUP_GROUP'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_CUSTOMER_MARKUP_GROUP', '~', to_char(3))::number as TASK_KEY
		, 'DIM_CUSTOMER_MARKUP_GROUP'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;

delete from control.TASK where task_name = 'DIM_GLOBAL_TRADE_ITEM_NUMBER';
insert into control.TASK (task_key, task_name, task_step_number, task_is_enabled_flag)
	select hash('DIM_GLOBAL_TRADE_ITEM_NUMBER', '~', to_char(1))::number as TASK_KEY
		, 'DIM_GLOBAL_TRADE_ITEM_NUMBER'::varchar as TASK_NAME
		, 1::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
	union
	select hash('DIM_GLOBAL_TRADE_ITEM_NUMBER', '~', to_char(3))::number as TASK_KEY
		, 'DIM_GLOBAL_TRADE_ITEM_NUMBER'::varchar as TASK_NAME
		, 3::number as TASK_STEP_NUMBER
		, true::number as TASK_IS_ENABLED_FLAG
;