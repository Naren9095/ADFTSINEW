CREATE OR REPLACE PROCEDURE CONTROL.SP_TASK_INSTANCE_LOG
(
	TASK_INSTANCE_KEY NUMBER, TASK_INSTANCE_PROPERTY VARCHAR, TASK_INSTANCE_VALUE VARCHAR
)
RETURNS INTEGER
LANGUAGE SQL
AS
DECLARE
v_proc_step VARCHAR DEFAULT '0';
v_proc_name STRING DEFAULT 'SP_TASK_INSTANCE_LOG';
BEGIN
    v_proc_step := '1';

    LET res RESULTSET := (SELECT TASK_STEP_NUMBER FROM CONTROL.TASK 
WHERE TASK_KEY = (SELECT MAX(TASK_KEY) FROM TASK_INSTANCE WHERE TASK_INSTANCE_KEY = :TASK_INSTANCE_KEY));


    LET src_schema VARCHAR DEFAULT 'NOT FOUND';

    LET TASK_STEP_NUMBER INTEGER DEFAULT 0;
    
    LET c1 CURSOR FOR res;
    OPEN c1;
    FETCH c1 INTO :TASK_STEP_NUMBER;

    IF (:TASK_STEP_NUMBER = 1) THEN
        src_schema := 'AX_NALA';
    END IF;

    IF (:TASK_STEP_NUMBER = 2) THEN
        src_schema := 'AX_RETAIL';
    END IF;

    IF (:TASK_STEP_NUMBER = 3) THEN
        src_schema := 'D365';
    END IF;

    IF (:TASK_STEP_NUMBER = 4) THEN
        src_schema := 'ARKIEVA';
    END IF;

    IF (:TASK_STEP_NUMBER = 98) THEN
        src_schema := 'PBI_DATASET_REFRESH';
    END IF;

    IF (:TASK_STEP_NUMBER = 99) THEN
        src_schema := 'GLOBAL.SP_DELETE_SOURCE_STAGING';  --Delete process for AXNALA. This might change or have an addition if we find D365 permits deletions
    END IF;
    
    
    INSERT INTO CONTROL.TASK_INSTANCE_LOG
                (
                    TASK_INSTANCE_KEY					
                    ,TASK_INSTANCE_PROPERTY				
                    ,TASK_INSTANCE_VALUE				   	
                )
                VALUES(
                    :TASK_INSTANCE_KEY
                    ,:TASK_INSTANCE_PROPERTY || ' - ' || :src_schema
                    ,:TASK_INSTANCE_VALUE
               );

    --This stored procedure will not contain an EXCEPTION block
    --This is because it would create a circular reference to SP_LOG_PROCEDURE_ERROR
END;