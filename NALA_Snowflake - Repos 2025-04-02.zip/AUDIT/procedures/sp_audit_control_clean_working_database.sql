/*
*******************************************************************************************************************************************************************************************************
    OBJECT NAME    : SP_CLEAN_WORKING_DATABASE
    CREATED BY     : Joshua Mills
    CREATED ON     : 08/13/2024
    PURPOSE        : Stored procedure for removing old working tables
    INPUT PARAMS   : ENVIRONMENT (DEV, TST, UAT, PROD), HISTORY_LENGTH (NUMBER in days)
    OUT PARAMS     : VARCHAR
    EXEC Statement : call CONTROL.SP_CLEAN_WORKING_DATABASE(<ENVIRONMENT>, <HISTORY_LENGTH>);
*******************************************************************************************************************************************************************************************************
*/
CREATE OR REPLACE PROCEDURE CONTROL.SP_CLEAN_WORKING_DATABASE
(
ENVIRONMENT VARCHAR
, HISTORY_LENGTH NUMBER
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
BEGIN

    LET show_tables_query VARCHAR := 'SHOW TABLES IN SCHEMA ' || :ENVIRONMENT || '_WORK.GLOBAL';

    LET res RESULTSET;

    -- Execute the SHOW command, and use result_scan() with last_query_id() to post-process the results
    -- last_query_id() will give the last query id for the SESSION (i.e. current run of the stored procedure)
    -- The second query will filter on the created_on column using the HISTORY_LENGTH parameter
    res := (EXECUTE IMMEDIATE :show_tables_query);
    
    res := (EXECUTE IMMEDIATE '
    SELECT 
    \"name\" AS TABLE_NAME
    , \"owner\" AS OWNER_ROLE
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
    WHERE DATEDIFF(day, \"created_on\", CURRENT_TIMESTAMP()) > ' || :HISTORY_LENGTH);

    -- Create a cursor and iterate over the results of the query
    
    LET cur CURSOR FOR res;
        
    LET drop_ctr NUMBER DEFAULT 0;

    -- failures will be appended to this variable
    LET fail_statement VARCHAR := 'The following tables met the drop criteria but failed:\n';

    LET is_failure BOOLEAN DEFAULT FALSE;
    
    FOR row_var IN cur DO
        BEGIN
            -- Must use the role of the owner of the object
            EXECUTE IMMEDIATE 'USE ROLE \"' || row_var."OWNER_ROLE" || '\"';
            EXECUTE IMMEDIATE 'DROP TABLE ' || :ENVIRONMENT || '_WORK.GLOBAL.' || row_var."TABLE_NAME";
            drop_ctr := drop_ctr + 1;

            -- In the event of a statement error, add a table to the fail statement along with its error
            -- Set failure flag to true
            EXCEPTION
                WHEN STATEMENT_ERROR THEN
                    is_failure := TRUE;
                    fail_statement := :fail_statement || row_var."TABLE_NAME" || ': ' || :SQLERRM || '\n';
        END;
    END FOR;
    

    LET return_statement VARCHAR := 'Dropped ' || :drop_ctr || ' table(s) from schema ' || :ENVIRONMENT || '_WORK.GLOBAL';

    -- In the event of a failure, append the fail statement to the return statement
    IF (:is_failure = TRUE) THEN
        return_statement := :return_statement || '\n' || :fail_statement;
    END IF;
    
    RETURN :return_statement;
END;
