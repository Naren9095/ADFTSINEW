CREATE OR REPLACE PROCEDURE CONTROL.SP_PBI_DATASET_REFRESH
(
	TASK_KEY NUMBER, TASK_STEP_NUMBER NUMBER, TASK_INSTANCE_KEY NUMBER, JOB_ID VARCHAR, ENVIRONMENT VARCHAR, TASK_NAME VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
DECLARE
	v_proc_step VARCHAR DEFAULT '0';
	v_proc_name STRING DEFAULT 'SP_PBI_DATASET_REFRESH';
	res RESULTSET;
	i_count INTEGER DEFAULT 0;
	u_count INTEGER DEFAULT 0;
BEGIN

	-- check for missing Power BI partitioning tables
	v_proc_step := '1';

	LET missing_table_list VARCHAR DEFAULT '';

	res := (
		WITH pbi_table_list AS (
			SELECT 'PBI_SNOWFLAKE_PARTITION' AS TABLE_NAME
			UNION ALL
			SELECT 'PBI_SNOWFLAKE_BRIDGE' AS TABLE_NAME
			UNION ALL
			SELECT 'PBI_SNOWFLAKE_PARTITION_DETAILS' AS TABLE_NAME
			UNION ALL
			-- do not remove this empty string. It is here to force a FALSE value
			SELECT '' AS TABLE_NAME
			)
		SELECT LISTAGG(pbl.TABLE_NAME, ',\n') AS MISSING_TABLES
			, CASE WHEN ist.table_name IS NULL THEN FALSE
					ELSE TRUE
				END AS TABLE_EXISTS
		FROM pbi_table_list pbl
		LEFT JOIN INFORMATION_SCHEMA.TABLES ist ON
			pbl.TABLE_NAME = ist.TABLE_NAME
		WHERE TABLE_EXISTS = FALSE
		GROUP BY TABLE_EXISTS
		);

	LET c4 CURSOR FOR res;
	OPEN c4;
	FETCH c4 INTO :missing_table_list;

	IF (:missing_table_list != '') THEN
		RETURN 'ERROR: The data was loaded successfully, but Power BI partitioning metadata could not be updated because the following tables are missing:\n' || :missing_table_list;
	END IF;
	

	-- Step for refreshing Power BI Partition Refresh Table
	v_proc_step := '2';
	
	--Get current timestamp as well as a formatted current timestamp
	--CURR_FORMATTED_TIMESTAMP is to be used in the names of the working tables
	--CURR_TIMESTAMP is for inserting/updating timestamps in the target table
	
	res := (SELECT TO_CHAR(CURRENT_TIMESTAMP) AS CURR_TIMESTAMP, TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISSFF3') AS CURR_FORMATTED_TIMESTAMP);

	LET CURR_TIMESTAMP STRING DEFAULT '';
	LET CURR_FORMATTED_TIMESTAMP STRING DEFAULT '';
	LET cur1 CURSOR FOR res;
	FOR row_variable IN cur1 DO
		CURR_TIMESTAMP := row_variable."CURR_TIMESTAMP";
		CURR_FORMATTED_TIMESTAMP := row_variable."CURR_FORMATTED_TIMESTAMP";
	END FOR;

	LET partition_by_column VARCHAR := NVL((SELECT MAX(PARTITION_BY_COLUMN) FROM CONTROL.PBI_SNOWFLAKE_PARTITION WHERE SNOWFLAKE_TABLE_NAME = :TASK_NAME), '');

	LET pbi_partition_query STRING := 'create or replace transient table ' || :ENVIRONMENT || '_WORK.GLOBAL.WRK_' || :TASK_NAME || '_PBI_PARTITION_PREP' || :CURR_FORMATTED_TIMESTAMP
	|| ' as
		select t1.SRC_SNOWFLAKE_TABLE_NAME, psb1.PBI_DB_NAME, t1.SRC_PARTITION, t1.SRC_PARTITION_COUNT, t1.SRC_PARTITION_SUM
			, case when nvl(p1.PARTITION_REFRESH_FLAG, FALSE) = TRUE or t1.SRC_PARTITION_COUNT != nvl(p1.PARTITION_COUNT, -1) or t1.SRC_PARTITION_SUM != nvl(p1.PARTITION_SUM, -1) then TRUE else FALSE end as PARTITION_REFRESH_FLAG
		from (select ''' || :TASK_NAME || ''' as SRC_SNOWFLAKE_TABLE_NAME
				, year(' || :partition_by_column || ') || ''Q'' || quarter(' || :partition_by_column || ') || to_char(' || :partition_by_column || ', ''mm'') as SRC_PARTITION
				, count(*) as SRC_PARTITION_COUNT
				, sum(to_char(HK_LAST_UPDATED_TIMESTAMP, ''yyyymmddhh24miss'')::number) as SRC_PARTITION_SUM
			from ' || :ENVIRONMENT || '_curate.global.' || :TASK_NAME || '
			where ' || :partition_by_column || ' >= date_trunc(''month'', add_months(current_date(), -72))
			group by 1, 2) t1
		-- the following join is meant to take each row from “t1” and multiply by the number of PBI_DB_NAME records for each SNOWFLAKE_TABLE_NAME. For example, if there 12 partitions returned from “t1” and there are 3 PBI_DB_NAME records for that table in the bridge table, then there will be 36 total records.
		inner join (select distinct case when left(SNOWFLAKE_TABLE_NAME, 2) = ''V_'' then substr(SNOWFLAKE_TABLE_NAME, 3) else SNOWFLAKE_TABLE_NAME end as SNOWFLAKE_TABLE_NAME
						, PBI_DB_NAME
					from control.PBI_SNOWFLAKE_BRIDGE) psb1 on
			t1.SRC_SNOWFLAKE_TABLE_NAME = psb1.SNOWFLAKE_TABLE_NAME
		left join control.PBI_SNOWFLAKE_PARTITION_DETAILS p1 on
			t1.SRC_SNOWFLAKE_TABLE_NAME = p1.SNOWFLAKE_TABLE_NAME and
			psb1.PBI_DB_NAME = p1.PBI_DB_NAME and
			t1.SRC_PARTITION = p1.PARTITION
		where (nvl(p1.PARTITION_COUNT, 0) != SRC_PARTITION_COUNT
        or nvl(p1.PARTITION_SUM, 0) != SRC_PARTITION_SUM)
		'
		;

	IF (:partition_by_column != '') THEN
		EXECUTE IMMEDIATE :pbi_partition_query;

		LET merge_statement STRING := 'merge into control.PBI_SNOWFLAKE_PARTITION_DETAILS tgt
									using ' || :ENVIRONMENT || '_WORK.GLOBAL.WRK_' || :TASK_NAME || '_PBI_PARTITION_PREP' || :CURR_FORMATTED_TIMESTAMP || ' src on
										src.SRC_SNOWFLAKE_TABLE_NAME = tgt.SNOWFLAKE_TABLE_NAME and
										src.PBI_DB_NAME = tgt.PBI_DB_NAME and
										src.SRC_PARTITION = tgt.PARTITION
									when matched then update set
										tgt.PARTITION_COUNT = src.SRC_PARTITION_COUNT
										, tgt.PARTITION_SUM = src.SRC_PARTITION_SUM
										, tgt.PARTITION_REFRESH_FLAG = src.PARTITION_REFRESH_FLAG
										, tgt.HK_LAST_UPDATED_TIMESTAMP = CURRENT_TIMESTAMP()
									when not matched then insert
									(
										SNOWFLAKE_TABLE_NAME
										, PBI_DB_NAME
										, PARTITION
										, PARTITION_COUNT
										, PARTITION_SUM
										, PARTITION_REFRESH_FLAG
										, HK_CREATED_TIMESTAMP
										, HK_LAST_UPDATED_TIMESTAMP
										, HK_WAREHOUSE_ID
									)
									values
									(
										src.SRC_SNOWFLAKE_TABLE_NAME
										, src.PBI_DB_NAME
										, src.SRC_PARTITION
										, src.SRC_PARTITION_COUNT
										, src.SRC_PARTITION_SUM
										, src.PARTITION_REFRESH_FLAG
										, CURRENT_TIMESTAMP()
										, CURRENT_TIMESTAMP()
										, uuid_string()
									);';

		res := (EXECUTE IMMEDIATE :merge_statement);
        
		LET cur3 CURSOR FOR res;
	
		FOR row_variable IN cur3 DO
			i_count := row_variable."number of rows inserted";
			u_count := row_variable."number of rows updated";
		END FOR;
	
		--Logging insert row count
		v_proc_step := '3';
	
		call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Insert Row Count', :i_count);
	
		--Logging update row count
		v_proc_step := '4';
	
		call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Update Row Count', :u_count);
	
		--Logging stored procedure completed
		v_proc_step := '5';
	
		call CONTROL.sp_task_instance_log(:TASK_INSTANCE_KEY, 'Stored Procedure Status', 'completed');
	
		--Update the TASK_INSTANCE table
		v_proc_step := '6';
		call CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'completed', :CURR_TIMESTAMP);
		
	END IF;
	
	RETURN 'TRUE';
	
	EXCEPTION
		WHEN STATEMENT_ERROR THEN
			CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
			RETURN :sqlerrm;
		WHEN EXPRESSION_ERROR THEN
			CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
			RETURN :sqlerrm;
		WHEN OTHER THEN
			CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
			RETURN :sqlerrm;
END;