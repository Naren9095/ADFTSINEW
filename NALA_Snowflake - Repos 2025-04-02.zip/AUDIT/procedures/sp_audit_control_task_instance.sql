
--------------------------------------------------------------------
-- SP_TASK_INSTANCE

CREATE OR REPLACE PROCEDURE CONTROL.SP_TASK_INSTANCE(TASK_INSTANCE_KEY NUMBER, TASK_KEY NUMBER, JOB_ID VARCHAR, TASK_INSTANCE_STATUS VARCHAR,
TASK_INSTANCE_TIMESTAMP TIMESTAMP_TZ)
RETURNS INTEGER
LANGUAGE SQL
AS
DECLARE 
    v_proc_step VARCHAR DEFAULT '0';
    v_proc_name STRING DEFAULT 'SP_TASK_INSTANCE';
    i_count INTEGER DEFAULT 0;
    u_count INTEGER DEFAULT 0;
    task_id INTEGER DEFAULT 0;
    task_name STRING DEFAULT '';
    res RESULTSET;
    err_msg STRING;
BEGIN 
    --Create merge into TASK_INSTANCE such that new task instances are inserted and old task instances are updated appropriately
    v_proc_step := '1';

    res := (MERGE INTO CONTROL.TASK_INSTANCE tgt USING (SELECT :TASK_INSTANCE_KEY AS TASK_INSTANCE_KEY) AS src ON tgt.TASK_INSTANCE_KEY = src.TASK_INSTANCE_KEY
    WHEN MATCHED THEN
        UPDATE
            SET
                tgt.TASK_INSTANCE_STATUS = :TASK_INSTANCE_STATUS
				,tgt.TASK_INSTANCE_END_TIMESTAMP = :TASK_INSTANCE_TIMESTAMP
                ,tgt.HK_LAST_UPDATED_BY_USER = CURRENT_USER()
                ,tgt.HK_LAST_UPDATED_TIMESTAMP = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT
        (
            TASK_INSTANCE_KEY
            ,TASK_KEY
            ,JOB_ID
            ,TASK_INSTANCE_STATUS
            ,TASK_INSTANCE_START_TIMESTAMP
            ,TASK_INSTANCE_END_TIMESTAMP
        )
        VALUES
        (
            :TASK_INSTANCE_KEY
            ,:TASK_KEY
            ,:JOB_ID
            ,:TASK_INSTANCE_STATUS
            ,:TASK_INSTANCE_TIMESTAMP
            ,:TASK_INSTANCE_TIMESTAMP
        ));
            
    LET cur CURSOR FOR res;
    
    FOR row_variable IN cur DO
        i_count := row_variable."number of rows inserted";
        u_count := row_variable."number of rows updated";
    END FOR;

    --Add the change of status to task instance log
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Status for TASK_KEY: ' || :TASK_KEY::INTEGER, :TASK_INSTANCE_STATUS);
    

    
    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR( :TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR( :TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR( :TASK_INSTANCE_KEY, :v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count);
        
END;


