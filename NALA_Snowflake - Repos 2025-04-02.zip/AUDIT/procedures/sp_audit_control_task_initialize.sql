CREATE OR REPLACE PROCEDURE CONTROL.SP_TASK_INITIALIZE
(
    JOB_ID VARCHAR, ENVIRONMENT VARCHAR, TASK_NAME VARCHAR, TASK_STEP_NUMBER NUMBER
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
DECLARE
    v_proc_step VARCHAR DEFAULT '0';
    v_proc_name STRING DEFAULT 'SP_TASK_INITIALIZE';
	v_task_name_suffix VARCHAR DEFAULT '';
	v_task_name_suffix2 VARCHAR DEFAULT '';
	v_task_name_without_suffix VARCHAR DEFAULT '';
    i_query STRING;
    i_count INTEGER DEFAULT 0;
    u_query STRING;
    u_count INTEGER DEFAULT 0;
    err_msg STRING;
BEGIN
    --Prep: create TASK_KEY and TASK_INSTANCE_KEY
    v_proc_step := '1';

    LET TASK_KEY NUMBER := hash(:TASK_NAME, '~', TO_CHAR(:TASK_STEP_NUMBER));
    LET TASK_INSTANCE_KEY NUMBER := hash(:TASK_KEY, '~', :JOB_ID);

    
    --create task instance
    v_proc_step := '2';

    CALL CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'started', CURRENT_TIMESTAMP());

    --Lookup to find if task is enabled
    v_proc_step := '4';

    LET res RESULTSET := (SELECT TASK_IS_ENABLED_FLAG FROM CONTROL.TASK WHERE TASK_KEY = :TASK_KEY);

    LET cur1 CURSOR for res;

    LET is_enabled BOOLEAN DEFAULT FALSE;
    FOR row_var IN cur1 DO
        is_enabled := row_var."TASK_IS_ENABLED_FLAG";
    END FOR;

    IF (:is_enabled = FALSE) THEN
        CALL CONTROL.SP_TASK_INSTANCE_LOG(:TASK_INSTANCE_KEY, 'Status', 'task is disabled');
        CALL CONTROL.SP_TASK_INSTANCE(:TASK_INSTANCE_KEY, :TASK_KEY, :JOB_ID, 'task is disabled', CURRENT_TIMESTAMP());
        RETURN 'Task Name ' || :TASK_NAME || ' with step number ' || :TASK_STEP_NUMBER || ' is disabled or does not exist (check table: CONTROL.TASK)';
    END IF;
    
    --Step only happens if task is enables
    --Call stored procedure for table
    v_proc_step := '5';
    
    LET sp_call VARCHAR DEFAULT '';

	v_task_name_suffix := '' || RIGHT(:TASK_NAME, 11) || '';
	v_task_name_suffix2 := '' || RIGHT(:TASK_NAME, 15) || '';
	CASE WHEN (:v_task_name_suffix = 'SOFT_DELETE') THEN
			v_task_name_without_suffix := '' || SUBSTR(:TASK_NAME, 1, LENGTH(:TASK_NAME) - 12) || '';
		WHEN (:v_task_name_suffix2 = 'DATASET_REFRESH') THEN
			v_task_name_without_suffix := '' || SUBSTR(:TASK_NAME, 1, LENGTH(:TASK_NAME) - 16) || '';
		ELSE
			v_task_name_without_suffix := :TASK_NAME;
	END CASE;


	CASE WHEN (:TASK_STEP_NUMBER = 99) OR (:v_task_name_suffix = 'SOFT_DELETE') THEN
			sp_call := 'CALL ' || :ENVIRONMENT || '_CURATE.GLOBAL.SP_DELETE_SOURCE_STAGING' || '(' || :TASK_KEY || ', ' || :TASK_STEP_NUMBER || ', ' || :TASK_INSTANCE_KEY || ', ''' || :JOB_ID || ''', ''' || :ENVIRONMENT || ''',''' || :v_task_name_without_suffix || ''')';
		WHEN (:TASK_STEP_NUMBER = 98) OR (:v_task_name_suffix2 = 'DATASET_REFRESH') THEN
			sp_call := 'CALL ' || :ENVIRONMENT || '_AUDIT.CONTROL.SP_PBI_DATASET_REFRESH' || '(' || :TASK_KEY || ', ' || :TASK_STEP_NUMBER || ', ' || :TASK_INSTANCE_KEY || ', ''' || :JOB_ID || ''', ''' || :ENVIRONMENT || ''',''' || :v_task_name_without_suffix || ''')';
		ELSE
			sp_call := 'CALL ' || :ENVIRONMENT || '_CURATE.GLOBAL.SP_' || :TASK_NAME || '(' || :TASK_KEY || ', ' || :TASK_STEP_NUMBER || ', ' || :TASK_INSTANCE_KEY || ', ''' || :JOB_ID || ''', ''' || :ENVIRONMENT || ''')';
    END CASE;
    
    LET sp_result BOOLEAN DEFAULT FALSE;
    res := (EXECUTE IMMEDIATE :sp_call);
    LET c2 CURSOR FOR res;
    OPEN c2;
    FETCH c2 INTO :sp_result;
    
    LET errormessage VARCHAR DEFAULT '';
    
    IF (:sp_result = FALSE) THEN
        res := (SELECT TOP 1 TASK_INSTANCE_VALUE FROM CONTROL.TASK_INSTANCE_LOG
                WHERE TASK_INSTANCE_KEY = :TASK_INSTANCE_KEY
                AND UPPER(TASK_INSTANCE_PROPERTY) LIKE '%SP ERROR%'
                ORDER BY HK_CREATED_TIMESTAMP DESC);
        LET c3 CURSOR FOR res;
        OPEN c3;
        FETCH c3 INTO :errormessage;

        RETURN :errormessage;
    END IF;
    
    RETURN 'TRUE';
    
    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
            RETURN :sqlerrm;
        WHEN EXPRESSION_ERROR THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
            RETURN :sqlerrm;
        WHEN OTHER THEN
            CALL CONTROL.SP_LOG_PROCEDURE_ERROR(:v_proc_name, :v_proc_step, :sqlerrm, :i_count, :u_count, :TASK_INSTANCE_KEY);
            RETURN :sqlerrm;
END;