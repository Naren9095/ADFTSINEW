create or replace view CONTROL.V_SOFT_HARD_DELETES_CONTROL(
	TASK_NAME,
	SOURCE_NAME,
	PK_SRC_COLS,
	PK_TGT_COLS,
	PK_CURATE_COLS,
	MAPPING,
	SOURCE_TABLE,
	TARGET_TABLE,
	RAW_TABLE,
	SCHEDULE_FREQUENCY,
	SCHEDULE_WEEKDAYS,
	SCHEDULE_DAY_OF_MONTH,
	IS_ACTIVE
) as
 SELECT TASK_NAME
    ,SOURCE_NAME
    ,PK_SRC_COLS
    ,PK_TGT_COLS
    ,PK_CURATE_COLS
    ,MAPPING
    ,SOURCE_TABLE
    ,TARGET_TABLE
    ,RAW_TABLE
    ,SCHEDULE_FREQUENCY
    ,SCHEDULE_WEEKDAYS
    ,SCHEDULE_DAY_OF_MONTH
    ,IS_ACTIVE
    FROM CONTROL.SOFT_HARD_DELETES_CONTROL
    WHERE is_active = 1
        AND CASE WHEN SCHEDULE_FREQUENCY = 'd' THEN 1=1 --daily will run every execution
        WHEN SCHEDULE_FREQUENCY = 'w'  --weekly, specific day(s)
            and nvl(charindex(upper(dayname(getdate())),upper(SCHEDULE_WEEKDAYS),1),0) != 0 then 1=1
        when SCHEDULE_FREQUENCY = 'm'  --monthly, specific day of month
            and dayofmonth(getdate()) = SCHEDULE_DAY_OF_MONTH then 1=1
        else 1=0
        end
    ;
;