import snowflake.connector
import argparse
import json


# Function to execute SQL file
def execute_sql_file(env, file_name, file_type, account, user, password, warehouse, database, role):
    file_path = database+"/"+file_type+"/"+file_name
    try:
        # Establish connection to Snowflake
        conn = snowflake.connector.connect(
            user=user,
            password=password,
            account=account,
            warehouse=warehouse,
            database=env+"_"+database,
            role=role
        )     
        cursor = conn.cursor()
        # Read SQL file

        with open(file_path, 'r') as sql_file:
            sql_script = sql_file.read()
        # Execute SQL script
        ##Appending execute immediate $$"+'\n'+"begin and \nend;\n$$ in order to execute multiple statements
        sql_script = "execute immediate $$\nbegin\n" +  sql_script 
        sql_script = sql_script + "\nend;\n$$"
        if(database == "PUBLISH"):
            #i.e DEV_RAW.AX_NALA -> $ENV$_RAW.AX_NALA
            sql_script = sql_script.replace("$ENV$",env)
        cursor.execute(sql_script)
        cursor.close()
        conn.close()
        
        print(f"Successfully executed {file_path}")

    except Exception as e:
        print(f"Failed executing {file_path}")
        print(f"Error: {e}")
        raise
        
# Main function to handle command-line arguments
def main():
    parser = argparse.ArgumentParser(description='Deploy SQL file to Snowflake.')

    parser.add_argument('--env', type=str, required=True, help='Environment (dev/tst/uat/prod)')
    parser.add_argument('--releaseConf', type=str, required=True, help='Path to release conf file')
    parser.add_argument('--account', type=str, required=True, help='Snowflake account identifier')
    parser.add_argument('--user', type=str, required=True, help='Snowflake user name')
    parser.add_argument('--password', type=str, required=True, help='Snowflake user password')
    parser.add_argument('--warehouse', type=str, required=True, help='Snowflake warehouse name')
    parser.add_argument('--role', type=str, required=True, help='Snowflake user role')
    #parser.add_argument('--database', type=str, required=True, help='Snowflake database name')
    #parser.add_argument('--schema', type=str, required=True, help='Snowflake schema name')

    args = parser.parse_args()
    
    with open(args.releaseConf, 'r') as file:
        data = json.load(file)

    for parent_attribute in data:
        # = args.env+"_"+parent_attribute

        # Iterate over each child list (schemas, tables, views, procedures, functions)
        for child_list_key in data[parent_attribute]:
            # Iterate over each item in the child list
            for sqlFile in data[parent_attribute][child_list_key]:
                 execute_sql_file(args.env,sqlFile, child_list_key, args.account, args.user, args.password, args.warehouse, parent_attribute, args.role)

if __name__ == '__main__':
    main()
