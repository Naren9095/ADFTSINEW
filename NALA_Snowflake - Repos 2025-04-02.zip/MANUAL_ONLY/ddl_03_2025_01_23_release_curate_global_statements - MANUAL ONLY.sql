--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				n/a
    -- updated:			INVENTORY_SITE_ID, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_INVOICES a
set a.inventory_site_id = b.inventory_site_id_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_invoices_key
		, nvl(f2.inventsiteid, '')::varchar as INVENTORY_SITE_ID_NEW
		
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.legal_entity, '~', f1.item_id, '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.commission_group_id, '~', f1.currency_code, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_group_id, '~', f1.customer_markup_group_id, '~', f1.default_dimension, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_status, '~', f1.line_return_reason_id, '~', f1.line_return_reason_group_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.payment_terms_id, '~', to_char(f1.procurement_category), '~', f1.return_disposition_id, '~', f1.return_reason_id, '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_order_id, '~', f1.sales_origin_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.tax_group_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', f1.sales_status, '~', f1.sales_type, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.due_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', to_char(f1.manufactured_date, 'yyyymmdd'), '~', to_char(f1.originating_order_created_date, 'yyyymmdd'), '~', to_char(f1.related_order_date, 'yyyymmdd'), '~', to_char(f1.return_arrival_date, 'yyyymmdd'), '~', to_char(f1.return_closed_date, 'yyyymmdd'), '~', to_char(f1.sales_line_created_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.invoice_id, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', to_char(f1.production_time, 'yyyymmddhh24missff3'), '~', f1.purchase_order_id, '~', f1.originating_order_sales_id, '~', f1.registry_number, '~', to_char(f1.inventory_quantity), '~', to_char(f1.invoice_quantity), '~', to_char(f1.physical_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.sales_price), '~', to_char(f1.commission_amount_transaction_currency), '~', to_char(f1.commission_amount_company_currency), '~', to_char(f1.line_amount_transaction_currency), '~', to_char(f1.line_amount_company_currency), '~', to_char(f1.tax_amount_transaction_currency), '~', to_char(f1.tax_amount_company_currency), '~', to_char(f1.discount_percent), '~', to_char(f1.discount_amount), '~', to_char(f1.line_discount), '~', to_char(f1.line_discount_percent), '~', to_char(f1.floor_line_discount), '~', to_char(f1.line_discount_total_transaction_currency), '~', to_char(f1.line_discount_total_company_currency), '~', to_char(f1.cost_of_goods_sold), '~', to_char(f1.fixed_overhead), '~', to_char(f1.labor), '~', to_char(f1.material), '~', to_char(f1.variable_overhead), '~', to_char(f1.frozen_cost_of_goods_sold), '~', to_char(f1.frozen_fixed_overhead), '~', to_char(f1.frozen_labor), '~', to_char(f1.frozen_material), '~', to_char(f1.frozen_variable_overhead), '~', to_char(f1.standard_cost), '~', to_char(f1.frozen_standard_cost), '~', f1.price_override_reason_code, '~', f1.price_override_reason_code_description, '~', to_char(f1.islr), '~', to_char(f1.record_id_pos), '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.journal_number, '~', f1.journal_name, '~', INVENTORY_SITE_ID_NEW)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_INVOICES f1
	inner join PROD_RAW.edw_dwh.FACTSALESINVOICES_INVENTSITEID_FIX f2 on
		f1.record_id = f2.recid and
		f1.legal_entity = f2.dataareaid and
		f1.item_id = f2.itemid
	where (f1.inventory_site_id != INVENTORY_SITE_ID_NEW
		)
	) b
where a.fact_sales_invoices_key = b.fact_sales_invoices_key
;

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				n/a
    -- updated:			DIM_COST_KEY, DIM_COST_SNKEY, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_INVOICES a
set a.dim_cost_key = b.dim_cost_key_new
	, a.dim_cost_snkey = b.dim_cost_snkey_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_invoices_key
		, case when f1.item_id = '' then -2
			else coalesce(dc1.dim_cost_key, dc2.dim_cost_key, dc3.dim_cost_key, dc4.dim_cost_key, -1)
			end::number as DIM_COST_KEY_NEW
		, case when f1.item_id = '' then -2
			else coalesce(dc1.dim_cost_snkey, dc2.dim_cost_snkey, dc3.dim_cost_snkey, dc4.dim_cost_snkey, -1)
			end::number as DIM_COST_SNKEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_INVOICES f1
	left join (select f10.fact_sales_invoices_key, dc10.dim_cost_key, dc10.dim_cost_snkey
			from global.DIM_COST dc10
			inner join global.FACT_SALES_INVOICES f10 on
				f10.legal_entity = dc10.legal_entity and
				f10.item_id = dc10.item_id and
				f10.configuration_id = dc10.configuration_id and
				f10.inventory_site_id = dc10.inventory_site_id
			where dc10.price_type_id = 0
			qualify row_number() over (partition by f10.fact_sales_invoices_key order by dc10.activation_date desc, dc10.hk_last_updated_timestamp desc) = 1) dc1 on
		f1.fact_sales_invoices_key = dc1.fact_sales_invoices_key
	left join (select f20.fact_sales_invoices_key, dc20.dim_cost_key, dc20.dim_cost_snkey
			from global.DIM_COST dc20
			inner join global.FACT_SALES_INVOICES f20 on
				f20.legal_entity = dc20.legal_entity and
				f20.item_id = dc20.item_id and
				f20.inventory_site_id = dc20.inventory_site_id and
				f20.invoice_date >= dc20.activation_date
			where dc20.price_type_id = 0
			qualify row_number() over (partition by f20.fact_sales_invoices_key order by dc20.activation_date desc, dc20.hk_last_updated_timestamp desc) = 1) dc2 on
		f1.fact_sales_invoices_key = dc2.fact_sales_invoices_key
	left join (select f30.fact_sales_invoices_key, dc30.dim_cost_key, dc30.dim_cost_snkey
			from global.DIM_COST dc30
			inner join global.FACT_SALES_INVOICES f30 on
				f30.legal_entity = dc30.legal_entity and
				f30.item_id = dc30.item_id and
				f30.configuration_id = dc30.configuration_id and
				f30.invoice_date >= dc30.activation_date
			where dc30.price_type_id = 0
			qualify row_number() over (partition by f30.fact_sales_invoices_key order by dc30.activation_date desc, dc30.hk_last_updated_timestamp desc) = 1) dc3 on
		f1.fact_sales_invoices_key = dc3.fact_sales_invoices_key
	left join (select f40.fact_sales_invoices_key, dc40.dim_cost_key, dc40.dim_cost_snkey
			from global.DIM_COST dc40
			inner join global.FACT_SALES_INVOICES f40 on
				f40.legal_entity = dc40.legal_entity and
				f40.item_id = dc40.item_id and
				f40.invoice_date >= dc40.activation_date
			where dc40.price_type_id = 0
			qualify row_number() over (partition by f40.fact_sales_invoices_key order by dc40.activation_date desc, dc40.hk_last_updated_timestamp desc) = 1) dc4 on
		f1.fact_sales_invoices_key = dc4.fact_sales_invoices_key
	where (f1.dim_cost_key != DIM_COST_KEY_NEW
		or f1.dim_cost_snkey != DIM_COST_SNKEY_NEW
		)
	) b
where a.fact_sales_invoices_key = b.fact_sales_invoices_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35198:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				n/a
    -- updated:			SALES_STATUS, SALES_TYPE, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_INVOICES a
set a.sales_status = b.sales_status_new
	, a.sales_type = b.sales_type_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_invoices_key
		, nvl(f2.salesstatus, '')::varchar as SALES_STATUS_NEW
		, nvl(f2.salestype, '')::varchar as SALES_TYPE_NEW
		
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.legal_entity, '~', f1.item_id, '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.commission_group_id, '~', f1.currency_code, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_group_id, '~', f1.customer_markup_group_id, '~', f1.default_dimension, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_status, '~', f1.line_return_reason_id, '~', f1.line_return_reason_group_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.payment_terms_id, '~', to_char(f1.procurement_category), '~', f1.return_disposition_id, '~', f1.return_reason_id, '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_order_id, '~', f1.sales_origin_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.tax_group_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', SALES_STATUS_NEW, '~', SALES_TYPE_NEW, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.due_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', to_char(f1.manufactured_date, 'yyyymmdd'), '~', to_char(f1.originating_order_created_date, 'yyyymmdd'), '~', to_char(f1.related_order_date, 'yyyymmdd'), '~', to_char(f1.return_arrival_date, 'yyyymmdd'), '~', to_char(f1.return_closed_date, 'yyyymmdd'), '~', to_char(f1.sales_line_created_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.invoice_id, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', to_char(f1.production_time, 'yyyymmddhh24missff3'), '~', f1.purchase_order_id, '~', f1.originating_order_sales_id, '~', f1.registry_number, '~', to_char(f1.inventory_quantity), '~', to_char(f1.invoice_quantity), '~', to_char(f1.physical_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.sales_price), '~', to_char(f1.commission_amount_transaction_currency), '~', to_char(f1.commission_amount_company_currency), '~', to_char(f1.line_amount_transaction_currency), '~', to_char(f1.line_amount_company_currency), '~', to_char(f1.tax_amount_transaction_currency), '~', to_char(f1.tax_amount_company_currency), '~', to_char(f1.discount_percent), '~', to_char(f1.discount_amount), '~', to_char(f1.line_discount), '~', to_char(f1.line_discount_percent), '~', to_char(f1.floor_line_discount), '~', to_char(f1.line_discount_total_transaction_currency), '~', to_char(f1.line_discount_total_company_currency), '~', to_char(f1.cost_of_goods_sold), '~', to_char(f1.fixed_overhead), '~', to_char(f1.labor), '~', to_char(f1.material), '~', to_char(f1.variable_overhead), '~', to_char(f1.frozen_cost_of_goods_sold), '~', to_char(f1.frozen_fixed_overhead), '~', to_char(f1.frozen_labor), '~', to_char(f1.frozen_material), '~', to_char(f1.frozen_variable_overhead), '~', to_char(f1.standard_cost), '~', to_char(f1.frozen_standard_cost), '~', f1.price_override_reason_code, '~', f1.price_override_reason_code_description, '~', to_char(f1.islr), '~', to_char(f1.record_id_pos), '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.journal_number, '~', f1.journal_name, '~', f1.inventory_site_id)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_INVOICES f1
	inner join PROD_RAW.edw_dwh.FACTSALESINVOICES_SALESSTATUSTYPE_FIX f2 on
		f1.record_id = f2.recid and
		f1.legal_entity = f2.dataareaid and
		f1.item_id = f2.itemid
	where f1.source_name = 'AXNALA'
	and (f1.sales_status != SALES_STATUS_NEW
		or f1.sales_type != SALES_TYPE_NEW
		)
	) b
where a.fact_sales_invoices_key = b.fact_sales_invoices_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_PURCHASE_INVOICES
    -- new:				n/a
    -- updated:			INVENTORY_SITE_ID, CONFIGURATION_ID, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_PURCHASE_INVOICES a
set a.inventory_site_id = b.inventory_site_id_new
	, a.configuration_id = b.configuration_id_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_purchase_invoices_key
		, nvl(f2.inventsiteid, '')::varchar as INVENTORY_SITE_ID_NEW
		, nvl(f2.configid, '')::varchar as CONFIGURATION_ID_NEW
		
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.inventory_dimension_id, '~', f1.item_id, '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.currency_code, '~', f1.default_dimension, '~', f1.delivery_mode_id, '~', f1.intra_stat_transaction_code, '~', to_char(f1.record_id_location), '~', to_char(f1.procurement_category), '~', f1.return_reason_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_inventory, '~', f1.unit_of_measure_code_purchase, '~', f1.vendor_account_id_invoice, '~', f1.vendor_account_id_order, '~', to_char(f1.record_id_orderer), '~', to_char(f1.record_id_requester), '~', f1.asset_transaction_type, '~', f1.delivery_type, '~', f1.document_status, '~', f1.is_stocked_product, '~', f1.purchase_line_status, '~', f1.purchase_header_status, '~', f1.purchase_type, '~', to_char(f1.inventory_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.legal_entity, '~', f1.purchase_order_id, '~', f1.purchase_invoice_id, '~', to_char(f1.line_number), '~', to_char(f1.purchase_line_number), '~', to_char(f1.qty_purchase_unit), '~', f1.purchase_unit, '~', to_char(f1.qty_inventory_unit), '~', f1.inventory_unit, '~', to_char(f1.price_unit), '~', to_char(f1.purchase_price), '~', to_char(f1.net_amount_company_currency), '~', to_char(f1.net_amount_transaction_currency), '~', to_char(f1.tax_amount_settlement_currency), '~', to_char(f1.standard_cost), '~', INVENTORY_SITE_ID_NEW, '~', CONFIGURATION_ID_NEW)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_PURCHASE_INVOICES f1
	inner join PROD_RAW.edw_dwh.FACTPURCHASEINVOICES_INVENTSITEIDCONFIGID_FIX f2 on
		f1.record_id = f2.recid
	where (f1.inventory_site_id != INVENTORY_SITE_ID_NEW
		or f1.configuration_id != CONFIGURATION_ID_NEW
		)
	) b
where a.fact_purchase_invoices_key = b.fact_purchase_invoices_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33815:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_MONTHLY_FORECAST
    -- new:				<loading historic data from EDW_DWH source>
    -- updated:			n/a
    -- removed:			n/a


-- insert historical data into table:
truncate table global.FACT_MONTHLY_FORECAST;
insert into global.FACT_MONTHLY_FORECAST (fact_monthly_forecast_key, source_name, legal_entity, arkieva_customer_id, arkieva_inventory_id, arkieva_sub_channel_id, item_id, monthly_forecast_date, monthly_forecast_load_date, dim_source_system_key, dim_source_system_snkey, monthly_forecast_date_dim_date_key, monthly_forecast_date_dim_date_snkey, monthly_forecast_load_date_dim_date_key, monthly_forecast_load_date_dim_date_snkey, dim_arkieva_customer_key, dim_arkieva_customer_snkey, dim_arkieva_sub_channel_key, dim_arkieva_sub_channel_snkey, dim_inventory_key, dim_inventory_snkey, dim_item_key, dim_item_snkey, dim_legal_entity_key, dim_legal_entity_snkey, forecast_quantity, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select a.fact_monthly_forecast_key as FACT_MONTHLY_FORECAST_KEY, a.source_name as SOURCE_NAME, a.legal_entity as LEGAL_ENTITY, a.arkieva_customer_id as ARKIEVA_CUSTOMER_ID, a.arkieva_inventory_id as ARKIEVA_INVENTORY_ID, a.arkieva_sub_channel_id as ARKIEVA_SUB_CHANNEL_ID, a.item_id as ITEM_ID, a.monthly_forecast_date as MONTHLY_FORECAST_DATE, a.monthly_forecast_load_date as MONTHLY_FORECAST_LOAD_DATE
		
		, case when a.source_name = '' then -2
			else nvl(dss1.dim_source_system_key, -1)
			end::number as DIM_SOURCE_SYSTEM_KEY
		, a.dim_source_system_snkey as DIM_SOURCE_SYSTEM_SNKEY
		
		, nvl(dd1.dim_date_key, -1)::number as MONTHLY_FORECAST_DATE_DIM_DATE_KEY
		, a.monthly_forecast_date_dim_date_snkey as MONTHLY_FORECAST_DATE_DIM_DATE_SNKEY
		, nvl(dd2.dim_date_key, -1)::number as MONTHLY_FORECAST_LOAD_DATE_DIM_DATE_KEY
		, a.monthly_forecast_load_date_dim_date_snkey as MONTHLY_FORECAST_LOAD_DATE_DIM_DATE_SNKEY
		
		, case when a.dim_arkieva_customer_snkey = -2 then -2
				else nvl(dac1.dim_arkieva_customer_key, -1)
			end::number as DIM_ARKIEVA_CUSTOMER_KEY
		, a.dim_arkieva_customer_snkey as DIM_ARKIEVA_CUSTOMER_SNKEY
		, case when a.dim_arkieva_sub_channel_snkey = -2 then -2
				else nvl(dasc1.dim_arkieva_sub_channel_key, -1)
			end::number as DIM_ARKIEVA_SUB_CHANNEL_KEY
		, a.dim_arkieva_sub_channel_snkey as DIM_ARKIEVA_SUB_CHANNEL_SNKEY
		, case when a.dim_inventory_snkey = -2 then -2
				else nvl(dinv1.dim_inventory_key, -1)
			end::number as DIM_INVENTORY_KEY
		, a.dim_inventory_snkey as DIM_INVENTORY_SNKEY
		, case when a.dim_item_snkey = -2 then -2
				else nvl(dit1.dim_item_key, -1)
			end::number as DIM_ITEM_KEY
		, a.dim_item_snkey as DIM_ITEM_SNKEY
		, case when a.dim_legal_entity_snkey = -2 then -2
				else nvl(dle1.dim_legal_entity_key, -1)
			end::number as DIM_LEGAL_ENTITY_KEY
		, a.dim_legal_entity_snkey as DIM_LEGAL_ENTITY_SNKEY
		
		, a.forecast_quantity as FORECAST_QUANTITY
	
		, hash(a.source_name, '~', a.legal_entity, '~', a.arkieva_customer_id, '~', a.arkieva_inventory_id, '~', a.arkieva_sub_channel_id, '~', a.item_id, '~', to_char(a.monthly_forecast_date, 'yyyymmdd'), '~', to_char(a.monthly_forecast_load_date, 'yyyymmdd'), '~', to_char(a.forecast_quantity))::number as HK_HASH_KEY
				
		, a.hk_source_name as HK_SOURCE_NAME
		, false::boolean as HK_SOFT_DELETE_FLAG
		, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID
		, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string()::varchar as HK_WAREHOUSE_ID

	from (select 'AXNALA'::varchar as SOURCE_NAME
			, nvl(b.legalentity, '')::varchar as LEGAL_ENTITY
			, nvl(b.arkievacustomerid, '')::varchar as ARKIEVA_CUSTOMER_ID
			, nvl(b.arkievainventoryid, '')::varchar as ARKIEVA_INVENTORY_ID
			, nvl(trim(b.arkievasubchannelid), '')::varchar as ARKIEVA_SUB_CHANNEL_ID
			, nvl(b.itemid, '')::varchar as ITEM_ID
			, nvl(b.monthlyforecastdate, '1950-01-01')::date as MONTHLY_FORECAST_DATE
			, nvl(b.monthlyforecastloaddate, '1950-01-01')::date as MONTHLY_FORECAST_LOAD_DATE
			, nvl(b.forecastquantity, 0)::number(25, 2) as FORECAST_QUANTITY
			
			, nvl(b.dw_sourcecode, '')::varchar as HK_SOURCE_NAME
			, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
			, nvl(b.dw_timestamp, '1950-01-01 00:00:00')::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
			, '-1'::varchar as HK_CREATED_JOB_RUN_ID
			, nvl(b.dw_batch, '-1')::varchar as HK_LAST_UPDATED_JOB_RUN_ID
			
			, case when nvl(SOURCE_NAME, '') = '' then -2
				else hash(SOURCE_NAME)
				end::number as DIM_SOURCE_SYSTEM_SNKEY
			, case when nvl(MONTHLY_FORECAST_DATE, '1950-01-01') = '1950-01-01' then -2
				else hash('', '~', to_char(MONTHLY_FORECAST_DATE, 'yyyymmdd'))
				end::number as MONTHLY_FORECAST_DATE_DIM_DATE_SNKEY
			, case when nvl(MONTHLY_FORECAST_LOAD_DATE, '1950-01-01') = '1950-01-01' then -2
				else hash('', '~', to_char(MONTHLY_FORECAST_LOAD_DATE, 'yyyymmdd'))
				end::number as MONTHLY_FORECAST_LOAD_DATE_DIM_DATE_SNKEY
			
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ARKIEVA_CUSTOMER_ID, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_CUSTOMER_ID)
				end::number as DIM_ARKIEVA_CUSTOMER_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ARKIEVA_SUB_CHANNEL_ID, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_SUB_CHANNEL_ID)
				end::number as DIM_ARKIEVA_SUB_CHANNEL_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ARKIEVA_INVENTORY_ID, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_INVENTORY_ID)
				end::number as DIM_INVENTORY_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ITEM_ID, '') = '' then -2
				else hash('', '~', LEGAL_ENTITY, '~', ITEM_ID)	-- (NOTE: ITEM_KEY is unique across all source systems; therefore, this field will always be set to '')
				end::number as DIM_ITEM_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY)
				end::number as DIM_LEGAL_ENTITY_SNKEY
			
			, hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_CUSTOMER_ID, '~', ARKIEVA_INVENTORY_ID, '~', ARKIEVA_SUB_CHANNEL_ID, '~', ITEM_ID, '~', to_char(MONTHLY_FORECAST_DATE, 'yyyymmdd'), '~', to_char(MONTHLY_FORECAST_LOAD_DATE, 'yyyymmdd'))::number as FACT_MONTHLY_FORECAST_KEY
			
		from (select hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, arkievacustomerkey, arkievasubchannelkey, inventorykey, itemkey, legalentitykey, monthlyforecastdate, monthlyforecastloaddate, legalentity, arkievacustomerid, arkievainventoryid, arkievasubchannelid, itemid, forecastquantity, incrementaldatetime, dw_batch, dw_sourcecode, dw_timestamp
			from PROD_RAW.edw_dwh.FACTMONTHLYFORECAST
			) b
		) a
	left join global.DIM_SOURCE_SYSTEM dss1 on
		a.dim_source_system_snkey = dss1.dim_source_system_snkey
	left join global.DIM_DATE dd1 on
		a.monthly_forecast_date_dim_date_snkey = dd1.dim_date_snkey
	left join global.DIM_DATE dd2 on
		a.monthly_forecast_load_date_dim_date_snkey = dd2.dim_date_snkey
	left join global.DIM_ARKIEVA_CUSTOMER dac1 on
		a.dim_arkieva_customer_snkey = dac1.dim_arkieva_customer_snkey and
		a.monthly_forecast_date >= dac1.hk_effective_start_timestamp and
		a.monthly_forecast_date < dac1.hk_effective_end_timestamp
	left join global.DIM_ARKIEVA_SUB_CHANNEL dasc1 on
		a.dim_arkieva_sub_channel_snkey = dasc1.dim_arkieva_sub_channel_snkey and
		a.monthly_forecast_date >= dasc1.hk_effective_start_timestamp and
		a.monthly_forecast_date < dasc1.hk_effective_end_timestamp
	left join global.DIM_INVENTORY dinv1 on
		a.dim_inventory_snkey = dinv1.dim_inventory_snkey
	left join global.DIM_ITEM dit1 on
		a.dim_item_snkey = dit1.dim_item_snkey
	left join global.DIM_LEGAL_ENTITY dle1 on
		a.dim_legal_entity_snkey = dle1.dim_legal_entity_snkey
	
	left join global.FACT_MONTHLY_FORECAST f1 on
		a.fact_monthly_forecast_key = f1.fact_monthly_forecast_key
	where f1.fact_monthly_forecast_key is null
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35700:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_MONTHLY_WMAPE
    -- new:				<loading historic data from EDW_DWH source>
    -- updated:			n/a
    -- removed:			n/a


-- insert historical data into table:
truncate table global.FACT_MONTHLY_WMAPE;
insert into global.FACT_MONTHLY_WMAPE (fact_monthly_wmape_key, source_name, legal_entity, arkieva_inventory_id, item_id, monthly_wmape_date, dim_source_system_key, dim_source_system_snkey, monthly_wmape_date_dim_date_key, monthly_wmape_date_dim_date_snkey, monthly_wmape_load_date_dim_date_key, monthly_wmape_load_date_dim_date_snkey, dim_inventory_key, dim_inventory_snkey, dim_item_key, dim_item_snkey, dim_legal_entity_key, dim_legal_entity_snkey, monthly_wmape_load_date, wmape, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select a.fact_monthly_wmape_key as FACT_MONTHLY_WMAPE_KEY, a.source_name as SOURCE_NAME, a.legal_entity as LEGAL_ENTITY, a.arkieva_inventory_id as ARKIEVA_INVENTORY_ID, a.item_id as ITEM_ID, a.monthly_wmape_date as MONTHLY_WMAPE_DATE
	
		, case when a.source_name = '' then -2
			else nvl(dss1.dim_source_system_key, -1)
			end::number as DIM_SOURCE_SYSTEM_KEY
		, a.dim_source_system_snkey as DIM_SOURCE_SYSTEM_SNKEY
		
		, nvl(dd1.dim_date_key, -1)::number as MONTHLY_WMAPE_DATE_DIM_DATE_KEY
		, a.monthly_wmape_date_dim_date_snkey as MONTHLY_WMAPE_DATE_DIM_DATE_SNKEY
		, nvl(dd2.dim_date_key, -1)::number as MONTHLY_WMAPE_LOAD_DATE_DIM_DATE_KEY
		, a.monthly_wmape_load_date_dim_date_snkey as MONTHLY_WMAPE_LOAD_DATE_DIM_DATE_SNKEY
		
		, case when a.dim_inventory_snkey = -2 then -2
				else nvl(dinv1.dim_inventory_key, -1)
			end::number as DIM_INVENTORY_KEY
		, a.dim_inventory_snkey as DIM_INVENTORY_SNKEY
		, case when a.dim_item_snkey = -2 then -2
				else nvl(dit1.dim_item_key, -1)
			end::number as DIM_ITEM_KEY
		, a.dim_item_snkey as DIM_ITEM_SNKEY
		, case when a.dim_legal_entity_snkey = -2 then -2
				else nvl(dle1.dim_legal_entity_key, -1)
			end::number as DIM_LEGAL_ENTITY_KEY
		, a.dim_legal_entity_snkey as DIM_LEGAL_ENTITY_SNKEY
		
	
		, a.monthly_wmape_load_date as MONTHLY_WMAPE_LOAD_DATE, a.wmape as WMAPE
		
		, hash(a.source_name, '~', a.legal_entity, '~', a.arkieva_inventory_id, '~', a.item_id, '~', to_char(a.monthly_wmape_date, 'yyyymmdd'), '~', to_char(a.monthly_wmape_load_date, 'yyyymmdd'), '~', to_char(a.wmape))::number as HK_HASH_KEY
		
		, a.hk_source_name as HK_SOURCE_NAME
		, false::boolean as HK_SOFT_DELETE_FLAG
		, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID
		, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string()::varchar as HK_WAREHOUSE_ID

	from (select 'AXNALA'::varchar as SOURCE_NAME
			, nvl(b.legalentity, '')::varchar as LEGAL_ENTITY
			, nvl(b.arkievainventoryid, '')::varchar as ARKIEVA_INVENTORY_ID
			, nvl(b.itemid, '')::varchar as ITEM_ID
			, nvl(b.monthlywmapedate, '1950-01-01')::date as MONTHLY_WMAPE_DATE
			
			, case when nvl(b.monthlywmapeloaddate, '1900-01-01') in ('1900-01-01') then '1950-01-01'
					when b.monthlywmapeloaddate < dd1.min_date_value then '1951-12-31'
					when b.monthlywmapeloaddate > dd1.max_date_value then '9951-12-31'
				else b.monthlywmapeloaddate
				end::date as MONTHLY_WMAPE_LOAD_DATE
			, nvl(b.wmape_src, 0)::number(25, 2) as WMAPE
			
			, nvl(b.dw_sourcecode, '')::varchar as HK_SOURCE_NAME
			, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
			, nvl(b.dw_timestamp, '1950-01-01 00:00:00')::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
			, '-1'::varchar as HK_CREATED_JOB_RUN_ID
			, nvl(b.dw_batch, '-1')::varchar as HK_LAST_UPDATED_JOB_RUN_ID
			
			, case when nvl(SOURCE_NAME, '') = '' then -2
				else hash(SOURCE_NAME)
				end::number as DIM_SOURCE_SYSTEM_SNKEY
			, case when nvl(MONTHLY_WMAPE_DATE, '1950-01-01') = '1950-01-01' then -2
				else hash('', '~', to_char(MONTHLY_WMAPE_DATE, 'yyyymmdd'))
				end::number as MONTHLY_WMAPE_DATE_DIM_DATE_SNKEY
			, case when nvl(MONTHLY_WMAPE_LOAD_DATE, '1950-01-01') = '1950-01-01' then -2
				else hash('', '~', to_char(MONTHLY_WMAPE_LOAD_DATE, 'yyyymmdd'))
				end::number as MONTHLY_WMAPE_LOAD_DATE_DIM_DATE_SNKEY
			
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ARKIEVA_INVENTORY_ID, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_INVENTORY_ID)
				end::number as DIM_INVENTORY_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' or nvl(ITEM_ID, '') = '' then -2
				else hash('', '~', LEGAL_ENTITY, '~', ITEM_ID)	-- (NOTE: ITEM_KEY is unique across all source systems; therefore, this field will always be set to '')
				end::number as DIM_ITEM_SNKEY
			, case when nvl(LEGAL_ENTITY, '') = '' then -2
				else hash(SOURCE_NAME, '~', LEGAL_ENTITY)
				end::number as DIM_LEGAL_ENTITY_SNKEY
			
			, hash(SOURCE_NAME, '~', LEGAL_ENTITY, '~', ARKIEVA_INVENTORY_ID, '~', ITEM_ID, '~', to_char(MONTHLY_WMAPE_DATE, 'yyyymmdd'))::number as FACT_MONTHLY_WMAPE_KEY
			
		from (select hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, inventorykey, itemkey, legalentitykey, monthlywmapedate, monthlywmapeloaddate, arkievainventoryid, itemid, legalentity, wmape as WMAPE_SRC, incrementaldatetime, dw_batch, dw_sourcecode, dw_timestamp
			from PROD_RAW.edw_dwh.FACTMONTHLYWMAPE
			) b
			inner join (select min(date_value) as MIN_DATE_VALUE
							, max(date_value) as MAX_DATE_VALUE
						from global.DIM_DATE
						where date_value not in ('1950-01-01', '1951-12-31', '9000-01-01', '9951-12-31')) dd1 on
				1=1
		) a
	left join global.DIM_SOURCE_SYSTEM dss1 on
		a.dim_source_system_snkey = dss1.dim_source_system_snkey
	left join global.DIM_DATE dd1 on
		a.monthly_wmape_date_dim_date_snkey = dd1.dim_date_snkey
	left join global.DIM_DATE dd2 on
		a.monthly_wmape_load_date_dim_date_snkey = dd2.dim_date_snkey
	left join global.DIM_INVENTORY dinv1 on
		a.dim_inventory_snkey = dinv1.dim_inventory_snkey
	left join global.DIM_ITEM dit1 on
		a.dim_item_snkey = dit1.dim_item_snkey
	left join global.DIM_LEGAL_ENTITY dle1 on
		a.dim_legal_entity_snkey = dle1.dim_legal_entity_snkey
	
	left join global.FACT_MONTHLY_WMAPE f1 on
		a.fact_monthly_wmape_key = f1.fact_monthly_wmape_key
	where f1.fact_monthly_wmape_key is null
;