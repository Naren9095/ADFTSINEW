--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactSalesInvoices (for inventsiteid fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		('"RECID"|' + '"DATAAREAID"|' + '"ITEMID"|' + '"inventsiteid"'
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTSALESINVOICES') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18], [19]
		, [20], [21], [22], [23], [24], [25], [26], [27], [28], [29]
		, [30], [31], [32], [33], [34], [35], [36], [37], [38], [39]
		, [40], [41], [42], [43], [44], [45], [46], [47], [48], [49]
		, [50], [51], [52], [53], [54], [55], [56], [57], [58], [59]
		, [60], [61], [62], [63], [64], [65], [66], [67], [68], [69]
		, [70], [71], [72], [73], [74], [75], [76], [77], [78], [79]
		, [80], [81], [82], [83], [84], [85], [86], [87], [88], [89]
		, [90], [91], [92], [93], [94], [95], [96], [97], [98], [99]
		, [100], [101], [102], [103], [104]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(f1.recordid as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.legalentity)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(case when f1.itemkey in (-1, -2) then f2.itemid else dit1.itemid end)), ''), '\', '\\'), '"', '\"') + '"|"'
 
 + replace(replace(isnull(ltrim(rtrim(f2.inventsiteid)), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTSALESINVOICES f1 with (nolock)
	inner join edw_hka.dbo.FACTSALESINVOICES f2 with (nolock) on
		f1.recordid = f2.recid and
		f1.datasource = f2.datasource
	left join dbo.DIMITEM dit1 with (nolock) on
		f1.itemkey = dit1.itemkey
	where isnull(f2.inventsiteid, '') != ''
) x
order by x.sql_order
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35198:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactSalesInvoices (for ordercustomer fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		('"RECID"|' + '"DATAAREAID"|' + '"ITEMID"|' + '"salesstatus"' + '"salestype"'
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTSALESINVOICES') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18], [19]
		, [20], [21], [22], [23], [24], [25], [26], [27], [28], [29]
		, [30], [31], [32], [33], [34], [35], [36], [37], [38], [39]
		, [40], [41], [42], [43], [44], [45], [46], [47], [48], [49]
		, [50], [51], [52], [53], [54], [55], [56], [57], [58], [59]
		, [60], [61], [62], [63], [64], [65], [66], [67], [68], [69]
		, [70], [71], [72], [73], [74], [75], [76], [77], [78], [79]
		, [80], [81], [82], [83], [84], [85], [86], [87], [88], [89]
		, [90], [91], [92], [93], [94], [95], [96], [97], [98], [99]
		, [100], [101], [102], [103], [104]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(f1.recordid as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.legalentity)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(case when f1.itemkey in (-1, -2) then f2.itemid else dit1.itemid end)), ''), '\', '\\'), '"', '\"') + '"|"'
 
 + replace(replace(isnull(ltrim(rtrim(dsd1.salesstatus)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(dsd1.salestype)), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTSALESINVOICES f1 with (nolock)
	inner join edw_hka.dbo.FACTSALESINVOICES f2 with (nolock) on
		f1.recordid = f2.recid and
		f1.datasource = f2.datasource
	inner join dbo.DIMITEM dit1 with (nolock) on
		dit1.itemid = 'Unrelated' and
		f1.itemkey = dit1.itemkey
	inner join dbo.DIMSALESDETAILS dsd1 with (nolock) on
		f1.salesdetailskey = dsd1.salesorderdetailskey
) x
order by x.sql_order
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactPurchaseInvoices (for inventsiteid, configid fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		('"RECID"|' + '"DATAAREAID"|' + '"ITEMID"|' + '"inventsiteid"'
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTPURCHASEINVOICES') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18], [19]
		, [20], [21], [22], [23], [24], [25], [26], [27], [28], [29]
		, [30], [31], [32], [33], [34], [35], [36], [37], [38], [39]
		, [40], [41], [42], [43], [44], [45], [46], [47], [48], [49]
		, [50], [51], [52], [53], [54], [55], [56], [57], [58], [59]
		, [60], [61], [62], [63], [64], [65], [66], [67], [68], [69]
		, [70], [71], [72], [73], [74], [75], [76], [77], [78], [79]
		, [80], [81], [82], [83], [84], [85], [86], [87], [88], [89]
		, [90], [91], [92], [93], [94], [95], [96], [97], [98], [99]
		, [100], [101], [102], [103], [104]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(f1.recordid as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 
 + replace(replace(isnull(ltrim(rtrim(f2.inventsiteid)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f2.configid)), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTPURCHASEINVOICES f1 with (nolock)
	left join edw_hka.dbo.FACTPURCHASEINVOICES f2 with (nolock) on
		f1.RecordID = f2.RECID
	where isnull(f2.inventsiteid, '') != ''
	or isnull(f2.configid, '') != ''
) x
order by x.sql_order
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33815:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactMonthlyForecast

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		([1] + [2] + [3] + [4] + [5] + [6] + [7] + [8] + [9]
		+ [10] + [11] + [12] + [13] + [14] + [15] + [16] + [17] + [18]
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTMONTHLYFORECAST') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(isnull(ltrim(rtrim(cast(f1.DW_Id as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.ArkievaCustomerKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.ArkievaSubchannelKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.InventoryKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.ItemKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.LegalEntityKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.MonthlyForecastDate, 120))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.MonthlyForecastLoadDate, 120))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.LegalEntity)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ArkievaCustomerID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ArkievaInventoryID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ArkievaSubchannelID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ItemID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(round(convert(decimal(36, 16), f1.ForecastQuantity), 2))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.IncrementalDateTime, 120))), ''), '"', '\"') + '"|"'
 
 + replace(isnull(ltrim(rtrim(cast(f1.DW_Batch as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.DW_SourceCode)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.DW_TimeStamp, 120))), ''), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTMONTHLYFORECAST f1 with (nolock)
	left join edw_hka.dbo.Export_Consensus_Forecast_Monthly_Snapshot f2 with (nolock) on
		f1.DW_Id = f2.DW_Id
) x
order by x.sql_order
;

--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35700:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactMonthlyForecast

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		([1] + [2] + [3] + [4] + [5] + [6] + [7] + [8] + [9]
		+ [10] + [11] + [12] + [13] + [14]
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTMONTHLYWMAPE') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(isnull(ltrim(rtrim(cast(f1.DW_Id as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.InventoryKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.ItemKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(cast(f1.LegalEntityKey as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.MonthlyWMAPEDate, 120))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.MonthlyWMAPELoadDate, 120))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ArkievaInventoryID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.ItemID)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.LegalEntity)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(round(convert(decimal(36, 16), f1.WMAPE), 2))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.IncrementalDateTime, 120))), ''), '"', '\"') + '"|"'
 
 + replace(isnull(ltrim(rtrim(cast(f1.DW_Batch as varchar))), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(f1.DW_SourceCode)), ''), '"', '\"') + '"|"'
 + replace(isnull(ltrim(rtrim(convert(varchar, f1.DW_TimeStamp, 120))), ''), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTMONTHLYWMAPE f1 with (nolock)
	left join edw_hka.dbo.Export_Consensus_Forecast_Monthly_WMAPE_Snapshot f2 with (nolock) on
		f1.DW_Id = f2.DW_Id
) x
order by x.sql_order
;
