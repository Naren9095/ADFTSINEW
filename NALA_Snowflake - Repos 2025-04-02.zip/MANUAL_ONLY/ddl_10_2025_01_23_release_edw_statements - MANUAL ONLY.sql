--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SalesRowLevelSecurity:

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		([1] + [2] + [3] + [4] + [5] + [6] + [7] + [8] + [9]
		+ [10]
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'SALESROWLEVELSECURITY') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(DW_Id as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(ReportParentID)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(DivisionID)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(RegionID)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(CustomerName)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(SalesRepID)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(ADUserID)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(cast(DW_Batch as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(DW_SourceCode)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(convert(varchar, DW_TimeStamp, 120))), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from security.SALESROWLEVELSECURITY with (nolock)
) x
order by x.sql_order
;