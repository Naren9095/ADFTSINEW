--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36483:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_CUSTOMER
    -- new:				n/a
    -- updated:			DEFAULT_DELIVERY_TERMS, HK_HASH_KEY
    -- removed:			n/a

update global.DIM_CUSTOMER a
set a.default_delivery_terms = b.default_delivery_terms_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select d1.dim_customer_key
		, nvl(d2.defaultdeliveryterms, '')::varchar as DEFAULT_DELIVERY_TERMS_NEW
		
		, hash(d1.source_name, '~', d1.legal_entity, '~', d1.customer_account, '~', d1.customer_name, '~', d1.record_type, '~', d1.customer_company_type, '~', d1.legacy_customer, '~', d1.legacy_consumer_number, '~', d1.organization_number, '~', d1.invoice_account, '~', d1.customer_currency_code, '~', d1.customer_currency_name, '~', d1.use_cash_discount, '~', d1.sales_representative_id, '~', d1.sales_representative, '~', d1.customer_is_blocked, '~', d1.is_past_due_check, '~', to_char(d1.credit_limit), '~', d1.is_mandatory_credit_limit, '~', d1.is_credit_limit_blocking_excluded, '~', to_char(d1.grace_days), '~', to_char(d1.current_period_average_days_to_pay), '~', to_char(d1.yearly_average_days_to_pay), '~', d1.buying_group_exempt, '~', d1.buying_group_kicker, '~', d1.default_cash_discount_id, '~', d1.default_cash_discount, '~', to_char(d1.default_cash_discount_percent), '~', d1.default_delivery_mode_id, '~', d1.default_delivery_mode, '~', d1.default_delivery_terms_id, '~', DEFAULT_DELIVERY_TERMS_NEW, '~', d1.default_payment_mode_id, '~', d1.default_payment_mode, '~', d1.default_payment_terms_id, '~', d1.default_payment_terms, '~', to_char(d1.payment_terms_number_of_days), '~', to_char(d1.payment_terms_number_of_months), '~', d1.classification_group_id, '~', d1.classification_group, '~', d1.company_chain_id, '~', d1.company_chain, '~', d1.customer_group_id, '~', d1.customer_group, '~', d1.division_id, '~', d1.division, '~', d1.line_of_business_id, '~', d1.line_of_business, '~', d1.markup_group_id, '~', d1.markup_group, '~', d1.price_group_id, '~', d1.price_group, '~', d1.sales_channel_id, '~', d1.sales_channel, '~', d1.sales_district_id, '~', d1.sales_district, '~', d1.sales_group_id, '~', d1.sales_group, '~', d1.sales_pool_id, '~', d1.sales_pool, '~', d1.segment_id, '~', d1.segment, '~', d1.sub_segment_id, '~', d1.sub_segment, '~', d1.tax_group_id, '~', d1.tax_group, '~', d1.primary_street, '~', d1.primary_city, '~', d1.primary_state, '~', d1.primary_zip_code, '~', d1.primary_country, '~', d1.primary_time_zone, '~', d1.primary_address_name, '~', d1.primary_email_address, '~', d1.primary_fax_number, '~', d1.primary_phone_number, '~', d1.invoice_street, '~', d1.invoice_city, '~', d1.invoice_state, '~', d1.invoice_zip_code, '~', d1.invoice_country, '~', d1.invoice_address_name, '~', d1.invoice_address_location_id, '~', d1.report_parent, '~', d1.report_parent_division_id, '~', d1.report_parent_division, '~', d1.report_parent_sales_district_id, '~', d1.report_parent_sales_district, '~', d1.report_parent_sales_representative_id, '~', d1.report_parent_sales_representative, '~', d1.alternative_rollup_1, '~', d1.alternative_rollup_2, '~', d1.alternative_rollup_3, '~', d1.external_pricing, '~', d1.reporting_dealer_id, '~', d1.reporting_dealer, '~', d1.mcs_network_id, '~', d1.reporting_dealer_name_id)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.DIM_CUSTOMER d1
	inner join PROD_raw.edw_dwh.DIMCUSTOMER_DEFAULTDELIVERYTERMS_FIX d2 on
		d1.legal_entity = d2.dataareaid and
		d1.customer_account = d2.customeraccount
	where d1.source_name = 'AXNALA'
	and (d1.default_delivery_terms != DEFAULT_DELIVERY_TERMS_NEW
		)
	) b
where a.dim_customer_key = b.dim_customer_key
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_DEFAULT_DIMENSION
    -- new:				<new ONE-TIME load of OracleSalesChannel data>
    -- updated:			n/a
    -- removed:			n/a

insert into global.DIM_DEFAULT_DIMENSION (dim_default_dimension_key, dim_default_dimension_snkey, source_name, default_dimension, dim_source_system_snkey, department_id, department, inter_company_id, inter_company, sales_channel_id, sales_channel, type_id, type, category_id, category, family_id, family, size_id, size, version_id, version, foam_sourced_id, foam_sourced, store_id, store, business_unit_id, business_unit, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select hash(a.source_name, '~', a.default_dimension)::number as DIM_DEFAULT_DIMENSION_KEY
		, a.dim_default_dimension_snkey as DIM_DEFAULT_DIMENSION_SNKEY, a.source_name as SOURCE_NAME, a.default_dimension as DEFAULT_DIMENSION
		, case when a.source_name = '' then -2
			else nvl(dss1.dim_source_system_snkey, -1)
			end::number as DIM_SOURCE_SYSTEM_SNKEY
		, a.department_id as DEPARTMENT_ID, a.department as DEPARTMENT, a.inter_company_id as INTER_COMPANY_ID, a.inter_company as INTER_COMPANY, a.sales_channel_id as SALES_CHANNEL_ID, a.sales_channel as SALES_CHANNEL, a.type_id as TYPE_ID, a.type as TYPE, a.category_id as CATEGORY_ID, a.category as CATEGORY, a.family_id as FAMILY_ID, a.family as FAMILY, a.size_id as SIZE_ID, a.size as SIZE, a.version_id as VERSION_ID, a.version as VERSION, a.foam_sourced_id as FOAM_SOURCED_ID, a.foam_sourced as FOAM_SOURCED, a.store_id as STORE_ID, a.store as STORE, a.business_unit_id as BUSINESS_UNIT_ID, a.business_unit as BUSINESS_UNIT
		, hash(a.source_name, '~', a.default_dimension, '~', a.department_id, '~', a.department, '~', a.inter_company_id, '~', a.inter_company, '~', a.sales_channel_id, '~', a.sales_channel, '~', a.type_id, '~', a.type, '~', a.category_id, '~', a.category, '~', a.family_id, '~', a.family, '~', a.size_id, '~', a.size, '~', a.version_id, '~', a.version, '~', a.foam_sourced_id, '~', a.foam_sourced, '~', a.store_id, '~', a.store, '~', a.business_unit_id, '~', a.business_unit)::number as HK_HASH_KEY
		, a.hk_source_name as HK_SOURCE_NAME, a.hk_soft_delete_flag as HK_SOFT_DELETE_FLAG, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID
		, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string()::varchar as HK_WAREHOUSE_ID
	from (select 'AXNALA'::varchar as SOURCE_NAME
			, 'Oracle_' || b.axsaleschannel::varchar as DEFAULT_DIMENSION
			, ''::varchar as DEPARTMENT_ID
			, ''::varchar as DEPARTMENT
			, ''::varchar as INTER_COMPANY_ID
			, ''::varchar as INTER_COMPANY
			, nvl(b.axsaleschannel, '')::varchar as SALES_CHANNEL_ID
			, nvl(b.description, '')::varchar as SALES_CHANNEL
			, ''::varchar as TYPE_ID
			, ''::varchar as TYPE
			, ''::varchar as CATEGORY_ID
			, ''::varchar as CATEGORY
			, ''::varchar as FAMILY_ID
			, ''::varchar as FAMILY
			, ''::varchar as SIZE_ID
			, ''::varchar as SIZE
			, ''::varchar as VERSION_ID
			, ''::varchar as VERSION
			, ''::varchar as FOAM_SOURCED_ID
			, ''::varchar as FOAM_SOURCED
			, ''::varchar as STORE_ID
			, ''::varchar as STORE
			, ''::varchar as BUSINESS_UNIT_ID
			, ''::varchar as BUSINESS_UNIT
	
			, nvl(b.dw_sourcecode, '')::varchar as HK_SOURCE_NAME
			, false::boolean as HK_SOFT_DELETE_FLAG
			, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
			, nvl(b.dw_timestamp, '1950-01-01 00:00:00')::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
			, '-1'::varchar as HK_CREATED_JOB_RUN_ID
			, nvl(b.dw_batch, '-1')::varchar as HK_LAST_UPDATED_JOB_RUN_ID
			
			, hash(SOURCE_NAME, '~', DEFAULT_DIMENSION)::number as DIM_DEFAULT_DIMENSION_SNKEY
		from (select hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, axsaleschannel, axsaleschannelkey, defaultdimensionkey, description, datasource, dw_batch, dw_sourcecode, dw_timestamp
			from PROD_raw.edw_dwh.ORACLESALESCHANNEL_DEFAULTDIMENSION_FIX
			) b
		) a
	left join global.DIM_SOURCE_SYSTEM dss1 on
		a.source_name = dss1.source_name
	left join global.DIM_DEFAULT_DIMENSION d1 on
		a.dim_default_dimension_snkey = d1.dim_default_dimension_snkey
	where d1.dim_default_dimension_snkey is null
;

-- insert missing -1 and -2 records
delete from global.dim_default_dimension where dim_default_dimension_key = -1 and hk_warehouse_id = 'UNKNOWN';
insert into global.dim_default_dimension (dim_default_dimension_key, dim_default_dimension_snkey, source_name, default_dimension, dim_source_system_snkey, department_id, department, inter_company_id, inter_company, sales_channel_id, sales_channel, type_id, type, category_id, category, family_id, family, size_id, size, version_id, version, foam_sourced_id, foam_sourced, store_id, store, business_unit_id, business_unit, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id) select '-1', '-1', 'UNKNOWN', 'UNKNOWN', '-1', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', '-1', 'UNKNOWN', '0', '1950-01-01 00:00:00', '1950-01-01 00:00:00', 'UNKNOWN', 'UNKNOWN', '1950-01-01 00:00:00', '1950-01-01 00:00:00', 'UNKNOWN';

delete from global.dim_default_dimension where dim_default_dimension_key = -2 and hk_warehouse_id = 'UNRELATED';
insert into global.dim_default_dimension (dim_default_dimension_key, dim_default_dimension_snkey, source_name, default_dimension, dim_source_system_snkey, department_id, department, inter_company_id, inter_company, sales_channel_id, sales_channel, type_id, type, category_id, category, family_id, family, size_id, size, version_id, version, foam_sourced_id, foam_sourced, store_id, store, business_unit_id, business_unit, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id) select '-2', '-2', 'UNRELATED', 'UNRELATED', '-2', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', 'UNRELATED', '-2', 'UNRELATED', '0', '1950-01-01 00:00:00', '1950-01-01 00:00:00', 'UNRELATED', 'UNRELATED', '1950-01-01 00:00:00', '1950-01-01 00:00:00', 'UNRELATED';



--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:


-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				n/a
    -- updated:			DEFAULT_DIMENSION, DIM_DEFAULT_DIMENSION_KEY, DIM_DEFAULT_DIMENSION_SNKEY, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_INVOICES a
set a.default_dimension = b.default_dimension_new
	, a.dim_default_dimension_key = b.dim_default_dimension_key_new
	, a.dim_default_dimension_snkey = b.dim_default_dimension_snkey_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_invoices_key
		, 'Oracle_' || nvl(f2.defaultdimension, '')::varchar as DEFAULT_DIMENSION_NEW
		, case when nvl(DEFAULT_DIMENSION_NEW, '') = '' then -2
				else hash(f1.source_name, '~', DEFAULT_DIMENSION_NEW)
			end::number as DIM_DEFAULT_DIMENSION_SNKEY_NEW
		, nvl(dd1.dim_default_dimension_key, -1)::number as DIM_DEFAULT_DIMENSION_KEY_NEW
		
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.legal_entity, '~', f1.item_id, '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.commission_group_id, '~', f1.currency_code, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_group_id, '~', f1.customer_markup_group_id, '~', DEFAULT_DIMENSION_NEW, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_status, '~', f1.line_return_reason_id, '~', f1.line_return_reason_group_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.payment_terms_id, '~', to_char(f1.procurement_category), '~', f1.return_disposition_id, '~', f1.return_reason_id, '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_order_id, '~', f1.sales_origin_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.tax_group_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', f1.sales_status, '~', f1.sales_type, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.due_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', to_char(f1.manufactured_date, 'yyyymmdd'), '~', to_char(f1.originating_order_created_date, 'yyyymmdd'), '~', to_char(f1.related_order_date, 'yyyymmdd'), '~', to_char(f1.return_arrival_date, 'yyyymmdd'), '~', to_char(f1.return_closed_date, 'yyyymmdd'), '~', to_char(f1.sales_line_created_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.invoice_id, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', to_char(f1.production_time, 'yyyymmddhh24missff3'), '~', f1.purchase_order_id, '~', f1.originating_order_sales_id, '~', f1.registry_number, '~', to_char(f1.inventory_quantity), '~', to_char(f1.invoice_quantity), '~', to_char(f1.physical_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.sales_price), '~', to_char(f1.commission_amount_transaction_currency), '~', to_char(f1.commission_amount_company_currency), '~', to_char(f1.line_amount_transaction_currency), '~', to_char(f1.line_amount_company_currency), '~', to_char(f1.tax_amount_transaction_currency), '~', to_char(f1.tax_amount_company_currency), '~', to_char(f1.discount_percent), '~', to_char(f1.discount_amount), '~', to_char(f1.line_discount), '~', to_char(f1.line_discount_percent), '~', to_char(f1.floor_line_discount), '~', to_char(f1.line_discount_total_transaction_currency), '~', to_char(f1.line_discount_total_company_currency), '~', to_char(f1.cost_of_goods_sold), '~', to_char(f1.fixed_overhead), '~', to_char(f1.labor), '~', to_char(f1.material), '~', to_char(f1.variable_overhead), '~', to_char(f1.frozen_cost_of_goods_sold), '~', to_char(f1.frozen_fixed_overhead), '~', to_char(f1.frozen_labor), '~', to_char(f1.frozen_material), '~', to_char(f1.frozen_variable_overhead), '~', to_char(f1.standard_cost), '~', to_char(f1.frozen_standard_cost), '~', f1.price_override_reason_code, '~', f1.price_override_reason_code_description, '~', to_char(f1.islr), '~', to_char(f1.record_id_pos), '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.journal_number, '~', f1.journal_name, '~', f1.inventory_site_id)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_INVOICES f1
	inner join PROD_raw.edw_dwh.FACTSALESINVOICES_DEFAULTDIMENSION_FIX f2 on
		f1.record_id = f2.recid and
		f1.legal_entity = f2.dataareaid and
		f1.item_id = f2.itemid
	left join global.DIM_DEFAULT_DIMENSION dd1 on
		DIM_DEFAULT_DIMENSION_SNKEY_NEW = dd1.dim_default_dimension_snkey
	where (f1.default_dimension != DEFAULT_DIMENSION_NEW
		or f1.dim_default_dimension_snkey != DIM_DEFAULT_DIMENSION_SNKEY_NEW
		or f1.dim_default_dimension_key != DIM_DEFAULT_DIMENSION_KEY_NEW
		)
	) b
where a.fact_sales_invoices_key = b.fact_sales_invoices_key
;

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	FACT_SALES_INVOICES
    -- new:				n/a
    -- updated:			DEFAULT_DIMENSION, DEFAULT_DIMENSION_KEY, DEFAULT_DIMENSION_SNKEY, HK_HASH_KEY
    -- removed:			n/a

update global.FACT_SALES_INVOICES a
set a.default_dimension = b.default_dimension_new
	, a.dim_default_dimension_key = b.dim_default_dimension_key_new
	, a.dim_default_dimension_snkey = b.dim_default_dimension_snkey_new
	, a.hk_hash_key = b.hk_hash_key_new
	, a.hk_last_updated_timestamp = b.hk_last_updated_timestamp_new
from (select f1.fact_sales_invoices_key
		, ''::varchar as DEFAULT_DIMENSION_NEW
		, -2::number as DIM_DEFAULT_DIMENSION_KEY_NEW
		, -2::number as DIM_DEFAULT_DIMENSION_SNKEY_NEW
		, hash(f1.source_name, '~', to_char(f1.record_id), '~', f1.legal_entity, '~', f1.item_id, '~', f1.business_unit_id, '~', f1.campaign_id, '~', f1.commission_group_id, '~', f1.currency_code, '~', f1.customer_account_invoice, '~', f1.customer_account_order, '~', f1.customer_group_id, '~', f1.customer_markup_group_id, '~', DEFAULT_DIMENSION_NEW, '~', f1.configuration_id, '~', f1.intra_stat_transaction_code, '~', f1.inventory_dimension_id, '~', f1.item_status, '~', f1.line_return_reason_id, '~', f1.line_return_reason_group_id, '~', to_char(f1.record_id_location_delivery_address), '~', to_char(f1.record_id_location_invoice_address), '~', f1.delivery_mode_id, '~', f1.delivery_term_id, '~', f1.payment_terms_id, '~', to_char(f1.procurement_category), '~', f1.return_disposition_id, '~', f1.return_reason_id, '~', f1.sales_group_id, '~', f1.sales_line_discount_group_id, '~', f1.sales_order_id, '~', f1.sales_origin_id, '~', f1.sales_pool_id, '~', f1.sales_price_group_id, '~', f1.tax_group_id, '~', f1.tax_item_group_id, '~', f1.unit_of_measure_code_sales, '~', f1.warehouse_id, '~', to_char(f1.record_id_sales_responsible), '~', to_char(f1.record_id_sales_taker), '~', f1.document_status, '~', f1.floor_sample_type, '~', f1.header_return_status, '~', f1.header_sales_status, '~', f1.return_status, '~', f1.sales_status, '~', f1.sales_type, '~', f1.ship_carrier_delivery_type, '~', f1.trade_line_delivery_type, '~', f1.is_at_agent_transaction, '~', f1.is_blind_shipment, '~', f1.is_expedited_shipment, '~', f1.is_floor_sample_discount, '~', f1.is_item_transaction, '~', f1.is_line_delivery_complete, '~', f1.is_order_blocked, '~', f1.is_order_line_blocked, '~', f1.is_order_locked, '~', f1.is_returned_item_scrap, '~', f1.is_ship_carrier_using_fuel_surcharge, '~', f1.is_stocked_product, '~', f1.drop_shipment, '~', to_char(f1.delivery_date, 'yyyymmdd'), '~', to_char(f1.document_date, 'yyyymmdd'), '~', to_char(f1.due_date, 'yyyymmdd'), '~', to_char(f1.invoice_date, 'yyyymmdd'), '~', to_char(f1.manufactured_date, 'yyyymmdd'), '~', to_char(f1.originating_order_created_date, 'yyyymmdd'), '~', to_char(f1.related_order_date, 'yyyymmdd'), '~', to_char(f1.return_arrival_date, 'yyyymmdd'), '~', to_char(f1.return_closed_date, 'yyyymmdd'), '~', to_char(f1.sales_line_created_date, 'yyyymmdd'), '~', f1.inventory_transaction_id, '~', f1.invoice_id, '~', f1.ledger_voucher, '~', to_char(f1.line_number), '~', f1.original_sales_order_id, '~', to_char(f1.production_time, 'yyyymmddhh24missff3'), '~', f1.purchase_order_id, '~', f1.originating_order_sales_id, '~', f1.registry_number, '~', to_char(f1.inventory_quantity), '~', to_char(f1.invoice_quantity), '~', to_char(f1.physical_quantity), '~', to_char(f1.price_unit), '~', to_char(f1.sales_price), '~', to_char(f1.commission_amount_transaction_currency), '~', to_char(f1.commission_amount_company_currency), '~', to_char(f1.line_amount_transaction_currency), '~', to_char(f1.line_amount_company_currency), '~', to_char(f1.tax_amount_transaction_currency), '~', to_char(f1.tax_amount_company_currency), '~', to_char(f1.discount_percent), '~', to_char(f1.discount_amount), '~', to_char(f1.line_discount), '~', to_char(f1.line_discount_percent), '~', to_char(f1.floor_line_discount), '~', to_char(f1.line_discount_total_transaction_currency), '~', to_char(f1.line_discount_total_company_currency), '~', to_char(f1.cost_of_goods_sold), '~', to_char(f1.fixed_overhead), '~', to_char(f1.labor), '~', to_char(f1.material), '~', to_char(f1.variable_overhead), '~', to_char(f1.frozen_cost_of_goods_sold), '~', to_char(f1.frozen_fixed_overhead), '~', to_char(f1.frozen_labor), '~', to_char(f1.frozen_material), '~', to_char(f1.frozen_variable_overhead), '~', to_char(f1.standard_cost), '~', to_char(f1.frozen_standard_cost), '~', f1.price_override_reason_code, '~', f1.price_override_reason_code_description, '~', to_char(f1.islr), '~', to_char(f1.record_id_pos), '~', f1.price_type, '~', to_char(f1.activation_date, 'yyyymmdd'), '~', to_char(f1.created_datetime, 'yyyymmddhh24missff3'), '~', f1.journal_number, '~', f1.journal_name, '~', f1.inventory_site_id)::number as HK_HASH_KEY_NEW
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP_NEW
	from global.FACT_SALES_INVOICES f1
	where f1.default_dimension = '0'
	and (f1.default_dimension != DEFAULT_DIMENSION_NEW
		or f1.dim_default_dimension_key != DIM_DEFAULT_DIMENSION_KEY_NEW
		or f1.dim_default_dimension_snkey != DIM_DEFAULT_DIMENSION_SNKEY_NEW)
	) b
where a.fact_sales_invoices_key = b.fact_sales_invoices_key
;