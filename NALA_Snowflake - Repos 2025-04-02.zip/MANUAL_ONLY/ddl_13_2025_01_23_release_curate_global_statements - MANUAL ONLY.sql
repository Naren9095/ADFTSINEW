--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	RLS_SALES
    -- new:				<loading historic data from EDW_DWH source>
    -- updated:			n/a
    -- removed:			n/a


-- insert historical data into table:
truncate table global.RLS_SALES;
insert into global.RLS_SALES (rls_sales_key, rls_sales_snkey, source_name, ad_user_id, report_parent_id, sales_rep_id, dim_source_system_snkey, division_id, region_id, customer_name, email_address, hk_hash_key, hk_source_name, hk_soft_delete_flag, hk_source_created_timestamp, hk_source_last_updated_timestamp, hk_created_job_run_id, hk_last_updated_job_run_id, hk_created_timestamp, hk_last_updated_timestamp, hk_warehouse_id)
	select hash(a.source_name, '~', a.ad_user_id, '~', a.report_parent_id, '~', a.sales_rep_id)::number as RLS_SALES_KEY
		, a.rls_sales_snkey as RLS_SALES_SNKEY, a.source_name as SOURCE_NAME, a.ad_user_id as AD_USER_ID, a.report_parent_id as REPORT_PARENT_ID, a.sales_rep_id as SALES_REP_ID
		
		, case when a.source_name = '' then -2
			else nvl(dss1.dim_source_system_snkey, -1)
			end::number as DIM_SOURCE_SYSTEM_SNKEY
		, a.division_id as DIVISION_ID, a.region_id as REGION_ID, a.customer_name as CUSTOMER_NAME, a.email_address as EMAIL_ADDRESS
		
		, hash(a.source_name, '~', a.ad_user_id, '~', a.report_parent_id, '~', a.sales_rep_id, '~', a.division_id, '~', a.region_id, '~', a.customer_name, '~', a.email_address)::number as HK_HASH_KEY
		
		, a.hk_source_name as HK_SOURCE_NAME, a.hk_soft_delete_flag as HK_SOFT_DELETE_FLAG, a.hk_source_created_timestamp as HK_SOURCE_CREATED_TIMESTAMP, a.hk_source_last_updated_timestamp as HK_SOURCE_LAST_UPDATED_TIMESTAMP, a.hk_created_job_run_id as HK_CREATED_JOB_RUN_ID, a.hk_last_updated_job_run_id as HK_LAST_UPDATED_JOB_RUN_ID
		, current_timestamp::timestamp_tz as HK_CREATED_TIMESTAMP
		, current_timestamp::timestamp_tz as HK_LAST_UPDATED_TIMESTAMP
		, uuid_string()::varchar as HK_WAREHOUSE_ID

	from (select distinct
			'ATHENA'::varchar as SOURCE_NAME
			, nvl(b.aduserid, '')::varchar as AD_USER_ID
			, nvl(b.reportparentid, '')::varchar as REPORT_PARENT_ID
			, nvl(b.salesrepid, '')::varchar as SALES_REP_ID
			, nvl(b.divisionid, '')::varchar as DIVISION_ID
			, nvl(b.regionid, '')::varchar as REGION_ID
			, nvl(b.customername, '')::varchar as CUSTOMER_NAME
			, case when AD_USER_ID = '' then '' else (substr(AD_USER_ID, charindex('\\', AD_USER_ID, 1) + 1) || '@tempursealy.com') end::varchar as EMAIL_ADDRESS
	
			, nvl(b.dw_sourcecode, '')::varchar as HK_SOURCE_NAME
			, false::boolean as HK_SOFT_DELETE_FLAG
			, '1950-01-01 00:00:00'::timestamp_tz as HK_SOURCE_CREATED_TIMESTAMP
			, nvl(b.dw_timestamp, '1950-01-01 00:00:00')::timestamp_tz as HK_SOURCE_LAST_UPDATED_TIMESTAMP
			, '-1'::varchar as HK_CREATED_JOB_RUN_ID
			, nvl(b.dw_batch, '-1')::varchar as HK_LAST_UPDATED_JOB_RUN_ID
			
			, hash(SOURCE_NAME, '~', AD_USER_ID, '~', REPORT_PARENT_ID, '~', SALES_REP_ID)::number as RLS_SALES_SNKEY
		from (select hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, reportparentid, divisionid, regionid, customername, salesrepid, aduserid, dw_batch, dw_sourcecode, dw_timestamp
			from prod_raw.edw_dwh.SALESROWLEVELSECURITY
			) b
		) a
	left join global.DIM_SOURCE_SYSTEM dss1 on
		a.source_name = dss1.source_name
	left join global.RLS_SALES d1 on
		a.rls_sales_snkey = d1.rls_sales_snkey
	where d1.rls_sales_snkey is null
;