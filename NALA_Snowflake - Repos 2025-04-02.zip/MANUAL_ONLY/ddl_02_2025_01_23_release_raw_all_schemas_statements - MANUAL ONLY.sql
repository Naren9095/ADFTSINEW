--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FACTSALESINVOICES_INVENTSITEID_FIX

truncate table edw_dwh.FACTSALESINVOICES_INVENTSITEID_FIX;
insert into edw_dwh.FACTSALESINVOICES_INVENTSITEID_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, recid, dataareaid, itemid, inventsiteid)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.recid as RECID, a.dataareaid as DATAAREAID, a.itemid as ITEMID, a.inventsiteid as INVENTSITEID
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as RECID, case when nvl(t.$2, '') = '' then '' else nvl(t.$2, '') end::varchar as DATAAREAID, case when nvl(t.$3, '') = '' then '' else nvl(t.$3, '') end::varchar as ITEMID, case when nvl(t.$4, '') = '' then '' else nvl(t.$4, '') end::varchar as INVENTSITEID
		from @PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_SALES_INVOICES_INVENTSITEID_FIX_HIST.*[.]txt'
			) t
		) a
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35198:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FACTSALESINVOICES_SALESSTATUSTYPE_FIX

truncate table edw_dwh.FACTSALESINVOICES_SALESSTATUSTYPE_FIX;
insert into edw_dwh.FACTSALESINVOICES_SALESSTATUSTYPE_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, recid, dataareaid, itemid, salesstatus, salestype)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.recid as RECID, a.dataareaid as DATAAREAID, a.itemid as ITEMID, a.salesstatus as SALESSTATUS, a.salestype as SALESTYPE
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as RECID, case when nvl(t.$2, '') = '' then '' else nvl(t.$2, '') end::varchar as DATAAREAID, case when nvl(t.$3, '') = '' then '' else nvl(t.$3, '') end::varchar as ITEMID, case when nvl(t.$4, '') = '' then '' else nvl(t.$4, '') end::varchar as SALESSTATUS, case when nvl(t.$5, '') = '' then '' else nvl(t.$5, '') end::varchar as SALESTYPE
		from @PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_SALES_INVOICES_SALESSTATUSTYPE_FIX_HIST.*[.]txt'
			) t
		) a
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33752:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FACTPURCHASEINVOICES_INVENTSITEIDCONFIGID_FIX

truncate table edw_dwh.FACTPURCHASEINVOICES_INVENTSITEIDCONFIGID_FIX;
insert into edw_dwh.FACTPURCHASEINVOICES_INVENTSITEIDCONFIGID_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, recid, inventsiteid, configid)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.recid as RECID, a.inventsiteid as INVENTSITEID, a.configid as CONFIGID
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as RECID, case when nvl(t.$2, '') = '' then '' else nvl(t.$2, '') end::varchar as INVENTSITEID, case when nvl(t.$3, '') = '' then '' else nvl(t.$3, '') end::varchar as CONFIGID
		from @PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_PURCHASE_INVOICES_INVENTSITEIDCONFIGID_FIX_HIST.*[.]txt'
			) t
		) a
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 33815:

truncate table edw_dwh.FACTMONTHLYFORECAST;
insert into edw_dwh.FACTMONTHLYFORECAST (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, arkievacustomerkey, arkievasubchannelkey, inventorykey, itemkey, legalentitykey, monthlyforecastdate, monthlyforecastloaddate, legalentity, arkievacustomerid, arkievainventoryid, arkievasubchannelid, itemid, forecastquantity, incrementaldatetime, dw_batch, dw_sourcecode, dw_timestamp)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.dw_id as DW_ID, a.arkievacustomerkey as ARKIEVACUSTOMERKEY, a.arkievasubchannelkey as ARKIEVASUBCHANNELKEY, a.inventorykey as INVENTORYKEY, a.itemkey as ITEMKEY, a.legalentitykey as LEGALENTITYKEY, a.monthlyforecastdate as MONTHLYFORECASTDATE, a.monthlyforecastloaddate as MONTHLYFORECASTLOADDATE, a.legalentity as LEGALENTITY, a.arkievacustomerid as ARKIEVACUSTOMERID, a.arkievainventoryid as ARKIEVAINVENTORYID, a.arkievasubchannelid as ARKIEVASUBCHANNELID, a.itemid as ITEMID, a.forecastquantity as FORECASTQUANTITY, a.incrementaldatetime as INCREMENTALDATETIME, a.dw_batch as DW_BATCH, a.dw_sourcecode as DW_SOURCECODE, a.dw_timestamp as DW_TIMESTAMP
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as DW_ID, case when nvl(t.$2, '') = '' then 0 else to_number(t.$2, 38, 0) end::number(38, 0) as ARKIEVACUSTOMERKEY, case when nvl(t.$3, '') = '' then 0 else to_number(t.$3, 38, 0) end::number(38, 0) as ARKIEVASUBCHANNELKEY, case when nvl(t.$4, '') = '' then 0 else to_number(t.$4, 38, 0) end::number(38, 0) as INVENTORYKEY, case when nvl(t.$5, '') = '' then 0 else to_number(t.$5, 38, 0) end::number(38, 0) as ITEMKEY, case when nvl(t.$6, '') = '' then 0 else to_number(t.$6, 38, 0) end::number(38, 0) as LEGALENTITYKEY, case when nvl(t.$7, '') = '' then '1950-01-01' else to_date(substr(t.$7, 1, 10), 'yyyy-mm-dd') end::date as MONTHLYFORECASTDATE, case when nvl(t.$8, '') = '' then '1950-01-01' else to_date(substr(t.$8, 1, 10), 'yyyy-mm-dd') end::date as MONTHLYFORECASTLOADDATE, case when nvl(t.$9, '') = '' then '' else (t.$9) end::varchar as LEGALENTITY, case when nvl(t.$10, '') = '' then '' else (t.$10) end::varchar as ARKIEVACUSTOMERID, case when nvl(t.$11, '') = '' then '' else (t.$11) end::varchar as ARKIEVAINVENTORYID, case when nvl(t.$12, '') = '' then '' else (t.$12) end::varchar as ARKIEVASUBCHANNELID, case when nvl(t.$13, '') = '' then '' else (t.$13) end::varchar as ITEMID, case when nvl(t.$14, '') = '' then 0 else to_number(t.$14, 25, 2) end::number(25, 2) as FORECASTQUANTITY, case when nvl(t.$15, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$15, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as INCREMENTALDATETIME, case when nvl(t.$16, '') = '' then 0 else to_number(t.$16, 38, 0) end::number(38, 0) as DW_BATCH, case when nvl(t.$17, '') = '' then '' else (t.$17) end::varchar as DW_SOURCECODE, case when nvl(t.$18, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$18, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as DW_TIMESTAMP
		from @PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_MONTHLY_FORECAST_HIST.*[.]txt'
			) t
		) a
;

--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35700:

truncate table edw_dwh.FACTMONTHLYWMAPE;
insert into edw_dwh.FACTMONTHLYWMAPE (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, inventorykey, itemkey, legalentitykey, monthlywmapedate, monthlywmapeloaddate, arkievainventoryid, itemid, legalentity, wmape, incrementaldatetime, dw_batch, dw_sourcecode, dw_timestamp)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.dw_id as DW_ID, a.inventorykey as INVENTORYKEY, a.itemkey as ITEMKEY, a.legalentitykey as LEGALENTITYKEY, a.monthlywmapedate as MONTHLYWMAPEDATE, a.monthlywmapeloaddate as MONTHLYWMAPELOADDATE, a.arkievainventoryid as ARKIEVAINVENTORYID, a.itemid as ITEMID, a.legalentity as LEGALENTITY, a.wmape as WMAPE, a.incrementaldatetime as INCREMENTALDATETIME, a.dw_batch as DW_BATCH, a.dw_sourcecode as DW_SOURCECODE, a.dw_timestamp as DW_TIMESTAMP
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as DW_ID, case when nvl(t.$2, '') = '' then 0 else to_number(t.$2, 38, 0) end::number(38, 0) as INVENTORYKEY, case when nvl(t.$3, '') = '' then 0 else to_number(t.$3, 38, 0) end::number(38, 0) as ITEMKEY, case when nvl(t.$4, '') = '' then 0 else to_number(t.$4, 38, 0) end::number(38, 0) as LEGALENTITYKEY, case when nvl(t.$5, '') = '' then '1950-01-01' else to_date(substr(t.$5, 1, 10), 'yyyy-mm-dd') end::date as MONTHLYWMAPEDATE, case when nvl(t.$6, '') = '' then '1950-01-01' else to_date(substr(t.$6, 1, 10), 'yyyy-mm-dd') end::date as MONTHLYWMAPELOADDATE, case when nvl(t.$7, '') = '' then '' else (t.$7) end::varchar as ARKIEVAINVENTORYID, case when nvl(t.$8, '') = '' then '' else (t.$8) end::varchar as ITEMID, case when nvl(t.$9, '') = '' then '' else (t.$9) end::varchar as LEGALENTITY, case when nvl(t.$10, '') = '' then 0 else to_number(t.$10, 25, 2) end::number(25, 2) as WMAPE, case when nvl(t.$11, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$11, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as INCREMENTALDATETIME, case when nvl(t.$12, '') = '' then 0 else to_number(t.$12, 38, 0) end::number(38, 0) as DW_BATCH, case when nvl(t.$13, '') = '' then '' else (t.$13) end::varchar as DW_SOURCECODE, case when nvl(t.$14, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$14, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as DW_TIMESTAMP
		from @PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_RAW.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_MONTHLY_WMAPE_HIST.*[.]txt'
			) t
		) a
;