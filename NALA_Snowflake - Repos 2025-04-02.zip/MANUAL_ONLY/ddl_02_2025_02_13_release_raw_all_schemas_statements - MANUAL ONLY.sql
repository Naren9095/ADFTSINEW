--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36483:

truncate table edw_dwh.DIMCUSTOMER_DEFAULTDELIVERYTERMS_FIX;
insert into edw_dwh.DIMCUSTOMER_DEFAULTDELIVERYTERMS_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dataareaid, customeraccount, defaultdeliveryterms)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.dataareaid as DATAAREAID, a.customeraccount as CUSTOMERACCOUNT, a.defaultdeliveryterms as DEFAULTDELIVERYTERMS
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then '' else nvl(t.$1, '') end::varchar as DATAAREAID, case when nvl(t.$2, '') = '' then '' else nvl(t.$2, '') end::varchar as CUSTOMERACCOUNT, case when nvl(t.$3, '') = '' then '' else nvl(t.$3, '') end::varchar as DEFAULTDELIVERYTERMS
		from @PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*DIM_CUSTOMER_DEFAULTDELIVERYTERMS_FIX_HIST.*[.]txt'
			) t
		) a
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

truncate table edw_dwh.ORACLESALESCHANNEL_DEFAULTDIMENSION_FIX;
insert into edw_dwh.ORACLESALESCHANNEL_DEFAULTDIMENSION_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, axsaleschannel, axsaleschannelkey, defaultdimensionkey, description, datasource, dw_batch, dw_sourcecode, dw_timestamp)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.dw_id as DW_ID, a.axsaleschannel as AXSALESCHANNEL, a.axsaleschannelkey as AXSALESCHANNELKEY, a.defaultdimensionkey as DEFAULTDIMENSIONKEY, a.description as DESCRIPTION, a.datasource as DATASOURCE, a.dw_batch as DW_BATCH, a.dw_sourcecode as DW_SOURCECODE, a.dw_timestamp as DW_TIMESTAMP
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as DW_ID, case when nvl(t.$2, '') = '' then '' else (t.$2) end::varchar as AXSALESCHANNEL, case when nvl(t.$3, '') = '' then 0 else to_number(t.$3, 38, 0) end::number(38, 0) as AXSALESCHANNELKEY, case when nvl(t.$4, '') = '' then 0 else to_number(t.$4, 38, 0) end::number(38, 0) as DEFAULTDIMENSIONKEY, case when nvl(t.$5, '') = '' then '' else (t.$5) end::varchar as DESCRIPTION, case when nvl(t.$6, '') = '' then '' else (t.$6) end::varchar as DATASOURCE, case when nvl(t.$7, '') = '' then 0 else to_number(t.$7, 38, 0) end::number(38, 0) as DW_BATCH, case when nvl(t.$8, '') = '' then '' else (t.$8) end::varchar as DW_SOURCECODE, case when nvl(t.$9, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$9, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as DW_TIMESTAMP
		from @PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*ORACLE_SALES_CHANNEL_DEFAULTDIMENSION_FIX_HIST.*[.]txt'
			) t
		) a
;


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

truncate table edw_dwh.FACTSALESINVOICES_DEFAULTDIMENSION_FIX;
insert into edw_dwh.FACTSALESINVOICES_DEFAULTDIMENSION_FIX (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, recid, dataareaid, itemid, defaultdimension)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.recid as RECID, a.dataareaid as DATAAREAID, a.itemid as ITEMID, a.defaultdimension as DEFAULTDIMENSION
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as RECID, case when nvl(t.$2, '') = '' then '' else nvl(t.$2, '') end::varchar as DATAAREAID, case when nvl(t.$3, '') = '' then '' else nvl(t.$3, '') end::varchar as ITEMID, case when nvl(t.$4, '') = '' then '' else nvl(t.$4, '') end::varchar as DEFAULTDIMENSION
		from @PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'PROD_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*FACT_SALES_INVOICES_DEFAULTDIMENSION_FIX_HIST.*[.]txt'
			) t
		) a
;