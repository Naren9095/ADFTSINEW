--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:

-------------------------------------------------------------------------------------
-- Table(s)/View(s):	DIM_DEFAULT_DIMENSION
    -- new:				n/a
    -- updated:			<**************** ONLY RUN THIS AFTER A FULL RUN OF D365 SOURCE DATA ******************************>
    -- removed:			n/a

update global.DIM_DEFAULT_DIMENSION a
set a.hk_soft_delete_flag = true
from (select d1.dim_default_dimension_key
	from global.DIM_DEFAULT_DIMENSION d1
	left join PROD_raw.d365.DEFAULTDIMENSION d2 on
		d1.source_name = d2.hk_source_name and
		d1.default_dimension = to_char(d2.dimensionattributevalueset)
	where d1.dim_default_dimension_key not in (-1, -2)
	and d1.source_name = 'D365'
	and d1.hk_soft_delete_flag != true
	and d2.dimensionattributevalueset is null) b
where a.dim_default_dimension_key = b.dim_default_dimension_key
;