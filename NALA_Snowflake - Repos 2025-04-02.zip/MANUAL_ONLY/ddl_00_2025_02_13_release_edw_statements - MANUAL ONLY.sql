--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 36483:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- DimCustomer (for defaultdeliveryterms fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		('"LEGALENTITY"|' + '"CUSTOMERACCOUNT"|' + '"DEFAULTDELIVERYTERMS"'
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'DIMCUSTOMER') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18], [19]
		, [20], [21], [22], [23], [24], [25], [26], [27], [28], [29]
		, [30], [31], [32], [33], [34], [35], [36], [37], [38], [39]
		, [40], [41], [42], [43], [44], [45], [46], [47], [48], [49]
		, [50], [51], [52], [53], [54], [55], [56], [57], [58], [59]
		, [60], [61], [62], [63], [64], [65], [66], [67], [68], [69]
		, [70], [71], [72], [73], [74], [75], [76], [77], [78], [79]
		, [80], [81], [82], [83], [84], [85], [86], [87], [88], [89]
		, [90], [91], [92], [93], [94], [95], [96], [97], [98], [99]
		, [100], [101], [102], [103], [104]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(dc1.legalentity)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(dc1.customeraccount)), ''), '\', '\\'), '"', '\"') + '"|"'
 
 + replace(replace(isnull(ltrim(rtrim(dc1.defaultdeliveryterms)), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.DIMCUSTOMER dc1 with (nolock)
	where dc1.iscurrent = 1
) x
order by x.sql_order
;

-- =======================> name file:	DIM_CUSTOMER_DEFAULTDELIVERYTERMS_FIX_HIST_2025_02_13.txt
-- est. extract time:  < 1 minutes



--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- OracleSalesChannel (for defaultdimension fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		([1] + [2] + [3] + [4] + [5] + [6] + [7] + [8] + [9]
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from edw_hka.sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from edw_hka.sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'ORACLESALESCHANNEL') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(f1.dw_id as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.axsaleschannel)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(cast(f1.oraclesaleschannelkey as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(cast(f1.defaultdimensionkey as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.description)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.datasource)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(cast(DW_Batch as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(DW_SourceCode)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(convert(varchar, DW_TimeStamp, 120))), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from edw_hka.dbo.ORACLESALESCHANNEL f1 with (nolock)
	where isnull(f1.axsaleschannel, '') != ''
) x
order by x.sql_order
;

-- =======================> name file:	ORACLE_SALES_CHANNEL_DEFAULTDIMENSION_FIX_HIST_2025_02_13.txt
-- est. extract time:  < 1 second


--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 35983:


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- build an export from SQL Server Management Studio
-- each SQL is what you will use for your extract statement to get the data + header records

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- FactSalesInvoices (for defaultdimension fix)

select x.OUTPUT_ROW
from (
	-- Use the below SQL to build the SELECT "column header" extract in SQL Server Management Studio:
	select '1' as SQL_ORDER,
		('"RECID"|' + '"DATAAREAID"|' + '"ITEMID"|' + '"defaultdimension"'
			) as OUTPUT_ROW
	from (select ('"' + c.name + '"'
			+ case when c.column_id = c.max_column_id then ''
				else '|'
				end) as COLUMN_NAME
			, c.column_id
		from sys.tables t with (nolock)
		inner join (select object_id, column_id, name
						, max(column_id) over (partition by object_id) as MAX_COLUMN_ID
					from sys.all_columns with (nolock)) c on
			t.object_id = c.object_id
		where upper(t.name) = 'FACTSALESINVOICES') a
	pivot
	(max(a.column_name)
	for a.column_id in ([1], [2], [3], [4], [5], [6], [7], [8], [9]
		, [10], [11], [12], [13], [14], [15], [16], [17], [18], [19]
		, [20], [21], [22], [23], [24], [25], [26], [27], [28], [29]
		, [30], [31], [32], [33], [34], [35], [36], [37], [38], [39]
		, [40], [41], [42], [43], [44], [45], [46], [47], [48], [49]
		, [50], [51], [52], [53], [54], [55], [56], [57], [58], [59]
		, [60], [61], [62], [63], [64], [65], [66], [67], [68], [69]
		, [70], [71], [72], [73], [74], [75], [76], [77], [78], [79]
		, [80], [81], [82], [83], [84], [85], [86], [87], [88], [89]
		, [90], [91], [92], [93], [94], [95], [96], [97], [98], [99]
		, [100], [101], [102], [103], [104]
		)) as pt
union
	select --top (10)
		'2' as SQL_ORDER,
		('"' + replace(replace(isnull(ltrim(rtrim(cast(f1.recordid as varchar))), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(f1.legalentity)), ''), '\', '\\'), '"', '\"') + '"|"'
 + replace(replace(isnull(ltrim(rtrim(case when f1.itemkey in (-1, -2) then f2.axitem else dit1.itemid end)), ''), '\', '\\'), '"', '\"') + '"|"'
 
 + replace(replace(isnull(ltrim(rtrim(f2.axsaleschannel)), ''), '\', '\\'), '"', '\"') + '"'
		) as OUTPUT_ROW
	from dbo.FACTSALESINVOICES f1 with (nolock)
	inner join edw_hka.dbo.BOSALESINVOICE f2 with (nolock) on
		f1.recordid = f2.ar_trx_line_id and
		f1.datasource = f2.datasource
	left join dbo.DIMITEM dit1 with (nolock) on
		f1.itemkey = dit1.itemkey
	where isnull(f2.axsaleschannel, '') != ''
) x
order by x.sql_order
;

-- =======================> name file:	FACT_SALES_INVOICES_DEFAULTDIMENSION_FIX_HIST_2025_02_13.txt
-- est. extract time:  < 2 minutes