--------------------------------------------------------------------------------------------------------------------------------------------------------------
-- fix for BUG 30736:

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SalesRowLevelSecurity

truncate table edw_dwh.SALESROWLEVELSECURITY;
insert into edw_dwh.SALESROWLEVELSECURITY (hk_source_name, hk_job_run_id, hk_created_timestamp, hk_warehouse_id, dw_id, reportparentid, divisionid, regionid, customername, salesrepid, aduserid, dw_batch, dw_sourcecode, dw_timestamp)
	select a.hk_source_name as HK_SOURCE_NAME, a.hk_job_run_id as HK_JOB_RUN_ID, a.hk_created_timestamp as HK_CREATED_TIMESTAMP, a.hk_warehouse_id as HK_WAREHOUSE_ID, a.dw_id as DW_ID, a.reportparentid as REPORTPARENTID, a.divisionid as DIVISIONID, a.regionid as REGIONID, a.customername as CUSTOMERNAME, a.salesrepid as SALESREPID, a.aduserid as ADUSERID, a.dw_batch as DW_BATCH, a.dw_sourcecode as DW_SOURCECODE, a.dw_timestamp as DW_TIMESTAMP
	from (select 'EDW_DWH'::varchar as HK_SOURCE_NAME, '-1'::varchar as HK_JOB_RUN_ID, current_timestamp as HK_CREATED_TIMESTAMP, uuid_string()::varchar as HK_WAREHOUSE_ID, case when nvl(t.$1, '') = '' then 0 else to_number(t.$1, 38, 0) end::number(38, 0) as DW_ID, case when nvl(t.$2, '') = '' then '' else (t.$2) end::varchar as REPORTPARENTID, case when nvl(t.$3, '') = '' then '' else (t.$3) end::varchar as DIVISIONID, case when nvl(t.$4, '') = '' then '' else (t.$4) end::varchar as REGIONID, case when nvl(t.$5, '') = '' then '' else (t.$5) end::varchar as CUSTOMERNAME, case when nvl(t.$6, '') = '' then '' else (t.$6) end::varchar as SALESREPID, case when nvl(t.$7, '') = '' then '' else (t.$7) end::varchar as ADUSERID, case when nvl(t.$8, '') = '' then 0 else to_number(t.$8, 38, 0) end::number(38, 0) as DW_BATCH, case when nvl(t.$9, '') = '' then '' else (t.$9) end::varchar as DW_SOURCECODE, case when nvl(t.$10, '') = '' then '1950-01-01 00:00:00' else to_timestamp(t.$10, 'yyyy-mm-dd hh24:mi:ss') end::timestamp_tz as DW_TIMESTAMP
		from @prod_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_STAGE
			(file_format => 'prod_raw.edw_dwh.PROD_EDW_HISTORY_SOURCE_CSV_FF'
			, pattern=>'.*RLS_SALES_HIST.*[.]txt'
			) t
		) a
;